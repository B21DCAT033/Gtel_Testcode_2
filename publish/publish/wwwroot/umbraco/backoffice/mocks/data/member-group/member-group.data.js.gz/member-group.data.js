export const data = [
    {
        name: 'Member Group 1',
        id: 'member-group-1-id',
    },
    {
        name: 'Member Group 2',
        id: 'member-group-2-id',
    },
];
