export const UMB_SLUG = '/dictionary';
