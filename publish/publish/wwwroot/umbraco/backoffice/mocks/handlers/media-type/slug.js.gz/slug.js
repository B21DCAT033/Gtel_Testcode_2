export const UMB_SLUG = '/media-type';
