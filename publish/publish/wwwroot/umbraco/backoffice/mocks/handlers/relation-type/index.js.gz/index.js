import { detailHandlers } from './detail.handlers.js';
export const handlers = [...detailHandlers];
