export const UMB_SLUG = '/relation-type';
