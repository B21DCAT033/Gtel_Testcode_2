import { itemHandlers } from './item.handlers.js';
export const handlers = [...itemHandlers];
