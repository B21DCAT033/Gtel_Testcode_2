export const UMB_SLUG = '/static-file';
