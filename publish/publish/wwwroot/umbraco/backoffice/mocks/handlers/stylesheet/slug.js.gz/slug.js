export const UMB_SLUG = '/stylesheet';
