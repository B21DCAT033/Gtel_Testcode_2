export const UMB_SLUG = '/user-group';
