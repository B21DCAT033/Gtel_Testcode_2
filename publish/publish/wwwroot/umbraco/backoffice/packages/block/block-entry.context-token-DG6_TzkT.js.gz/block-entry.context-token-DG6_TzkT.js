import { UmbContextToken as o } from "@umbraco-cms/backoffice/context-api";
const n = new o("UmbBlockEntryContext");
export {
  n as U
};
//# sourceMappingURL=block-entry.context-token-DG6_TzkT.js.map
