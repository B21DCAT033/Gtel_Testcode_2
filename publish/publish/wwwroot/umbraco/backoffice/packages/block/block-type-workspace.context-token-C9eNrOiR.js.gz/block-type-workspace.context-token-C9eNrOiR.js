import { UmbContextToken as C } from "@umbraco-cms/backoffice/context-api";
const t = new C(
  "UmbWorkspaceContext",
  void 0,
  (o) => o.IS_BLOCK_TYPE_WORKSPACE_CONTEXT
);
export {
  t as U
};
//# sourceMappingURL=block-type-workspace.context-token-C9eNrOiR.js.map
