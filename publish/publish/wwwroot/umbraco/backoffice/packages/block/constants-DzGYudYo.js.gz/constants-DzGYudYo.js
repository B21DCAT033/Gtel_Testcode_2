import "./index-BbCqfSen.js";
const o = "block-list-type", s = "block-list";
export {
  o as U,
  s as a
};
//# sourceMappingURL=constants-DzGYudYo.js.map
