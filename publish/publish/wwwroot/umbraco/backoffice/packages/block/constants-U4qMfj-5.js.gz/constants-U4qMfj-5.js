import "./index-Cc47Hgez.js";
const o = "/umbraco/backoffice/css/umbraco-blockgridlayout.css";
export {
  o as U
};
//# sourceMappingURL=constants-U4qMfj-5.js.map
