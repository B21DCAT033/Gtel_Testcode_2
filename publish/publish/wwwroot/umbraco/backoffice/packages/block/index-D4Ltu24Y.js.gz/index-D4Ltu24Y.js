import { UmbModalToken as a } from "@umbraco-cms/backoffice/modal";
const e = "block-rte-type", t = "block-rte", _ = "Umbraco.RichText", s = new a(
  "Umb.Modal.Workspace",
  {
    modal: {
      type: "sidebar",
      size: "medium"
    },
    data: { entityType: "block", preset: {}, originData: {}, baseDataPath: void 0 }
  }
  // Recast the type, so the entityType data prop is not required:
), c = "Umb.Workspace.BlockRteType";
export {
  t as U,
  s as a,
  e as b,
  _ as c,
  c as d
};
//# sourceMappingURL=index-D4Ltu24Y.js.map
