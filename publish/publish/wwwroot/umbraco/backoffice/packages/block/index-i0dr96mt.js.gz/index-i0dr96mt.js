import "./block-workspace.modal-token-N1xnaaIe.js";
const c = "Umb.Workspace.Block";
export {
  c as U
};
//# sourceMappingURL=index-i0dr96mt.js.map
