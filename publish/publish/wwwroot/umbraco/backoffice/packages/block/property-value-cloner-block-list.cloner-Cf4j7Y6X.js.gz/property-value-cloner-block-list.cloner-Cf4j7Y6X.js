import { U as r } from "./index-BbCqfSen.js";
import { UmbFlatLayoutBlockPropertyValueCloner as t } from "@umbraco-cms/backoffice/block";
class s extends t {
  constructor(o) {
    super(r, o);
  }
}
export {
  s as UmbBlockListPropertyValueCloner,
  s as api
};
//# sourceMappingURL=property-value-cloner-block-list.cloner-Cf4j7Y6X.js.map
