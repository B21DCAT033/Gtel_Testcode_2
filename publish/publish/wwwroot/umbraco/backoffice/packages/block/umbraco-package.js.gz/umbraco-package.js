const e = "Umbraco.Core.DocumentManagement", n = [
  {
    name: "Block Management Bundle",
    alias: "Umb.Bundle.BlockManagement",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  n as extensions,
  e as name
};
//# sourceMappingURL=umbraco-package.js.map
