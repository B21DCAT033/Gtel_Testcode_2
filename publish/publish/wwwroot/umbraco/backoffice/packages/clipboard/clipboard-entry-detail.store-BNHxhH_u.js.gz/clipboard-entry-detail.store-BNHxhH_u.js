import { g as r } from "./entity-B4DsEs7O.js";
import { UmbDetailStoreBase as o } from "@umbraco-cms/backoffice/store";
class i extends o {
  /**
   * Creates an instance of UmbClipboardEntryDetailStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbClipboardEntryDetailStore
   */
  constructor(t) {
    super(t, r.toString());
  }
}
export {
  i as UmbClipboardEntryDetailStore,
  i as default
};
//# sourceMappingURL=clipboard-entry-detail.store-BNHxhH_u.js.map
