import { i as t } from "./entity-B4DsEs7O.js";
import { UmbItemStoreBase as o } from "@umbraco-cms/backoffice/store";
class a extends o {
  /**
   * Creates an instance of UmbClipboardEntryItemStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbClipboardEntryItemStore
   */
  constructor(r) {
    super(r, t.toString());
  }
}
export {
  a as UmbClipboardEntryItemStore,
  a as api
};
//# sourceMappingURL=clipboard-entry-item.store-SoeZGmFP.js.map
