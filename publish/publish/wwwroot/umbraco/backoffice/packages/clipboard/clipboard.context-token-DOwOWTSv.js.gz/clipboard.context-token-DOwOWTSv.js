import { UmbContextToken as o } from "@umbraco-cms/backoffice/context-api";
const e = new o("UmbClipboardContext");
export {
  e as U
};
//# sourceMappingURL=clipboard.context-token-DOwOWTSv.js.map
