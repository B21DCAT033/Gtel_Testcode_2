import { UmbContextToken as o } from "@umbraco-cms/backoffice/context-api";
const e = new o(
  "UmbPropertyContext",
  "UmbClipboardPropertyContext"
);
export {
  e as U
};
//# sourceMappingURL=clipboard.property-context-token-DMlYzAUk.js.map
