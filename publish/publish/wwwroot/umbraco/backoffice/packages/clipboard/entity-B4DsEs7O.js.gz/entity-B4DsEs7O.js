import { UmbContextToken as _ } from "@umbraco-cms/backoffice/context-api";
const t = "Umb.Repository.ClipboardCollection", E = "Umb.CollectionView.Clipboard.Table", I = "Umb.Collection.Clipboard", R = "Umb.Modal.ClipboardEntryPicker", T = "clipboard-entry", C = new _(
  "UmbClipboardEntryDetailStore"
), A = "Umb.Repository.ClipboardEntry.Detail", O = "Umb.Store.ClipboardEntry.Detail", r = new _(
  "UmbClipboardEntryItemStore"
), a = "Umb.Repository.ClipboardEntryItem", L = "Umb.Store.ClipboardEntryItem", s = "Umb.Workspace.ClipboardRoot", n = "clipboard-root";
export {
  A as U,
  a,
  T as b,
  s as c,
  n as d,
  I as e,
  O as f,
  C as g,
  L as h,
  r as i,
  R as j,
  t as k,
  E as l
};
//# sourceMappingURL=entity-B4DsEs7O.js.map
