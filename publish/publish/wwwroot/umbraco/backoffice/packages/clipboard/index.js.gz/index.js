import { U as o } from "./clipboard-entry-picker-modal.token-BWZEakh-.js";
import { UmbClipboardEntryDetailRepository as T } from "./clipboard-entry-detail.repository-1VkIBpID.js";
import { UmbClipboardEntryDetailStore as I } from "./clipboard-entry-detail.store-BNHxhH_u.js";
import { e as a, k as A, U as C, f as L, g as B, b as e, a as t, h as P, i as U, j as s, d as p, c as D, l } from "./entity-B4DsEs7O.js";
import { UmbClipboardEntryItemRepository as m } from "./clipboard-entry-item.repository-BLSut6DQ.js";
import { UmbClipboardCollectionRepository as S } from "./clipboard-collection.repository-Dll4uWAf.js";
import { U as Y } from "./clipboard.property-context-token-DMlYzAUk.js";
import { U as x } from "./clipboard.context-token-DOwOWTSv.js";
import { UmbClipboardContext as d, UmbClipboardContext as y } from "./clipboard.context-DPuzpKeP.js";
import { U as V, a as u } from "./clipboard-paste-translator-value-resolver-COIXfV23.js";
export {
  a as UMB_CLIPBOARD_COLLECTION_ALIAS,
  A as UMB_CLIPBOARD_COLLECTION_REPOSITORY_ALIAS,
  x as UMB_CLIPBOARD_CONTEXT,
  C as UMB_CLIPBOARD_ENTRY_DETAIL_REPOSITORY_ALIAS,
  L as UMB_CLIPBOARD_ENTRY_DETAIL_STORE_ALIAS,
  B as UMB_CLIPBOARD_ENTRY_DETAIL_STORE_CONTEXT,
  e as UMB_CLIPBOARD_ENTRY_ENTITY_TYPE,
  t as UMB_CLIPBOARD_ENTRY_ITEM_REPOSITORY_ALIAS,
  P as UMB_CLIPBOARD_ENTRY_ITEM_STORE_ALIAS,
  U as UMB_CLIPBOARD_ENTRY_ITEM_STORE_CONTEXT,
  o as UMB_CLIPBOARD_ENTRY_PICKER_MODAL,
  s as UMB_CLIPBOARD_ENTRY_PICKER_MODAL_ALIAS,
  Y as UMB_CLIPBOARD_PROPERTY_CONTEXT,
  p as UMB_CLIPBOARD_ROOT_ENTITY_TYPE,
  D as UMB_CLIPBOARD_ROOT_WORKSPACE_ALIAS,
  l as UMB_CLIPBOARD_TABLE_COLLECTION_VIEW_ALIAS,
  S as UmbClipboardCollectionRepository,
  d as UmbClipboardContext,
  V as UmbClipboardCopyPropertyValueTranslatorValueResolver,
  T as UmbClipboardEntryDetailRepository,
  I as UmbClipboardEntryDetailStore,
  m as UmbClipboardEntryItemRepository,
  u as UmbClipboardPastePropertyValueTranslatorValueResolver,
  y as api
};
//# sourceMappingURL=index.js.map
