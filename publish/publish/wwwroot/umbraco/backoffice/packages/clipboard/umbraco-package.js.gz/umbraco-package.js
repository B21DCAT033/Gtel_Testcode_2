const e = "Umbraco.Clipboard", n = [
  {
    name: "Clipboard Bundle",
    alias: "Umb.Bundle.Clipboard",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  n as extensions,
  e as name
};
//# sourceMappingURL=umbraco-package.js.map
