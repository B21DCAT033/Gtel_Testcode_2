const e = [
  {
    name: "Umbraco Code Editor Bundle",
    alias: "Umb.Bundle.UmbracoCodeEditor",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  e as extensions
};
//# sourceMappingURL=umbraco-package.js.map
