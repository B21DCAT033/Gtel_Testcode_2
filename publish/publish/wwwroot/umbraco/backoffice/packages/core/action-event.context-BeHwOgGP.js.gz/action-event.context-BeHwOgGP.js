import { UmbContextBase as o } from "@umbraco-cms/backoffice/class-api";
import { UmbContextToken as e } from "@umbraco-cms/backoffice/context-api";
class c extends o {
  constructor(t) {
    super(t, n);
  }
}
const n = new e(
  "UmbActionEventContext"
);
export {
  c as U,
  n as a
};
//# sourceMappingURL=action-event.context-BeHwOgGP.js.map
