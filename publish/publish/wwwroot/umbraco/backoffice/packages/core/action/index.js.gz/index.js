import { a as c, U } from "../action-event.context-BeHwOgGP.js";
import { UmbControllerBase as r } from "@umbraco-cms/backoffice/class-api";
class a extends r {
  constructor(t, o) {
    super(t), this.args = o;
  }
}
export {
  c as UMB_ACTION_EVENT_CONTEXT,
  a as UmbActionBase,
  U as UmbActionEventContext
};
//# sourceMappingURL=index.js.map
