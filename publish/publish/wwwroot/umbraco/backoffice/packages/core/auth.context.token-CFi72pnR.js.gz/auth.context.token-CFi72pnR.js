import { UmbContextToken as t } from "@umbraco-cms/backoffice/context-api";
const e = new t("UmbAuthContext");
export {
  e as U
};
//# sourceMappingURL=auth.context.token-CFi72pnR.js.map
