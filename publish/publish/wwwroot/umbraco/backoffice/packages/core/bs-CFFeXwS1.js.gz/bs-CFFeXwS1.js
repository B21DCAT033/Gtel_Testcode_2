const e = {
  actions: {
    assigndomain: "Kultura i imena hostova",
    auditTrail: "Revizije",
    browse: "Pregledaj čvor",
    changeDocType: "Promijeni Tip Dokumenta",
    copy: "Kopiraj",
    create: "Kreiraj",
    export: "Izvezi",
    createPackage: "Kreiraj Paket",
    createGroup: "Kreiraj grupu",
    delete: "Obriši",
    disable: "Onemogući",
    editSettings: "Uredi postavke",
    emptyrecyclebin: "Isprazni kantu za smeće",
    enable: "Omogući",
    exportDocumentType: "Izvezi Tip Dokumenta",
    importdocumenttype: "Uvezi Tip Dokumenta",
    importPackage: "Uvezi Paket",
    liveEdit: "Uredi u Platnu",
    logout: "Izađi",
    move: "Pomakni",
    notify: "Obavještenja",
    protect: "Ograničite javni pristup",
    publish: "Objavi",
    unpublish: "Poništi objavu",
    refreshNode: "Ponovo učitaj",
    republish: "Ponovo objavite cijelu stranicu",
    remove: "Ukloni",
    rename: "Preimenuj",
    restore: "Vrati",
    chooseWhereToCopy: "Odaberite gdje ćete kopirati",
    chooseWhereToMove: "Odaberite gdje ćete pomaknuti",
    chooseWhereToImport: "Odaberite gdje ćete uvesti",
    toInTheTreeStructureBelow: "do u strukturi stabla ispod",
    infiniteEditorChooseWhereToCopy: "Odaberite gdje želite kopirati odabrane stavke",
    infiniteEditorChooseWhereToMove: "Odaberite gdje želite pomaknuti odabrane stavke",
    wasMovedTo: "je pomaknuta u",
    wasCopiedTo: "je kopirana u",
    wasDeleted: "je obrisana",
    rights: "Dozvole",
    rollback: "Vraćanje unazad",
    sendtopublish: "Pošalji na objavljivanje",
    sendToTranslate: "Pošalji na prijevod",
    setGroup: "Postavi grupu",
    sort: "Sortiraj",
    translate: "Prevedi",
    update: "Ažuriraj",
    setPermissions: "Postavi dozvole",
    unlock: "Otključaj",
    createblueprint: "Kreirajte Predložak Sadržaja",
    resendInvite: "Ponovo pošaljite pozivnicu"
  },
  actionCategories: {
    content: "Sadržaj",
    administration: "Administracija",
    structure: "Struktura",
    other: "Ostalo"
  },
  actionDescriptions: {
    assignDomain: "Dozvolite pristup za dodjelu kulture i imena hostova",
    auditTrail: "Dozvolite pristup za pregled dnevnika historije čvora",
    browse: "Dozvolite pristup za pregled čvora",
    changeDocType: "Dozvolite pristup za promjenu Tipa Dokumenta za čvor",
    copy: "Dozvolite pristup za kopiranje čvora",
    create: "Dozvolite pristup za kreiranje čvora",
    delete: "Dozvolite pristup za brisanje čvora",
    move: "Dozvolite pristup za pomicanje čvora",
    protect: "Dozvolite pristup za postavljanje i promjenu ograničenja pristupa za čvor",
    publish: "Dozvolite pristup za objavljivanje čvora",
    unpublish: "Dozvolite pristup da poništavanje objave čvora",
    rights: "Dozvolite pristup za promjenu dozvola za čvor",
    rollback: "Dozvolite pristup za vraćanje čvora u prethodno stanje",
    sendtopublish: "Dozvolite pristup za slanje čvora na odobrenje prije objavljivanja",
    sendToTranslate: "Dozvolite pristup za slanje čvora na prijevod",
    sort: "Dozvolite pristup za promjenu sortiranja čvorova",
    translate: "Dozvolite pristup za prevođenje čvora",
    update: "Dozvolite pristup za spremanje čvora",
    createblueprint: "Dozvolite pristup za kreiranje Predloška Sadržaja",
    notify: "Dozvolite pristup za podešavanje obaviještenja za čvorove"
  },
  apps: {
    umbContent: "Sadržaj",
    umbInfo: "Info"
  },
  assignDomain: {
    permissionDenied: "Dozvola odbijena.",
    addNew: "Dodaj novu domenu",
    addCurrent: "Dodaj postojeću domenu",
    remove: "ukloni",
    invalidNode: "Nevažeći čvor.",
    invalidDomain: "Jedna ili više domena imaju nevažeći format.",
    duplicateDomain: "Domena je već dodijeljena.",
    language: "Jezik",
    domain: "Domena",
    domainCreated: "Nova domena '%0%' je kreirana",
    domainDeleted: "Domena '%0%' je obrisana",
    domainExists: "Domena '%0%' je već dodijeljena",
    domainUpdated: "Domena '%0%' je ažurirana",
    orEdit: "Uredi trenutne domene",
    domainHelpWithVariants: `Važeći nazivi domena su: "example.com", "www.example.com", "example.com:8080", ili "https://www.example.com/".
     Nadalje, podržane su i poddomene prvog nivoa, npr. "example.com/en" ili "/en".`,
    inherit: "Naslijedi",
    setLanguage: "Kultura",
    setLanguageHelp: `Postavite kulturu za čvorove ispod trenutnog čvora,<br /> ili naslijedite kulturu od roditeljskih čvorova. Također će se primijeniti<br />
      na trenutni čvor, osim ako se domena u nastavku ne primjenjuje.`,
    setDomains: "Domene"
  },
  buttons: {
    clearSelection: "Obriši odabir",
    select: "Odaberi",
    somethingElse: "Uradi nešto drugo",
    bold: "Boldiraj",
    deindent: "Otkaži uvlačenje pasusa",
    formFieldInsert: "Umetni polje obrasca",
    graphicHeadline: "Umetnite grafički naslov",
    htmlEdit: "Uredi Html",
    indent: "Uvuci pasus",
    italic: "Kurziv",
    justifyCenter: "Centriraj",
    justifyLeft: "Poravnaj lijevo",
    justifyRight: "Poravnaj desno",
    linkInsert: "Umetni link",
    linkLocal: "Umetni lokalni link (sidro)",
    listBullet: "Lista",
    listNumeric: "Numerička lista",
    macroInsert: "Umetni makro",
    pictureInsert: "Umetni sliku",
    publishAndClose: "Objavi i zatvori",
    publishDescendants: "Objavi sa potomcima",
    relations: "Uredite odnose",
    returnToList: "Povratak na listu",
    save: "Spremi",
    saveAndClose: "Spremi i zatvori",
    saveAndPublish: "Spremi i objavi",
    saveToPublish: "Spremi i pošalji na odobrenje",
    saveListView: "Spremi prikaz liste",
    schedulePublish: "Zakaži",
    saveAndPreview: "Spremi i pregledaj",
    showPageDisabled: "Pregled je onemogućen jer nije dodijeljen predložak",
    styleChoose: "Odaberi stil",
    styleShow: "Prikaži stilove",
    tableInsert: "Umetni tabelu",
    saveAndGenerateModels: "Spremi i generiši modele",
    undo: "Poništi",
    redo: "Ponovi",
    deleteTag: "Obriši tag",
    confirmActionCancel: "Otkaži",
    confirmActionConfirm: "Potvrdi",
    morePublishingOptions: "Više opcija za objavljivanje",
    submitChanges: "Pošalji"
  },
  auditTrailsMedia: {
    delete: "Mediji je izbrisan",
    move: "Mediji premješten",
    copy: "Mediji kopiran",
    save: "Mediji spremljen"
  },
  auditTrails: {
    atViewingFor: "Pregled za",
    delete: "Sadržaj je izbrisan",
    unpublish: "Sadržaj nije objavljen",
    publish: "Sadržaj spremljen i objavljen",
    publishvariant: "Sadržaj spremljen i objavljen za jezike: %0%",
    save: "Sadržaj spremljen",
    savevariant: "Sadržaj spremljen za jezike: %0%",
    move: "Sadržaj premješten",
    copy: "Sadržaj kopiran",
    rollback: "Sadržaj vraćen",
    sendtopublish: "Sadržaj poslan na objavljivanje",
    sendtopublishvariant: "Sadržaj poslan na objavljivanje za jezike: %0%",
    sort: "Sortiranje podređenih stavki je izvršio korisnik",
    custom: "%0%",
    contentversionpreventcleanup: "Čišćenje je onemogućeno za verziju: %0%",
    contentversionenablecleanup: "Čišćenje je omogućeno za verziju: %0%",
    smallCopy: "Kopiraj",
    smallPublish: "Objavljeno",
    smallPublishVariant: "Objavi",
    smallMove: "Pomakni",
    smallSave: "Spremljeno",
    smallSaveVariant: "Spremi",
    smallDelete: "Obriši",
    smallUnpublish: "Poništi objavu",
    smallRollBack: "Vrat",
    smallSendToPublish: "Pošalji na objavljivanje",
    smallSendToPublishVariant: "Pošalji na objavljivanje",
    smallSort: "Sortiraj",
    smallCustom: "Prilagođeno",
    smallContentVersionPreventCleanup: "Spremi",
    smallContentVersionEnableCleanup: "Spremi",
    historyIncludingVariants: "Historija (sve varijante)"
  },
  codefile: {
    createFolderIllegalChars: "Naziv mape ne može sadržavati nedozvoljene znakove.",
    deleteItemFailed: "Nije uspjelo brisanje stavke: %0%"
  },
  content: {
    isPublished: "Da li je objavljeno",
    about: "O ovoj stranici",
    alias: "Alias",
    alternativeTextHelp: "(kako biste opisali sliku preko telefona)",
    alternativeUrls: "Alternativni linkovi",
    clickToEdit: "Kliknite da uredite ovu stavku",
    createBy: "Kreirao",
    createByDesc: "Originalni autor",
    updatedBy: "Ažurirao",
    createDate: "Kreirano",
    createDateDesc: "Datum i vrijeme kreiranja ovog dokumenta",
    documentType: "Tip dokumenta",
    editing: "Uređivanje",
    expireDate: "Ukloni na",
    itemChanged: "Ova stavka je promijenjena nakon objavljivanja",
    itemNotPublished: "Ova stavka nije objavljena",
    lastPublished: "Posljednje objavljeno",
    noItemsToShow: "Nema stavki za prikaz",
    listViewNoItems: "Nema stavki za prikaz na listi.",
    listViewNoContent: "Nije dodan sadržaj",
    listViewNoMembers: "Nijedan član nije dodan",
    mediatype: "Tip medija",
    mediaLinks: "Link do medijske stavke",
    membergroup: "Grupa članova",
    memberrole: "Uloga",
    membertype: "Tip člana",
    noChanges: "Nisu napravljene nikakve promjene",
    noDate: "Nije odabran datum",
    nodeName: "Naslov stranice",
    noMediaLink: "Ova medijska stavka nema vezu",
    otherElements: "Svojstva",
    parentNotPublished: "Ovaj dokument je objavljen, ali nije vidljiv jer nadređeni '%0%' nije objavljen",
    parentCultureNotPublished: "Ova kultura je objavljena, ali nije vidljiva jer nije objavljena na nadređenom '%0%'",
    parentNotPublishedAnomaly: "Ovaj dokument je objavljen, ali nije u kešu",
    getUrlException: "Nije moguće dobiti URL",
    routeError: "Ovaj dokument je objavljen, ali njegov URL je u koliziji sa sadržajem %0%",
    routeErrorCannotRoute: "Ovaj dokument je objavljen, ali njegov URL se ne može preusmjeriti",
    publish: "Objavi",
    published: "Objavljeno",
    publishedPendingChanges: "Objavljeno (čeka izmjene)",
    publishStatus: "Status publikacije",
    publishDescendantsHelp: "Objavi <strong>%0%</strong> i sve stavke sadržaja ispod i time čineći njihov sadržaj javno dostupnim.",
    publishDescendantsWithVariantsHelp: "Objavi varijante i varijante istog tipa ispod i na taj način učinite njihov sadržaj javno dostupnim.",
    releaseDate: "Objavi na",
    unpublishDate: "Poništi objavu na",
    removeDate: "Obriši datum",
    setDate: "Postavi datum",
    sortDone: "Sortiranje je ažurirano",
    sortHelp: `Da biste sortirali čvorove, jednostavno prevucite čvorove ili kliknite na jedno od zaglavlja kolona. Možete odabrati
       više čvorova držeći tipku "shift" ili "control" dok birate
    `,
    statistics: "Statistika",
    titleOptional: "Naslov (opcionalno)",
    altTextOptional: "Alternativni tekst (opcionalno)",
    captionTextOptional: "Natpis (opcionalno)",
    type: "Tip",
    unpublish: "Poništi objavu",
    unpublished: "Neobjavljeno",
    notCreated: "Nije kreirano",
    updateDate: "Poslednji put uređeno",
    updateDateDesc: "Datum/vrijeme uređivanja ovog dokumenta",
    uploadClear: "Ukloni fajlove",
    uploadClearImageContext: "Kliknite ovdje da uklonite sliku iz medijske stavke",
    uploadClearFileContext: "Kliknite ovdje da uklonite fajl iz medijske stavke",
    urls: "Link do dokumenta",
    memberof: "Član grupe",
    notmemberof: "Nije član grupe",
    childItems: "Dječiji artikli",
    target: "Meta",
    scheduledPublishServerTime: "Ovo se prevodi kao sljedeće vrijeme na serveru:",
    scheduledPublishDocumentation: '<a href="https://docs.umbraco.com/umbraco-cms/fundamentals/data/scheduled-publishing#timezones" target="_blank" rel="noopener">Šta ovo znači?</a>',
    nestedContentDeleteItem: "Jeste li sigurni da želite izbrisati ovu stavku?",
    nestedContentEditorNotSupported: `Svojstvo %0% koristi uređivač %1% koji nije podržan za Ugniježđeni
      Sadržaj.
    `,
    nestedContentDeleteAllItems: "Jeste li sigurni da želite izbrisati sve stavke?",
    nestedContentNoContentTypes: "Za ovo svojstvo nisu konfigurirani tipovi sadržaja.",
    nestedContentAddElementType: "Dodajte tip elementa",
    nestedContentSelectElementTypeModalTitle: "Odaberi tip elementa",
    nestedContentGroupHelpText: `Odaberite grupu čija svojstva trebaju biti prikazana. Ako je ostavljeno prazno,
       koristit će se prva grupa na tipu elementa.
    `,
    nestedContentTemplateHelpTextPart1: `Unesite angular izraz za procjenu svake stavke za njeno
       ime. Koristi
    `,
    nestedContentTemplateHelpTextPart2: "za prikaz indeksa stavke",
    nestedContentNoGroups: "Odabrani tip elementa ne sadrži nijednu podržanu grupu (ovaj uređivač ne podržava kartice, promijenite ih u grupe ili koristite uređivač liste blokova).",
    addTextBox: "Dodajte još jedan okvir za tekst",
    removeTextBox: "Uklonite ovaj okvir za tekst",
    contentRoot: "Korijen Sadržaja",
    includeUnpublished: "Uključite neobjavljeni sadržaj.",
    isSensitiveValue: `Ova vrijednost je skrivena. Ako vam je potreban pristup da vidite ovu vrijednost, obratite se
       administratoru web stranice.
    `,
    isSensitiveValue_short: "Ova vrijednost je skrivena.",
    languagesToPublish: "Koje jezike želite da objavite?",
    languagesToSendForApproval: "Koje jezike želite poslati na odobrenje?",
    languagesToSchedule: "Koje jezike želite da zakažete?",
    languagesToUnpublish: `Odaberite jezike za poništavanje objavljivanja. Poništavanje objavljivanja obaveznog jezika će
       poništiti objavljivanje svih jezika.
    `,
    variantsWillBeSaved: "Sve nove varijante će biti sačuvane.",
    variantsToPublish: "Koje varijante želite da objavite?",
    variantsToSave: "Odaberite koje varijante želite sačuvati.",
    publishRequiresVariants: "Za objavljivanje su potrebne sljedeće varijante:",
    notReadyToPublish: "Nismo spremni za objavljivanje",
    readyToPublish: "Spremno za objavljivanje?",
    readyToSave: "Spremno za spremanje?",
    resetFocalPoint: "Resetuj fokusnu tačku",
    sendForApproval: "Pošalji na odobrenje",
    schedulePublishHelp: "Odaberite datum i vrijeme za objavljivanje i/ili poništavanje objave stavke sadržaja.",
    createEmpty: "Napravi novi",
    createFromClipboard: "Zalijepi iz međuspremnika",
    nodeIsInTrash: "Ova stavka je u korpi za otpatke",
    saveModalTitle: "Spremi"
  },
  blueprints: {
    createBlueprintFrom: "Kreirajte novi predložak sadržaja iz <em>%0%</em>",
    blankBlueprint: "Prazno",
    selectBlueprint: "Odaberite predložak sadržaja",
    createdBlueprintHeading: "Predložak sadržaja kreiran",
    createdBlueprintMessage: "Predložak sadržaja je kreiran od '%0%'",
    duplicateBlueprintMessage: "Drugi predložak sadržaja sa istim imenom već postoji",
    blueprintDescription: `Predložak sadržaja je unaprijed definiran sadržaj koji uređivač može odabrati da koristi
       kao osnovu za kreiranje novog sadržaja
    `
  },
  media: {
    clickToUpload: "Kliknite za učitavanje",
    orClickHereToUpload: "ili kliknite ovdje da odaberete fajlove",
    disallowedFileType: "Nije moguće učitati ovu datoteku, ona nema odobreni tip datoteke",
    disallowedMediaType: "Nije moguće učitati ovu datoteku, tip medija sa pseudonimom '%0%' nije dozvoljen ovdje",
    invalidFileName: "Nije moguće učitati ovu datoteku, ona nema važeći naziv datoteke",
    maxFileSize: "Maksimalna veličina datoteke je",
    mediaRoot: "Korijen medija",
    createFolderFailed: "Kreiranje foldera pod ID-om roditelja nije uspjelo %0%",
    renameFolderFailed: "Preimenovanje foldera sa ID-om %0% nije uspjelo",
    dragAndDropYourFilesIntoTheArea: "Prevucite i ispustite svoje datoteke u područje"
  },
  member: {
    createNewMember: "Kreirajte novog člana",
    allMembers: "Svi članovi",
    memberGroupNoProperties: "Grupe članova nemaju dodatna svojstva za uređivanje.",
    "2fa": "Dvostruka provjera autentičnosti"
  },
  contentType: {
    copyFailed: "Kopiranje tipa sadržaja nije uspjelo",
    moveFailed: "Premještanje tipa sadržaja nije uspjelo"
  },
  mediaType: {
    copyFailed: "Kopiranje tipa medija nije uspjelo",
    moveFailed: "Premještanje tipa medija nije uspjelo",
    autoPickMediaType: "Automatski odabir"
  },
  memberType: {
    copyFailed: "Kopiranje tipa člana nije uspjelo"
  },
  create: {
    chooseNode: "Gdje želite kreirati novi %0%",
    createUnder: "Kreirajte stavku pod",
    createContentBlueprint: "Odaberite vrstu dokumenta za koju želite da napravite predložak sadržaja",
    enterFolderName: "Unesite naziv foldera",
    updateData: "Odaberite vrstu i naslov",
    noDocumentTypes: "Nema dozvoljenih tipova dokumenata dostupnih za kreiranje sadržaja ovdje. Morate ih omogućiti u <strong>Dokument Tip</strong> unutar sekcije <strong>Postavke</strong>, uređivanjem <strong>Dozvoljeni tipovi podređenih čvorova</strong> unutar <strong>Dozvole</strong>.",
    noDocumentTypesAtRoot: "Nema dozvoljenih tipova dokumenata dostupnih za kreiranje sadržaja ovdje. Morate ih kreirati u <strong>Dokument Tip</strong> unutar sekcije <strong>Postavke</strong>.",
    noDocumentTypesWithNoSettingsAccess: `Odabrana stranica u stablu sadržaja ne dozvoljava nijednu stranicu
       biti kreiran ispod njega.
    `,
    noDocumentTypesEditPermissions: "Uredi dozvole za ovaj tip dokumenta",
    noDocumentTypesCreateNew: "Kreiraj novi tip dokumenta",
    noDocumentTypesAllowedAtRoot: "Nema dozvoljenih tipova dokumenata dostupnih za kreiranje sadržaja ovdje. Morate ih omogućiti u <strong>Dokument Tip</strong> unutar sekcije <strong>Postavke</strong>, izmjenom <strong>Dozvoli kao root</strong> opcije unutar <strong>Dozvole</strong>.",
    noMediaTypes: "Nema dozvoljenih tipova medija dostupnih za kreiranje medija ovdje. Morate ih omogućiti u <strong>Media Tip</strong> unutar sekcije <strong>Postavke</strong>, uređivanjem <strong>Dozvoljeni tipovi podređenih čvorova</strong> unutar <strong>Dozvole</strong>.",
    noMediaTypesWithNoSettingsAccess: `Odabrani medij u stablu ne dopušta bilo koji drugi medij
       kreiran ispod njega.
    `,
    noMediaTypesEditPermissions: "Uredi dozvole za ovaj tip medija",
    documentTypeWithoutTemplate: "Tip dokumenta bez predloška",
    documentTypeWithTemplate: "Tip dokumenta sa predloškom",
    documentTypeWithTemplateDescription: `Definicija podataka za stranicu sadržaja koja se može kreirati
       uređivača u stablu sadržaja i direktno je dostupan preko URL-a.
    `,
    documentType: "Tip dokumenta",
    documentTypeDescription: `Definicija podataka za komponentu sadržaja koju mogu kreirati urednici u
       stablo sadržaja i biti izabran na drugim stranicama, ali nema direktan URL.
    `,
    elementType: "Tip elementa",
    elementTypeDescription: `Definira shemu za ponavljajući skup svojstava, na primjer, u 'Bloku
       Uređivač svojstava Lista' ili 'Ugniježđeni sadržaj'.
    `,
    composition: "Kompozicija",
    compositionDescription: `Definira višekratni skup svojstava koja se mogu uključiti u definiciju
       više drugih vrsta dokumenata. Na primjer, skup 'Common Page Settings'.
    `,
    folder: "Mapa",
    folderDescription: `Koristi se za organiziranje tipova dokumenata, sastava i tipova elemenata kreiranih u ovome
       Stablo vrste dokumenta.
    `,
    newFolder: "Nova mapa",
    newDataType: "Novi tip podatka",
    newJavascriptFile: "Novi JavaScript fajl",
    newEmptyPartialView: "Novi prazan djelomični prikaz",
    newPartialViewMacro: "Novi djelomični prikaz za makro",
    newPartialViewFromSnippet: "Novi djelomični prikaz iz isječka",
    newPartialViewMacroFromSnippet: "Novi djelomični prikaz za makro iz isječka",
    newPartialViewMacroNoMacro: "Novi djelomični prikaz za makro (bez makroa)",
    newStyleSheetFile: "Novi CSS fajl",
    newRteStyleSheetFile: "Novi Rich Text Editor CSS fajl"
  },
  dashboard: {
    browser: "Pregledajte svoju web stranicu",
    dontShowAgain: "- Sakrij",
    nothinghappens: "Ako se Umbraco ne otvara, možda ćete morati dozvoliti iskačuće prozore sa ove stranice",
    openinnew: "je otvoren u novom prozoru",
    restart: "Restart",
    visit: "Posjetite",
    welcome: "Dobrodošli"
  },
  prompt: {
    stay: "Ostani",
    discardChanges: "Odbacite promjene",
    unsavedChanges: "Imate nesačuvane promjene",
    unsavedChangesWarning: `Jeste li sigurni da želite otići s ove stranice? - imate nesačuvane
       promjene
    `,
    confirmListViewPublish: "Objavljivanjem će odabrane stavke biti vidljive na stranici.",
    confirmListViewUnpublish: `Poništavanje objavljivanja će ukloniti odabrane stavke i sve njihove potomke sa
       stranice.
    `,
    confirmUnpublish: "Poništavanje objavljivanja će ukloniti ovu stranicu i sve njene potomke sa stranice.",
    doctypeChangeWarning: "Imate nesačuvane promjene. Promjenom vrste dokumenta odbacit će se promjene."
  },
  bulk: {
    done: "Završeno",
    deletedItem: "Izbrisana %0% stavka",
    deletedItems: "Izbrisano %0% stavki",
    deletedItemOfItem: "Izbrisana %0% od %1% stavka",
    deletedItemOfItems: "Izbrisano %0% od %1% stavki",
    publishedItem: "Objavljeno %0% stavka",
    publishedItems: "Objavljeno %0% stavki",
    publishedItemOfItem: "Objavljeno %0% od %1% stavka",
    publishedItemOfItems: "Objavljeno %0% od %1% stavki",
    unpublishedItem: "Ukinuta objava za %0% stavku",
    unpublishedItems: "Ukinuta objava za %0% stavki",
    unpublishedItemOfItem: "Ukinuta objava za %0% od %1% stavku",
    unpublishedItemOfItems: "Ukinuta objava za %0% od %1% stavki",
    movedItem: "Pomjerena %0% stavka",
    movedItems: "Pomjereno %0% stavki",
    movedItemOfItem: "Pomjereno %0% od %1% stavku",
    movedItemOfItems: "Pomjereno %0% od %1% stavki",
    copiedItem: "Kopirana %0% stavka",
    copiedItems: "Kopirano %0% stavki",
    copiedItemOfItem: "Kopirano %0% od %1% stavku",
    copiedItemOfItems: "Kopirano %0% od %1% stavki"
  },
  defaultdialogs: {
    nodeNameLinkPicker: "Naslov linka",
    urlLinkPicker: "Link",
    anchorLinkPicker: "Anchor / querystring",
    anchorInsert: "Naziv",
    assignDomain: "Upravljajte imenima hostova",
    closeThisWindow: "Zatvorite ovaj prozor",
    confirmdelete: "Jeste li sigurni da želite izbrisati",
    confirmdeleteNumberOfItems: "Jeste li sigurni da želite izbrisati <strong>%0%</strong> od <strong>%1%</strong> stavki",
    confirmdisable: "Jeste li sigurni da želite onemogućiti",
    confirmremove: "Jeste li sigurni da želite ukloniti",
    confirmremoveusageof: "Jeste li sigurni da želite ukloniti korištenje <strong>%0%</strong>",
    confirmlogout: "Jeste li sigurni?",
    confirmSure: "Jeste li sigurni?",
    cut: "Izreži",
    editDictionary: "Uredi stavku iz rječnika",
    editLanguage: "Uredi jezik",
    editSelectedMedia: "Uredite odabrane medije",
    insertAnchor: "Umetnite lokalnu vezu",
    insertCharacter: "Umetni znak",
    insertgraphicheadline: "Umetnite grafički naslov",
    insertimage: "Umetnite sliku",
    insertlink: "Umetnite link",
    insertMacro: "Kliknite da dodate makro",
    inserttable: "Umetnite tabelu",
    languagedeletewarning: "Ovo će izbrisati jezik",
    languageChangeWarning: `Promjena kulture jezika može biti skupa operacija i rezultirat će
       u kešu sadržaja i indeksima koji se rekonstruišu
    `,
    lastEdited: "Posljednji put uređeno",
    link: "Link",
    linkinternal: "Interni link",
    linklocaltip: 'Kada koristite lokalne veze, umetnite "#" ispred linka',
    linknewwindow: "Otvori u novom prozoru?",
    macroDoesNotHaveProperties: "Ovaj makro ne sadrži svojstva koja možete uređivati",
    paste: "Zalijepi",
    permissionsEdit: "Uredite dozvole za",
    permissionsSet: "Postavite dozvole za",
    permissionsSetForGroup: "Postavite dozvole za %0% za grupu korisnika %1%",
    permissionsHelp: "Odaberite grupe korisnika za koje želite postaviti dozvole",
    recycleBinDeleting: `Stavke u korpi za otpatke se sada brišu. Molimo vas da ne zatvarate ovaj prozor
       dok se ova operacija odvija
    `,
    recycleBinIsEmpty: "Korpa za otpatke je sada prazna",
    recycleBinWarning: "Kada se predmeti izbrišu iz korpe za otpatke, oni će nestati zauvijek",
    regexSearchError: "<a target='_blank' rel='noopener' href='http://regexlib.com'>regexlib.com</a> web servis trenutno ima nekih problema, nad kojima nemamo kontrolu. Veoma nam je žao zbog ove neugodnosti.",
    regexSearchHelp: `Potražite regularni izraz da dodate provjeru valjanosti u polje obrasca. Primjer: 'e-pošta,
       'poštanski broj', 'URL'.
    `,
    removeMacro: "Ukloni makro",
    requiredField: "Obavezno polje",
    sitereindexed: "Stranica je ponovo indeksirana",
    siterepublished: `Predmemorija web stranice je osvježena. Sav objavljeni sadržaj je sada ažuriran. Dok će sav
		neobjavljen sadržaj ostati neobjavljen
    `,
    siterepublishHelp: `Keš web stranice će biti osvježen. Svi objavljeni sadržaji će biti ažurirani, dok će sav
       neobjavljeni sadržaj ostati neobjavljen.
    `,
    tableColumns: "Broj kolona",
    tableRows: "Broj redova",
    thumbnailimageclickfororiginal: "Kliknite na sliku da vidite punu veličinu",
    treepicker: "Izaberite stavku",
    viewCacheItem: "Prikaži keš stavku",
    relateToOriginalLabel: "Odnosi se na original",
    includeDescendants: "Uključiti potomke",
    theFriendliestCommunity: "Najljubaznija zajednica",
    linkToPage: "Link na stranicu",
    openInNewWindow: "Otvara povezani dokument u novom prozoru ili kartici",
    linkToMedia: "Link do medija",
    selectContentStartNode: "Odaberite početni čvor sadržaja",
    selectMedia: "Odaberite medije",
    selectMediaType: "Odaberite tip medija",
    selectIcon: "Odaberite ikonu",
    selectItem: "Odaberite stavku",
    selectLink: "Odaberite vezu",
    selectMacro: "Odaberite makro",
    selectContent: "Odaberite sadržaj",
    selectContentType: "Odaberite tip sadržaja",
    selectMediaStartNode: "Odaberite početni čvor medija",
    selectMember: "Odaberite člana",
    selectMemberGroup: "Odaberite grupu članova",
    selectMemberType: "Odaberite tip članova",
    selectNode: "Odaberite čvor",
    selectLanguages: "Odaberite jezike",
    selectSections: "Odaberite sekcije",
    selectUser: "Odaberite korisnika",
    selectUsers: "Odaberite korisnike",
    noIconsFound: "Ikone nisu pronađene",
    noMacroParams: "Nema parametara za ovaj makro",
    noMacros: "Nema dostupnih makroa za umetanje",
    externalLoginProviders: "Eksterni provajderi prijave",
    exceptionDetail: "Detalji o izuzetku",
    stacktrace: "Stacktrace",
    innerException: "Inner Exception",
    linkYour: "Povežite svoje",
    unLinkYour: "Odspojite svoju vezu",
    account: "račun",
    selectEditor: "Odaberite uređivač",
    selectSnippet: "Odaberite isječak",
    variantdeletewarning: `Ovo će izbrisati čvor i sve njegove jezike. Ako želite da izbrišete samo jedan
       jezik, trebali biste poništiti objavljivanje čvora na tom jeziku.
    `,
    propertyuserpickerremovewarning: "Ovo će ukloniti korisnika <strong>%0%</strong>.",
    userremovewarning: "Ovo će ukloniti korisnika <strong>%0%</strong> iz grupe <strong>%1%</strong>",
    yesRemove: "Da, ukloni",
    deleteLayout: "Brišete izgled",
    deletingALayout: "Promjena izgleda će rezultirati gubitkom podataka za bilo koji postojeći sadržaj koji je zasnovan na ovoj konfiguraciji."
  },
  dictionary: {
    importDictionaryItemHelp: `
      Da biste uvezli stavku iz rječnika, pronađite ".udt" datoteku na svom računaru klikom na
       Dugme "Uvezi" (na sljedećem ekranu će se tražiti da potvrdite)
    `,
    itemDoesNotExists: "Stavka iz rječnika ne postoji.",
    parentDoesNotExists: "Nadređena stavka ne postoji.",
    noItems: "Ne postoje stavke iz rječnika.",
    noItemsInFile: "U ovoj datoteci nema stavki iz rječnika.",
    noItemsFound: "Nisu pronađene stavke iz rječnika.",
    createNew: "Kreirajte stavku iz rječnika"
  },
  dictionaryItem: {
    description: "Uredite različite jezičke verzije za stavku rječnika '%0%' ispod",
    displayName: "Kultura",
    changeKeyError: "Ključ '%0%' već postoji.",
    overviewTitle: "Pregled riječnika"
  },
  examineManagement: {
    configuredSearchers: "Konfigurisani pretraživači",
    configuredSearchersDescription: `Prikazuje svojstva i alate za bilo koji konfigurirani pretraživač (tj
       višeindeksni pretraživač)
    `,
    fieldValues: "Vrijednosti polja",
    healthStatus: "Zdravstveno stanje",
    healthStatusDescription: "Zdravstveno stanje indeksa i da li se može pročitati",
    indexers: "Indeksi",
    indexInfo: "Indeks info",
    contentInIndex: "Sadržaj u indeksu",
    indexInfoDescription: "Navodi svojstva indeksa",
    manageIndexes: "Upravljajte Examine-ovim indeksima",
    manageIndexesDescription: `Omogućava vam da vidite detalje svakog indeksa i pruža neke alate za
       upravljanje indeksima
    `,
    rebuildIndex: "Ponovo izgradi indeks",
    rebuildIndexWarning: `
      Ovo će uzrokovati ponovnu izgradnju indeksa.<br />
      Ovisno o tome koliko sadržaja ima na vašoj web lokaciji, to može potrajati.<br />
      Ne preporučuje se obnavljanje indeksa u vrijeme velikog prometa na web stranici ili kada urednici uređuju sadržaj.
     `,
    searchers: "Pretraživači",
    searchDescription: "Pretražite indeks i pogledajte rezultate",
    tools: "Alati",
    toolsDescription: "Alati za upravljanje indeksom",
    fields: "polja",
    indexCannotRead: "Indeks se ne može pročitati i morat će se ponovo izgraditi",
    processIsTakingLonger: `Proces traje duže od očekivanog, provjerite Umbraco dnevnik da vidite
       je li bilo grešaka tokom ove operacije
    `,
    indexCannotRebuild: "Ovaj indeks se ne može ponovo izgraditi jer mu nije dodijeljen",
    iIndexPopulator: "IIndexPopulator"
  },
  placeholders: {
    username: "Unesite svoje korisničko ime",
    password: "Unesite svoju lozinku",
    confirmPassword: "Potvrdite lozinku",
    nameentity: "Imenujte %0%...",
    entername: "Unesite ime...",
    enteremail: "Unesite email...",
    enterusername: "Unesite korisničko ime...",
    label: "Labela...",
    enterDescription: "Unesite opis...",
    search: "Unesite za pretragu...",
    filter: "Unesite za filtriranje...",
    enterTags: "Unesite da dodate oznake (pritisnite enter nakon svake oznake)...",
    email: "Unesite vaš email",
    enterMessage: "Unesite poruku...",
    usernameHint: "Vaše korisničko ime je obično vaš email",
    anchor: "#value ili ?key=value",
    enterAlias: "Unesite alias...",
    generatingAlias: "Generišite alias...",
    a11yCreateItem: "Kreiraj stavku",
    a11yEdit: "Uredi",
    a11yName: "Ime"
  },
  editcontenttype: {
    createListView: "Kreirajte prilagođeni prikaz liste",
    removeListView: "Ukloni prilagođeni prikaz liste",
    aliasAlreadyExists: "Tip sadržaja, tip medija ili tip člana s ovim aliasom već postoji"
  },
  renamecontainer: {
    renamed: "Preimenovano",
    enterNewFolderName: "Ovdje unesite novi naziv mape",
    folderWasRenamed: "%0% je preimenovan u %1%"
  },
  editdatatype: {
    addPrevalue: "Dodajte vrijednost",
    dataBaseDatatype: "Tip podataka baze podataka",
    guid: "Uređivač osobine GUID",
    renderControl: "Uređivač osobina",
    rteButtons: "Dugmad",
    rteEnableAdvancedSettings: "Omogući napredne postavke za",
    rteEnableContextMenu: "Omogući kontekstni meni",
    rteMaximumDefaultImgSize: "Maksimalna zadana veličina umetnutih slika",
    rteRelatedStylesheets: "Povezani stilovi",
    rteShowLabel: "Prikaži oznaku",
    rteWidthAndHeight: "Širina i visina",
    selectFolder: "Odaberite mapu za premještanje",
    inTheTree: "do u strukturi stabla ispod",
    wasMoved: "je premeštena ispod"
  },
  errorHandling: {
    errorButDataWasSaved: `Vaši podaci su sačuvani, ali prije nego što možete objaviti ovu stranicu postoje neke
       greške koje prvo morate ispraviti:
    `,
    errorChangingProviderPassword: `Trenutni provajder članstva ne podržava promjenu lozinke
       (Omogući preuzimanje lozinke mora biti uključeno)
    `,
    errorExistsWithoutTab: "%0% već postoji",
    errorHeader: "Bilo je grešaka:",
    errorHeaderWithoutTab: "Bilo je grešaka:",
    errorInPasswordFormat: `Lozinka treba da ima najmanje %0% znakova i da sadrži najmanje %1%
      znakova koji nisu alfanumerički
    `,
    errorIntegerWithoutTab: "%0% mora biti cijeli broj",
    errorMandatory: "Polje %0% na kartici %1% je obavezno",
    errorMandatoryWithoutTab: "%0% je obavezno polje",
    errorRegExp: "%0% na %1% nije u ispravnom formatu",
    errorRegExpWithoutTab: "%0% nije u ispravnom formatu"
  },
  errors: {
    receivedErrorFromServer: "Primljena greška sa servera",
    dissallowedMediaType: "Administrator je zabranio navedeni tip datoteke",
    codemirroriewarning: `NAPOMENA! Iako je CodeMirror omogućen konfiguracijom, on je onemogućen u
       Internet Explorer-u jer nije dovoljno stabilan.
    `,
    contentTypeAliasAndNameNotNull: "Unesite i pseudonim i ime na novu vrstu osobine!",
    filePermissionsError: "Postoji problem sa pristupom za čitanje/pisanje određenoj datoteci ili fascikli",
    macroErrorLoadingPartialView: "Greška pri učitavanju skripte djelomičnog prikaza (fajl: %0%)",
    missingTitle: "Unesite naslov",
    missingType: "Molimo odaberite tip",
    pictureResizeBiggerThanOrg: `Napravit ćete sliku veću od originalne veličine. Jeste li sigurni
       da želite nastaviti?
    `,
    startNodeDoesNotExists: "Početni čvor je obrisan, kontaktirajte svog administratora",
    stylesMustMarkBeforeSelect: "Molimo označite sadržaj prije promjene stila",
    stylesNoStylesOnPage: "Nema dostupnih aktivnih stilova",
    tableColMergeLeft: "Postavite kursor lijevo od dvije ćelije koje želite spojiti",
    tableSplitNotSplittable: "Ne možete podijeliti ćeliju koja nije spojena.",
    propertyHasErrors: "Ovo svojstvo je nevažeće"
  },
  general: {
    about: "O",
    action: "Akcija",
    actions: "Akcije",
    add: "Dodaj",
    alias: "Alias",
    all: "Sve",
    areyousure: "Da li ste sigurni?",
    back: "Nazad",
    backToOverview: "Nazad na pregled",
    border: "Rub",
    by: "od",
    cancel: "Otkaži",
    cellMargin: "Margina ćelije",
    choose: "Odaberi",
    clear: "Očisti",
    close: "Zatvori",
    closewindow: "Zatvori prozor",
    closepane: "Zatvori okno",
    comment: "Komentar",
    confirm: "Potvrdi",
    constrain: "Ograniči",
    constrainProportions: "Ograniči proporcije",
    content: "Sadržaj",
    continue: "Nastavi",
    copy: "Kopiraj",
    create: "Kreiraj",
    database: "Baza podataka",
    date: "Datum",
    default: "Podrazumjevano",
    delete: "Obriši",
    deleted: "Obrisano",
    deleting: "Brisanje...",
    design: "Dizajn",
    dictionary: "Riječnik",
    dimensions: "Dimenzije",
    discard: "Otkaži",
    down: "Dole",
    download: "Preuzimanje",
    edit: "Uredi",
    edited: "Uređeno",
    elements: "Elementi",
    email: "Email",
    error: "Greška",
    field: "Polje",
    findDocument: "Pronađi",
    first: "Prvi",
    focalPoint: "Fokusna tačka",
    general: "Generalno",
    groups: "Grupe",
    group: "Grupa",
    height: "Visina",
    help: "Pomoć",
    hide: "Sakrij",
    history: "Historija",
    icon: "Ikona",
    id: "Id",
    import: "Uvezi",
    excludeFromSubFolders: "Pretraži samo ovu mapu",
    info: "Info",
    innerMargin: "Unutrašnja margina",
    insert: "Umetni",
    install: "Instaliraj",
    invalid: "Nevažeći",
    justify: "Poravnaj",
    label: "Labela",
    language: "Jezik",
    last: "Zadnji",
    layout: "Izgled",
    links: "Linkovi",
    loading: "Učitavanje",
    locked: "Zaključano",
    login: "Prijava",
    logoff: "Odjavi se",
    logout: "Odjavi se",
    macro: "Makro",
    mandatory: "Obavezno",
    message: "Poruka",
    move: "Pomakni",
    name: "Ime",
    new: "Novi",
    next: "Sljedeći",
    no: "Ne",
    nodeName: "Ime čvora",
    of: "od",
    off: "Isključeno",
    ok: "OK",
    open: "Otvori",
    options: "Opcije",
    on: "Uključeno",
    or: "ili",
    orderBy: "Poredaj po",
    password: "Lozinka",
    path: "Putanja",
    pleasewait: "Jedan momenat molim...",
    previous: "Prethodni",
    properties: "Svojstva",
    readMore: "Pročitaj više",
    rebuild: "Ponovo izgradi",
    reciept: "Email za primanje obrasca",
    recycleBin: "Kanta za smeće",
    recycleBinEmpty: "Vaša kanta za smeće je prazna",
    reload: "Ponovo učitaj",
    remaining: "Preostalo",
    remove: "Izbriši",
    rename: "Preimenuj",
    renew: "Obnovi",
    required: "Obavezno",
    retrieve: "Povratiti",
    retry: "Pokušaj ponovo",
    rights: "Permisije",
    scheduledPublishing: "Planirano objavljivanje",
    umbracoInfo: "Umbraco info",
    search: "Pretraga",
    searchNoResult: "Žao nam je, ne možemo pronaći ono što tražite.",
    noItemsInList: "Nije dodana nijedna stavka",
    server: "Server",
    settings: "Postavke",
    show: "Prikaži",
    showPageOnSend: "Prikaži stranicu na Pošalji",
    size: "Veličina",
    sort: "Sortiranje",
    status: "Status",
    submit: "Potvrdi",
    success: "Uspjeh",
    type: "Tip",
    typeName: "Ime tipa",
    typeToSearch: "Unesite za pretragu...",
    under: "ispod",
    up: "Gore",
    update: "Ažuriraj",
    upgrade: "Nadogradi",
    upload: "Prenesi",
    url: "URL",
    user: "Korisnik",
    username: "Korisničko ime",
    value: "Vrijednost",
    view: "Pogled",
    welcome: "Dobrodošli...",
    width: "Širina",
    yes: "Da",
    folder: "Mapa",
    searchResults: "Rezultati pretrage",
    reorder: "Promijeni redosljed",
    reorderDone: "Završio sam sa promjenom redosljeda",
    preview: "Pregled",
    changePassword: "Promijeni lozinku",
    to: "do",
    listView: "Prikaz liste",
    saving: "Spremanje...",
    current: "trenutni",
    embed: "Ugradi",
    selected: "odabran",
    other: "Ostalo",
    articles: "Članci",
    videos: "Videi",
    avatar: "Avatar za",
    header: "Zaglavlje",
    systemField: "sistemsko polje",
    lastUpdated: "Posljednje ažurirano"
  },
  colors: {
    blue: "Plava"
  },
  shortcuts: {
    addGroup: "Dodaj grupu",
    addProperty: "Dodaj svojstvo",
    addEditor: "Dodaj urednika",
    addTemplate: "Dodaj šablon",
    addChildNode: "Dodajte podređeni čvor",
    addChild: "Dodaj dijete",
    editDataType: "Uredite tip podataka",
    navigateSections: "Krećite se po odjeljcima",
    shortcut: "Prečice",
    showShortcuts: "prikaži prečice",
    toggleListView: "Uključi prikaz liste",
    toggleAllowAsRoot: "Uključi dozvoli kao root",
    commentLine: "Redovi za komentarisanje/dekomentarisanje",
    removeLine: "Uklonite liniju",
    copyLineUp: "Kopiraj linije gore",
    copyLineDown: "Kopiraj linije dole",
    moveLineUp: "Pomakni linije gore",
    moveLineDown: "Pomakni linije dole",
    generalHeader: "Općenito",
    editorHeader: "Uređivač",
    toggleAllowCultureVariants: "Uključi dozvoli varijante kulture"
  },
  graphicheadline: {
    backgroundcolor: "Boja pozadine",
    bold: "Boldirano",
    color: "Boja teksta",
    font: "Font",
    text: "Tekst"
  },
  headers: {
    page: "Stranica"
  },
  installer: {
    databaseErrorCannotConnect: "Instalacija se ne može povezati s bazom podataka.",
    databaseErrorWebConfig: `Nije moguće sačuvati web.config datoteku. Molimo izmijenite konekcijski string
       ručno.
    `,
    databaseFound: "Vaša baza podataka je pronađena i identificirana je kao",
    databaseHeader: "Konfiguracija baze podataka",
    databaseInstall: `
      Pritisnite <strong>Instaliraj</strong> za instalaciju Umbraco %0% baze podataka
    `,
    databaseInstallDone: "Umbraco %0% je sada kopiran u vašu bazu podataka. Pritisnite <strong>Dalje</strong> da nastavite.",
    databaseNotFound: `<p>Baza podataka nije pronađena! Provjerite jesu li informacije u "konekcijskom string" u "web.config" fajlu ispravne.</p>
              <p>Da nastavite, uredite "web.config" fajl. (koristeći Visual Studio ili vaš omiljeni uređivač teksta), skrolujte do dna, dodajte konekcijski string za vašu bazu podataka u ključ nazvan "UmbracoDbDSN" i sačuvajte fajl. </p>
              <p>
              Kliknite na <strong>pokušaj ponovo</strong> dugme kada završite.<br />
			  <a href="https://our.umbraco.com/documentation/Reference/Config/webconfig/" target="_blank" rel="noopener">
			              Više informacija o uređivanju web.config fajla možete pronaći ovdje</a>.</p>`,
    databaseText: `Da biste dovršili ovaj korak, morate znati neke informacije o vašem poslužitelju baze podataka ("konekcijski string").<br />
        Molimo kontaktirajte svog ISP-a ako je potrebno.
        Ako instalirate na lokalnoj mašini ili serveru, možda će vam trebati informacije od administratora sistema.`,
    databaseUpgrade: `
      <p>
      Pritisnite <strong>nadogradnja</strong> za nadogradnju vaše baze podataka na Umbraco %0%</p>
      <p>
      Ne brinite - nijedan sadržaj neće biti obrisan i sve će nastaviti raditi nakon toga!
      </p>
      `,
    databaseUpgradeDone: "Vaša baza podataka je nadograđena na konačnu verziju %0%.<br />Pritisnite <strong>Dalje</strong> da nastavite.",
    databaseUpToDate: "Vaša trenutna baza podataka je ažurirana!. Pritisnite <strong>Dalje</strong> da nastavite sa čarobnjakom za konfiguraciju",
    defaultUserChangePass: "<strong>Zadanu korisničku lozinku treba promijeniti!</strong>",
    defaultUserDisabled: "<strong>Zadani korisnik je onemogućen ili nema pristup Umbraco!</strong></p><p>Ne treba preduzimati nikakve daljnje radnje. Pritisnite <strong>Dalje</strong> da nastavite.",
    defaultUserPassChanged: "<strong>Zadana korisnička lozinka je uspješno promijenjena od instalacije!</strong></p><p>Ne treba preduzimati nikakve daljnje radnje. Pritisnite <strong>Dalje</strong> da nastavite.",
    defaultUserPasswordChanged: "Lozinka je promijenjena!",
    greatStart: "Započnite odlično, pogledajte naše uvodne video zapise",
    licenseText: `Klikom na sljedeće dugme (ili modifikacijom umbracoConfigurationStatus u web.config),
       prihvatate licencu za ovaj softver kao što je navedeno u polju ispod. Primijetite da je ova Umbraco distribucija
       sastoji se od dvije različite licence, open source MIT licence za okvir i licence za besplatni softver Umbraco
       koji pokriva korisničko sučelje.
    `,
    None: "Još nije instalirano.",
    permissionsAffectedFolders: "Zahvaćeni datoteke i mape",
    permissionsAffectedFoldersMoreInfo: "Više informacija o postavljanju dozvola za Umbraco ovdje",
    permissionsAffectedFoldersText: `Morate dodijeliti dozvole za izmjenu ASP.NET-a za sljedeće
       datoteke/mape
    `,
    permissionsAlmostPerfect: `<strong>Vaše postavke dozvola su gotovo savršene!</strong><br /><br />
        Možete pokrenuti Umbraco bez problema, ali nećete moći instalirati pakete koji se preporučuju da biste u potpunosti iskoristili Umbraco.`,
    permissionsHowtoResolve: "Kako riješiti",
    permissionsHowtoResolveLink: "Kliknite ovdje da pročitate tekstualnu verziju",
    permissionsHowtoResolveText: "Gledajte naše <strong>video tutorijale</strong> o postavljanju dozvola foldera za Umbraco ili pročitajte tekstualnu verziju.",
    permissionsMaybeAnIssue: `<strong>Vaše postavke dozvola mogu biti problem!</strong>
      <br/><br />
      Možete pokrenuti Umbraco bez problema, ali nećete moći kreirati foldere ili instalirati pakete koji se preporučuju da biste u potpunosti iskoristili Umbraco.`,
    permissionsNotReady: `<strong>Vaše postavke dozvola nisu spremne za Umbraco!</strong>
          <br /><br />
          Da biste pokrenuli Umbraco, morat ćete ažurirati postavke dozvola.`,
    permissionsPerfect: `<strong>Vaše postavke dozvola su savršene!</strong><br /><br />
              Spremni ste da pokrenete Umbraco i instalirate pakete!`,
    permissionsResolveFolderIssues: "Rješavanje problema sa mapom",
    permissionsResolveFolderIssuesLink: `Pratite ovu vezu za više informacija o problemima sa ASP.NET i
       kreiranje foldera
    `,
    permissionsSettingUpPermissions: "Postavljanje dozvola za foldere",
    permissionsText: `
      Umbraco treba pristup za pisanje/izmjenu određenih direktorija kako bi pohranio datoteke poput slika i PDF-ova.
      Također pohranjuje privremene podatke (tj: cache) za poboljšanje performansi vaše web stranice.
    `,
    runwayFromScratch: "Želim da počnem od nule",
    runwayFromScratchText: `
        Vaša web stranica je trenutno potpuno prazna, tako da je savršeno ako želite početi od nule i kreirati vlastite vrste dokumenata i predloške.
        (<a href="https://umbraco.tv/documentation/videos/for-site-builders/foundation/document-types">naučite kako</a>)
        I dalje možete odabrati da kasnije instalirate Runway. Molimo idite na odjeljak Developer i odaberite Paketi.
      `,
    runwayHeader: "Upravo ste postavili čistu Umbraco platformu. Šta želite sljedeće učiniti?",
    runwayInstalled: "Runway je instaliran",
    runwayInstalledText: `
      Imate postavljene temelje. Odaberite koje module želite instalirati na njega.<br />
      Ovo je naša lista preporučenih modula, označite one koje želite da instalirate ili pogledajte <a href="#" onclick="toggleModules(); return false;" id="toggleModuleList">punu listu modula</a>
      `,
    runwayOnlyProUsers: "Preporučuje se samo iskusnim korisnicima",
    runwaySimpleSite: "Želim početi s jednostavnom web-stranicom",
    runwaySimpleSiteText: `
      <p>
      "Runway" je jednostavna web stranica koja nudi neke osnovne tipove dokumenata i predloške. Instalater može postaviti Runway za vas automatski,
        ali ga možete lako urediti, proširiti ili ukloniti. Nije potrebno i možete savršeno koristiti Umbraco i bez njega. Kako god,
        Runway nudi laku osnovu zasnovanu na najboljim praksama za početak brže nego ikad.
        Ako se odlučite za instalaciju Runway, opciono možete odabrati osnovne građevne blokove tzv. Runway Modules da poboljšate svoje Runway stranice.
        </p>
        <small>
        <em>Uključeno u Runway:</em> Početna stranica, Stranica za početak, Stranica za instaliranje modula.<br />
        <em>Dodatni moduli:</em> Navigacija, Sitemap, Kontakt, Galerija.
        </small>
      `,
    runwayWhatIsRunway: "Šta je Runway",
    step1: "Korak 1/5: Prihvatite licencu",
    step2: "Korak 2/5: Konfiguracija baze podataka",
    step3: "Korak 3/5: Potvrđivanje dozvola za fajlove",
    step4: "Korak 4/5: Provjerite Umbraco sigurnost",
    step5: "Korak 5/5: Umbraco je spreman za početak",
    thankYou: "Hvala vam što ste odabrali Umbraco",
    theEndBrowseSite: `<h3>Pregledajte svoju novu stranicu</h3>
Instalirali ste Runway, pa zašto ne biste vidjeli kako izgleda vaša nova web stranica.`,
    theEndFurtherHelp: `<h3>Dodatna pomoć i informacije</h3>
Potražite pomoć od naše nagrađivane zajednice, pregledajte dokumentaciju ili pogledajte nekoliko besplatnih videozapisa o tome kako napraviti jednostavnu stranicu, kako koristiti pakete i brzi vodič za terminologiju Umbraco`,
    theEndHeader: "Umbraco %0% je instaliran i spreman za upotrebu",
    theEndInstallFailed: `Da biste završili instalaciju, morat ćete
        ručno uredite <strong>/web.config fajl</strong> i ažurirate ključ unutar AppSetting <strong>UmbracoConfigurationStatus</strong> na dnu do vrijednosti od <strong>'%0%'</strong>.`,
    theEndInstallSuccess: `Možeš dobiti <strong>započeto odmah</strong> klikom na "Pokreni Umbraco" dugme ispod. <br />Ako ste <strong>novi u Umbraco-u</strong>,
možete pronaći mnogo resursa na našim stranicama za početak.`,
    theEndOpenUmbraco: `<h3>Pokreni Umbraco</h3>
Da upravljate svojom web lokacijom, jednostavno otvorite Umbraco backoffice i počnite dodavati sadržaj, ažurirati predloške i stilove ili dodati novu funkcionalnost`,
    Unavailable: "Povezivanje s bazom podataka nije uspjelo.",
    Version3: "Umbraco Verzija 3",
    Version4: "Umbraco Verzija 4",
    watch: "Gledaj",
    welcomeIntro: `Ovaj čarobnjak će vas voditi kroz proces konfiguracije <strong>Umbraco %0%</strong> za novu instalaciju ili nadogradnju sa verzije 3.0.
                                <br /><br />
                                Pritisnite <strong>"Dalje"</strong> da pokrenete čarobnjaka.`
  },
  language: {
    cultureCode: "Kod kulture",
    displayName: "Naziv kulture"
  },
  lockout: {
    lockoutWillOccur: "Bili ste u stanju mirovanja i automatski će doći do odjave",
    renewSession: "Obnovite sada da sačuvate svoj rad"
  },
  login: {
    greeting0: "Dobrodošli",
    greeting1: "Dobrodošli",
    greeting2: "Dobrodošli",
    greeting3: "Dobrodošli",
    greeting4: "Dobrodošli",
    greeting5: "Dobrodošli",
    greeting6: "Dobrodošli",
    instruction: "Prijavite se ispod",
    signInWith: "Prijavite se sa",
    timeout: "Isteklo je vrijeme sesije",
    bottomText: '<p style="text-align:right;">&copy; 2001 - %0% <br /><a href="https://umbraco.com" style="text-decoration: none" target="_blank" rel="noopener">Umbraco.com</a></p> ',
    forgottenPassword: "Zaboravljena lozinka?",
    forgottenPasswordInstruction: `E-mail će biti poslan na adresu navedenu sa vezom za reset
       lozinke
    `,
    requestPasswordResetConfirmation: `E-mail s uputama za poništavanje lozinke će biti poslan na
       navedenu adresu ukoliko odgovara našoj evidenciji
    `,
    showPassword: "Prikaži lozinku",
    hidePassword: "Sakrij lozinku",
    returnToLogin: "Vratite se na obrazac za prijavu",
    setPasswordInstruction: "Molimo unesite novu lozinku",
    setPasswordConfirmation: "Vaša lozinka je ažurirana",
    resetCodeExpired: "Link na koji ste kliknuli je nevažeći ili je istekao",
    resetPasswordEmailCopySubject: "Umbraco: Reset lozinke",
    resetPasswordEmailCopyFormat: `
        <html>
			<head>
				<meta name='viewport' content='width=device-width'>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
			</head>
			<body class='' style='font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; color: #392F54; line-height: 22px; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background: #1d1333; margin: 0; padding: 0;' bgcolor='#1d1333'>
				<style type='text/css'> @media only screen and (max-width: 620px) {table[class=body] h1 {font-size: 28px !important; margin-bottom: 10px !important; } table[class=body] .wrapper {padding: 32px !important; } table[class=body] .article {padding: 32px !important; } table[class=body] .content {padding: 24px !important; } table[class=body] .container {padding: 0 !important; width: 100% !important; } table[class=body] .main {border-left-width: 0 !important; border-radius: 0 !important; border-right-width: 0 !important; } table[class=body] .btn table {width: 100% !important; } table[class=body] .btn a {width: 100% !important; } table[class=body] .img-responsive {height: auto !important; max-width: 100% !important; width: auto !important; } } .btn-primary table td:hover {background-color: #34495e !important; } .btn-primary a:hover {background-color: #34495e !important; border-color: #34495e !important; } .btn  a:visited {color:#FFFFFF;} </style>
				<table border="0" cellpadding="0" cellspacing="0" class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;" bgcolor="#1d1333">
					<tr>
						<td style="font-family: sans-serif; font-size: 14px; vertical-align: top; padding: 24px;" valign="top">
							<table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;">
								<tr>
									<td background="https://umbraco.com/umbraco/assets/img/application/logo.png" bgcolor="#1d1333" width="28" height="28" valign="top" style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
										<!--[if gte mso 9]> <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:30px;height:30px;"> <v:fill type="tile" src="https://umbraco.com/umbraco/assets/img/application/logo.png" color="#1d1333" /> <v:textbox inset="0,0,0,0"> <![endif]-->
<div></div>
<!--[if gte mso 9]> </v:textbox> </v:rect> <![endif]-->
</td>
<td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top"></td>
</tr>
</table>
</td>
</tr>
</table>
<table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;' bgcolor='#1d1333'>
<tr>
<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'></td>
<td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 560px; width: 560px; margin: 0 auto; padding: 10px;' valign='top'>
<div class='content' style='box-sizing: border-box; display: block; max-width: 560px; margin: 0 auto; padding: 10px;'>
<br>
<table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; border-radius: 3px; background: #FFFFFF;' bgcolor='#FFFFFF'>
<tr>
<td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 50px;' valign='top'>
<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
<tr>
<td style='line-height: 24px; font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'>
<h1 style='color: #392F54; font-family: sans-serif; font-weight: bold; line-height: 1.4; font-size: 24px; text-align: left; text-transform: capitalize; margin: 0 0 30px;' align='left'>
															Zatraženo je ponovno postavljanje lozinke
														</h1>
<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Vaše korisničko ime za prijavu na Umbraco backoffice je: <strong>%0%</strong>
</p>
<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
<tbody>
<tr>
<td style='font-family: sans-serif; font-size: 14px; vertical-align: top; border-radius: 5px; text-align: center; background: #35C786;' align='center' bgcolor='#35C786' valign='top'>
<a href='%1%' target='_blank' rel='noopener' style='color: #FFFFFF; text-decoration: none; -ms-word-break: break-all; word-break: break-all; border-radius: 5px; box-sizing: border-box; cursor: pointer; display: inline-block; font-size: 14px; font-weight: bold; text-transform: capitalize; background: #35C786; margin: 0; padding: 12px 30px; border: 1px solid #35c786;'>
																				Kliknite na ovaj link da poništite lozinku
																			</a>
</td>
</tr>
</tbody>
</table>
</p>
<p style='max-width: 400px; display: block; color: #392F54; font-family: sans-serif; font-size: 14px; line-height: 20px; font-weight: normal; margin: 15px 0;'>Ukoliko ne možete kliknuti na link, kopirajte i zalijepite ovaj URL u prozor vašeg pretraživača:</p>
<table border='0' cellpadding='0' cellspacing='0'>
<tr>
<td style='-ms-word-break: break-all; word-break: break-all; font-family: sans-serif; font-size: 11px; line-height:14px;'>
<font style="-ms-word-break: break-all; word-break: break-all; font-size: 11px; line-height:14px;">
<a style='-ms-word-break: break-all; word-break: break-all; color: #392F54; text-decoration: underline; font-size: 11px; line-height:15px;' href='%1%'>%1%</a>
</font>
</td>
</tr>
</table>
</p>
</td>
</tr>
</table>
</td>
</tr>
</table>
<br><br><br>
</div>
</td>
<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'></td>
</tr>
</table>
</body>
</html>
	`,
    mfaSecurityCodeSubject: "Umbraco: Sigurnosni kod",
    mfaSecurityCodeMessage: "Vaš sigurnosni kod je: %0%",
    "2faTitle": "Poslednji korak",
    "2faText": "Omogućili ste 2-faktorsku autentifikaciju i morate potvrditi svoj identitet.",
    "2faMultipleText": "Molimo odaberite 2-faktor provajdera",
    "2faCodeInput": "Verifikacijski kod",
    "2faCodeInputHelp": "Unesite verifikacioni kod",
    "2faInvalidCode": "Unesen je nevažeći kod"
  },
  main: {
    dashboard: "Kontrolna tabla",
    sections: "Sekcije",
    tree: "Sadržaj"
  },
  moveOrCopy: {
    choose: "Odaberite stranicu iznad...",
    copyDone: "%0% je kopiran u %1%",
    copyTo: "Odaberite gdje dokument %0% treba kopirati ispod",
    moveDone: "%0% je premješten u %1%",
    moveTo: "Odaberite gdje dokument %0% treba premjestiti ispod",
    nodeSelected: "je odabrano kao korijen vašeg novog sadržaja, kliknite na 'Uredu' ispod.",
    noNodeSelected: "Još nije odabran čvor, molimo odaberite čvor na gornjoj listi prije nego kliknete na 'Uredu'",
    notAllowedByContentType: "Trenutni čvor nije dozvoljen pod odabranim čvorom zbog njegovog tipa",
    notAllowedByPath: "Trenutni čvor se ne može premjestiti na jednu od njegovih podstranica niti roditelj i odredište mogu biti isti",
    notAllowedAtRoot: "Trenutni čvor ne može postojati u korijenu",
    notValid: `Radnja nije dozvoljena jer nemate dovoljna dopuštenja za 1 ili više djece
       dokumenata.
    `,
    relateToOriginal: "Povežite kopirane stavke s originalom"
  },
  notifications: {
    editNotifications: "Odaberite vaše obavještenje za %0%",
    notificationsSavedFor: "Postavke obavještenja su sačuvane za %0%",
    notifications: "Obavještenja"
  },
  packager: {
    actions: "Akcije",
    created: "Kreirano",
    createPackage: "Kreiraj paket",
    chooseLocalPackageText: `
      Odaberite paket sa vašeg uređaja klikom na Pregledaj<br />
         i locirajte paket. Umbraco paketi uglavnom imaju ".umb" ili ".zip" ekstenziju.
      `,
    deletewarning: "Ovo će izbrisati paket",
    includeAllChildNodes: "Uključi sve podređene čvorove",
    installed: "Instalirano",
    installedPackages: "Instalirani paketi",
    installInstructions: "Uputstvo za instalaciju",
    noConfigurationView: "Ovaj paket nema prikaz konfiguracije",
    noPackagesCreated: "Još nije kreiran nijedan paket",
    noPackages: "Nijedan paket nije instaliran",
    noPackagesDescription: "Pregledajte dostupne pakete koristeći ikonu <strong>'Paketi'</strong> u gornjem desnom uglu ekrana",
    packageContent: "Sadržaj paketa",
    packageLicense: "Licenca",
    packageSearch: "Pretražite pakete",
    packageSearchResults: "Rezultati za",
    packageNoResults: "Nismo mogli pronaći ništa za",
    packageNoResultsDescription: `Pokušajte potražiti drugi paket ili pregledajte kategorije
    `,
    packagesPopular: "Popularno",
    packagesPromoted: "Promocije",
    packagesNew: "Nova izdanja",
    packageHas: "ima",
    packageKarmaPoints: "karma poeni",
    packageInfo: "Informacije",
    packageOwner: "Vlasnik",
    packageContrib: "Saradnici",
    packageCreated: "Kreirano",
    packageCurrentVersion: "Trenutna verzija",
    packageNetVersion: ".NET verzija",
    packageDownloads: "Preuzimanja",
    packageLikes: "Lajkovi",
    packageCompatibility: "Kompatibilnost",
    packageCompatibilityDescription: `Ovaj paket je kompatibilan sa sljedećim verzijama Umbraco-a, kako su
      prijavili članovi zajednice. Potpuna kompatibilnost se ne može garantirati za dolje navedene verzije 100%
    `,
    packageExternalSources: "Eksterni izvori",
    packageAuthor: "Autor",
    packageDocumentation: "Dokumentacija",
    packageMetaData: "Meta podaci paketa",
    packageName: "Naziv paketa",
    packageNoItemsHeader: "Paket ne sadrži nikakve stavke",
    packageNoItemsText: `Ovaj paket ne sadrži nijednu stavku za deinstalaciju.<br/><br/>
      Ovo možete bezbjedno ukloniti iz sistema klikom na "deinstaliraj paket".`,
    packageOptions: "Opcije paketa",
    packageMigrationsRun: "Pokrenite migracije paketa na čekanju",
    packageReadme: "Readme paketa",
    packageRepository: "Repozitorij paketa",
    packageUninstallConfirm: "Potvrdi deinstalaciju paketa",
    packageUninstalledHeader: "Paket je deinstaliran",
    packageUninstalledText: "Paket je uspješno deinstaliran",
    packageUninstallHeader: "Deinstaliraj paket",
    packageUninstallText: `U nastavku možete poništiti odabir stavki koje trenutno ne želite ukloniti. Kada kliknete na "potvrdi deinstalaciju" sve označene stavke će biti uklonjene.<br />
      <span style="color: Red; font-weight: bold;">Bilješka:</span> svi dokumenti, mediji itd. u zavisnosti od stavki koje uklonite, prestat će raditi i mogu dovesti do nestabilnosti sistema,
      pa deinstalirajte sa oprezom. Ako ste u nedoumici, kontaktirajte autora paketa.`,
    packageVersion: "Verzija paketa",
    verifiedToWorkOnUmbracoCloud: "Provjereno za rad na Umbraco Cloud"
  },
  paste: {
    doNothing: "Zalijepi s punim formatiranjem (nije preporučljivo)",
    errorMessage: `Tekst koji pokušavate zalijepiti sadrži posebne znakove ili formatiranje. Ovo bi moglo biti
       uzrokovano kopiranjem teksta iz programa Microsoft Word. Umbraco može automatski ukloniti posebne znakove ili formatiranje, tako da
       zalijepljeni sadržaj će biti prikladniji za web.
    `,
    removeAll: "Zalijepite kao sirovi tekst bez ikakvog oblikovanja",
    removeSpecialFormattering: "Zalijepi, ali ukloni oblikovanje (preporučeno)"
  },
  publicAccess: {
    paGroups: "Grupna zaštita",
    paGroupsHelp: "Ako želite dodijeliti pristup svim članovima određenih grupa članova",
    paGroupsNoGroups: "Morate kreirati grupu članova prije nego što možete koristiti grupnu autentifikaciju",
    paErrorPage: "Stranica sa greškom",
    paErrorPageHelp: "Koristi se kada su ljudi prijavljeni, ali nemaju pristup",
    paHowWould: "Odaberite kako ograničiti pristup stranici <strong>%0%</strong>",
    paIsProtected: "<strong>%0%</strong> je sada zaštićen",
    paIsRemoved: "Zaštita uklonjena sa <strong>%0%</strong>",
    paLoginPage: "Stranica za prijavu",
    paLoginPageHelp: "Odaberite stranicu koja sadrži obrazac za prijavu",
    paRemoveProtection: "Uklonite zaštitu...",
    paRemoveProtectionConfirm: "Jeste li sigurni da želite ukloniti zaštitu sa stranice <strong>%0%</strong>?",
    paSelectPages: "Odaberite stranice koje sadrže obrazac za prijavu i poruke o greškama",
    paSelectGroups: "Odaberite grupe koje imaju pristup stranici <strong>%0%</strong>",
    paSelectMembers: "Odaberite članove koji imaju pristup stranici <strong>%0%</strong>",
    paMembers: "Posebna zaštita članova",
    paMembersHelp: "Ako želite dati pristup određenim članovima"
  },
  publish: {
    contentPublishedFailedAwaitingRelease: `
      %0% nije mogao biti objavljen jer je stavka zakazana za objavu.
    `,
    contentPublishedFailedExpired: `
      %0% nije mogao biti objavljen jer je stavka istekla.
    `,
    contentPublishedFailedInvalid: `
      %0% nije moglo biti objavljeno jer ova svojstva:  %1%  nisu prošla pravila validacije.
    `,
    contentPublishedFailedByEvent: `
      %0% nije mogao biti objavljen, dodatak treće strane je otkazao radnju.
    `,
    contentPublishedFailedByParent: `
      %0% ne može biti objavljena, jer roditeljska stranica nije objavljena.
    `,
    contentPublishedFailedByMissingName: "%0% ne može se objaviti jer mu nedostaje ime.",
    includeUnpublished: "Uključite neobjavljene podstranice",
    inProgress: "Objavljivanje u toku - molimo sačekajte...",
    inProgressCounter: "%0% od %1% stranica je objavljeno...",
    nodePublish: "%0% je objavljeno",
    nodePublishAll: "%0% i objavljene su podstranice",
    publishAll: "Objavi %0% i sve njegove podstranice",
    publishHelp: `Pritisni <em>Objavi</em> za objavu <strong>%0%</strong> i na taj način svoj sadržaj učiniti javno dostupnim.<br/><br />
      Ovu stranicu i sve njene podstranice možete objaviti odabirom <em>Uključi neobjavljene podstranice</em>.
      `
  },
  colorpicker: {
    noColors: "Niste konfigurirali nijednu odobrenu boju"
  },
  contentPicker: {
    allowedItemTypes: "Možete odabrati samo stavke tipa: %0%",
    pickedTrashedItem: "Odabrali ste stavku sadržaja koja je trenutno izbrisana ili je u korpi za otpatke",
    pickedTrashedItems: "Odabrali ste stavke sadržaja koje su trenutno izbrisane ili su u korpi za otpatke"
  },
  mediaPicker: {
    deletedItem: "Izbrisana stavka",
    pickedTrashedItem: "Odabrali ste medijsku stavku koja je trenutno izbrisana ili je u korpi za otpatke",
    pickedTrashedItems: "Odabrali ste medijske stavke koje su trenutno izbrisane ili su u korpi za otpatke",
    trashed: "Otpad",
    openMedia: "Otvorite u biblioteci medija",
    changeMedia: "Promjena medijske stavke",
    editMediaEntryLabel: "Uredi %0% od %1%",
    confirmCancelMediaEntryCreationHeadline: "Odbaci kreiranje?",
    confirmCancelMediaEntryCreationMessage: "Jeste li sigurni da želite otkazati kreiranje.",
    confirmCancelMediaEntryHasChanges: `Izmijenili ste ovaj sadržaj. Jeste li sigurni da ga želite
       odbaciti?
    `,
    confirmRemoveAllMediaEntryMessage: "Uklonite sve medije?",
    tabClipboard: "Međuspremnik",
    notAllowed: "Nije dozvoljeno",
    openMediaPicker: "Otvorite birač medija"
  },
  relatedlinks: {
    enterExternal: "unesite eksterni link",
    chooseInternal: "izaberite internu stranicu",
    caption: "Naslov",
    link: "Link",
    newWindow: "Otvori u novom prozoru",
    captionPlaceholder: "unesite natpis na ekranu",
    externalLinkPlaceholder: "Unesite link"
  },
  imagecropper: {
    reset: "Resetujte izrezivanje",
    updateEditCrop: "Gotovo",
    undoEditCrop: "Poništi izmjene",
    customCrop: "Korisnički definisano"
  },
  rollback: {
    changes: "Promjene",
    created: "Kreirano",
    currentVersion: "Trenutna verzija",
    diffHelp: "Ovo pokazuje razlike između trenutne verzije (nacrta) i odabrane verzije<br /><del>Crveni tekst</del> će biti uklonjen u odabranoj verziji, <ins>zeleni tekst</ins> će biti dodan",
    noDiff: "Nema razlike između trenutne verzije (nacrta) i odabrane verzije",
    documentRolledBack: "Dokument je vraćen",
    headline: "Odaberite verziju koju želite usporediti sa trenutnom verzijom",
    htmlHelp: `Ovo prikazuje odabranu verziju kao HTML, ako želite vidjeti razliku između dvije
       verzije u isto vrijeme, koristite pogled diff
    `,
    rollbackTo: "Vratite se na",
    selectVersion: "Odaberite verziju",
    view: "Pogled"
  },
  scripts: {
    editscript: "Uredite datoteku skripte"
  },
  sections: {
    concierge: "Portirnica",
    content: "Sadržaj",
    courier: "Kurir",
    developer: "Developer",
    forms: "Forme",
    help: "Pomoć",
    installer: "Umbraco Konfiguracijski Čarobnjak",
    media: "Mediji",
    member: "Članovi",
    newsletters: "Bilteni",
    packages: "Paketi",
    marketplace: "Marketplace",
    settings: "Postavke",
    statistics: "Statistika",
    translation: "Prevodi",
    users: "Korisnici"
  },
  help: {
    tours: "Ture",
    theBestUmbracoVideoTutorials: "Najbolji Umbraco video tutorijali",
    umbracoForum: "Posjetite our.umbraco.com",
    umbracoTv: "Posjetite umbraco.tv",
    umbracoLearningBase: "Pogledajte naše besplatne video tutoriale",
    umbracoLearningBaseDescription: "na Umbraco Learning Base"
  },
  settings: {
    defaulttemplate: "Podrazumevani šablon",
    importDocumentTypeHelp: `Da biste uvezli vrstu dokumenta, pronađite ".udt" datoteku na svom računaru klikom na
       dugme "Uvezi" (na sljedećem ekranu će se tražiti da potvrdite)
    `,
    newtabname: "Naslov nove kartice",
    nodetype: "Tip čvora",
    objecttype: "Tip",
    stylesheet: "Stilovi",
    script: "Skripte",
    tab: "Kartica",
    tabname: "Naslov kartice",
    tabs: "Kartice",
    contentTypeEnabled: "Glavni tip sadržaja je omogućen",
    contentTypeUses: "Ovaj tip sadržaja koristi",
    noPropertiesDefinedOnTab: `Nema definiranih svojstava na ovoj kartici. Kliknite na vezu "dodaj novu nekretninu" na
       vrh za kreiranje novog svojstva.
    `,
    createMatchingTemplate: "Kreirajte odgovarajući šablon",
    addIcon: "Dodaj ikonu"
  },
  sort: {
    sortOrder: "Redoslijed sortiranja",
    sortCreationDate: "Datum kreiranja",
    sortDone: "Sortiranje završeno.",
    sortHelp: `Povucite različite stavke gore ili dolje ispod da postavite kako bi trebale biti raspoređene. Ili kliknite na
       zaglavlja kolona za sortiranje cijele kolekcije stavki
    `,
    sortPleaseWait: "Pričekajte. Stavke se sortiraju, ovo može potrajati."
  },
  speechBubbles: {
    validationFailedHeader: "Validacija",
    validationFailedMessage: "Greške u validaciji moraju biti ispravljene pre nego što se stavka može sačuvati",
    operationFailedHeader: "Nije uspjelo",
    operationSavedHeader: "Sačuvano",
    invalidUserPermissionsText: "Nedovoljne korisničke dozvole, ne mogu dovršiti operaciju",
    operationCancelledHeader: "Otkazano",
    operationCancelledText: "Operaciju je otkazao dodatak treće strane",
    folderUploadNotAllowed: "Ovaj fajl se učitava kao deo fascikle, ali kreiranje novog foldera ovde nije dozvoljeno",
    folderCreationNotAllowed: "Kreiranje novog foldera ovdje nije dozvoljeno",
    contentPublishedFailedByEvent: "Objavljivanje je otkazao dodatak treće strane",
    contentTypeDublicatePropertyType: "Tip svojstva već postoji",
    contentTypePropertyTypeCreated: "Tip svojstva kreiran",
    contentTypePropertyTypeCreatedText: "Naziv: %0% <br /> Tip podatka: %1%",
    contentTypePropertyTypeDeleted: "Tip svojstva obrisan",
    contentTypeSavedHeader: "Tip dokumenta sačuvan",
    contentTypeTabCreated: "Kartica kreirana",
    contentTypeTabDeleted: "Kartica je izbrisana",
    contentTypeTabDeletedText: "Kartica sa id-em: %0% je obrisana",
    cssErrorHeader: "Stilovi nisu sačuvani",
    cssSavedHeader: "Stilovi sačuvani",
    cssSavedText: "Stilovi sačuvani bez ikakvih grešaka",
    dataTypeSaved: "Tip podatka sačuvan",
    dictionaryItemSaved: "Stavka rječnika je sačuvana",
    editContentPublishedFailedByParent: "Objavljivanje nije uspjelo jer nadređena stranica nije objavljena",
    editContentPublishedHeader: "Sadržaj objavljen",
    editContentPublishedText: "i vidljivo na web stranici",
    editBlueprintSavedHeader: "Šablon sadržaja je sačuvan",
    editBlueprintSavedText: "Promjene su uspješno sačuvane",
    editContentSavedHeader: "Sadržaj sačuvan",
    editContentSavedText: "Ne zaboravite objaviti da promjene budu vidljive",
    editContentSendToPublish: "Poslano na odobrenje",
    editContentSendToPublishText: "Promjene su poslane na odobrenje",
    editMediaSaved: "Medij sačuvan",
    editMediaSavedText: "Medij sačuvan bez ikakvih grešaka",
    editMemberSaved: "Član sačuvan",
    editStylesheetPropertySaved: "Svojstvo stilova sačuvano",
    editStylesheetSaved: "Stilovi sačuvani",
    editTemplateSaved: "Šablon sačuvan",
    editUserError: "Greška pri spremanju korisnika (provjerite log)",
    editUserSaved: "Korisnik sačuvan",
    editUserTypeSaved: "Tip korisnika sačuvan",
    editUserGroupSaved: "Grupa korisnika sačuvana",
    editCulturesAndHostnamesSaved: "Kulture i imena hostova su sačuvani",
    editCulturesAndHostnamesError: "Greška pri spremanju kultura i imena hostova",
    fileErrorHeader: "Fajl nije sačuvan",
    fileErrorText: "fajl nije mogao biti sačuvan. Molimo provjerite dozvole za fajlove",
    fileSavedHeader: "Fajl sačuvan",
    fileSavedText: "Fajl sačuvan bez ikakvih grešaka",
    languageSaved: "Jezik sačuvan",
    mediaTypeSavedHeader: "Tip medija sačuvan",
    memberTypeSavedHeader: "Tip člana sačuvan",
    memberGroupSavedHeader: "Grupa članova sačuvana",
    memberGroupNameDuplicate: "Druga grupa članova sa istim imenom već postoji",
    templateErrorHeader: "Šablon nije sačuvan",
    templateErrorText: "Uvjerite se da nemate 2 šablona sa istim pseudonimom",
    templateSavedHeader: "Šablon sačuvan",
    templateSavedText: "Šablon sačuvan bez ikakvih grešaka!",
    contentUnpublished: "Sadržaj nije objavljen",
    partialViewSavedHeader: "Djelomični prikaz sačuvan",
    partialViewSavedText: "Djelomični prikaz sačuvan bez ikakvih grešaka!",
    partialViewErrorHeader: "Djelomični prikaz nije sačuvan",
    partialViewErrorText: "Došlo je do greške prilikom spremanja fajla.",
    permissionsSavedFor: "Dozvole su sačuvane za",
    deleteUserGroupsSuccess: "Izbrisano je %0% grupa korisnika",
    deleteUserGroupSuccess: "%0% je obrisano",
    enableUsersSuccess: "Omogućeno %0% korisnika",
    disableUsersSuccess: "Onemogućeno %0% korisnika",
    enableUserSuccess: "%0% je sada omogućen",
    disableUserSuccess: "%0% je sada onemogućen",
    setUserGroupOnUsersSuccess: "Grupe korisnika su postavljene",
    unlockUsersSuccess: "Otključano %0% korisnika",
    unlockUserSuccess: "%0% je sada otključan",
    memberExportedSuccess: "Član je izvezen u fajl",
    memberExportedError: "Došlo je do greške prilikom izvoza člana",
    deleteUserSuccess: "Korisnik %0% je obrisan",
    resendInviteHeader: "Pozovi korisnika",
    resendInviteSuccess: "Pozivnica je ponovo poslana na %0%",
    documentTypeExportedSuccess: "Tip dokumenta je izvezen u fajl",
    documentTypeExportedError: "Došlo je do greške prilikom izvoza tipa dokumenta",
    dictionaryItemExportedSuccess: "Stavke iz rječnika su izvezene u fajl",
    dictionaryItemExportedError: "Došlo je do greške prilikom izvoza stavki rječnika",
    dictionaryItemImported: "Sljedeće stavke iz rječnika su uvezene!",
    publishWithNoDomains: `Domene nisu konfigurirane za višejezične stranice, molimo kontaktirajte administratora,
       pogledajte dnevnik za više informacija
    `,
    publishWithMissingDomain: `Nijedan domen nije konfigurisan za %0%, molimo kontaktirajte administratora, pogledajte
       prijavite se za više informacija
    `,
    copySuccessMessage: "Vaše sistemske informacije su uspješno kopirane u međuspremnik",
    cannotCopyInformation: "Nije moguće kopirati vaše sistemske informacije u međuspremnik"
  },
  stylesheet: {
    addRule: "Dodaj stil",
    editRule: "Uredi stil",
    editorRules: "Stilovi za uređivanje bogatog teksta",
    editorRulesHelp: `Definirajte stilove koji bi trebali biti dostupni u uređivaču obogaćenog teksta za ove
	   stilove
    `,
    editstylesheet: "Uredi stilove",
    editstylesheetproperty: "Uredi svojstvo stilova",
    nameHelp: "Ime prikazano u uređivaču birača stilova",
    preview: "Pregled",
    previewHelp: "Kako će tekst izgledati u uređivaču obogaćenog teksta.",
    selector: "Selektor",
    selectorHelp: 'Koristite CSS sintaksu, npr. "h1" ili ".redHeader"',
    styles: "Stilovi",
    stylesHelp: 'CSS koji treba primijeniti u uređivaču obogaćenog teksta, npr. "color:red;"',
    tabCode: "Kod",
    tabRules: "Uređivač"
  },
  template: {
    runtimeModeProduction: "Sadržaj se ne može uređivati kada se koristi način rada <code>Produkcija</code>.",
    deleteByIdFailed: "Brisanje šablona sa ID-om %0% nije uspjelo",
    edittemplate: "Uredi šablon",
    insertSections: "Sekcije",
    insertContentArea: "Umetnite područje sadržaja",
    insertContentAreaPlaceHolder: "Umetnite čuvar mjesta u području sadržaja",
    insert: "Umetni",
    insertDesc: "Odaberite šta ćete umetnuti u svoj šablon",
    insertDictionaryItem: "Stavka iz rječnika",
    insertDictionaryItemDesc: `Stavka rječnika je čuvar mjesta za prevodljiv dio teksta, koji
       olakšava kreiranje dizajna za višejezične web stranice.
    `,
    insertMacro: "Makro",
    insertMacroDesc: `
       Makro je komponenta koja se može konfigurirati i odlična je za
       višekratni dijelovi vašeg dizajna, gdje vam je potrebna opcija za pružanje parametara,
       kao što su galerije, obrasci i liste.
    `,
    insertPageField: "Vrijednost",
    insertPageFieldDesc: `Prikazuje vrijednost imenovanog polja sa trenutne stranice, s opcijama za izmjenu
       vrijednost ili povratak na alternativne vrijednosti.
    `,
    insertPartialView: "Djelomičan pogled",
    insertPartialViewDesc: `
       Djelomični prikaz je zasebna datoteka šablona koja se može prikazati unutar druge
       predložak, odličan je za ponovnu upotrebu markupa ili za odvajanje složenih predložaka u zasebne datoteke.
    `,
    mastertemplate: "Master šablon",
    noMaster: "Nema mastera",
    renderBody: "Renderirajte podređeni predložak",
    renderBodyDesc: `
     Renderira sadržaj podređenog predloška, umetanjem
     <code>@RenderBody()</code>.
      `,
    defineSection: "Definirajte imenovanu sekciju",
    defineSectionDesc: `
         Definira dio vašeg predloška kao imenovanu sekciju tako što ga umotava
          <code>@section { ... }</code>. Ovo se može prikazati u
           određenom području nadređenog predloška, koristeći <code>@RenderSection</code>.
      `,
    renderSection: "Renderirajte imenovanu sekciju",
    renderSectionDesc: `
      Renderira imenovano područje podređenog predloška, umetanjem <code>@RenderSection(name)</code>.
      Ovo prikazuje područje podređenog šablona koje je umotano u odgovarajuću <code>@section [name]{ ... }</code> definiciju.
      `,
    sectionName: "Naziv sekcije",
    sectionMandatory: "Sekcija je obavezna",
    sectionMandatoryDesc: `
            Ako je obavezan, podređeni predložak mora sadržavati <code>@section</code>, u suprotnom se prikazuje greška.
    `,
    queryBuilder: "Kreator upita",
    itemsReturned: "stavke vraćene, u",
    iWant: "želim",
    allContent: "sav sadržaj",
    contentOfType: 'sadržaj tipa "%0%"',
    from: "iz",
    websiteRoot: "moja web stranica",
    where: "gdje",
    and: "i",
    is: "je",
    isNot: "nije",
    before: "prije",
    beforeIncDate: "prije (uključujući odabrani datum)",
    after: "poslije",
    afterIncDate: "poslije (uključujući odabrani datum)",
    equals: "jednako",
    doesNotEqual: "nije jednako",
    contains: "sadrži",
    doesNotContain: "ne sadrži",
    greaterThan: "veće od",
    greaterThanEqual: "veće ili jednako",
    lessThan: "manje od",
    lessThanEqual: "manje ili jednako",
    id: "Id",
    name: "Naziv",
    createdDate: "Kreirano",
    lastUpdatedDate: "Ažurirano",
    orderBy: "poredaj po",
    ascending: "uzlazno",
    descending: "silazno",
    template: "Predložak"
  },
  grid: {
    media: "Slika",
    macro: "Makro",
    insertControl: "Odaberite tip sadržaja",
    chooseLayout: "Odaberite izgled",
    addRows: "Dodaj red",
    addElement: "Dodaj sadržaj",
    dropElement: "Ispusti sadržaj",
    settingsApplied: "Postavke su primijenjene",
    contentNotAllowed: "Ovaj sadržaj ovdje nije dozvoljen",
    contentAllowed: "Ovaj sadržaj je ovdje dozvoljen",
    clickToEmbed: "Kliknite za ugradnju",
    clickToInsertImage: "Kliknite da umetnete sliku",
    clickToInsertMacro: "Kliknite da umetnete makro",
    placeholderWriteHere: "Pišite ovdje...",
    gridLayouts: "Raspored mreže",
    gridLayoutsDetail: `Izgledi su cjelokupno radno područje za uređivač mreže, obično vam je potreban samo jedan ili
       dva različita izgleda
    `,
    addGridLayout: "Dodajte raspored mreže",
    editGridLayout: "Uredite raspored mreže",
    addGridLayoutDetail: "Prilagodite izgled postavljanjem širine kolona i dodavanjem dodatnih odjeljaka",
    rowConfigurations: "Konfiguracije redova",
    rowConfigurationsDetail: "Redovi su predefinirani za raspored vodoravno",
    addRowConfiguration: "Dodajte konfiguraciju reda",
    editRowConfiguration: "Uredite konfiguraciju reda",
    addRowConfigurationDetail: "Podesite red postavljanjem širine ćelija i dodavanjem dodatnih ćelija",
    noConfiguration: "Nije dostupna dodatna konfiguracija",
    columns: "Kolone",
    columnsDetails: "Ukupan kombinovani broj kolona u rasporedu mreže",
    settings: "Postavke",
    settingsDetails: "Konfigurirajte koje postavke urednici mogu promijeniti",
    styles: "Stilovi",
    stylesDetails: "Konfigurirajte šta uređivači stilova mogu promijeniti",
    allowAllEditors: "Dozvoli svim urednicima",
    allowAllRowConfigurations: "Dozvoli sve konfiguracije redaka",
    maxItems: "Maksimalan broj stavki",
    maxItemsDescription: "Ostavite prazno ili postavite na 0 za neograničeno",
    setAsDefault: "Postavi kao zadano",
    chooseExtra: "Odaberite extra",
    chooseDefault: "Odaberite zadano",
    areAdded: "su dodani",
    warning: "Upozorenje",
    warningText: "<p>Promjena imena konfiguracije reda će rezultirati gubitkom podataka za bilo koji postojeći sadržaj koji se temelji na ovoj konfiguraciji.</p> <p><strong>Izmjena samo oznake neće rezultirati gubitkom podataka.</strong></p>",
    youAreDeleting: "Brišete konfiguraciju reda",
    deletingARow: `
      Brisanje imena konfiguracije reda će rezultirati gubitkom podataka za bilo koji postojeći sadržaj koji je zasnovan na ovome
      konfiguraciju.
    `,
    deleteLayout: "Brišete izgled",
    deletingALayout: `Izmjena izgleda će rezultirati gubitkom podataka za bilo koji postojeći sadržaj koji je zasnovan
       na ovoj konfiguraciji.
    `
  },
  contentTypeEditor: {
    compositions: "Kompozicije",
    group: "Grupa",
    noGroups: "Niste dodali nijednu grupu",
    addGroup: "Dodaj grupu",
    inheritedFrom: "Naslijeđeno od",
    addProperty: "Dodaj svojstvo",
    requiredLabel: "Obavezna oznaka",
    enableListViewHeading: "Omogući prikaz liste",
    enableListViewDescription: `Konfiguriše stavku sadržaja da prikaže njenu listu koja se može sortirati i pretraživati
      djeco, djeca neće biti prikazana na drvetu
    `,
    allowedTemplatesHeading: "Dozvoljeni predlošci",
    allowedTemplatesDescription: `Odaberite koje predloške urednici mogu koristiti na sadržaju ove vrste
    `,
    allowAsRootHeading: "Dozvoli kao korijen",
    allowAsRootDescription: `Dozvolite urednicima da kreiraju sadržaj ovog tipa u korijenu stabla sadržaja.
    `,
    childNodesHeading: "Dozvoljeni tipovi podređenih čvorova",
    childNodesDescription: `Dozvolite da se sadržaj navedenih tipova kreira ispod sadržaja ovog
      tip.
    `,
    chooseChildNode: "Odaberite podređeni čvor",
    compositionsDescription: `Naslijediti kartice i svojstva iz postojeće vrste dokumenta. Nove kartice će biti
      dodano trenutnoj vrsti dokumenta ili spojeno ako postoji kartica s identičnim imenom.
    `,
    compositionInUse: `Ovaj tip sadržaja se koristi u kompoziciji i stoga se ne može sam sastaviti.
    `,
    noAvailableCompositions: "Nema dostupnih tipova sadržaja za upotrebu kao kompozicija.",
    compositionRemoveWarning: `Uklanjanje kompozicije će izbrisati sve povezane podatke o svojstvu. Jednom ti
      sačuvajte tip dokumenta, nema povratka.
    `,
    availableEditors: "Napravi novi",
    reuse: "Koristite postojeće",
    editorSettings: "Postavke urednika",
    configuration: "Konfiguracija",
    yesDelete: "Da, izbriši",
    movedUnderneath: "je premještena ispod",
    copiedUnderneath: "je kopirano ispod",
    folderToMove: "Odaberite folder za premještanje",
    folderToCopy: "Odaberite folder za kopiranje",
    structureBelow: "do u strukturi stabla ispod",
    allDocumentTypes: "Svi tipovi dokumenata",
    allDocuments: "Svi dokumenti",
    allMediaItems: "Sve medijske stavke",
    usingThisDocument: `korištenje ovog tipa dokumenta će biti trajno izbrisano, potvrdite da želite
       izbrišite i ove.
    `,
    usingThisMedia: `korištenje ove vrste medija će biti trajno izbrisano, potvrdite da želite izbrisati
       ovi takođe.
    `,
    usingThisMember: `korištenje ove vrste člana će biti trajno izbrisano, potvrdite da želite izbrisati
       ovi takođe
    `,
    andAllDocuments: "i svi dokumenti koji koriste ovu vrstu",
    andAllMediaItems: "i sve medijske stavke koje koriste ovu vrstu",
    andAllMembers: "i svi članovi koji koriste ovaj tip",
    memberCanEdit: "Član može uređivati",
    memberCanEditDescription: "Dozvolite da ovu vrijednost svojstva uređuje član na svojoj stranici profila",
    isSensitiveData: "Osjetljivi podaci",
    isSensitiveDataDescription: "Sakrij ovu vrijednost svojstva od uređivača sadržaja koji nemaju pristup pregledu osjetljive informacije",
    showOnMemberProfile: "Prikaži na profilu člana",
    showOnMemberProfileDescription: "Dozvolite da se ova vrijednost svojstva prikaže na stranici profila člana",
    tabHasNoSortOrder: "kartica nema redoslijed sortiranja",
    compositionUsageHeading: "Gdje se koristi ovaj sastav?",
    compositionUsageSpecification: `Ovaj sastav se trenutno koristi u sastavu sljedećih
      tipa sadržaja:
    `,
    variantsHeading: "Dozvoli varijacije",
    cultureVariantHeading: "Dozvolite varirati u zavisnosti od kulture",
    segmentVariantHeading: "Dozvoli segmentaciju",
    cultureVariantLabel: "Varijacije po kulturi",
    segmentVariantLabel: "Varijacije po segmentima",
    variantsDescription: "Dozvolite urednicima da kreiraju sadržaj ove vrste na različitim jezicima.",
    cultureVariantDescription: "Dozvolite urednicima da kreiraju sadržaj na različitim jezicima.",
    segmentVariantDescription: "Dozvolite urednicima da kreiraju segmente ovog sadržaja.",
    allowVaryByCulture: "Dozvolite varijaciju po kulturi",
    allowVaryBySegment: "Dozvoli segmentaciju",
    elementType: "Tip elementa",
    elementHeading: "Je li tip elementa",
    elementDescription: `Tip elementa je namijenjen za korištenje na primjer u ugniježđenom sadržaju, a ne u
      drvo.
    `,
    elementCannotToggle: `Tip dokumenta se ne može promijeniti u tip elementa nakon što je naviknut
      kreirati jednu ili više stavki sadržaja.
    `,
    elementDoesNotSupport: "Ovo nije primjenjivo za tip elementa",
    propertyHasChanges: "Napravili ste promjene u ovoj nekretnini. Jeste li sigurni da ih želite odbaciti?",
    displaySettingsHeadline: "Izgled",
    displaySettingsLabelOnTop: "Oznaka iznad (puna širina)",
    removeChildNode: "Uklanjate podređeni čvor",
    removeChildNodeWarning: `Uklanjanje podređenog čvora ograničit će opcije urednika da kreiraju drugačiji sadržaj
      tipovi ispod čvora.
    `,
    usingEditor: "korišćenjem ovog uređivača biće ažurirane nove postavke.",
    historyCleanupHeading: "Čišćenje istorije",
    historyCleanupDescription: "Dozvoli zaobilaženje postavki čišćenja globalne historije.",
    historyCleanupKeepAllVersionsNewerThanDays: "Neka sve verzije budu novije od dana",
    historyCleanupKeepLatestVersionPerDayForDays: "Čuvajte najnoviju verziju po danu danima",
    historyCleanupPreventCleanup: "Spriječi čišćenje",
    historyCleanupEnableCleanup: "Omogući čišćenje",
    historyCleanupGloballyDisabled: "<strong>BILJEŠKA!</strong> Čišćenje istorijskih verzija sadržaja onemogućeno je globalno. Ove postavke neće stupiti na snagu prije nego što se omogući."
  },
  languages: {
    addLanguage: "Dodaj jezik",
    culture: "ISO kod",
    mandatoryLanguage: "Obavezan jezik",
    mandatoryLanguageHelp: `Svojstva na ovom jeziku moraju biti popunjena prije nego što se čvor može ispuniti
      objavljeno.
    `,
    defaultLanguage: "Zadani jezik",
    defaultLanguageHelp: "Umbraco stranica može imati samo jedan zadani jezik.",
    changingDefaultLanguageWarning: "Promjena zadanog jezika može rezultirati nedostatkom zadanog sadržaja.",
    fallsbackToLabel: "Vraća se na",
    noFallbackLanguageOption: "Nema zamjenskog jezika",
    fallbackLanguageDescription: `Da se omogući višejezični sadržaj da se vrati na drugi jezik ako ne
      bude prisutan na traženom jeziku, odaberite ga ovdje.
    `,
    fallbackLanguage: "Zamjenski jezik",
    none: "nijedan"
  },
  macro: {
    addParameter: "Dodaj parameter",
    editParameter: "Uredi parameter",
    enterMacroName: "Unesite naziv makroa",
    parameters: "Parametri",
    parametersDescription: "Definišite parametre koji bi trebali biti dostupni kada koristite ovaj makro.",
    selectViewFile: "Odaberite djelimični prikaz makro datoteke"
  },
  modelsBuilder: {
    buildingModels: "Kreiranje modela",
    waitingMessage: "ovo može potrajati, ne brinite",
    modelsGenerated: "Modeli generisani",
    modelsGeneratedError: "Models nije mogao biti generisani",
    modelsExceptionInUlog: "Generisanje modela nije uspjelo, pogledajte izuzetak u log dnevniku"
  },
  templateEditor: {
    addDefaultValue: "Dodajte zadanu vrijednost",
    defaultValue: "Zadana vrijednost",
    alternativeField: "Rezervno polje",
    alternativeText: "Zadana vrijednost",
    casing: "Veličina slova",
    encoding: "Kodiranje",
    chooseField: "Odaberite polje",
    convertLineBreaks: "Pretvorite prijelome redaka",
    convertLineBreaksHelp: "Zamjenjuje prijelome reda sa 'br' html oznakom",
    customFields: "Prilagođena polja",
    dateOnly: "Samo datum",
    formatAsDate: "Formatiraj kao datum",
    htmlEncode: "Kodirati kao HTML",
    htmlEncodeHelp: "Zamijenit će specijalne znakove njihovim HTML ekvivalentom.",
    insertedAfter: "Biće umetnuto iza vrednosti polja",
    insertedBefore: "Biće umetnuto ispred vrednosti polja",
    lowercase: "Mala slova",
    none: "Nema",
    outputSample: "Izlazni uzorak",
    postContent: "Umetnuti nakon polja",
    preContent: "Umetnuti ispred polja",
    recursive: "Rekurzivno",
    recursiveDescr: "Da, neka bude rekurzivno",
    standardFields: "Standardna polja",
    uppercase: "Velika slova",
    urlEncode: "Kodirati kao URL",
    urlEncodeHelp: "Formatirati će posebne znakove u URL-ovima",
    usedIfAllEmpty: "Koristit će se samo kada su vrijednosti polja iznad prazne",
    usedIfEmpty: "Ovo polje će se koristiti samo ako je primarno polje prazno",
    withTime: "Datum i vrijeme"
  },
  translation: {
    details: "Detalji prijevoda",
    DownloadXmlDTD: "Preuzmi XML DTD",
    fields: "Polja",
    includeSubpages: "Uključi podstranice",
    mailBody: `
      Zdravo %0%

      Ovo je automatska pošta koja vas obavještava da je za
	  dokument '%1%' zatražen prevod na '%5%' od %2%.

      Idi na http://%3%/translation/details.aspx?id=%4% za uređivanje.

      Ili se prijavite na Umbraco da biste dobili pregled vaših zadataka za prevod
      http://%3%

      Ugodan dan!
      Pozdrav od Umbraco robota
    `,
    noTranslators: `Nije pronađen nijedan korisnik prevodioca. Molimo kreirajte korisnika prevodioca prije nego počnete slati
       sadržaj u prijevod
    `,
    pageHasBeenSendToTranslation: "Stranica '%0%' je poslana na prijevod",
    sendToTranslate: "Pošaljite stranicu '%0%' u prijevod",
    totalWords: "Ukupno riječi",
    translateTo: "Prevedi na",
    translationDone: "Prevod završen.",
    translationDoneHelp: `Možete pregledati stranice koje ste upravo preveli klikom ispod. Ako je
       originalna stranica je pronađena, dobićete poređenje 2 stranice.
    `,
    translationFailed: "Prevod nije uspio, XML datoteka je možda oštećena",
    translationOptions: "Opcije prevođenja",
    translator: "Prevodilac",
    uploadTranslationXml: "Uvezite XML prijevod"
  },
  treeHeaders: {
    content: "Sadržaj",
    contentBlueprints: "Predlošci sadržaja",
    media: "Mediji",
    cacheBrowser: "Pretraživač keša",
    contentRecycleBin: "Kanta za smeće",
    createdPackages: "Kreirani paketi",
    dataTypes: "Tipovi podataka",
    dictionary: "Riječnik",
    installedPackages: "Instalirani paketi",
    installSkin: "Instaliraj skin",
    installStarterKit: "Instaliraj početnički kit",
    languages: "Jezici",
    localPackage: "Instaliraj lokalni paket",
    macros: "Makroi",
    mediaTypes: "Tipovi medija",
    member: "Članovi",
    memberGroups: "Grupe članova",
    memberRoles: "Uloge članova",
    memberTypes: "Tipovi članova",
    documentTypes: "Tipovi dokumenata",
    relationTypes: "Tipovi relacija",
    packager: "Paketi",
    packages: "Paketi",
    partialViews: "Parcijalni pogledi",
    partialViewMacros: "Parcijalni pregledi makro fajlova",
    repositories: "Instaliraj iz repozitorija",
    runway: "Instaliraj Runway",
    runwayModules: "Runway moduli",
    scripting: "Skripte",
    scripts: "Skripte",
    stylesheets: "Stilovi",
    templates: "Predlošci",
    logViewer: "Log preglednik",
    users: "Korisnici",
    settingsGroup: "Postavke",
    templatingGroup: "Predložak",
    thirdPartyGroup: "Treća strana"
  },
  update: {
    updateAvailable: "Novo ažuriranje spremno",
    updateDownloadText: "%0% je spremno, kliknite ovdje za preuzimanje",
    updateNoServer: "Nema konekcije sa serverom",
    updateNoServerError: "Greška pri provjeri ažuriranja. Molimo pregledajte log za dodatne informacije"
  },
  user: {
    access: "Pristup",
    accessHelp: `Na osnovu dodijeljenih grupa i početnih čvorova, korisnik ima pristup sljedećim čvorovima
    `,
    assignAccess: "Dodijeli pristup",
    administrators: "Administrator",
    categoryField: "Polje kategorije",
    createDate: "Korisnik kreiran",
    changePassword: "Promijeni lozinku",
    changePhoto: "Promijeni sliku",
    newPassword: "Nova lozinka",
    newPasswordFormatLengthTip: "Najmanje %0% znakova!",
    newPasswordFormatNonAlphaTip: "Trebalo bi biti najmanje %0% specijalnih znakova.",
    noLockouts: "nije zaključan",
    noPasswordChange: "Lozinka nije promijenjena",
    confirmNewPassword: "Potvrdite novu lozinku",
    changePasswordDescription: `Možete promijeniti lozinku za pristup Umbraco backofficeu popunjavanjem
       izađite iz donjeg obrasca i kliknite na dugme 'Promijeni lozinku'
    `,
    contentChannel: "Kanal sadržaja",
    createAnotherUser: "Kreirajte drugog korisnika",
    createUserHelp: `Kreirajte nove korisnike da im date pristup Umbraco. Kada se novom korisniku kreira lozinka
       će biti generisano koje možete podijeliti s korisnikom.
    `,
    descriptionField: "Polje za opis",
    disabled: "Onemogući korisnika",
    documentType: "Tip dokumenta",
    editors: "Urednik",
    emailRequired: "Obavezno - unesite email adresu za ovog korisnika",
    excerptField: "Polje izvoda",
    failedPasswordAttempts: "Neuspjeli pokušaji prijave",
    goToProfile: "Idite na korisnički profil",
    groupsHelp: "Dodajte grupe za dodjelu pristupa i dozvola",
    inviteAnotherUser: "Pozovite drugog korisnika",
    inviteUserHelp: `Pozovite nove korisnike da im daju pristup Umbraco. E-mail sa pozivom će biti poslan na
       korisnik s informacijama o tome kako se prijaviti na Umbraco. Pozivnice traju 72 sata.
    `,
    language: "Jezik",
    languageHelp: "Podesite jezik koji ćete videti u menijima i dijalozima",
    lastLockoutDate: "Zadnji datum zaključavanja",
    lastLogin: "Zadnja prijava",
    lastPasswordChangeDate: "Lozinka zadnji put promijenjena",
    loginname: "Korisničko ime",
    mediastartnode: "Medijski startni čvor",
    mediastartnodehelp: "Ograničite biblioteku medija na određeni početni čvor",
    mediastartnodes: "Medijski startni čvorovi",
    mediastartnodeshelp: "Ograničite biblioteku medija na određene početne čvorove",
    modules: "Sekcije",
    nameRequired: "Obavezno - unesite ime za ovog korisnika",
    noConsole: "Onemogućite pristup Umbraco-u",
    noLogin: "se još nije prijavio",
    oldPassword: "Stara lozinka",
    password: "Lozinka",
    resetPassword: "Reset lozinke",
    passwordChanged: "Vaša lozinka je promijenjena!",
    passwordChangedGeneric: "Lozinka je promijenjena",
    passwordConfirm: "Molimo potvrdite novu lozinku",
    passwordEnterNew: "Unesite novu lozinku",
    passwordIsBlank: "Vaša nova lozinka ne može biti prazna!",
    passwordCurrent: "Trenutna lozinka",
    passwordInvalid: "Nevažeća trenutna lozinka",
    passwordIsDifferent: `Postojala je razlika između nove lozinke i potvrđene lozinke. Molim te
      pokušaj ponovo!
    `,
    passwordMismatch: "Potvrđena lozinka ne odgovara novoj lozinki!",
    permissionReplaceChildren: "Zamijenite dozvole podređenog čvora",
    permissionSelectedPages: "Trenutno mijenjate dozvole za stranice:",
    permissionSelectPages: "Odaberite stranice da promijenite njihove dozvole",
    removePhoto: "Ukloni sliku",
    permissionsDefault: "Zadane dozvole",
    permissionsGranular: "Detaljne dozvole",
    permissionsGranularHelp: "Postavite dozvole za određene čvorove",
    profile: "Profil",
    searchAllChildren: "Pretražite svu djecu",
    languagesHelp: "Ograničite jezike kojima korisnici imaju pristup za uređivanje",
    sectionsHelp: "Dodajte odjeljke da korisnicima omogućite pristup",
    selectUserGroups: "Odaberite grupe korisnika",
    noStartNode: "Nije odabran početni čvor",
    noStartNodes: "Nije odabran nijedan početni čvor",
    startnode: "Početni čvor sadržaja",
    startnodehelp: "Ograničite stablo sadržaja na određeni početni čvor",
    startnodes: "Početni čvorovi sadržaja",
    startnodeshelp: "Ograničite stablo sadržaja na određene početne čvorove",
    updateDate: "Korisnik zadnji put ažuriran",
    userCreated: "je kreiran",
    userCreatedSuccessHelp: `Novi korisnik je uspješno kreiran. Za prijavu na Umbraco koristite
      lozinka ispod.
    `,
    userManagement: "Upravljanje korisnicima",
    username: "Korisničko ime",
    userPermissions: "Korisničke dozvole",
    usergroup: "Grupa korisnika",
    userInvited: "je pozvan",
    userInvitedSuccessHelp: `Novom korisniku je poslana pozivnica s detaljima o tome kako se prijaviti
      Umbraco.
    `,
    userinviteWelcomeMessage: "Pozdrav i dobrodošli u Umbraco! Za samo 1 minut možete krenuti, mi samo trebate postaviti lozinku.",
    userinviteExpiredMessage: `Dobrodošli u Umbraco! Nažalost, vaš poziv je istekao. Molimo kontaktirajte svoju
      administratora i zamolite ih da ga ponovo pošalju.
    `,
    writer: "Pisac",
    change: "Promjena",
    yourProfile: "Vaš profil",
    yourHistory: "Vaša nedavna istorija",
    sessionExpires: "Sesija ističe za",
    inviteUser: "Pozovi korisnika",
    createUser: "Kreiraj korisnika",
    sendInvite: "Pošalji pozivnicu",
    backToUsers: "Nazad na korisnike",
    inviteEmailCopySubject: "Umbraco: Pozivnica",
    inviteEmailCopyFormat: `
        <html>
			<head>
				<meta name='viewport' content='width=device-width'>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
			</head>
			<body class='' style='font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; color: #392F54; line-height: 22px; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background: #1d1333; margin: 0; padding: 0;' bgcolor='#1d1333'>
				<style type='text/css'> @media only screen and (max-width: 620px) {table[class=body] h1 {font-size: 28px !important; margin-bottom: 10px !important; } table[class=body] .wrapper {padding: 32px !important; } table[class=body] .article {padding: 32px !important; } table[class=body] .content {padding: 24px !important; } table[class=body] .container {padding: 0 !important; width: 100% !important; } table[class=body] .main {border-left-width: 0 !important; border-radius: 0 !important; border-right-width: 0 !important; } table[class=body] .btn table {width: 100% !important; } table[class=body] .btn a {width: 100% !important; } table[class=body] .img-responsive {height: auto !important; max-width: 100% !important; width: auto !important; } } .btn-primary table td:hover {background-color: #34495e !important; } .btn-primary a:hover {background-color: #34495e !important; border-color: #34495e !important; } .btn  a:visited {color:#FFFFFF;} </style>
				<table border="0" cellpadding="0" cellspacing="0" class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;" bgcolor="#1d1333">
					<tr>
						<td style="font-family: sans-serif; font-size: 14px; vertical-align: top; padding: 24px;" valign="top">
							<table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;">
								<tr>
									<td background="https://umbraco.com/umbraco/assets/img/application/logo.png" bgcolor="#1d1333" width="28" height="28" valign="top" style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
										<!--[if gte mso 9]> <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:30px;height:30px;"> <v:fill type="tile" src="https://umbraco.com/umbraco/assets/img/application/logo.png" color="#1d1333" /> <v:textbox inset="0,0,0,0"> <![endif]-->
<div></div>
<!--[if gte mso 9]> </v:textbox> </v:rect> <![endif]-->
</td>
<td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top"></td>
</tr>
</table>
</td>
</tr>
</table>
<table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;' bgcolor='#1d1333'>
<tr>
<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'></td>
<td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 560px; width: 560px; margin: 0 auto; padding: 10px;' valign='top'>
<div class='content' style='box-sizing: border-box; display: block; max-width: 560px; margin: 0 auto; padding: 10px;'>
<br>
<table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; border-radius: 3px; background: #FFFFFF;' bgcolor='#FFFFFF'>
<tr>
<td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 50px;' valign='top'>
<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
<tr>
<td style='line-height: 24px; font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'>
<h1 style='color: #392F54; font-family: sans-serif; font-weight: bold; line-height: 1.4; font-size: 24px; text-align: left; text-transform: capitalize; margin: 0 0 30px;' align='left'>
															Zdravo %0%,
														</h1>
<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Pozvani ste od <a href="mailto:%4%" style="text-decoration: underline; color: #392F54; -ms-word-break: break-all; word-break: break-all;">%1%</a> u Umbraco Back Office.
														</p>
<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Poruka od <a href="mailto:%1%" style="text-decoration: none; color: #392F54; -ms-word-break: break-all; word-break: break-all;">%1%</a>:
															<br/>
<em>%2%</em>
</p>
<table border='0' cellpadding='0' cellspacing='0' class='btn btn-primary' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; box-sizing: border-box;'>
<tbody>
<tr>
<td align='left' style='font-family: sans-serif; font-size: 14px; vertical-align: top; padding-bottom: 15px;' valign='top'>
<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
<tbody>
<tr>
<td style='font-family: sans-serif; font-size: 14px; vertical-align: top; border-radius: 5px; text-align: center; background: #35C786;' align='center' bgcolor='#35C786' valign='top'>
<a href='%3%' target='_blank' rel='noopener' style='color: #FFFFFF; text-decoration: none; -ms-word-break: break-all; word-break: break-all; border-radius: 5px; box-sizing: border-box; cursor: pointer; display: inline-block; font-size: 14px; font-weight: bold; text-transform: capitalize; background: #35C786; margin: 0; padding: 12px 30px; border: 1px solid #35c786;'>
																							Kliknite na ovaj link da prihvatite pozivnicu
																						</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<p style='max-width: 400px; display: block; color: #392F54; font-family: sans-serif; font-size: 14px; line-height: 20px; font-weight: normal; margin: 15px 0;'>Ukoliko ne možete kliknuti na link, kopirajte i zalijepite ovaj URL u prozor vašeg pretraživača:</p>
<table border='0' cellpadding='0' cellspacing='0'>
<tr>
<td style='-ms-word-break: break-all; word-break: break-all; font-family: sans-serif; font-size: 11px; line-height:14px;'>
<font style="-ms-word-break: break-all; word-break: break-all; font-size: 11px; line-height:14px;">
<a style='-ms-word-break: break-all; word-break: break-all; color: #392F54; text-decoration: underline; font-size: 11px; line-height:15px;' href='%3%'>%3%</a>
</font>
</td>
</tr>
</table>
</p>
</td>
</tr>
</table>
</td>
</tr>
</table>
<br><br><br>
</div>
</td>
<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'></td>
</tr>
</table>
</body>
</html>`,
    defaultInvitationMessage: "Ponovno slanje pozivnice...",
    deleteUser: "Izbriši korisnika",
    deleteUserConfirmation: "Jeste li sigurni da želite izbrisati ovaj korisnički račun?",
    stateAll: "Sve",
    stateActive: "Aktivan",
    stateDisabled: "Onemogućen",
    stateLockedOut: "Zaključan",
    stateApproved: "Odobren",
    stateInvited: "Pozvan",
    stateInactive: "Neaktivan",
    sortNameAscending: "Ime (A-Z)",
    sortNameDescending: "Ime (Z-A)",
    sortCreateDateAscending: "Najstarije",
    sortCreateDateDescending: "Najnovije",
    sortLastLoginDateDescending: "Zadnja prijava",
    noUserGroupsAdded: "Nijedna korisnička grupa nije dodana",
    "2faDisableText": "Ako želite da onemogućite ovog dvofaktorskog provajdera, onda morate uneti kod prikazan na vašem uređaju za autentifikaciju:",
    "2faProviderIsEnabled": "Ovaj dvofaktorski provajder je omogućen",
    "2faProviderIsDisabledMsg": "Ovaj dvofaktorski provajder je sada onemogućen",
    "2faProviderIsNotDisabledMsg": "Nešto je pošlo po zlu s pokušajem da se onemogući ovaj dvofaktorski provajder",
    "2faDisableForUser": "Želite li onemogućiti ovog dvofaktorskog provajdera za ovog korisnika?"
  },
  validation: {
    validation: "Validacija",
    noValidation: "Nema validacije",
    validateAsEmail: "Potvrdi kao adresu e-pošte",
    validateAsNumber: "Potvrdite kao broj",
    validateAsUrl: "Potvrdi kao URL",
    enterCustomValidation: "...ili unesite prilagođenu validaciju",
    fieldIsMandatory: "Polje je obavezno",
    mandatoryMessage: "Unesite prilagođenu poruku o grešci validacije (opcionalno)",
    validationRegExp: "Unesite regularni izraz",
    validationRegExpMessage: "Unesite prilagođenu poruku o grešci validacije (opcionalno)",
    minCount: "Morate dodati barem",
    maxCount: "Samo možeš imati",
    addUpTo: "Dodajte do",
    items: "stavke",
    urls: "URL-ovi",
    urlsSelected: "Odabrani URL-ovi",
    itemsSelected: "odabrane stavke",
    invalidDate: "Nevažeći datum",
    invalidNumber: "Nije broj",
    invalidNumberStepSize: "Nije važeća brojčana veličina koraka",
    invalidEmail: "Nevažeći email",
    invalidNull: "Vrijednost ne može biti null",
    invalidEmpty: "Vrijednost ne može biti prazna",
    invalidPattern: "Vrijednost je nevažeća, ne odgovara ispravnom uzorku",
    customValidation: "Prilagođena validacija",
    entriesShort: "Minimalno %0% unosa, potrebno <strong>%1%</strong> više.",
    entriesExceed: "Maksimalno %0% unosa, <strong>%1%</strong> previše.",
    entriesAreasMismatch: "Zahtjevi za količinu sadržaja nisu ispunjeni za jedno ili više područja."
  },
  healthcheck: {
    checkSuccessMessage: "Vrijednost je postavljena na preporučenu vrijednost: '%0%'.",
    checkErrorMessageDifferentExpectedValue: `Očekivana vrijednost '%1%' za '%2%' u konfiguracijskoj datoteci '%3%', ali
      pronađeno '%0%'.
    `,
    checkErrorMessageUnexpectedValue: `Pronađena neočekivana vrijednost '%0%' za '%2%' u konfiguracijskoj datoteci '%3%'.
    `,
    macroErrorModeCheckSuccessMessage: "Makro greške su postavljene na '%0%'.",
    macroErrorModeCheckErrorMessage: `Greške makroa su postavljene na '%0%' što će spriječiti potpuno učitavanje nekih ili svih stranica
	  na vašem sajtu ako postoje greške u makroima. Ako ovo ispravite, vrijednost će biti postavljena na '%1%'.
    `,
    httpsCheckValidCertificate: "Certifikat Vaše web stranice je važeći.",
    httpsCheckInvalidCertificate: "Greška u validaciji certifikata: '%0%'",
    httpsCheckExpiredCertificate: "SSL certifikat vaše web stranice je istekao.",
    httpsCheckExpiringCertificate: "SSL certifikat vaše web stranice ističe za %0% dana.",
    healthCheckInvalidUrl: "Greška pri pingovanju URL-a %0% - '%1%'",
    httpsCheckIsCurrentSchemeHttps: "Trenutno %0% pregledavate stranicu koristeći HTTPS šemu.",
    httpsCheckConfigurationRectifyNotPossible: `AppSetting 'Umbraco:CMS:Global:UseHttps' je postavljen na 'false' u
      vašem appSettings.json fajl. Jednom kada pristupite ovoj stranici koristeći HTTPS šemu, to bi trebalo biti postavljeno na 'true'.
    `,
    httpsCheckConfigurationCheckResult: `Postavka aplikacije 'Umbraco:CMS:Global:UseHttps' je postavljena na '%0%' u vašem
      appSettings.json datoteku, vaši kolačići su %1% označeni kao sigurni.
    `,
    compilationDebugCheckSuccessMessage: "Način kompilacije otklanjanja grešaka je onemogućen.",
    compilationDebugCheckErrorMessage: `Način kompilacije za otklanjanje grešaka je trenutno omogućen. Preporučuje se da se
      onemogućite ovu postavku prije emitiranja uživo.
    `,
    umbracoApplicationUrlCheckResultTrue: "AppSetting 'Umbraco:CMS:WebRouting:UmbracoApplicationUrl' je postavljen na <strong>%0%</strong>.",
    umbracoApplicationUrlCheckResultFalse: "AppSetting 'Umbraco:CMS:WebRouting:UmbracoApplicationUrl' nije postavljen.",
    clickJackingCheckHeaderFound: "Zaglavlje ili meta-tag <strong>X-Frame-Options</strong> koji se koristi za kontrolu da li neko mjesto može biti IFRAMED od strane drugog je pronađen.",
    clickJackingCheckHeaderNotFound: "Zaglavlje ili meta-tag <strong>X-Frame-Options</strong> koji se koristi za kontrolu da li neko mjesto može biti IFRAMED od strane drugog nije pronađen.",
    noSniffCheckHeaderFound: "Zaglavlje ili meta-tag <strong>X-Content-Type-Options</strong> koji se koristi za zaštitu od ranjivosti MIME sniffinga je pronađen.",
    noSniffCheckHeaderNotFound: "Zaglavlje ili meta-tag <strong>X-Content-Type-Options</strong> koji se koristi za zaštitu od ranjivosti MIME sniffinga nije pronađen.",
    hSTSCheckHeaderFound: "Zaglavlje <strong>Strict-Transport-Security</strong>, takođe poznat kao HSTS-header, je pronađen.",
    hSTSCheckHeaderNotFound: "Zaglavlje <strong>Strict-Transport-Security</strong> nije pronađeno.",
    hSTSCheckHeaderFoundOnLocalhost: "Zaglavlje <strong>Strict-Transport-Security</strong>, takođe poznat kao HSTS-header, je pronađen. <strong>Ovo zaglavlje ne bi trebalo biti prisutno na lokalnom hostu.</strong>",
    hSTSCheckHeaderNotFoundOnLocalhost: "Zaglavlje <strong>Strict-Transport-Security</strong> nije pronađeno. Ovo zaglavlje ne bi trebalo biti prisutno na lokalnom hostu.",
    xssProtectionCheckHeaderFound: "Zaglavlje <strong>X-XSS-Protection</strong> je pronađeno.",
    xssProtectionCheckHeaderNotFound: "Zaglavlje <strong>X-XSS-Protection</strong> nije pronađeno.",
    excessiveHeadersFound: "Pronađena su sljedeća zaglavlja koja otkrivaju informacije o tehnologiji web stranice: <strong>%0%</strong>.",
    excessiveHeadersNotFound: `Nisu pronađena zaglavlja koja otkrivaju informacije o tehnologiji web stranice.
    `,
    smtpMailSettingsNotFound: "U datoteci Web.config, system.net/mailsettings nije moguće pronaći.",
    smtpMailSettingsHostNotConfigured: `U datoteci Web.config, system.net/mailsettings, host
      nije konfigurisan.
    `,
    smtpMailSettingsConnectionSuccess: `SMTP postavke su ispravno konfigurisane i usluga radi
      kao što je očekivano.
    `,
    smtpMailSettingsConnectionFail: `SMTP server konfigurisan sa hostom '%0%' i portom '%1%' ne može biti
      dosegnut. Provjerite jesu li SMTP postavke u datoteci Web.config, system.net/mailsettings ispravne.
    `,
    notificationEmailsCheckSuccessMessage: "E-mail za obavještenje je postavljen na <strong>%0%</strong>.",
    notificationEmailsCheckErrorMessage: "E-pošta za obavještenje je i dalje postavljena na zadanu vrijednost od <strong>%0%</strong>.",
    checkGroup: "Provjerite grupu",
    helpText: `
        <p>Provjera zdravlja procjenjuje različita područja vaše web lokacije u pogledu postavki najbolje prakse, konfiguracije, potencijalnih problema itd. Možete jednostavno riješiti probleme pritiskom na dugme.
        Možete dodati svoje zdravstvene preglede, pogledajte <a href="https://docs.umbraco.com/umbraco-cms/extending/health-check" target="_blank" rel="noopener" class="btn-link -underline">dokumentaciju za više informacija</a> o prilagođenim zdravstvenim pregledima.</p>
        `
  },
  redirectUrls: {
    disableUrlTracker: "Onemogući URL tragač",
    enableUrlTracker: "Omogući URL tragač",
    originalUrl: "Originalni URL",
    redirectedTo: "Preusmjeri na",
    redirectUrlManagement: "Preusmjeravanje URL-ova",
    panelInformation: "Sljedeći URL-ovi preusmjeravaju na ovu stavku sadržaja:",
    noRedirects: "Nisu napravljena nikakva preusmjeravanja",
    noRedirectsDescription: `Kada se objavljena stranica preimenuje ili premjesti, preusmjeravanje će automatski biti
       napravljen na novu stranicu.
    `,
    redirectRemoved: "Preusmjeravanje uklonjeno.",
    redirectRemoveError: "Greška pri uklanjanju preusmjeravanja.",
    redirectRemoveWarning: "Ovo će ukloniti preusmjeravanje",
    confirmDisable: "Jeste li sigurni da želite onemogućiti URL tragač?",
    disabledConfirm: "URL tragač je sada onemogućen.",
    disableError: "Greška pri onemogućavanju URL tragača, više informacija možete pronaći u vašem log fajlu.",
    enabledConfirm: "URL tragač je sada omogućen.",
    enableError: "Greška pri omogućavanju URL tragača, više informacija možete pronaći u vašem log fajlu."
  },
  emptyStates: {
    emptyDictionaryTree: "Nema stavki iz rječnika za odabir"
  },
  textbox: {
    characters_left: "<strong>%0%</strong> preostalih znakova.",
    characters_exceed: "Maksimalno %0% karaktera, <strong>%1%</strong> previše."
  },
  recycleBin: {
    contentTrashed: "Sadržaj u otpadu s ID-om: {0} povezan je s originalnim nadređenim sadržajem s ID-om: {1}",
    mediaTrashed: "Medij u otpadu s ID-om: {0} povezan je s originalnim nadređenim medijem s ID-om: {1}",
    itemCannotBeRestored: "Nije moguće automatski vratiti ovu stavku",
    itemCannotBeRestoredHelpText: `Ne postoji lokacija na kojoj se ova stavka može automatski vratiti. Vi
       može ručno premjestiti stavku koristeći stablo ispod.
    `,
    wasRestored: "je restauriran pod"
  },
  relationType: {
    direction: "Smjer",
    parentToChild: "Roditelj djetetu",
    bidirectional: "Bidirectional",
    parent: "Roditelj",
    child: "Dijete",
    count: "Broj",
    relation: "Relacija",
    relations: "Relacije",
    created: "Kreirano",
    comment: "Komentar",
    name: "Naziv",
    noRelations: "Nema relacija za ovu vrstu odnosa",
    tabRelationType: "Tip relacije",
    tabRelations: "Relacije",
    isDependency: "Je zavisan",
    dependency: "Da",
    noDependency: "Ne"
  },
  dashboardTabs: {
    contentIntro: "Početak rada",
    contentRedirectManager: "Preusmjeravanje URL-ova",
    mediaFolderBrowser: "Sadržaj",
    settingsWelcome: "Dobrodošli",
    settingsExamine: "Examine menadžment",
    settingsPublishedStatus: "Status stranice",
    settingsModelsBuilder: "Generator modela",
    settingsHealthCheck: "Provjera zdravlja",
    settingsProfiler: "Profilisanje",
    memberIntro: "Početak rada",
    formsInstall: "Instaliraj Umbraco Forms"
  },
  visuallyHiddenTexts: {
    goBack: "Vrati se",
    activeListLayout: "Aktivan raspored:",
    jumpTo: "Skoči na",
    group: "grupa",
    passed: "prošao",
    warning: "upozorenje",
    failed: "neuspješno",
    suggestion: "prijedlog",
    checkPassed: "Provjera prošla",
    checkFailed: "Provjera nije uspjela",
    openBackofficeSearch: "Otvorite backoffice pretragu",
    openCloseBackofficeHelp: "Otvori/Zatvori pomoć za backoffice",
    openCloseBackofficeProfileOptions: "Opcije otvaranja/zatvaranja profila",
    assignDomainDescription: "Postavite kulturu i imena hostova za %0%",
    createDescription: "Kreirajte novi čvor ispod %0%",
    protectDescription: "Postavite ograničenja pristupa uključena %0%",
    rightsDescription: "Dozvole za postavljanje su uključene %0%",
    sortDescription: "Promijenite redoslijed sortiranja za %0%",
    createblueprintDescription: "Kreirajte predložak sadržaja na osnovu %0%",
    openContextMenu: "Otvorite kontekstni meni za",
    currentLanguage: "Trenutni jezik",
    switchLanguage: "Prebaci jezik na",
    createNewFolder: "Kreirajte novi folder",
    newPartialView: "Parcijalni pogled",
    newPartialViewMacro: "Makro za djelomični prikaz",
    newMember: "Član",
    newDataType: "Tip podatka",
    redirectDashboardSearchLabel: "Pretražite kontrolnu tablu za preusmjeravanje",
    userGroupSearchLabel: "Pretražite odjeljak korisničke grupe",
    userSearchLabel: "Pretražite odjeljak korisnika",
    createItem: "Kreiraj stavku",
    create: "Kreiraj",
    edit: "Uredi",
    name: "Naziv",
    addNewRow: "Dodaj novi red",
    tabExpand: "Pogledajte više opcija",
    searchOverlayTitle: "Pogledajte više opcija",
    searchOverlayDescription: "Potražite čvorove sadržaja, medijske čvorove itd. u backofficeu.",
    searchInputDescription: `Kada su dostupni rezultati autodovršavanja, pritisnite strelice gore i dolje ili koristite
      taster tab i koristite taster enter da izaberete.
    `,
    path: "Putanja:",
    foundIn: "Pronađeno u",
    hasTranslation: "Ima prevod",
    noTranslation: "Nedostaje prijevod",
    dictionaryListCaption: "Stavke iz rječnika",
    contextMenuDescription: "Odaberite jednu od opcija za uređivanje čvora.",
    contextDialogDescription: "Izvršite akciju %0% na čvoru %1%.",
    addImageCaption: "Dodajte natpis slike",
    searchContentTree: "Pretraži stablo sadržaja",
    maxAmount: "Maksimalni iznos"
  },
  references: {
    tabName: "Reference",
    DataTypeNoReferences: "Ovaj tip podataka nema reference.",
    itemHasNoReferences: "Ova stavka nema reference.",
    labelUsedByDocumentTypes: "Koristi se u tipovima dokumenata",
    labelUsedByMediaTypes: "Koristi se u tipovima medija",
    labelUsedByMemberTypes: "Koristi se u tipovima članova",
    usedByProperties: "Koristi",
    labelUsedItems: "Stavke u upotrebi",
    labelUsedDescendants: "Potomci u upotrebi",
    deleteWarning: "Ova stavka ili njeni potomci se koriste. Brisanje može dovesti do neispravnih veza na vašoj web stranici.",
    unpublishWarning: "Ova stavka ili njeni potomci se koriste. Poništavanje objavljivanja može dovesti do neispravnih veza na vašoj web stranici. Molimo poduzmite odgovarajuće radnje.",
    deleteDisabledWarning: "Ova stavka ili njeni potomci se koriste. Stoga je brisanje onemogućeno.",
    listViewDialogWarning: "Sljedeće stavke koje pokušavate %0% koriste drugi sadržaj."
  },
  logViewer: {
    deleteSavedSearch: "Izbriši sačuvane pretrage",
    logLevels: "Nivoi loga",
    selectAllLogLevelFilters: "Označi sve",
    deselectAllLogLevelFilters: "Odznači sve",
    savedSearches: "Sačuvane pretrage",
    saveSearch: "Sačuvaj pretragu",
    saveSearchDescription: "Unesite prijateljski naziv za vaš upit za pretragu",
    filterSearch: "Filtriraj pretragu",
    totalItems: "Ukupno",
    timestamp: "Vrijeme",
    level: "Nivo",
    machine: "Uređaj",
    message: "Poruka",
    exception: "Izuzetak",
    properties: "Svojstva",
    searchWithGoogle: "Pretraži pomoću Google-a",
    searchThisMessageWithGoogle: "Pretraži ovu poruku pomoću Google-a",
    searchWithBing: "Pretraži pomoću Bing-a",
    searchThisMessageWithBing: "Pretraži ovu poruku pomoću Bing-a",
    searchOurUmbraco: "Pretraži Our Umbraco",
    searchThisMessageOnOurUmbracoForumsAndDocs: "Pretraži ovu poruku na Our Umbraco forumu i dokumentaciji",
    searchOurUmbracoWithGoogle: "Pretraži Our Umbraco pomoću Google-a",
    searchOurUmbracoForumsUsingGoogle: "Pretraži Our Umbraco forume pomoću Google-a",
    searchUmbracoSource: "Pretraži Umbraco Source",
    searchWithinUmbracoSourceCodeOnGithub: "Pretraži Umbraco source code on Github-u",
    searchUmbracoIssues: "Pretraži Umbraco Issues",
    searchUmbracoIssuesOnGithub: "Pretraži Umbraco Issues na Github-u",
    deleteThisSearch: "Obriši ovu pretragu",
    findLogsWithRequestId: "Pronađi logove sa ID-om zatjeva",
    findLogsWithNamespace: "Pronađi logove sa namespace-om",
    findLogsWithMachineName: "Pronađi logove sa nazivom uređaja",
    open: "Otvori",
    polling: "Provjera",
    every2: "Svako 2 sekunde",
    every5: "Svako 5 sekundi",
    every10: "Svako 10 sekundi",
    every20: "Svako 20 sekundi",
    every30: "Svako 30 sekundi",
    pollingEvery2: "Provjera svako 2s",
    pollingEvery5: "Provjera svako 5s",
    pollingEvery10: "Provjera svako 10s",
    pollingEvery20: "Provjera svako 20s",
    pollingEvery30: "Provjera svako 30s"
  },
  clipboard: {
    labelForCopyAllEntries: "Kopiraj %0%",
    labelForArrayOfItemsFrom: "%0% od %1%",
    labelForArrayOfItems: "Zbirka od %0%",
    labelForRemoveAllEntries: "Uklonite sve stavke",
    labelForClearClipboard: "Očisti međuspremnik"
  },
  propertyActions: {
    tooltipForPropertyActionsMenu: "Otvorite radnje svojstva",
    tooltipForPropertyActionsMenuClose: "Zatvorite Property Actions"
  },
  nuCache: {
    refreshStatus: "Osvježi status",
    memoryCache: "Memorijski keš",
    memoryCacheDescription: `
            Ovo dugme vam omogućava da obnovite keš u memoriji tako što ćete je u potpunosti ponovo učitati iz baze podataka
    (ali ne obnavlja keš baze podataka). Ovo je relativno brzo.
    Koristite ga kada mislite da keš memorija nije pravilno osvježena, nakon nekih događaja
    pokrenuo&mdash;što bi ukazivalo na manji problem sa Umbracom.
    (Napomena: pokreće ponovno učitavanje na svim serverima u LB okruženju).
    `,
    reload: "Ponovo učitaj",
    databaseCache: "Keš baze podataka",
    databaseCacheDescription: `
    Ovo dugme vam omogućava da ponovo izgradite keš baze podataka, tj. sadržaj tabele cmsContentNu.
    <strong>Obnova može biti skupa.</strong>
    Koristite ga kada ponovno učitavanje nije dovoljno, a mislite da keš baze podataka nije bio
    pravilno generisan&mdash;što bi ukazivalo na neko kritično pitanje Umbraco.
    `,
    rebuild: "Ponovo sagradi",
    internals: "Unutrašnjost",
    internalsDescription: `
    Ovo dugme vam omogućava da pokrenete kolekciju NuCache snimaka (nakon pokretanja fullCLR GC-a).
    Osim ako ne znate šta to znači, vjerovatno ga <em>ne</em> morate koristiti.
    `,
    collect: "Skupiti",
    publishedCacheStatus: "Objavljeni status keša",
    caches: "Predmemorije"
  },
  profiling: {
    performanceProfiling: "Profiliranje performansi",
    performanceProfilingDescription: `
            <p>
               Umbraco trenutno radi u načinu za otklanjanje grešaka. To znači da možete koristiti ugrađeni profiler performansi za procjenu performansi prilikom renderiranja stranica.
            </p>
            <p>
                Ako želite da aktivirate profiler za određeno prikazivanje stranice, jednostavno dodajte <strong>umbDebug=true</strong> na string upita kada tražite stranicu.
            </p>
            <p>
                Ako želite da se profilator aktivira prema zadanim postavkama za sve prikaze stranica, možete koristiti prekidač ispod.
                On će postaviti kolačić u vaš pretraživač, koji zatim automatski aktivira profiler.
                Drugim riječima, profiler će biti aktivan samo po defaultu u <em>vašen</em> pretraživaču - ne svačijem drugom.
            </p>
    `,
    activateByDefault: "Podrazumevano aktivirajte profiler",
    reminder: "Prijateljski podsjetnik",
    reminderDescription: `
        <p>
            Nikada ne biste trebali dozvoliti da proizvodna lokacija radi u načinu za otklanjanje grešaka. Režim za otklanjanje grešaka se isključuje podešavanjem <strong>Umbraco:CMS:Hosting:Debug</strong> na <strong>false</strong> u appsettings.json, appsettings.{Environment}.json ili preko varijable okruženja.
        </p>
    `,
    profilerEnabledDescription: `
        <p>
            Umbraco trenutno ne radi u načinu za otklanjanje grešaka, tako da ne možete koristiti ugrađeni profiler. Ovako bi trebalo da bude za proizvodnu lokaciju.
        </p>
        <p>
            Režim za otklanjanje grešaka se uključuje podešavanjem <strong>Umbraco:CMS:Hosting:Debug</strong> na <strong>true</strong> u appsettings.json, appsettings.{Environment}.json ili preko varijable okruženja.
        </p>
    `
  },
  settingsDashboardVideos: {
    trainingHeadline: "Sati Umbraco trening videa udaljeni su samo jedan klik",
    trainingDescription: `
            <p>Želite savladati Umbraco? Provedite nekoliko minuta učeći neke najbolje prakse gledajući jedan od ovih videozapisa o korištenju Umbraco-a. I posjetite <a href="https://umbraco.tv" target="_blank" rel="noopener">umbraco.tv</a> za još više Umbraco videa</p>
        `,
    learningBaseDescription: `
        <p>Želite savladati Umbraco? Provedite nekoliko minuta učeći neke najbolje prakse gledajući jedan od ovih videozapisa o korištenju Umbraco-a <a class="btn-link -underline" href="https://www.youtube.com/c/UmbracoLearningBase" target="_blank" rel="noopener"> Umbraco Learning Base Youtube kanal</a>. Ovdje možete pronaći gomilu video materijala koji pokriva mnoge aspekte Umbraco-a.</p>
      `,
    getStarted: "Za početak"
  },
  settingsDashboard: {
    start: "Počni ovdje",
    startDescription: `Ovaj odjeljak sadrži blokove za izgradnju vaše Umbraco stranice. Slijedite dolje
      veze da saznate više o radu sa stavkama u odjeljku Postavke
    `,
    more: "Saznajte više",
    bulletPointOne: `
        Pročitajte više o radu sa stavkama u Postavkama <a class="btn-link -underline" href="https://docs.umbraco.com/umbraco-cms/fundamentals/backoffice/sections/" target="_blank" rel="noopener">u odjeljku Dokumentacija</a> na Our Umbraco
    `,
    bulletPointTwo: `
        Postavite pitanje na <a class="btn-link -underline" href="https://our.umbraco.com/forum" target="_blank" rel="noopener">Forumu zajednice</a>
    `,
    bulletPointTutorials: `
        Gledajte besplatno <a class="btn-link -underline" href="https://umbra.co/ulb" target="_blank" rel="noopener">video tutorijale na Umbraco Learning Base</a>
    `,
    bulletPointFour: `
        Saznajte više o našim <a class="btn-link -underline" href="https://umbraco.com/products/" target="_blank" rel="noopener">alatima za povećanje produktivnosti i komercijalna podrška</a>
    `,
    bulletPointFive: `
        Saznajte nešto o mogućnosti stvarne <a class="btn-link -underline" href="https://umbraco.com/training/" target="_blank" rel="noopener">obuke i certifikacije</a>
    `
  },
  startupDashboard: {
    fallbackHeadline: "Dobrodošli u The Friendly CMS",
    fallbackDescription: `Hvala vam što ste odabrali Umbraco - mislimo da bi ovo mogao biti početak nečega
      predivno. Iako se u početku može činiti neodoljivim, učinili smo mnogo da kriva učenja bude što glatka i brza
      što je moguće.
    `
  },
  formsDashboard: {
    formsHeadline: "Umbraco Forms",
    formsDescription: `Kreirajte obrasce pomoću intuitivnog drag and drop interfejsa. Od jednostavnih kontakt obrazaca
       koji šalje e-mail do naprednih obrazaca koji se integrišu sa CRM sistemima. Vašim klijentima će se svidjeti!
    `
  },
  blockEditor: {
    headlineCreateBlock: "Odaberite tip elementa",
    headlineAddSettingsElementType: "Priložite postavke na tip elementa",
    headlineAddCustomView: "Odaberite prikaz",
    headlineAddCustomStylesheet: "Odaberite stil",
    headlineAddThumbnail: "Odaberite sličicu",
    labelcreateNewElementType: "Kreirajte novi tip elementa",
    labelCustomStylesheet: "Prilagođeni stil",
    addCustomStylesheet: "Dodaj stil",
    headlineEditorAppearance: "Izgled bloka",
    headlineDataModels: "Modeli podataka",
    headlineCatalogueAppearance: "Izgled kataloga",
    labelBackgroundColor: "Boja pozadine",
    labelIconColor: "Boja ikone",
    labelContentElementType: "Model sadržaja",
    labelLabelTemplate: "Labela",
    labelCustomView: "Prilagođeni prikaz",
    labelCustomViewInfoTitle: "Prikaži opis prilagođenog prikaza",
    labelCustomViewDescription: `Zamenite način na koji se ovaj blok pojavljuje u korisničkom sučelju backofficea. Odaberite .html datoteku
      koji sadrži vašu prezentaciju.
    `,
    labelSettingsElementType: "Model postavki",
    labelEditorSize: "Veličina uređivača preklapanja",
    addCustomView: "Dodaj prilagođeni prikaz",
    addSettingsElementType: "Dodaj postavke",
    confirmDeleteBlockMessage: "Jeste li sigurni da želite izbrisati sadržaj <strong>%0%</strong>?",
    confirmDeleteBlockTypeMessage: "Jeste li sigurni da želite izbrisati konfiguraciju bloka <strong>%0%</strong>?",
    confirmDeleteBlockTypeNotice: `Sadržaj ovog bloka će i dalje biti prisutan, uređivanje ovog sadržaja
      više neće biti dostupan i bit će prikazan kao nepodržani sadržaj.
    `,
    confirmDeleteBlockGroupMessage: "Jeste li sigurni da želite izbrisati grupu <strong>%0%</strong> i sve konfiguracije ovog bloka?",
    confirmDeleteBlockGroupNotice: `Sadržaj ovih blokova će i dalje biti prisutan, uređivanje ovog sadržaja
      više neće biti dostupan i bit će prikazan kao nepodržani sadržaj.
    `,
    blockConfigurationOverlayTitle: "Konfiguracija od '%0%'",
    elementTypeDoesNotExist: "Ne može se uređivati jer tip elementa ne postoji.",
    thumbnail: "Sličica",
    addThumbnail: "Dodaj sličicu",
    tabCreateEmpty: "Kreiraj prazno",
    tabClipboard: "Međuspremnik",
    tabBlockSettings: "Postavke",
    headlineAdvanced: "Napredno",
    forceHideContentEditor: "Sakrij uređivač sadržaja",
    forceHideContentEditorHelp: "Sakrijte dugme za uređivanje sadržaja i uređivač sadržaja iz preklapanja Block Editor.",
    gridInlineEditing: "Inline editovanje",
    gridInlineEditingHelp: "Omogućava inline uređivanje za prvo svojstvo. Dodatna svojstva se mogu uređivati u prekrivaču.",
    blockHasChanges: "Izmijenili ste ovaj sadržaj. Jeste li sigurni da ih želite odbaciti?",
    confirmCancelBlockCreationHeadline: "Odbaciti kreiranje?",
    confirmCancelBlockCreationMessage: "Jeste li sigurni da želite otkazati kreiranje.",
    elementTypeDoesNotExistHeadline: "Greška!",
    elementTypeDoesNotExistDescription: "Tip elementa ovog bloka više ne postoji",
    addBlock: "Dodaj sadržaj",
    addThis: "Dodaj %0%",
    propertyEditorNotSupported: "Svojstvo '%0%' koristi uređivač '%1%' koji nije podržan u blokovima.",
    focusParentBlock: "Postavite fokus na blok kontejnera",
    areaIdentification: "Identifikacija",
    areaValidation: "Validacija",
    areaValidationEntriesShort: "<strong>%0%</strong> mora biti prisutan barem <strong>%2%</strong> puta.",
    areaValidationEntriesExceed: "<strong>%0%</strong> mora biti maksimalno prisutan <strong>%3%</strong> puta.",
    areaNumberOfBlocks: "Broj blokova",
    areaDisallowAllBlocks: "Dozvolite samo određene tipove blokova",
    areaAllowedBlocks: "Dozvoljene vrste blokova",
    areaAllowedBlocksHelp: "Definirajte tipove blokova koji su dozvoljeni u ovoj oblasti i opciono koliko svakog tipa treba biti prisutan.",
    confirmDeleteBlockAreaMessage: "Jeste li sigurni da želite izbrisati ovo područje?",
    confirmDeleteBlockAreaNotice: "Svi blokovi koji su trenutno kreirani unutar ovog područja bit će obrisani.",
    layoutOptions: "Opcije rasporeda",
    structuralOptions: "Strukturno",
    sizeOptions: "Opcije veličine",
    sizeOptionsHelp: "Definirajte jednu ili više opcija veličine, ovo omogućava promjenu veličine bloka",
    allowedBlockColumns: "Definirajte jednu ili više opcija veličine, ovo omogućava promjenu veličine bloka",
    allowedBlockColumnsHelp: "Definirajte različit broj kolona preko kojih ovaj blok može da se proteže. Ovo ne sprječava postavljanje blokova u područja s manjim rasponom kolona.",
    allowedBlockRows: "Dostupni rasponi redova",
    allowedBlockRowsHelp: "Definirajte raspon redova rasporeda preko kojih se ovaj blok može prostirati.",
    allowBlockInRoot: "Dozvolite u korijenu",
    allowBlockInRootHelp: "Učinite ovaj blok dostupnim u korijenu izgleda.",
    allowBlockInAreas: "Dozvolite u područjima",
    allowBlockInAreasHelp: "Učinite ovaj blok dostupnim prema zadanim postavkama unutar područja drugih blokova (osim ako za ove oblasti nisu postavljene eksplicitne dozvole).",
    areaAllowedBlocksEmpty: "Prema zadanim postavkama, svi tipovi blokova su dozvoljeni u području. Koristite ovu opciju da dozvolite samo odabrane tipove.",
    areas: "Područja",
    areasLayoutColumns: "Mrežne kolone za područja",
    areasLayoutColumnsHelp: "Definirajte koliko će stupaca biti dostupno za područja. Ako nije definiran, koristit će se broj kolona definiranih za cijeli izgled.",
    areasConfigurations: "Područja",
    areasConfigurationsHelp: "Da biste omogućili ugniježđenje blokova unutar ovog bloka, definirajte jedno ili više područja. Područja slijede raspored definiran njihovom vlastitom konfiguracijom stupca mreže. 'Raspon kolone' i 'raspon reda' za svaku oblast može se podesiti korištenjem okvira za rukovanje skalom u donjem desnom uglu odabranog područja.",
    invalidDropPosition: "<strong>%0%</strong> nije dozvoljeno na ovom mestu.",
    defaultLayoutStylesheet: "Zadani raspored stilova",
    confirmPasteDisallowedNestedBlockHeadline: "Nedozvoljeni sadržaj je odbijen",
    confirmPasteDisallowedNestedBlockMessage: "Umetnuti sadržaj sadržavao je nedozvoljeni sadržaj koji nije kreiran. Želite li ipak zadržati ostatak ovog sadržaja??",
    areaAliasHelp: `Kada koristite GetBlockGridHTML() za prikazivanje Block Grid-a, pseudonim će biti prikazan u oznaci kao 'data-area-alias' atribut. Koristite atribut alias za ciljanje elementa za područje. Npr. .umb-block-grid__area[data-area-alias="MyAreaAlias"] { ... }`,
    scaleHandlerButtonTitle: "Povucite za skaliranje",
    areaCreateLabelTitle: "Kreiraj oznaku dugmeta",
    areaCreateLabelHelp: "Nadjačajte tekst oznake za dodavanje novog bloka u ovo područje, primjer: 'Dodaj widget'",
    showSizeOptions: "Prikaži opcije promjene veličine",
    addBlockType: "Dodaj blok",
    addBlockGroup: "Dodaj grupu",
    pickSpecificAllowance: "Odaberi grupu ili blok",
    allowanceMinimum: "Postavite minimalni zahtjev",
    allowanceMaximum: "Postavite maksimalan zahtjev",
    block: "Blok",
    tabBlock: "Blok",
    tabBlockTypeSettings: "Postavke",
    tabAreas: "Područja",
    tabAdvanced: "Napredno",
    headlineAllowance: "Dozvole",
    getSampleHeadline: "Instalirajte uzorak konfiguracije",
    getSampleDescription: "Ovo će dodati osnovne blokove i pomoći vam da započnete s Block Grid Editorom. Dobit ćete blokove za naslov, obogaćeni tekst, sliku, kao i raspored u dvije kolone.",
    getSampleButton: "Instaliraj",
    actionEnterSortMode: "Način sortiranja",
    actionExitSortMode: "Završi način sortiranja",
    areaAliasIsNotUnique: "Ovaj pseudonim oblasti mora biti jedinstven u poređenju sa drugim oblastima ovog bloka.",
    configureArea: "Konfiguriraj područje",
    deleteArea: "Obriši područje",
    addColumnSpanOption: "Dodajte opciju raspona %0% kolona"
  },
  contentTemplatesDashboard: {
    whatHeadline: "Šta su predlošci sadržaja?",
    whatDescription: `Predlošci sadržaja su unaprijed definirani sadržaj koji se može odabrati prilikom kreiranja novog
      sadržaj čvora.
    `,
    createHeadline: "Kako da kreiram predložak sadržaja?",
    createDescription: `
            <p>Postoje dva načina za kreiranje predloška sadržaja:</p>
            <ul>
                <li>Desnom tipkom miša kliknite čvor sadržaja i odaberite "Kreiraj predložak sadržaja" da kreirate novi predložak sadržaja.</li>
                <li>Kliknite desnim tasterom miša na stablo predložaka sadržaja u odjeljku Postavke i odaberite vrstu dokumenta za koju želite da kreirate predložak sadržaja.</li>
            </ul>
            <p>Nakon što dobiju ime, urednici mogu početi koristiti predložak sadržaja kao osnovu za svoju novu stranicu.</p>
        `,
    manageHeadline: "Kako da upravljam predlošcima sadržaja?",
    manageDescription: `Možete uređivati i brisati predloške sadržaja iz stabla "Šabloni sadržaja" u
      odjeljak postavki. Proširite vrstu dokumenta na kojoj se temelji predložak sadržaja i kliknite na nju da biste uredili ili izbrisali to.
    `
  },
  preview: {
    endLabel: "Kraj",
    endTitle: "Završi način pregleda",
    openWebsiteLabel: "Pregledajte web stranicu",
    openWebsiteTitle: "Otvorite web stranicu u načinu pregleda",
    returnToPreviewHeadline: "Pregledajte web stranicu?",
    returnToPreviewDescription: `Završili ste način pregleda, želite li ga ponovo omogućiti da vidite
      najnovija sačuvana verzija vaše web stranice?
    `,
    returnToPreviewAcceptButton: "Pregledajte najnoviju verziju",
    returnToPreviewDeclineButton: "Pogledajte objavljenu verziju",
    viewPublishedContentHeadline: "Pogledajte objavljenu verziju?",
    viewPublishedContentDescription: `Nalazite se u načinu pregleda, želite li izaći da biste vidjeli
      objavljena verzija Vaše web stranice?
    `,
    viewPublishedContentAcceptButton: "Pogledajte objavljenu verziju",
    viewPublishedContentDeclineButton: "Ostanite u načinu pregleda"
  },
  permissions: {
    FolderCreation: "Kreiranje foldera",
    FileWritingForPackages: "Pisanje datoteka za pakete",
    FileWriting: "Pisanje fajlova",
    MediaFolderCreation: "Kreiranje medijskog foldera"
  },
  treeSearch: {
    searchResult: "stavka vraćena",
    searchResults: "stavke vraćene"
  }
};
export {
  e as default
};
//# sourceMappingURL=bs-CFFeXwS1.js.map
