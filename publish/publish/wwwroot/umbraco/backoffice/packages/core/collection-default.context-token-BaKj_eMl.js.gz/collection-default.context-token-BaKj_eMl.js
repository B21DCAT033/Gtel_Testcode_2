import { UmbContextToken as o } from "@umbraco-cms/backoffice/context-api";
const e = new o("UmbCollectionContext");
export {
  e as U
};
//# sourceMappingURL=collection-default.context-token-BaKj_eMl.js.map
