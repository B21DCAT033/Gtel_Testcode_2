import { U as o } from "./config.store.token-CsbU_19N.js";
import { UmbStoreObjectBase as t } from "@umbraco-cms/backoffice/store";
class a extends t {
  constructor(r) {
    super(r, o.toString());
  }
}
export {
  a as UmbTemporaryFileConfigStore,
  a as default
};
//# sourceMappingURL=config.store-CVJDS2rs.js.map
