import { U as _ } from "./constants-CDwqkOdg.js";
import { UmbContextToken as o } from "@umbraco-cms/backoffice/context-api";
const T = new o(
  _
);
export {
  T as U
};
//# sourceMappingURL=config.store.token-CsbU_19N.js.map
