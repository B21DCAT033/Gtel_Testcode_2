const a = "data-mark";
export {
  a as UMB_MARK_ATTRIBUTE_NAME
};
//# sourceMappingURL=index.js.map
