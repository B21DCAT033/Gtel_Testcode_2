const U = "Umb.Repository.Culture";
export {
  U
};
//# sourceMappingURL=constants-BdzGok2s.js.map
