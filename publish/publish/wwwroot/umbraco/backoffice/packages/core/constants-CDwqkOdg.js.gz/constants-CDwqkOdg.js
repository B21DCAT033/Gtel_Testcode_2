const o = "Umb.Repository.TemporaryFile.Config", _ = "UmbTemporaryFileConfigStore";
export {
  _ as U,
  o as a
};
//# sourceMappingURL=constants-CDwqkOdg.js.map
