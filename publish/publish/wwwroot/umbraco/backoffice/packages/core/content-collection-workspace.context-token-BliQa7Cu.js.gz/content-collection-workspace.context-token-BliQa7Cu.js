import { UmbContextToken as t } from "@umbraco-cms/backoffice/context-api";
const n = new t(
  "UmbWorkspaceContext",
  void 0,
  (o) => o.contentTypeHasCollection !== void 0
);
export {
  n as U
};
//# sourceMappingURL=content-collection-workspace.context-token-BliQa7Cu.js.map
