import { UmbContextToken as T } from "@umbraco-cms/backoffice/context-api";
const t = new T(
  "UmbWorkspaceContext",
  void 0,
  (o) => o.IS_CONTENT_WORKSPACE_CONTEXT
);
export {
  t as U
};
//# sourceMappingURL=content-workspace.context-token-BMs4lY7q.js.map
