const e = {
  actions: {
    assignDomain: "Kultura a názvy hostitelů",
    auditTrail: "Historie změn",
    browse: "Prohlížet uzel",
    changeDocType: "Změnit typ dokumentu",
    copy: "Kopírovat",
    create: "Vytvořit",
    export: "Exportovat",
    createPackage: "Vytvořit balíček",
    createGroup: "Vytvořit skupinu",
    delete: "Odstranit",
    disable: "Deaktivovat",
    emptyrecyclebin: "Vyprázdnit koš",
    enable: "Aktivovat",
    exportDocumentType: "Exportovat typ dokumentu",
    importdocumenttype: "Importovat typ dokumentu",
    importPackage: "Importovat balíček",
    liveEdit: "Editovat na stránce",
    logout: "Odhlásit",
    move: "Přesunout",
    notify: "Upozornění",
    protect: "Veřejný přístup",
    publish: "Publikovat",
    unpublish: "Nepublikovat",
    refreshNode: "Znovu načíst uzly",
    republish: "Znovu publikovat celý web",
    rights: "Práva",
    rename: "Přejmenovat",
    restore: "Obnovit",
    chooseWhereToCopy: "Kam zkopírovat",
    chooseWhereToMove: "Kam přesunout",
    toInTheTreeStructureBelow: "do struktury stromu pod",
    infiniteEditorChooseWhereToCopy: "Choose where to copy the selected item(s)",
    infiniteEditorChooseWhereToMove: "Choose where to move the selected item(s)",
    wasMovedTo: "bylo přesunuto",
    wasCopiedTo: "bylo zkopírováno",
    wasDeleted: "bylo smazáno",
    rollback: "Vrátit starší verzi",
    sendtopublish: "Odeslat k publikování",
    sendToTranslate: "Odeslat k překladu",
    setGroup: "Nastavit skupinu",
    sort: "Seřadit",
    translate: "Přeložit",
    update: "Aktualizovat",
    setPermissions: "Nastavit oprávnění",
    unlock: "Odemknout",
    createblueprint: "Vytvořit šablonu obsahu",
    resendInvite: "Přeposlat pozvánku"
  },
  actionCategories: {
    content: "Obsah",
    administration: "Administrace",
    structure: "Struktura",
    other: "Ostatní"
  },
  actionDescriptions: {
    assigndomain: "Povolit přístup k přiřazování kultury a názvů hostitelů",
    auditTrail: "Povolit přístup k zobrazení protokolu historie uzlu",
    browse: "Povolit přístup k zobrazení uzlu",
    changeDocType: "Povolit přístup ke změně typu dokumentu daného uzlu",
    copy: "Povolit přístup ke kopírování uzlu",
    create: "Povolit přístup k vytváření uzlů",
    delete: "Povolit přístup k mazání uzlů",
    move: "Povolit přístup k přesunutí uzlu",
    protect: "Povolit přístup k nastavení a změně veřejného přístupu k uzlu",
    publish: "Povolit přístup k publikování uzlu",
    unpublish: "Povolit přístup k zrušení publikování uzlu",
    rights: "Povolit přístup ke změně oprávnění pro uzel",
    rollback: "Povolit přístup k vrácení uzlu do předchozího stavu",
    sendtopublish: "Povolit přístup k odeslání uzlu ke schválení před publikováním",
    sendToTranslate: "Povolit přístup k odeslání uzlu k překladu",
    sort: "Povolit přístup ke změně pořadí uzlů",
    translate: "Povolit přístup k překladu uzlu",
    update: "Povolit přístup k uložení uzlu",
    createblueprint: "Povolit přístup k vytvoření šablony obsahu"
  },
  apps: {
    umbContent: "Obsah",
    umbInfo: "Info"
  },
  assignDomain: {
    permissionDenied: "Přístup zakázán.",
    addNew: "Přidat novou doménu",
    remove: "Odebrat",
    invalidNode: "Neplatný uzel.",
    invalidDomain: "Neplatný tvar domény.",
    duplicateDomain: "Doména už byla přiřazena.",
    domain: "Doména",
    language: "Jazyk",
    domainCreated: "Nová doména '%0%' byla vytvořena",
    domainDeleted: "Doména '%0%' je odstraněna",
    domainExists: "Doména '%0%' už byla přiřazena",
    domainUpdated: "Doména '%0%' byla aktualizována",
    orEdit: "Editace aktuálních domén",
    domainHelpWithVariants: `Povolené názvy domén jsou: "example.com", "www.example.com", "example.com:8080", nebo "https://www.example.com/".
     Dále jsou podporovány také jednoúrovňové cesty v doménách, např. "example.com/en" nebo "/en".`,
    inherit: "Dědit",
    setLanguage: "Kultura",
    setLanguageHelp: `Nastaví kulturu pro uzly pod aktuálním uzlem,<br />nebo dědění kultury po nadřazeném uzlu. Vztahuje se také<br />
       na aktivní uzel.`,
    setDomains: "Domény"
  },
  buttons: {
    clearSelection: "Zrušit výběr",
    select: "Vybrat",
    somethingElse: "Dělat něco jiného",
    bold: "Tučně",
    deindent: "Zrušit odsazení odstavce",
    formFieldInsert: "Vložit formulářové pole",
    graphicHeadline: "Vložit grafický nadpis",
    htmlEdit: "Editovat Html",
    indent: "Odsadit odstavec",
    italic: "Kurzíva",
    justifyCenter: "Zarovnat na střed",
    justifyLeft: "Zarovnat na levo",
    justifyRight: "Zarovnat na pravo",
    linkInsert: "Vložit odkaz",
    linkLocal: "Vložit místní odkaz (kotvu)",
    listBullet: "Neuspořádaný seznam",
    listNumeric: "Číslovaný seznam",
    macroInsert: "Vložit makro",
    pictureInsert: "Vložit obrázek",
    publishAndClose: "Publikovat a zavřít",
    publishDescendants: "Publikovat s potomky",
    relations: "Editovat vztahy",
    returnToList: "Zpět na seznam",
    save: "Uložit",
    saveAndClose: "Uložit a zavřít",
    saveAndPublish: "Uložit a publikovat",
    saveToPublish: "Uložit a odeslat ke schválení",
    saveAndPreview: "Náhled",
    saveListView: "Uložit zobrazení seznamu",
    schedulePublish: "Naplánovat",
    showPageDisabled: "Náhled je deaktivován, protože není přiřazena žádná šablona",
    styleChoose: "Vybrat styl",
    styleShow: "Zobrazit styly",
    tableInsert: "Vložit tabulku",
    generateModelsAndClose: "Generovat modely a zavřít",
    saveAndGenerateModels: "Uložit a generovat modely",
    undo: "Zpět",
    redo: "Znovu",
    deleteTag: "Smazat štítek",
    confirmActionCancel: "Zrušit",
    confirmActionConfirm: "Potvrdit",
    morePublishingOptions: "Další možnosti publikování"
  },
  auditTrailsMedia: {
    delete: "Média smazán",
    move: "Média přesunut",
    copy: "Média zkopírován",
    save: "Média uložen"
  },
  auditTrails: {
    atViewingFor: "Zobrazení pro",
    delete: "Obsah smazán",
    unpublish: "Obsah nepublikován",
    unpublishvariant: "Obsah nepublikován pro jazyky: %0% ",
    publish: "Obsah publikován",
    publishvariant: "Obsah publikován pro jazyky: %0% ",
    save: "Obsah uložen",
    savevariant: "Obsah uložen pro jazyky: %0%",
    move: "Obsah přesunut",
    copy: "Obsah zkopírován",
    rollback: "Obsah vrácen zpět",
    sendtopublish: "Obsah odeslán k publikování",
    sendtopublishvariant: "Obsah odeslán k publikování pro jazyky: %0%",
    sort: "Seřadit podřízené položky prováděné uživatelem",
    smallCopy: "Kopírovat",
    smallPublish: "Publikovat",
    smallPublishVariant: "Publikovat",
    smallMove: "Přesunout",
    smallSave: "Uložit",
    smallSaveVariant: "Uložit",
    smallDelete: "Smazat",
    smallUnpublish: "Nepublikovat",
    smallUnpublishVariant: "Nepublikovat",
    smallRollBack: "Vrátit zpět",
    smallSendToPublish: "Odeslat k publikování",
    smallSendToPublishVariant: "Odeslat k publikování",
    smallSort: "Seřadit",
    historyIncludingVariants: "Historie (všechny jazyky)"
  },
  codefile: {
    createFolderIllegalChars: "Název složky nesmí obsahovat nepovolené znaky.",
    deleteItemFailed: "Odstranění položky se nezdařilo: %0%"
  },
  content: {
    isPublished: "Is Published",
    about: "O této stránce",
    alias: "Alias",
    alternativeTextHelp: "(jak byste popsali obrázek přes telefon)",
    alternativeUrls: "Alternativní adresy URL",
    clickToEdit: "Klikněte pro editaci položky",
    createBy: "Vytvořeno uživatelem",
    createByDesc: "Původní autor",
    updatedBy: "Aktualizováno uživatelem",
    createDate: "Vytvořeno",
    createDateDesc: "Datum/čas vytvoření tohoto dokumentu",
    documentType: "Typ dokumentu",
    editing: "Editování",
    expireDate: "Datum odebrání",
    itemChanged: "Tato položko byla změněna po publikování",
    itemNotPublished: "Tato položka není publikována",
    lastPublished: "Naposledy publikováno",
    noItemsToShow: "There are no items to show",
    listViewNoItems: "There are no items to show in the list.",
    listViewNoContent: "No child items have been added",
    listViewNoMembers: "No members have been added",
    mediatype: "Typ média",
    mediaLinks: "Odkaz na položky medií",
    membergroup: "Skupina členů",
    memberrole: "Role",
    membertype: "Typ člena",
    noChanges: "No changes have been made",
    noDate: "Nevybráno žádné datum",
    nodeName: "Titulek stránky",
    noMediaLink: "This media item has no link",
    noProperties: "No content can be added for this item",
    otherElements: "Vlastnosti",
    parentNotPublished: "Tento dokument je publikován, ale není viditelný, protože jeho rodič '%0%' publikován není",
    parentCultureNotPublished: "Tato jazyková verze je publikována, ale není viditelná, protože její rodič '%0%' publikován není",
    parentNotPublishedAnomaly: "Jejda: tento dokument je publikován, ale není v mezipaměti (vnitřní chyba)",
    getUrlException: "Could not get the URL",
    routeError: "This document is published but its URL would collide with content %0%",
    routeErrorCannotRoute: "This document is published but its URL cannot be routed",
    publish: "Publikovat",
    published: "Published",
    publishedPendingChanges: "Published (pending changes)",
    publishStatus: "Stav publikování",
    publishDescendantsHelp: "Click <em>Publish with descendants</em> to publish <strong>%0%</strong> and all content items underneath and thereby making their content publicly available.",
    publishDescendantsWithVariantsHelp: "Click <em>Publish with descendants</em> to publish <strong>the selected languages</strong> and the same languages of content items underneath and thereby making their content publicly available.",
    releaseDate: "Datum publikování",
    unpublishDate: "Datum ukončení publikování",
    removeDate: "Datum odebrání",
    setDate: "Set date",
    sortDone: "Třídění je aktualizováno",
    sortHelp: 'Abyste uzly setřídili, jednoduše je přetáhněte anebo klikněte na jednu z hlaviček sloupce. Podržením "shift" nebo "control" při výběru můžete označit uzlů více.',
    statistics: "Statistika",
    titleOptional: "Titulek (volitelně)",
    altTextOptional: "Alternative text (optional)",
    type: "Typ",
    unpublish: "Nepublikovat",
    unpublished: "Draft",
    notCreated: "Not created",
    updateDate: "Naposledy změněno",
    updateDateDesc: "Datum/čas poslední změny dokumentu",
    uploadClear: "Odebrat soubor(y)",
    uploadClearImageContext: "Click here to remove the image from the media item",
    uploadClearFileContext: "Click here to remove the file from the media item",
    urls: "URL adresa dokumentu",
    memberof: "Člen skupin(y)",
    notmemberof: "Není člen skupin(y)",
    childItems: "Podřízené položky",
    target: "Cíl",
    scheduledPublishServerTime: "This translates to the following time on the server:",
    scheduledPublishDocumentation: '<a href="https://docs.umbraco.com/umbraco-cms/fundamentals/data/scheduled-publishing#timezones" target="_blank" rel="noopener">What does this mean?</a>',
    nestedContentDeleteItem: "Are you sure you want to delete this item?",
    nestedContentDeleteAllItems: "Are you sure you want to delete all items?",
    nestedContentEditorNotSupported: "Property %0% uses editor %1% which is not supported by Nested Content.",
    nestedContentNoContentTypes: "No content types are configured for this property.",
    nestedContentAddElementType: "Add element type",
    nestedContentSelectElementTypeModalTitle: "Select element type",
    nestedContentGroupHelpText: "Select the group whose properties should be displayed. If left blank, the first group on the element type will be used.",
    nestedContentTemplateHelpTextPart1: "Enter an angular expression to evaluate against each item for its name. Use",
    nestedContentTemplateHelpTextPart2: "to display the item index",
    addTextBox: "Add another text box",
    removeTextBox: "Remove this text box",
    contentRoot: "Content root",
    includeUnpublished: "Include drafts: also publish unpublished content items.",
    isSensitiveValue: "This value is hidden. If you need access to view this value please contact your website administrator.",
    isSensitiveValue_short: "This value is hidden.",
    languagesToPublish: "What languages would you like to publish?",
    languagesToSendForApproval: "What languages would you like to send for approval?",
    languagesToSchedule: "What languages would you like to schedule?",
    languagesToUnpublish: "Select the languages to unpublish. Unpublishing a mandatory language will unpublish all languages.",
    readyToPublish: "Ready to Publish?",
    readyToSave: "Ready to Save?",
    sendForApproval: "Send for approval",
    schedulePublishHelp: "Select the date and time to publish and/or unpublish the content item.",
    createEmpty: "Create new",
    createFromClipboard: "Paste from clipboard",
    nodeIsInTrash: "This item is in the Recycle Bin",
    saveModalTitle: "Uložit"
  },
  blueprints: {
    createBlueprintFrom: "Vytvořit novou šablonu obsahu z <em>%0%</em>",
    blankBlueprint: "Prázdná",
    selectBlueprint: "Vybrat obsahovou šablonu",
    createdBlueprintHeading: "Šablona obsahu byla vytvořena",
    createdBlueprintMessage: "Šablona obsahu byla vytvořena z '%0%'",
    duplicateBlueprintMessage: "Již existuje jiná šablona obsahu se stejným názvem",
    blueprintDescription: "Šablona obsahu je předdefinovaný obsah, který si editor může vybrat jako základ pro vytváření nového obsahu"
  },
  media: {
    clickToUpload: "Klikněte pro nahrání",
    orClickHereToUpload: "nebo kliknutím sem vyberte soubory",
    disallowedFileType: "Tento soubor nelze nahrát, nemá povolený typ souboru",
    maxFileSize: "Maximální velikost souboru je",
    mediaRoot: "Nejvyšší složka médií",
    moveToSameFolderFailed: "Nadřazené a cílové složky nemohou být stejné",
    createFolderFailed: "Nepodařilo se vytvořit složku pod nadřazeným id %0%",
    renameFolderFailed: "Nepodařilo se přejmenovat složku s id %0%",
    dragAndDropYourFilesIntoTheArea: "Přetáhněte své soubory do oblasti"
  },
  member: {
    createNewMember: "Vytvořit nového člena",
    allMembers: "Všichni členové",
    memberGroupNoProperties: "Členské skupiny nemají žádné další vlastnosti pro úpravy."
  },
  create: {
    chooseNode: "Kde chcete vytvořit nový %0%",
    createUnder: "Vytvořit položku pod",
    createContentBlueprint: "Vyberte typ dokumentu, pro který chcete vytvořit šablonu obsahu",
    enterFolderName: "Zadejte název složky",
    updateData: "Vyberte typ a titulek",
    noDocumentTypes: 'Nejsou dostupné žádné povolené typy dokumentů. Tyto musíte povolit v sekci nastavení pod <strong>"typy dokumentů"</strong>.',
    noDocumentTypesAtRoot: "Nejsou zde k dispozici žádné typy dokumentů pro vytváření obsahu. Musíte je vytvořit v <strong>Typy dokumentů</strong> v části <strong>Nastavení</strong>.",
    noDocumentTypesWithNoSettingsAccess: "Vybraná stránka ve stromu obsahu neumožňuje vytváření žádných stránek pod ní.",
    noDocumentTypesEditPermissions: "Oprávnění k úpravám pro tento typ dokumentu",
    noDocumentTypesCreateNew: "Vytvořit nový typ dokumentu",
    noDocumentTypesAllowedAtRoot: "Nejsou zde k dispozici žádné povolené typy dokumentů pro vytváření obsahu. Musíte je povolit v sekci <strong>Typy dokumentů</strong> v části <strong>Nastavení</strong> změnou možnosti <strong>Povolit jako root</strong> v části <strong>Oprávnění</strong>.",
    noMediaTypes: 'Nejsou dostupné žádné povolené typy medií. Tyto musíte povolit v sekci nastavení pod <strong>"typy medií"</strong>.',
    noMediaTypesWithNoSettingsAccess: "Vybraná média ve stromu neumožňuje vytváření pod nimi žádná další média.",
    noMediaTypesEditPermissions: "Upravit oprávnění pro tento typ média",
    documentTypeWithoutTemplate: "Typ dokumentu bez šablony",
    newFolder: "Nová složka",
    newDataType: "Nový datový typ",
    newJavascriptFile: "Nový skript JavaScript",
    newEmptyPartialView: "Nová prázdná částečná šablona",
    newPartialViewMacro: "Nové makro pro částečnou šablonu",
    newPartialViewFromSnippet: "Nová částečná šablona ze snippetu",
    newPartialViewMacroFromSnippet: "Nové makro částečné šablony ze snippetu",
    newPartialViewMacroNoMacro: "Nové makro pro částečnou šablonu (bez makra)",
    newStyleSheetFile: "Nový soubor stylů - stylopis",
    newRteStyleSheetFile: "Nový soubor stylů Rich Text editoru"
  },
  dashboard: {
    browser: "Prohlédnout svůj web",
    dontShowAgain: "- Skrýt",
    nothinghappens: "Jestli se Umbraco neotevírá, možná budete muset povolit na tomto webu vyskakovací okna",
    openinnew: "byl otevřený v novém okně",
    restart: "Restart",
    visit: "Navštívit",
    welcome: "Vítejte"
  },
  prompt: {
    stay: "Zůstat zde",
    discardChanges: "Zahodit změny",
    unsavedChanges: "Máte neuložené změny",
    unsavedChangesWarning: "Opravdu chcete opustit tuto stránku? Máte neuložené změny.",
    confirmListViewPublish: "Publikování zviditelní vybrané položky na webu.",
    confirmListViewUnpublish: "Zrušení publikování odstraní vybrané položky a všechny jejich potomky z webu.",
    confirmUnpublish: "Zrušení publikování odstraní tuto stránku a všechny její potomky z webu.",
    doctypeChangeWarning: "Máte neuložené změny. Provedením změn typu dokumentu změny zahodíte."
  },
  bulk: {
    done: "Hotovo",
    deletedItem: "Smazána %0% položka",
    deletedItems: "Smazáno %0% položek",
    deletedItemOfItem: "Smazána %0% z %1% položek",
    deletedItemOfItems: "Smazáno %0% z %1% položek",
    publishedItem: "Publikována %0% položka",
    publishedItems: "Publikováno %0% položek",
    publishedItemOfItem: "Publikována %0% z %1% položek",
    publishedItemOfItems: "Publikováno %0% z %1% položek",
    unpublishedItem: "Zrušeno publikování %0% položky",
    unpublishedItems: "Zrušeno publikování %0% položek",
    unpublishedItemOfItem: "Zrušeno publikování %0% z %1% položek",
    unpublishedItemOfItems: "Zrušeno publikování %0% z %1% položek",
    movedItem: "Přesunuta %0% položka",
    movedItems: "Přesunuto %0% položek",
    movedItemOfItem: "Přesunuta %0% z %1% položek",
    movedItemOfItems: "Přesunuto %0% z %1% položek",
    copiedItem: "Zkopírována %0% položka",
    copiedItems: "Zkopírováno %0% položek",
    copiedItemOfItem: "Zkopírována %0% z %1% položek",
    copiedItemOfItems: "Zkopírováno %0% z %1% položek"
  },
  defaultdialogs: {
    nodeNameLinkPicker: "Titulek odkazu",
    urlLinkPicker: "Odkaz",
    anchorLinkPicker: "Kotva / dotaz",
    anchorInsert: "Název",
    assignDomain: "Spravovat názvy hostitelů",
    closeThisWindow: "Zavřít toto okno",
    confirmdelete: "Jste si jistí. že chcete odstranit",
    confirmdisable: "Jste si jistí, že chcete deaktivovat",
    confirmlogout: "Jste si jistí?",
    confirmSure: "Jste si jistí?",
    cut: "Vyjmout",
    editDictionary: "Editovat položku slovníku",
    editLanguage: "Editovat jazyk",
    editSelectedMedia: "Edit selected media",
    insertAnchor: "Vložit místní odkaz",
    insertCharacter: "Vložit znak",
    insertgraphicheadline: "Vložit grafický titulek",
    insertimage: "Vložit obrázek",
    insertlink: "Vložit odkaz",
    insertMacro: "Kliknout pro přidání makra",
    inserttable: "Vložit tabulku",
    languagedeletewarning: "Tím se odstraní jazyk",
    languageChangeWarning: "Změna kultury jazyka může být náročná operace a bude mít za následek opětovné sestavení mezipaměti obsahu a indexů",
    lastEdited: "Naposledy editováno",
    link: "Odkaz",
    linkinternal: "Místní odkaz",
    linklocaltip: 'Při používání místních odkazů vložte znak "#" před odkaz',
    linknewwindow: "Otevřít v novém okně?",
    macroDoesNotHaveProperties: "Toto makro nemá žádné vlastnosti, které by bylo možno editovat",
    paste: "Vložit",
    permissionsEdit: "Editovat oprávnění pro",
    permissionsSet: "Nastavit oprávnění pro",
    permissionsSetForGroup: "Nastavit oprávnění pro %0% pro skupinu %1%",
    permissionsHelp: "Vyberte skupiny uživatelů, pro které chcete nastavit oprávnění",
    recycleBinDeleting: "Položky koše jsou nyní mazány. Nezavírejte, prosím, toto okno, dokud operace probíhá",
    recycleBinIsEmpty: "Koš je nyní prázdný",
    recycleBinWarning: "Odebrání položek z koše způsobí jejich trvalé odstranění",
    regexSearchError: "Webová služba<a target='_blank' rel='noopener' href='http://regexlib.com'>regexlib.com</a> má v tuto chvíli nějaké problémy, které jsou mimo naší kontrolu. Omlouváme se za vzniklé nepříjemnosti.",
    regexSearchHelp: "Vyhledat regulární výraz pro přidání validace formulářového prvku. Například: 'email, 'PSČ' 'URL'",
    removeMacro: "Odstranit makro",
    requiredField: "Pole je vyžadování",
    sitereindexed: "Web je přeindexován",
    siterepublished: "Mezipaměť webu byla obnovena. Všechen publikovaný obsah je nyní aktuální, zatímco nepublikovaný obsah zůstal nepublikovaný.",
    siterepublishHelp: "Mezipaměť webu bude obnovena. Všechen publikovaný obsah bude aktualizován, zatímco nepublikovaný obsah zůstane nepublikovaný.",
    tableColumns: "Počet sloupců",
    tableRows: "Počet řádků",
    thumbnailimageclickfororiginal: "Klikněte na obrázek pro zobrazení v plné velikosti",
    treepicker: "Vybrat položku",
    viewCacheItem: "Zobrazit položku mezipaměti",
    relateToOriginalLabel: "Navázat na originál",
    includeDescendants: "Včetně potomků",
    theFriendliestCommunity: "Nejpřátelštější komunita",
    linkToPage: "Odkaz na stránku",
    openInNewWindow: "Otevře propojený dokument v novém okně nebo na kartě",
    linkToMedia: "Odkaz na média",
    selectContentStartNode: "Vybrat počáteční uzel obsahu",
    selectMedia: "Vybrat média",
    selectMediaType: "Vybrat typ média",
    selectIcon: "Vybrat ikonu",
    selectItem: "Vybrat položku",
    selectLink: "Vybrat odkaz",
    selectMacro: "Vybrat makro",
    selectContent: "Vybrat obsah",
    selectContentType: "Vybrat typ obsahu",
    selectMediaStartNode: "Vybrat počáteční uzel média",
    selectMember: "Vybrat člena",
    selectMemberGroup: "Vybrat skupinu členů",
    selectMemberType: "Vybrat typ člena",
    selectNode: "Vybrat uzel",
    selectSections: "Vybrat sekce",
    selectUsers: "Vybrat uživatele",
    noIconsFound: "Nebyly nalezeny žádné ikony",
    noMacroParams: "Pro toto makro neexistují žádné parametry",
    noMacros: "K dispozici nejsou žádná makra",
    externalLoginProviders: "Externí poskytovatelé přihlášení",
    exceptionDetail: "Podrobnosti o výjimce",
    stacktrace: "Stacktrace",
    innerException: "Vnitřní výjimka",
    linkYour: "Propojit se",
    unLinkYour: "Odpojit se",
    account: "účet",
    selectEditor: "Vybrat editora",
    selectSnippet: "Vybrat snippet",
    variantdeletewarning: "Tímto odstraníte uzel a všechny jeho jazyky. Pokud chcete smazat pouze jeden jazyk, měli byste zrušit publikování uzlu v tomto jazyce."
  },
  dictionary: {
    noItems: "Nejsou žádné položky ve slovníku."
  },
  dictionaryItem: {
    description: "Editujte různé jazykové verze pro položku slovníku '%0%' níže.<br/>Můžete přidat další jazyky v nabídce 'jazyky' nalevo.",
    displayName: "Název jazyka",
    changeKeyError: "Klíč '%0%' již existuje.",
    overviewTitle: "Přehled slovníku"
  },
  examineManagement: {
    configuredSearchers: "Konfigurovaní vyhledávače",
    configuredSearchersDescription: "Zobrazuje vlastnosti a nástroje pro libovolný konfigurovaný vyhledávač (např. pro víceindexový vyhledávač)",
    fieldValues: "Hodnoty pole",
    healthStatus: "Stav",
    healthStatusDescription: "Stav indexu a jeho čitelnost",
    indexers: "Indexery",
    indexInfo: "Informace o indexu",
    indexInfoDescription: "Uvádí vlastnosti indexu",
    manageIndexes: "Spravovat indexy Examine",
    manageIndexesDescription: "Umožňuje zobrazit podrobnosti každého indexu a poskytuje některé nástroje pro správu indexů",
    rebuildIndex: "Znovu vytvořit index",
    rebuildIndexWarning: `
      To způsobí opětovné sestavení indexu.<br />V závislosti na tom, kolik obsahu je na vašem webu, může to chvíli trvat.<br />Nedoporučuje se znovu vytvářet index v době vysokého provozu na webu nebo při úpravách obsahu editory.
     `,
    searchers: "Vyhledávače",
    searchDescription: "Prohledat index a zobrazit výsledky",
    tools: "Nástroje",
    toolsDescription: "Nástroje pro správu indexu",
    fields: "pole",
    indexCannotRead: "Index nelze číst a bude nutné jej znovu sestavit",
    processIsTakingLonger: "Proces trvá déle, než se očekávalo, zkontrolujte Umbraco log a zkontrolujte, zda během této operace nedošlo k chybám",
    indexCannotRebuild: "Tento index nelze znovu sestavit, protože nemá přiřazen",
    iIndexPopulator: "IIndexPopulator"
  },
  placeholders: {
    username: "Zadejte Vaše uživatelské jméno",
    password: "Zadejte Vaše heslo",
    confirmPassword: "Potvrďte heslo",
    nameentity: "Pojmenujte %0%...",
    entername: "Zadejte jméno...",
    enteremail: "Zadejte e-mail...",
    enterusername: "Zadejte uživatelské jméno...",
    label: "Popisek...",
    enterDescription: "Zadejte popis...",
    search: "Pište pro vyhledání...",
    filter: "Pište pro filtrování...",
    enterTags: "Pište pro vložení štítků (po každém stiskněte klávesu Enter)...",
    email: "Vložte svůj e-mail",
    enterMessage: "Vložte zprávu...",
    usernameHint: "Vaše uživatelské jméno je obvykle váš e-mail",
    anchor: "#hodnota or ?klíč=hodnota",
    enterAlias: "Vložte alias...",
    generatingAlias: "Generování aliasu..."
  },
  editcontenttype: {
    createListView: "Vytvořit vlastní zobrazení seznamu",
    removeListView: "Odebrat vlastní zobrazení seznamu",
    aliasAlreadyExists: "Typ obsahu, typ média nebo typ člena s tímto aliasem již existuje"
  },
  renamecontainer: {
    renamed: "Přejmenováno",
    enterNewFolderName: "Sem zadejte nový název složky",
    folderWasRenamed: "%0% přejmenováno na %1%"
  },
  editdatatype: {
    addPrevalue: "Přidat předlohu",
    dataBaseDatatype: "Databázový datový typ",
    guid: "GUID editoru vlastností",
    renderControl: "Editor vlastností",
    rteButtons: "Tlačítka",
    rteEnableAdvancedSettings: "Povolit rozšířené nastavení pro",
    rteEnableContextMenu: "Povolit kontextové menu",
    rteMaximumDefaultImgSize: "Největší výchozí rozměr pro vložené obrázky",
    rteRelatedStylesheets: "Související stylopisy",
    rteShowLabel: "Zobrazit jmenovku",
    rteWidthAndHeight: "Šířka a výška",
    selectFolder: "Vyberte složku, kterou chcete přesunout",
    inTheTree: "do stromové struktury níže",
    wasMoved: "byla přesunuta pod",
    hasReferencesDeleteConsequence: "Smazáním <strong>%0%</strong> vymažete vlastnosti a jejich data z následujících položek",
    acceptDeleteConsequence: "Rozumím, že tato akce odstraní vlastnosti a data založená na tomto datovém typu"
  },
  errorHandling: {
    errorButDataWasSaved: "Vaše data byla uložena, ale než budete moci publikovat tuto stránku, je třeba odstranit některé chyby:",
    errorChangingProviderPassword: "Současný MemberShip Provider nepodporuje změnu hesla (EnablePasswordRetrieval musí mít hodnotu true)",
    errorExistsWithoutTab: "%0% již existuje",
    errorHeader: "Vyskytly se chyby:",
    errorHeaderWithoutTab: "Vyskytly se chyby:",
    errorInPasswordFormat: "Heslo musí být nejméně %0% znaků dlouhé a obsahovat nejméně %1% nealfanumerických znaků",
    errorIntegerWithoutTab: "%0% musí být celé číslo",
    errorMandatory: "Pole %0% na záložce %1% je povinné",
    errorMandatoryWithoutTab: "%0% je povinné pole",
    errorRegExp: "%0% v %1% není ve správném formátu",
    errorRegExpWithoutTab: "%0% není ve správném formátu"
  },
  errors: {
    receivedErrorFromServer: "Ze serveru byla přijata chyba",
    dissallowedMediaType: "Použití daného typu souboru bylo zakázáno adminitrátorem",
    codemirroriewarning: "UPOZORNĚNÍ! I když CodeMirror je dle konfigurace povolený, je zakázaný v Internet Exploreru, protože není dost stabilní.",
    contentTypeAliasAndNameNotNull: "Vyplňte, prosím, alias i název nového typu vlastností!",
    filePermissionsError: "Vyskytl se problém při čtení/zápisu do určeného souboru nebo adresáře",
    macroErrorLoadingPartialView: "Chyba při načítání skriptu částečné šablony (soubor: %0%)",
    missingTitle: "Uveďte, prosím, titulek",
    missingType: "Vyberte, prosím, typ",
    pictureResizeBiggerThanOrg: "Chystáte se obrázek zvětšit více, než je jeho původní rozměr. Opravdu chcete pokračovat?",
    startNodeDoesNotExists: "Počáteční uzel je odstraněný, kontaktujte, prosím, administrátora",
    stylesMustMarkBeforeSelect: "Před změnou stylu označte, prosím, obsah",
    stylesNoStylesOnPage: "Žádne aktivní styly nejsou dostupné",
    tableColMergeLeft: "Umístěte, prosím, kurzor nalevo od těch dvou buňek, které chcete sloučit",
    tableSplitNotSplittable: "Nemužete rozdělit buňku, která nebyla sloučená.",
    propertyHasErrors: "Tato vlastnost je neplatná"
  },
  general: {
    options: "Volby",
    about: "O...",
    action: "Akce",
    actions: "Akce",
    add: "Přidat",
    alias: "Alias",
    all: "Vše",
    areyousure: "Jste si jistí?",
    back: "Zpět",
    backToOverview: "Zpět na přehled",
    border: "Okraj",
    by: "o",
    cancel: "Zrušit",
    cellMargin: "Okraj buňky",
    choose: "Vybrat",
    clear: "Vyčistit",
    close: "Zavřít",
    closewindow: "Zavřít okno",
    comment: "Komentovat",
    confirm: "Potvrdit",
    constrain: "Omezit",
    constrainProportions: "Zachovat proporce",
    content: "Obsah",
    continue: "Pokračovat",
    copy: "Kopírovat",
    create: "Vytvořit",
    database: "Databáze",
    date: "Datum",
    default: "Výchozí",
    delete: "Odstranit",
    deleted: "Odstraněno",
    deleting: "Odstraňování...",
    design: "Vzhled",
    dictionary: "Slovník",
    dimensions: "Rozměry",
    down: "Dolů",
    download: "Stáhnout",
    edit: "Editovat",
    edited: "Editováno",
    elements: "Prvky",
    email: "Email",
    error: "Chyba",
    field: "Pole",
    findDocument: "Najít",
    first: "První",
    focalPoint: "Focal point",
    general: "Obecné",
    groups: "Skupiny",
    group: "Skupina",
    height: "Výška",
    help: "Nápověda",
    hide: "Skrýt",
    history: "Historie",
    icon: "Ikona",
    id: "Id",
    import: "Import",
    info: "Info",
    innerMargin: "Vnitřní okraj",
    insert: "Vložit",
    install: "Instalovat",
    invalid: "Neplatné",
    justify: "Vyrovnat",
    label: "Popisek",
    language: "Jazyk",
    last: "Poslední",
    layout: "Rozvržení",
    links: "Odkazy",
    loading: "Nahrávání",
    locked: "Zamčeno",
    login: "Přihlášení",
    logoff: "Odhlášení",
    logout: "Odhlášení",
    macro: "Makro",
    mandatory: "Povinné",
    message: "Zpráva",
    move: "Přesunout",
    name: "Název",
    new: "Nový",
    next: "Následující",
    no: "Ne",
    of: "z",
    off: "Vypnuto",
    ok: "OK",
    open: "Otevřít",
    on: "Zapnuto",
    or: "nebo",
    orderBy: "Seřadit podle",
    password: "Heslo",
    path: "Cesta",
    pleasewait: "Moment, prosím...",
    previous: "Předchozí",
    properties: "Vlastnosti",
    rebuild: "Obnovit",
    reciept: "Email pro obdržení formulářových dat",
    recycleBin: "Koš",
    recycleBinEmpty: "Váš koš je prázdný",
    reload: "Znovu načíst",
    remaining: "Zbývající",
    remove: "Odebrat",
    rename: "Přejmenovat",
    renew: "Obnovit",
    required: "Povinné",
    retrieve: "Načíst",
    retry: "Zopakovat",
    rights: "Oprávnění",
    scheduledPublishing: "Plánované publikování",
    search: "Hledat",
    searchNoResult: "Litujeme, ale nemůžeme najít to, co hledáte.",
    noItemsInList: "Nebyly přidány žádné položky",
    server: "Server",
    settings: "Nastavení",
    show: "Zobrazit",
    showPageOnSend: "Zobrazit stránku při odeslání",
    size: "Rozměr",
    sort: "Seřadit",
    status: "Stav",
    submit: "Potvrdit",
    type: "Zadejte",
    typeToSearch: "Pište pro vyhledávání...",
    under: "pod",
    up: "Nahoru",
    update: "Aktualizovat",
    upgrade: "Povýšit",
    upload: "Nahrání",
    url: "URL",
    user: "Uživatel",
    username: "Uživatelské jméno",
    value: "Hodnota",
    view: "Pohled",
    welcome: "Vítejte...",
    width: "Šířka",
    yes: "Ano",
    folder: "Složka",
    searchResults: "Výsledky hledání",
    reorder: "Přesunout",
    reorderDone: "Skončil jsem s přesouváním",
    preview: "Náhled",
    changePassword: "Změnit heslo",
    to: "na",
    listView: "Seznam",
    saving: "Ukládám...",
    current: "aktuální",
    embed: "Vložené",
    selected: "vybrané",
    other: "Další",
    articles: "Články",
    videos: "Videa"
  },
  colors: {
    blue: "Modrá"
  },
  shortcuts: {
    addGroup: "Přidat skupinu",
    addProperty: "Přidat vlastnost",
    addEditor: "Přidat editor",
    addTemplate: "Přidat šablonu",
    addChildNode: "Přidat vnořený uzel",
    addChild: "Přidat potomka",
    editDataType: "Upravit datový typ",
    navigateSections: "Navigace v sekcích",
    shortcut: "Klávesové zkratky",
    showShortcuts: "zobrazit klávesové zkratky",
    toggleListView: "Přepnout zobrazení seznamu",
    toggleAllowAsRoot: "Přepnout povolení jako root",
    commentLine: "Okomentovat/Odkomentovat řádky",
    removeLine: "Odebrat řádek",
    copyLineUp: "Kopírovat řádky nahoru",
    copyLineDown: "Kopírovat řádky dolů",
    moveLineUp: "Přesunout řádky nahoru",
    moveLineDown: "Přesunout řádky dolů",
    generalHeader: "Obecný",
    editorHeader: "Editor",
    toggleAllowCultureVariants: "Přepnout povolení jazykových verzí"
  },
  graphicheadline: {
    backgroundcolor: "Barva pozadí",
    bold: "Tučně",
    color: "Barva písma",
    font: "Font",
    text: "Text"
  },
  headers: {
    page: "Stránka"
  },
  installer: {
    databaseErrorCannotConnect: "Instalátor se nemůže připojit k databázi.",
    databaseFound: "Vyše databáze byla nalezena a je identifikována jako",
    databaseHeader: "Nastavení databáze",
    databaseInstall: `
      Stiskněte tlačítko <strong>instalovat</strong>, abyste nainstalovali Umbraco %0% databázi
    `,
    databaseInstallDone: "Umbraco %0% bylo zkopírováno do Vaši databáze. Stiskněte <strong>následující</strong> pro pokračování.",
    databaseUpgrade: `
      <p>
      Stiskněte tlačítko <strong>povýšit</strong> pro povýšení Vaší databáze na Umbraco %0%</p>
      <p>
      Neobávejte se - žádný obsah nebude odstraněn a všechno bude fungovat jak má!
      </p>
      `,
    databaseUpgradeDone: "Vaše databáze byla povýšená na konečnou verzi %0%.<br />Stiskněte <strong>Následující</strong> pro pokračování. ",
    databaseUpToDate: "Vaše současná databáze je aktuální!. Klikněte na <strong>následující</strong>, pro pokračování konfiguračního průvodce",
    defaultUserChangePass: "<strong>Heslo výchozího uživatele musí být změněno!</strong>",
    defaultUserDisabled: "<strong>Výchozí uživatel byl deaktivován, nebo nemá přístup k umbracu!</strong></p><p>Netřeba nic dalšího dělat. Klikněte na <strong>Následující</strong> pro pokračování.",
    defaultUserPassChanged: "<strong>Heslo výchozího uživatele bylo úspěšně změněno od doby instalace!</strong></p><p>Netřeba nic dalšího dělat. Klikněte na <strong>Následující</strong> pro pokračování.",
    defaultUserPasswordChanged: "Heslo je změněno!",
    greatStart: "Mějte skvělý start, sledujte naše uváděcí videa",
    None: "Není nainstalováno.",
    permissionsAffectedFolders: "Dotčené soubory a složky",
    permissionsAffectedFoldersMoreInfo: "Další informace o nastavování oprávnění pro Umbraco zde",
    permissionsAffectedFoldersText: "Musíte udělit ASP.NET oprávnění měnit následující soubory/složky",
    permissionsAlmostPerfect: `<strong>Vaše nastavení oprávnění je téměř dokonalé!</strong><br /><br />
        Můžete provozovat Umbraco bez potíží, ale nebudete smět instalovat balíčky, které jsou doporučené pro plné využívání všech možností umbraca.`,
    permissionsHowtoResolve: "Jak to vyřešit",
    permissionsHowtoResolveLink: "Klikněte zde, chcete-li číst textovou verzi",
    permissionsHowtoResolveText: "Shlédněte naše <strong>výukové video</strong> o nastavovaní oprávnění pro složky umbraca, nebo si přečtěte textovou verzi.",
    permissionsMaybeAnIssue: `<strong>Vaše nastavení oprávnění může být problém!</strong>
      <br/><br />
      Můžete provozovat Umbraco bez potíží, ale nebudete smět vytvářet složky a instalovat balíčky, které jsou doporučené pro plné využívání všech možností umbraca.`,
    permissionsNotReady: `<strong>Vaše nastavení oprívnění není připraveno pro Umbraco!</strong>
          <br /><br />
          Abyste mohli Umbraco provozovat, budete muset aktualizovat Vaše nastavení oprávnění.`,
    permissionsPerfect: `<strong>Vaše nastavení oprávnění je dokonalé!</strong><br /><br />
              Jste připraveni provozovat Umbraco a instalovat balíčky!`,
    permissionsResolveFolderIssues: "Řešení potíží se složkami",
    permissionsResolveFolderIssuesLink: "Následujte tento odkaz pro další informace o potížích s ASP.NET a vytvářením složek.",
    permissionsSettingUpPermissions: "Nastavování oprávnění pro složky",
    permissionsText: `
      Umbraco potřebuje oprávnění pro zápis/změnu k některým složkám, aby mohlo ukládat soubory jako například obrázky a PDF.
      Také ukládá dočasná data (čili mezipaměť) pro zvýšení výkonu Vašeho webu.
    `,
    runwayFromScratch: "Chci začít od nuly",
    runwayFromScratchText: `
        V tuto chíli je Váš web úplně prázdný, takže je ideální chvíle začít od nuly a vytvořit si vlastní typy dokumentu a šablon.
        (<a href="https://umbraco.tv/documentation/videos/for-site-builders/foundation/document-types">zjistěte jak</a>)
        Stále se můžete později rozhodnout nainstalovat Runway. Za tím účelem navštivte Vývojářskou sekci a zvolte Balíčky.
      `,
    runwayHeader: "Právě jste vytvořili čistou platformu Umbraco. Co chcete dělat dále?",
    runwayInstalled: "Runway je nainstalován",
    runwayInstalledText: `
      Základy máte na svém místě. Vyberte, které moduly chcete na ně nainstalovat.<br />
      Toto je náš seznam doporučených modulů, vyberte ty, které chcete nainstalovat, nebo si prohlédněte <a href="#" onclick="toggleModules(); return false;" id="toggleModuleList">úplný seznam modulů</a>
      `,
    runwayOnlyProUsers: "Doporučeno pouze pro zkušené uživatele",
    runwaySimpleSite: "Chci začít s jednoduchým webem",
    runwaySimpleSiteText: `
      <p>
      "Runway" je jednoduchý web poskytující některé základní typy dokumentů a šablon. Instalátor pro Vás může Runway nainstalovat automaticky a Vy ho pak můžete jednoduše editovat, rozšířit anebo úplně odstranit. Není nezbytný a můžete bez problému provozovat Umbraco bez něj. Runway nicméně nabízí jednoduché základy založené na nejlepších praktikách tak, abyste mohli začít rychleji, než kdykoliv jindy. Rozhodnete-li se Runway si nainstalovat, můžete si volitelně vybrat základní stavební bloky zvané Moduly Runway a stránky Runway si tak vylepšit.
        </p>
        <small>
        <em>Runway obsahuje:</em> Úvodní stránku, stránku Začínáme, stránku Instalace modulů.<br />
        <em>Volitelné moduly:</em> Horní navigace, Mapa webu, Kontakt, Galerie.
        </small>
      `,
    runwayWhatIsRunway: "Co je Runway",
    step1: "Krok 1/5: Přijetí licence",
    step2: "Krok 2/5: Konfigurace databáze",
    step3: "Krok 3/5: Ověřování oprávnění k souborům",
    step4: "Krok 4/5: Kontrola zabezpečení umbraca",
    step5: "Krok 5/5: Umbraco je připraveno a můžete začít",
    thankYou: "Děkujeme, že jeste si vybrali Umbraco",
    theEndBrowseSite: `<h3>Prohlédněte si svůj nový web</h3>
    Nainstalovali jste Runway, tak proč se nepodívat, jak Váš nový web vypadá.`,
    theEndFurtherHelp: `<h3>Další pomoc a informace</h3>
    Abyste získali pomoc od naší oceňované komunity, projděte si dokumentaci, nebo si pusťte některá videa zdarma o tom, jak vytvořit jednoduchý web, jak používat balíčky a rychlý úvod do terminologie umbraca`,
    theEndHeader: "Umbraco %0% je nainstalováno a připraveno k použití",
    theEndInstallSuccess: `Můžete <strong>ihned začít</strong> kliknutím na tlačítko "Spustit Umbraco" níže. <br />Jestliže <strong>je pro Vás Umbraco nové</strong>,
    spoustu zdrojů naleznete na naších stránkách "začínáme".`,
    theEndOpenUmbraco: `<h3>Spustit Umbraco</h3>
    Chcete-li spravovat Váš web, jednoduše přejděte do administrace umbraca a začněte přidávat obsah, upravovat šablony a stylopisy, nebo přidávat nové funkce`,
    Unavailable: "Připojení k databázi selhalo.",
    Version3: "Umbraco verze 3",
    Version4: "Umbraco verze 4",
    watch: "Shlédnout",
    welcomeIntro: `Tento průvodce Vás provede procesem nastavení <strong>umbraca %0%</strong> jako čisté instalace nebo povýšením z 3.0.
                                <br /><br />
                                Stiskněte <strong>"následující"</strong> pro spuštění průvodce.`
  },
  language: {
    cultureCode: "Kód jazyka",
    displayName: "Název jazyka"
  },
  lockout: {
    lockoutWillOccur: "Byli jste nečinní a odhlášení proběhne automaticky za",
    renewSession: "Obnovte nyní pro uložení práce"
  },
  login: {
    greeting0: "Vítejte",
    greeting1: "Vítejte",
    greeting2: "Vítejte",
    greeting3: "Vítejte",
    greeting4: "Vítejte",
    greeting5: "Vítejte",
    greeting6: "Vítejte",
    instruction: "přihlašte se níže",
    signInWith: "Přihlásit se pomocí",
    timeout: "Relace vypršela",
    bottomText: '<p style="text-align:right;">&copy; 2001 - %0% <br /><a href="https://umbraco.com" style="text-decoration: none" target="_blank" rel="noopener">umbraco.org</a></p> ',
    forgottenPassword: "Zapomenuté heslo?",
    forgottenPasswordInstruction: "Na uvedenou adresu bude zaslán e-mail s odkazem pro obnovení hesla",
    requestPasswordResetConfirmation: "Pokud odpovídá našim záznamům, bude na zadanou adresu zaslán e-mail s pokyny k obnovení hesla",
    showPassword: "Zobrazit heslo",
    hidePassword: "Skrýt heslo",
    returnToLogin: "Vrátit se na přihlašovací obrazovku",
    setPasswordInstruction: "Zadejte nové heslo",
    setPasswordConfirmation: "Vaše heslo bylo aktualizováno",
    resetCodeExpired: "Odkaz, na který jste klikli, je neplatný nebo jeho platnost vypršela",
    resetPasswordEmailCopySubject: "Umbraco: Resetování hesla",
    resetPasswordEmailCopyFormat: `
        <html>
            <head>
                <meta name='viewport' content='width=device-width'>
                <meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
            </head>
            <body class='' style='font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; color: #392F54; line-height: 22px; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background: #1d1333; margin: 0; padding: 0;' bgcolor='#1d1333'>
                <style type='text/css'> @media only screen and (max-width: 620px) {table[class=body] h1 {font-size: 28px !important; margin-bottom: 10px !important; } table[class=body] .wrapper {padding: 32px !important; } table[class=body] .article {padding: 32px !important; } table[class=body] .content {padding: 24px !important; } table[class=body] .container {padding: 0 !important; width: 100% !important; } table[class=body] .main {border-left-width: 0 !important; border-radius: 0 !important; border-right-width: 0 !important; } table[class=body] .btn table {width: 100% !important; } table[class=body] .btn a {width: 100% !important; } table[class=body] .img-responsive {height: auto !important; max-width: 100% !important; width: auto !important; } } .btn-primary table td:hover {background-color: #34495e !important; } .btn-primary a:hover {background-color: #34495e !important; border-color: #34495e !important; } .btn  a:visited {color:#FFFFFF;} </style>
                <table border="0" cellpadding="0" cellspacing="0" class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;" bgcolor="#1d1333">
                    <tr>
                        <td style="font-family: sans-serif; font-size: 14px; vertical-align: top; padding: 24px;" valign="top">
                            <table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;">
                                <tr>
                                    <td background="https://umbraco.com/umbraco/assets/img/application/logo.png" bgcolor="#1d1333" width="28" height="28" valign="top" style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
                                        <!--[if gte mso 9]> <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:30px;height:30px;"> <v:fill type="tile" src="https://umbraco.com/umbraco/assets/img/application/logo.png" color="#1d1333" /> <v:textbox inset="0,0,0,0"> <![endif]-->
                                        <div> </div>
                                        <!--[if gte mso 9]> </v:textbox> </v:rect> <![endif]-->
                                    </td>
                                    <td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top"></td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
                <table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;' bgcolor='#1d1333'>
                    <tr>
                        <td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
                        <td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 560px; width: 560px; margin: 0 auto; padding: 10px;' valign='top'>
                            <div class='content' style='box-sizing: border-box; display: block; max-width: 560px; margin: 0 auto; padding: 10px;'>
                                <br>
                                <table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; border-radius: 3px; background: #FFFFFF;' bgcolor='#FFFFFF'>
                                    <tr>
                                        <td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 50px;' valign='top'>
                                            <table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
                                                <tr>
                                                    <td style='line-height: 24px; font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'>
                                                        <h1 style='color: #392F54; font-family: sans-serif; font-weight: bold; line-height: 1.4; font-size: 24px; text-align: left; text-transform: capitalize; margin: 0 0 30px;' align='left'>
                                                            Vyžadováno resetování hesla
                                                        </h1>
                                                        <p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
                                                            Vaše uživatelské jméno pro přihlášení do backoffice Umbraco je: <strong>%0%</strong>
                                                        </p>
                                                        <p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
                                                            <table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
                                                                <tbody>
                                                                    <tr>
                                                                        <td style='font-family: sans-serif; font-size: 14px; vertical-align: top; border-radius: 5px; text-align: center; background: #35C786;' align='center' bgcolor='#35C786' valign='top'>
                                                                            <a href='%1%' target='_blank' rel='noopener' style='color: #FFFFFF; text-decoration: none; -ms-word-break: break-all; word-break: break-all; border-radius: 5px; box-sizing: border-box; cursor: pointer; display: inline-block; font-size: 14px; font-weight: bold; text-transform: capitalize; background: #35C786; margin: 0; padding: 12px 30px; border: 1px solid #35c786;'>
                                                                                Kliknutím na tento odkaz obnovíte své heslo
                                                                            </a>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </p>
                                                        <p style='max-width: 400px; display: block; color: #392F54; font-family: sans-serif; font-size: 14px; line-height: 20px; font-weight: normal; margin: 15px 0;'>Pokud nemůžete kliknout na odkaz, zkopírujte a vložte tuto adresu URL do okna prohlížeče:</p>
                                                            <table border='0' cellpadding='0' cellspacing='0'>
                                                                <tr>
                                                                    <td style='-ms-word-break: break-all; word-break: break-all; font-family: sans-serif; font-size: 11px; line-height:14px;'>
                                                                        <font style="-ms-word-break: break-all; word-break: break-all; font-size: 11px; line-height:14px;">
                                                                            <a style='-ms-word-break: break-all; word-break: break-all; color: #392F54; text-decoration: underline; font-size: 11px; line-height:15px;' href='%1%'>%1%</a>
                                                                        </font>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </p>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                                <br><br><br>
                            </div>
                        </td>
                        <td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
                    </tr>
                </table>
            </body>
        </html>
    `
  },
  main: {
    dashboard: "Ovládací panel",
    sections: "Sekce",
    tree: "Obsah"
  },
  moveOrCopy: {
    choose: "Vyberte stránku výše...",
    copyDone: "%0% byl zkopírován do %1%",
    copyTo: "Níže vyberte, kam má být dokument %0% zkopírován",
    moveDone: "%0% byl přesunut do %1%",
    moveTo: "Níže vyberte, kam má být dokument %0% přesunut",
    nodeSelected: "byl vybrán jako kořen Vašeho nového obsahu, klikněte na 'ok' níže.",
    noNodeSelected: "Ještě nebyl vybrán uzel, vyberte, prosím, uzel ze seznamu výše, než stisknete 'ok'",
    notAllowedByContentType: "Aktuální uzel není povolen pod vybraným uzlem kvůli jeho typu",
    notAllowedByPath: "Aktuální uzel nemůže být přesunut do jedné ze svých podstránek",
    notAllowedAtRoot: "Aktuální uzel nemůže být v kořeni",
    notValid: "Operace není povolena, protože máte nedostatečná práva pro 1 nebo více podřizených dokumentů.",
    relateToOriginal: "Vztáhněte kopírované položky k originálu"
  },
  notifications: {
    editNotifications: "Upravte vaše oznámení pro %0%",
    notificationsSavedFor: "Nastavení oznámení bylo uloženo pro %0%",
    notifications: "Upozornění"
  },
  packager: {
    actions: "Akce",
    created: "Vytvořeno",
    createPackage: "Vytvořit balíček",
    chooseLocalPackageText: `
      Vyberte balíček ve svém počítači kliknutím na tlačítko Procházet<br />
         a výběrem balíčku. Balíčky Umbraco mají obvykle přípony ".umb" nebo ".zip".
      `,
    deletewarning: "Tím se balíček odstraní",
    includeAllChildNodes: "Zahrnout všechny podřízené uzly",
    installed: "Nainstalováno",
    installedPackages: "Nainstalované balíčky",
    noConfigurationView: "Tento balíček nemá žádné zobrazení konfigurace",
    noPackagesCreated: "Zatím nebyly vytvořeny žádné balíčky",
    noPackages: "Nemáte nainstalované žádné balíčky",
    noPackagesDescription: "Nemáte nainstalované žádné balíčky. Nainstalujte místní balíček tak, že jej vyberete ze svého počítače, nebo procházejte dostupné balíčky pomocí ikony <strong>Balíčky</strong> v pravém horním rohu obrazovky.",
    packageContent: "Obsah balíčku",
    packageLicense: "Licence",
    packageSearch: "Hledat balíčky",
    packageSearchResults: "Výsledky pro",
    packageNoResults: "Nemohli jsme nic najít",
    packageNoResultsDescription: "Zkuste prosím vyhledat jiný balíček nebo procházet jednotlivé kategorie",
    packagesPopular: "Oblíbené",
    packagesNew: "Nové",
    packageHas: "má",
    packageKarmaPoints: "karma body",
    packageInfo: "Informace",
    packageOwner: "Vlastník",
    packageContrib: "Přispěvatelé",
    packageCreated: "Vytvořeno",
    packageCurrentVersion: "Aktuální verze",
    packageNetVersion: ".NET verze",
    packageDownloads: "Počet stažení",
    packageLikes: "Počet lajků",
    packageCompatibility: "kompatibilita",
    packageCompatibilityDescription: "Tento balíček je kompatibilní s následujícími verzemi Umbraco, jak ohlásili členové komunity. Plnou kompatibilitu nelze zaručit u verzí hlášených pod 100%",
    packageExternalSources: "Externí zdroje",
    packageAuthor: "Autor",
    packageDocumentation: "Dokumentace",
    packageMetaData: "Meta data balíčku",
    packageName: "Název balíčku",
    packageNoItemsHeader: "Balíček neobsahuje žádné položky",
    packageNoItemsText: `Tento balíček neobsahuje žádné položky k odinstalování.<br/><br/>
      Můžete jej ze systému bezpečně odstranit kliknutím na "odebrat balíček" níže.`,
    packageOptions: "Možnosti balíčku",
    packageReadme: "Čti mě balíčku",
    packageRepository: "Úložiště balíčku",
    packageUninstallConfirm: "Potvrdit odinstalování",
    packageUninstalledHeader: "Balíček byl odinstalován",
    packageUninstalledText: "Balíček byl úspěšně odinstalován",
    packageUninstallHeader: "Odinstalovat balíček",
    packageUninstallText: `Níže můžete zrušit zaškrtnutí položek, které si nepřejete nyní odebrat. Jakmile kliknete na "potvrdit odinstalování", všechny zaškrtnuté položky budou odebrány.<br />
      <span style="color: Red; font-weight: bold;">Upozornění:</span> všechny dokumenty, media atd. závislé na položkách, které odstraníte, přestanou pracovat a mohou vést k nestabilitě systému,
      takže odinstalovávejte opatrně. Jste-li na pochybách, kontaktujte autora balíčku.`,
    packageVersion: "Verze balíčku"
  },
  paste: {
    doNothing: "Vložit s úplným formatováním (nedoporučeno)",
    errorMessage: "Text, který chcete vložit, obsahuje speciální znaky nebo formatování. Toto může být způsobeno kopirováním textu z Microsoft Wordu. Umbraco může odstranit speciální znaky nebo formatování, takže vložený obsah bude pro web vhodnější.",
    removeAll: "Vložit jako čistý text bez jakéhokoliv formátování",
    removeSpecialFormattering: "Vložit, ale odstranit formátování (doporučeno)"
  },
  publicAccess: {
    paGroups: "Ochrana prostřednictvím rolí",
    paGroupsHelp: "Pokud si přejete řídit přístup ke stránce za použití autentizace prostřednictvím rolí,<br /> použijte členské skupiny umbraca.",
    paGroupsNoGroups: "Musíte vytvořit členskou skupinu před tím, než můžete použít autentizaci prostřednictvím rolí",
    paErrorPage: "Chybová stránka",
    paErrorPageHelp: "Použita, když jsou lidé přihlášení, ale nemají přístup",
    paHowWould: "Vyberte, jak omezit přístup k této stránce",
    paIsProtected: "%0% je nyní chráněna",
    paIsRemoved: "Ochrana odebrána z %0%",
    paLoginPage: "Přihlašovací stránka",
    paLoginPageHelp: "Vyberte stránku, která obsahuje přihlašovací formulář",
    paRemoveProtection: "Odstranit ochranu",
    paRemoveProtectionConfirm: "Are you sure you want to remove the protection from the page <strong>%0%</strong>?",
    paSelectPages: "Vyberte stránky, které obsahují přihlašovací formulář a chybová hlášení",
    paSelectRoles: "Vyberte role, které mají přístup k této stránce",
    paSelectGroups: "Vyberte role, které mají přístup ke stránce <strong>%0%</strong>",
    paSelectMembers: "Vyberte členy, kteří mají přístup ke stránce <strong>%0%</strong>",
    paMembers: "Ochrana konkrétních členů",
    paMembersHelp: "Pokud si přejete udělit přístup konkrétním členům",
    paSetLogin: "Nastavte přihlašovací jmého a heslo pro tuto stránku",
    paSimple: "Jednouživatelská ochrana",
    paSimpleHelp: "Jestliže chcete nastavit jenom jednoduchou ochranu prostřednictvím uživatelského jména a hesla"
  },
  publish: {
    invalidPublishBranchPermissions: "Nedostatečná uživatelská oprávnění k publikování všech potomků",
    contentPublishedFailedIsTrashed: `
      %0% nelze publikovat, protože položka je v koši.
    `,
    contentPublishedFailedAwaitingRelease: `
      %0% nemůže být publikována, protože položka je naplánovaná k uvolnění.
    `,
    contentPublishedFailedExpired: `
      %0% nelze publikovat, protože platnost položky vypršela.
    `,
    contentPublishedFailedInvalid: `
      %0% nemůže být publikována, protože tyto vlastnosti: %1%  nesplňují validační pravidla.
    `,
    contentPublishedFailedByEvent: `
      %0% nemůže být publikována, protože rozšíření třetí strany akci zrušilo.
    `,
    contentPublishedFailedByParent: `
      %0% nemůže být publikována, protože rodičovská stránka není publikována.
    `,
    contentPublishedFailedByMissingName: "%0% nelze zveřejnit, protože chybí jméno.",
    contentPublishedFailedReqCultureValidationError: "Ověření se nezdařilo pro požadovaný jazyk '% 0%'. Tento jazyk byl uložen, ale nezveřejněn.",
    inProgress: "Probíhá publikování - počkejte, prosím...",
    inProgressCounter: "%0% ze %1% stránek bylo publikováno...",
    nodePublish: "%0% byla publikována",
    nodePublishAll: "%0% a podstránky byly publikovány",
    publishAll: "Publikovat %0% a všechny její podstránky",
    publishHelp: `Klikněte <em>ok</em> pro publikování <strong>%0%</strong> a tedy zveřejnění jejího obsahu.<br/><br />
      Můžete publikovat tuto stránku a všechny její podstránky zatrhnutím <em>publikovat všchny podstránky</em> níže.
      `,
    includeUnpublished: "Zahrnout nepublikované podřízené stránky"
  },
  colorpicker: {
    noColors: "Nenakonfigurovali jste žádné schválené barvy"
  },
  contentPicker: {
    allowedItemTypes: "Můžete vybrat pouze položky typu (typů): %0%",
    pickedTrashedItem: "Vybrali jste aktuálně odstraněnou položku obsahu nebo položku v koši",
    pickedTrashedItems: "Vybrali jste aktuálně odstraněné položky obsahu nebo položky v koši"
  },
  mediaPicker: {
    deletedItem: "Smazaná položka",
    pickedTrashedItem: "Vybrali jste aktuálně odstraněnou položku média nebo položku v koši",
    pickedTrashedItems: "Vybrali jste aktuálně odstraněné položky médií nebo položky médií v koši",
    trashed: "V koši"
  },
  relatedlinks: {
    enterExternal: "zadejte externí odkaz",
    chooseInternal: "zvolte interní stránku",
    caption: "Nadpis",
    link: "Odkaz",
    newWindow: "Otevřít v novém okně",
    captionPlaceholder: "zadejte titulek",
    externalLinkPlaceholder: "Zadejte odkaz",
    addExternal: "Přidat vnější odkaz",
    addInternal: "Přidat vnitřní odkaz",
    addlink: "Přidat",
    internalPage: "Vnitřní stránka",
    linkurl: "URL",
    modeDown: "Posunout dolů",
    modeUp: "Posunout nahoru",
    removeLink: "Odebrat odkaz"
  },
  imagecropper: {
    reset: "Zrušit oříznutí",
    updateEditCrop: "Hotovo",
    undoEditCrop: "Vrátit změny"
  },
  rollback: {
    headline: "Vyberte verzi, kterou chcete porovnat s aktuální verzí",
    diffHelp: "Tohle ukazuje rozdíly mezi současnou verzi a vybranou verzi<br /><del>Červený</del> text nebude ve vybrané verzi zobrazen, <ins>zelený znamená přidaný</ins>].",
    documentRolledBack: "Dokument byl vrácen na starší verzi",
    htmlHelp: "Tohle zobrazuje vybranou verzi jako html, jestliže chcete vidět rozdíly mezi 2 verzemi najednou, použijte rozdílové zobrazení",
    rollbackTo: "Vrátit starší verzi ",
    selectVersion: "Vybrat verzi",
    view: "Zobrazení"
  },
  scripts: {
    editscript: "Editovat skriptovací soubor"
  },
  sections: {
    content: "Obsah",
    forms: "Formuláře",
    media: "Média",
    member: "Členové",
    packages: "Balíčky",
    settings: "Nastavení",
    translation: "Překlad",
    users: "Uživatelé",
    concierge: "Domovník",
    courier: "Kurýr",
    developer: "Vývojář",
    installer: "Průvodce nastavením Umbraca",
    newsletters: "Zpravodaje",
    statistics: "Statistiky",
    help: "Nápověda"
  },
  help: {
    tours: "Příručky",
    theBestUmbracoVideoTutorials: "Nejlepší videopříručky Umbraco",
    umbracoForum: "Navštívit our.umbraco.com",
    umbracoTv: "Navštívit umbraco.tv"
  },
  settings: {
    defaulttemplate: "Výchozí šablona",
    importDocumentTypeHelp: 'Pro importování typu dokumentu vyhledejte soubor ".udt" ve svém počítači tak, že kliknete na tlačítko "Prohledat" a pak kliknete na "Import" (na následující obrazovce budete vyzváni k potvrzení)',
    newtabname: "Název nové záložky",
    nodetype: "Typ uzlu",
    objecttype: "Typ",
    stylesheet: "Stylopis",
    script: "Skript",
    tab: "Záložka",
    tabname: "Název záložky",
    tabs: "Záložky",
    contentTypeEnabled: "Nadřazený typ obsahu povolen",
    contentTypeUses: "Tento typ obsahu používá",
    noPropertiesDefinedOnTab: 'Na této záložce nejsou definovány žádné vlastnosti. Pro vytvoření nové vlastnosti klikněte na odkaz "přidat novou vlastnost" nahoře.',
    createMatchingTemplate: "Vytvořit odpovídající šablonu",
    addIcon: "Přidat ikonu"
  },
  sort: {
    sortOrder: "Řazení",
    sortCreationDate: "Datum vytvoření",
    sortDone: "Třídění bylo ukončeno.",
    sortHelp: "Abyste nastavili, jak mají být položky seřazeny, přetáhněte jednotlivé z nich nahoru či dolů. Anebo klikněte na hlavičku sloupce pro setřídění celé kolekce",
    sortPleaseWait: " Čekejte, prosím. Položky jsou tříděny a může to chvíli trvat.",
    sortEmptyState: "Tato položka nemá vnořené položky k seřazení"
  },
  speechBubbles: {
    validationFailedHeader: "Validace",
    validationFailedMessage: "Před uložením položky je nutné opravit chyby",
    operationFailedHeader: "Chyba",
    operationSavedHeader: "Uloženo",
    invalidUserPermissionsText: "Nedostatečná uživatelská oprávnění, operace nemohla být dokončena",
    operationCancelledHeader: "Zrušeno",
    operationCancelledText: "Operace byla zrušena doplňkem třetí strany",
    contentTypeDublicatePropertyType: "Typ vlastnosti už existuje",
    contentTypePropertyTypeCreated: "Typ vlastnosti vytvořen",
    contentTypePropertyTypeCreatedText: "Název: %0% <br />Datový typ: %1%",
    contentTypePropertyTypeDeleted: "Typ vlastnosti odstraněn",
    contentTypeSavedHeader: "Typ vlastnosti uložen",
    contentTypeTabCreated: "Záložka vytvořena",
    contentTypeTabDeleted: "Záložka odstraněna",
    contentTypeTabDeletedText: "Záložka s id: %0% odstraněna",
    cssErrorHeader: "Stylopis nebyl uložen",
    cssSavedHeader: "Stylopis byl uložen",
    cssSavedText: "Stylopis byl uložen bez chyb",
    dataTypeSaved: "Datový typ byl uložen",
    dictionaryItemSaved: "Položka slovníku byla uložena",
    editContentPublishedHeader: "Obsah byl publikován",
    editContentPublishedText: "a je viditelný na webu",
    editMultiContentPublishedText: "%0% dokumentů zveřejněných a viditelných na webu",
    editVariantPublishedText: "%0% zveřejněných a viditelných na webu",
    editMultiVariantPublishedText: "%0% dokumentů zveřejněných pro jazyky %1% a viditelných na webu",
    editContentSavedHeader: "Obsah byl uložen",
    editContentSavedText: "Nezapomeňte na publikování, aby se změny projevily",
    editContentScheduledSavedText: "Načasování publikování bylo aktualizováno",
    editVariantSavedText: "%0% uloženo",
    editContentSendToPublish: "Odeslat ke schválení",
    editContentSendToPublishText: "Změny byly odeslány ke schválení",
    editVariantSendToPublishText: "%0% změn bylo odesláno ke schválení",
    editMediaSaved: "Médium bylo uloženo",
    editMediaSavedText: "Médium bylo uloženo bez chyb",
    editMemberSaved: "Člen byl uložen",
    editStylesheetPropertySaved: "Vlastnost stylopisu byla uložena",
    editStylesheetSaved: "Stylopis byl uložen",
    editTemplateSaved: "Šablona byla uložena",
    editUserError: "Chyba při ukládání uživatele (zkontrolujte log)",
    editUserSaved: "Uživatel byl uložen",
    editUserTypeSaved: "Typ uživatele byl uložen",
    editUserGroupSaved: "Skupina uživatelů byla uložena",
    editCulturesAndHostnamesSaved: "Jazyky a názvy hostitelů byly uloženy",
    editCulturesAndHostnamesError: "Při ukládání jazyků a názvů hostitelů došlo k chybě",
    fileErrorHeader: "Soubor nebyl uložen",
    fileErrorText: "soubor nemohl být uložen. Zkontrolujte, prosím, oprávnění k souboru",
    fileSavedHeader: "Soubor byl uložen",
    fileSavedText: "Soubor byl uložen bez chyb",
    languageSaved: "Jazyk byl uložen",
    mediaTypeSavedHeader: "Typ média byl uložen",
    memberTypeSavedHeader: "Typ člena byl uložen",
    memberGroupSavedHeader: "Skupina členů byla uložena",
    templateErrorHeader: "Šablona nebyla uložena",
    templateErrorText: "Ujistěte se, prosím, že nemáte 2 šablony se stejným aliasem",
    templateSavedHeader: "Šablona byla uložena",
    templateSavedText: "Šablona byla uložena bez chyb!",
    contentUnpublished: "Publikování obsahu bylo zrušeno",
    contentCultureUnpublished: "Varianta obsahu %0% nebyla publikována",
    contentMandatoryCultureUnpublished: "Povinný jazyk '%0%' nebyl publikován. Všechny jazyky pro tuto položku obsahu nejsou nyní publikovány.",
    partialViewSavedHeader: "Částečný pohled byl uložen",
    partialViewSavedText: "Částečný pohled byl uložen bez chyb!",
    partialViewErrorHeader: "Částečný pohled nebyl uložen",
    partialViewErrorText: "Při ukládání souboru došlo k chybě.",
    permissionsSavedFor: "Oprávnění byla uložena pro",
    deleteUserGroupsSuccess: "Smazáno %0% skupin uživatelů",
    deleteUserGroupSuccess: "%0% bylo smazáno",
    enableUsersSuccess: "Povoleno %0% uživatelů",
    disableUsersSuccess: "Zakázáno %0% uživatelů",
    enableUserSuccess: "%0% je nyní povoleno",
    disableUserSuccess: "%0% je nyní zakázáno",
    setUserGroupOnUsersSuccess: "Skupiny uživatelů byly nastaveny",
    unlockUsersSuccess: "Odemčeno %0% uživatelů",
    unlockUserSuccess: "%0% je nyný odemčeno",
    memberExportedSuccess: "Člen byl exportován do souboru",
    memberExportedError: "Při exportu člena došlo k chybě",
    deleteUserSuccess: "Uživatel %0% byl smazán",
    resendInviteHeader: "Pozvat uživatele",
    resendInviteSuccess: "Pozvánka byla znovu odeslána na %0%",
    contentReqCulturePublishError: "Dokument nelze publikovat, protože %0% není publikována",
    contentCultureValidationError: "Ověření pro jazyk '%0%' se nezdařilo",
    documentTypeExportedSuccess: "Typ dokumentu byl exportován do souboru",
    documentTypeExportedError: "Při exportu typu dokumentu došlo k chybě",
    scheduleErrReleaseDate1: "Datum vydání nemůže být v minulosti",
    scheduleErrReleaseDate2: "Nelze naplánovat publikování dokumentu, protože %0% není publikována",
    scheduleErrReleaseDate3: "Dokument nelze naplánovat na publikování, protože „%0%“ má datum zveřejnění později než nepovinný jazyk",
    scheduleErrExpireDate1: "Datum vypršení platnosti nemůže být v minulosti",
    scheduleErrExpireDate2: "Datum vypršení nemůže být před datem vydání",
    contentPublishedFailedByEvent: "Publikování bylo zrušeno doplňkem třetí strany",
    editContentPublishedFailedByParent: "Publikování se nezdařilo, protože nadřazená stránka není publikována"
  },
  stylesheet: {
    addRule: "Přidat styl",
    editRule: "Upravit styl",
    editorRules: "Styly Rich Text editoru",
    editorRulesHelp: "Definujte styly, které by měly být k dispozici v editoru formátovaného textu pro tuto šablonu stylů",
    editstylesheet: "Editovat stylopis",
    editstylesheetproperty: "Editovat vlastnost stylopisu",
    nameHelp: "Název, který identifikuje vlastnost stylu v editoru formátovaného textu",
    preview: "Náhled",
    previewHelp: "Jak bude text vypadat v Rich Text editoru.",
    selector: "CSS identifikátor nebo třída",
    selectorHelp: 'Používá syntaxi CSS, např. "h1" nebo ".redHeader"',
    styles: "Styly",
    stylesHelp: 'CSS, který by měl být použit v editoru RTF, např. "color:red;"',
    tabCode: "Kód",
    tabRules: "Rich Text editor",
    aliasHelp: "Používá CSS syntaxi např.: h1, .redHeader, .blueTex"
  },
  template: {
    deleteByIdFailed: "Nepodařilo se odstranit šablonu s ID %0%",
    edittemplate: "Editovat šablonu",
    insertSections: "Sekce",
    insertContentArea: "Vložit obsahovou oblast",
    insertContentAreaPlaceHolder: "Vložit zástupce obsahové oblasti",
    insert: "Vložit",
    insertDesc: "Vyberte, co chcete vložit do své šablony",
    insertDictionaryItem: "Vložit položku slovníku",
    insertDictionaryItemDesc: "Položka slovníku je zástupný symbol pro překladatelný text, což usnadňuje vytváření návrhů pro vícejazyčné webové stránky.",
    insertMacro: "Vložit makro",
    insertMacroDesc: `
      Makro je konfigurovatelná součást, která je skvělá pro opakovaně použitelné části návrhu, kde potřebujete předat parametry, jako jsou galerie, formuláře a seznamy.
    `,
    insertPageField: "Vložit pole stránky Umbraco",
    insertPageFieldDesc: "Zobrazuje hodnotu pojmenovaného pole z aktuální stránky s možnostmi upravit hodnotu nebo alternativní hodnoty.",
    insertPartialView: "Částečná šablona",
    insertPartialViewDesc: `
      Částečná šablona je samostatný soubor šablony, který lze vykreslit uvnitř jiné šablony. Je to skvělé pro opakované použití nebo pro oddělení složitých šablon.
    `,
    mastertemplate: "Nadřazená šablona",
    noMaster: "Žádný master",
    renderBody: "Vykreslit podřízenou šablonu",
    renderBodyDesc: `
     Vykreslí obsah podřízené šablony vložením zástupného symbolu <code>@RenderBody()</code>.
      `,
    defineSection: "Definujte pojmenovanou sekci",
    defineSectionDesc: `
         Definuje část vaší šablony jako pojmenovanou sekci jejím zabalením do <code>@section {...}</code>. Ta může být vykreslena v konkrétní oblasti nadřazené šablony pomocí <code>@RenderSection</code>.
      `,
    renderSection: "Vykreslit pojmenovanou sekci",
    renderSectionDesc: `
      Vykreslí pojmenovanou oblast podřízené šablony vložením zástupného symbolu <code>@RenderSection(name)</code>. Tím se vykreslí oblast podřízené šablony, která je zabalena do odpovídající definice <code>@section[name] {...}</code>.
      `,
    sectionName: "Název sekce",
    sectionMandatory: "Sekce je povinná",
    sectionMandatoryDesc: `
            Pokud je povinná, musí podřízená šablona obsahovat definici <code>@section</code>, jinak se zobrazí chyba.
            `,
    queryBuilder: "Tvůrce dotazů",
    itemsReturned: "položky vráceny, do",
    iWant: "Chci",
    allContent: "veškerý obsah",
    contentOfType: 'obsah typu "%0%"',
    from: "z(e)",
    websiteRoot: "můj web",
    where: "kde",
    and: "a",
    is: "je",
    isNot: "není",
    before: "před",
    beforeIncDate: "před (včetně zvoleného datumu)",
    after: "po",
    afterIncDate: "po (včetně zvoleného datumu)",
    equals: "rovná se",
    doesNotEqual: "nerovná se",
    contains: "obsahuje",
    doesNotContain: "neobsahuje",
    greaterThan: "větší než",
    greaterThanEqual: "větší nebo rovno",
    lessThan: "menší než",
    lessThanEqual: "menší nebo rovno",
    id: "Id",
    name: "Název",
    createdDate: "Datum vytvoření",
    lastUpdatedDate: "Datum poslední aktualizace",
    orderBy: "řadit podle",
    ascending: "vzestupně",
    descending: "sestupně",
    template: "Šablona",
    quickGuide: "Rychlá příručka k šablonovým značkám umbraca"
  },
  grid: {
    media: "Obrázek",
    macro: "Makro",
    insertControl: "Vybrat typ obsahu",
    chooseLayout: "Vybrat rozvržení",
    addRows: "Přidat řádek",
    addElement: "Přidat obsah",
    dropElement: "Zahodit obsah",
    settingsApplied: "Nastavení aplikováno",
    contentNotAllowed: "Tento obsah zde není povolen",
    contentAllowed: "Tento obsah je zde povolen",
    clickToEmbed: "Klepněte pro vložení",
    clickToInsertImage: "Klepnutím vložíte obrázek",
    placeholderWriteHere: "Zde pište...",
    gridLayouts: "Rozvržení mřížky",
    gridLayoutsDetail: "Rozvržení je celková pracovní oblast pro editor mřížky, obvykle potřebujete pouze jedno nebo dvě různá rozvržení",
    addGridLayout: "Přidat rozvržení mřížky",
    addGridLayoutDetail: "Upravte rozvržení nastavením šířky sloupců a přidáním dalších sekcí",
    rowConfigurations: "Konfigurace řádků",
    rowConfigurationsDetail: "Řádky jsou předdefinované buňky uspořádané vodorovně",
    addRowConfiguration: "Přidat konfiguraci řádku",
    addRowConfigurationDetail: "Upravte řádek nastavením šířky buněk a přidáním dalších buněk",
    columns: "Sloupce",
    columnsDetails: "Celkový počet sloupců v rozvržení mřížky",
    settings: "Nastavení",
    settingsDetails: "Nakonfigurujte, jaká nastavení mohou editoři změnit",
    styles: "Styly",
    stylesDetails: "Nakonfigurujte, co mohou editoři stylů změnit",
    allowAllEditors: "Povolit všechny editory",
    allowAllRowConfigurations: "Povolit všechny konfigurace řádků",
    maxItems: "Maximální počet položek",
    maxItemsDescription: "Nechte prázdné nebo nastavte na 0 pro neomezené",
    setAsDefault: "Nastavit jako výchozí",
    chooseExtra: "Vyberat navíc",
    chooseDefault: "Zvolit výchozí",
    areAdded: "jsou přidány",
    youAreDeleting: "Odstraňujete konfiguraci řádku",
    deletingARow: `
      Odstranění názvu konfigurace řádku povede ke ztrátě dat pro veškerý existující obsah založený na této konfiguraci.
    `
  },
  contentTypeEditor: {
    compositions: "Složení",
    group: "Skupina",
    noGroups: "Nepřidali jste žádné skupiny",
    addGroup: "Přidat skupinu",
    inheritedFrom: "Zděděno od",
    addProperty: "Přidat vlastnost",
    requiredLabel: "Požadovaný popisek",
    enableListViewHeading: "Povolit zobrazení seznamu",
    enableListViewDescription: "Nakonfiguruje položku obsahu tak, aby zobrazovala seznam svých potomků a seznam potomků, které je možné prohledávat, potomci se nebudou zobrazovat ve stromu",
    allowedTemplatesHeading: "Povolené šablony",
    allowedTemplatesDescription: "Vyberte, kteří editoři šablon mohou používat obsah tohoto typu",
    allowAsRootHeading: "Povolit jako root",
    allowAsRootDescription: "Povolit editorům vytvářet obsah tohoto typu v kořenovém adresáři stromu obsahu.",
    childNodesHeading: "Povolené typy podřízených uzlů",
    childNodesDescription: "Povolit vytváření obsahu zadaných typů pod obsahem tohoto typu.",
    chooseChildNode: "Vybrat podřízený uzel",
    compositionsDescription: "Zdědí záložky a vlastnosti z existujícího typu dokumentu. Nové záložky budou přidány do aktuálního typu dokumentu nebo sloučeny, pokud existuje záložka se stejným názvem.",
    compositionInUse: "Tento typ obsahu se používá ve složení, a proto jej nelze poskládat.",
    noAvailableCompositions: "Nejsou k dispozici žádné typy obsahu, které lze použít jako složení.",
    compositionRemoveWarning: "Odebráním složení odstraníte všechna související data vlastností. Jakmile uložíte typ dokumentu, již není cesta zpět.",
    availableEditors: "Vytvořit nové",
    reuse: "Použít existující",
    editorSettings: "Nastavení editoru",
    configuration: "Konfigurace",
    yesDelete: "Ano, smazat",
    movedUnderneath: "bylo přesunuto pod",
    copiedUnderneath: "bylo zkopírováno pod",
    folderToMove: "Vybrat složku, kterou chcete přesunout",
    folderToCopy: "Vybrat složku, kterou chcete kopírovat",
    structureBelow: "ve stromové struktuře níže",
    allDocumentTypes: "Všechny typy dokumentů",
    allDocuments: "Všechny dokumenty",
    allMediaItems: "Všechny média",
    usingThisDocument: "použití tohoto typu dokumentu bude trvale smazáno, prosím potvrďte, že je chcete také odstranit.",
    usingThisMedia: "použití tohoto typu média bude trvale smazáno, potvrďte, že je chcete také odstranit.",
    usingThisMember: "použití tohoto typu člena bude trvale smazáno, potvrďte, že je chcete také odstranit",
    andAllDocuments: "a všechny dokumenty používající tento typ",
    andAllMediaItems: "a všechny mediální položky používající tento typ",
    andAllMembers: "a všichni členové používající tento typ",
    memberCanEdit: "Člen může upravovat",
    memberCanEditDescription: "Povolit editaci této vlastnosti členem na jeho stránce profilu",
    isSensitiveData: "Obsahuje citlivá data",
    isSensitiveDataDescription: "Skrýt tuto hodnotu vlastnosti před editory obsahu, kteří nemají přístup k prohlížení citlivých informací",
    showOnMemberProfile: "Zobrazit v profilu člena",
    showOnMemberProfileDescription: "Povolit zobrazení této vlastnosti na stránce profilu člena",
    tabHasNoSortOrder: "záložka nemá žádné řazení",
    compositionUsageHeading: "Kde se toto složení používá?",
    compositionUsageSpecification: "Toto složení se v současnosti používá ve složení následujících typů obsahu:",
    variantsHeading: "Povolit různé jazyky",
    variantsDescription: "Povolit editorům vytvářet obsah tohoto typu v různých jazycích.",
    allowVaryByCulture: "Povolit různé jazyky",
    elementType: "Typ prvku",
    elementHeading: "Je typ prvku",
    elementDescription: "Typ prvku je určen k použití například ve vnořeném obsahu, nikoli ve stromu.",
    elementCannotToggle: "Jakmile byl typ dokumentu použit k vytvoření jedné nebo více položek obsahu, nelze jej změnit na typ prvku.",
    elementDoesNotSupport: "To neplatí pro typ prvku",
    propertyHasChanges: "V této vlastnosti jste provedli změny. Opravdu je chcete zahodit?"
  },
  languages: {
    addLanguage: "Přidat jazyk",
    mandatoryLanguage: "Povinný jazyk",
    mandatoryLanguageHelp: "Před publikováním uzlu je nutné vyplnit vlastnosti v tomto jazyce.",
    defaultLanguage: "Výchozí jazyk",
    defaultLanguageHelp: "Web Umbraco může mít nastaven pouze jeden výchozí jazyk.",
    changingDefaultLanguageWarning: "Přepnutí výchozího jazyka může mít za následek chybějící výchozí obsah.",
    fallsbackToLabel: "Nahradit nepřeložený obsah za",
    noFallbackLanguageOption: "Žádné nahrazení nepřeloženého jazyka",
    fallbackLanguageDescription: "Chcete-li povolit automatické zobrazení vícejazyčného obsahu v jiném jazyce, pokud není v požadovaném jazyce přeložen, vyberte jej zde.",
    fallbackLanguage: "Nahrazujicí jazyk",
    none: "žádný"
  },
  macro: {
    addParameter: "Přidat parametr",
    editParameter: "Upravit parametr",
    enterMacroName: "Zadejte název makra",
    parameters: "Parametry",
    parametersDescription: "Definujte parametry, které by měly být k dispozici při použití tohoto makra.",
    selectViewFile: "Vyberte soubor makra pro částečnou šablonu"
  },
  modelsBuilder: {
    buildingModels: "Stavební modely",
    waitingMessage: "to může chvíli trvat, nebojte se",
    modelsGenerated: "Generované modely",
    modelsGeneratedError: "Modely nelze vygenerovat",
    modelsExceptionInUlog: "Generování modelů selhalo, viz výjimka v logu Umbraca"
  },
  templateEditor: {
    addDefaultValue: "Přidat výchozí hodnotu",
    defaultValue: "Výchozí hodnota",
    alternativeField: "Alternativní pole",
    alternativeText: "Alternativní text",
    casing: "Velká a malá písmena",
    encoding: "Kódování",
    chooseField: "Vybrat pole",
    convertLineBreaks: "Konvertovat",
    convertLineBreaksHelp: "Nahrazuje nové řádky html tagem &lt;br&gt;",
    customFields: "Vlastní pole",
    dateOnly: "Ano, pouze datum",
    formatAsDate: "Formátovat jako datum",
    htmlEncode: "HTML kódování",
    htmlEncodeHelp: "Nahradí speciální znaky jejich HTML ekvivalentem.",
    insertedAfter: "Bude vloženo za hodnotou pole",
    insertedBefore: "Bude vloženo před hodnotou pole",
    lowercase: "Malá písmena",
    none: "Nic",
    outputSample: "Ukázka výstupu",
    postContent: "Vložit za polem",
    preContent: "Vložit před polem",
    recursive: "Rekurzivní",
    recursiveDescr: "Ano, udělej to rekurzivní",
    standardFields: "Standardní pole",
    uppercase: "Velká písmena",
    urlEncode: "Kódování URL",
    urlEncodeHelp: "Formátuje speciální znaky v URL adresách",
    usedIfAllEmpty: "Bude použito pouze pokud jsou pole nahoře prázdná",
    usedIfEmpty: "Toto pole bude použito pouze pokud je primární pole prázdné",
    withTime: "Ano, s časem. Oddělovač: "
  },
  translation: {
    details: "Podrobnosti překladu",
    DownloadXmlDTD: "Stáhnout XML DTD",
    fields: "Pole",
    includeSubpages: "Zahrnout podstránky",
    mailBody: `
      Dobrý den, %0%

      Toto je automatická zpráva informující Vás, že dokument '%1%'
      byl vyžádán k překladu do '%5%' uživatelem %2%.

      Přejděte na http://%3%/translation/details.aspx?id=%4% pro editování.

      Anebo se přihlašte do umbraca, abyste získali přehled o svých překladatelských úlohách
      http://%3%

      Mějte hezký den!

      Zdraví Umbraco robot
    `,
    noTranslators: "Žádní uživatelé překladatelé nebyli nalezeni. Vytvořte, prosím, překladatele před tím, než začnete posílat obsah k překladu",
    pageHasBeenSendToTranslation: "Stránka '%0%' byla poslána k překladu",
    sendToTranslate: "Poslat stránku '%0%' k překladu",
    totalWords: "Slov celkem",
    translateTo: "Přeložit do",
    translationDone: "Překlad hotov.",
    translationDoneHelp: "Klikutím níže můžete vidět stránky, které jste právě přeložili. Jestliže je nalezena originální stránka, dostanete srovnání 2 stránek.",
    translationFailed: "Překlad selhal, xml soubor může být poškozený",
    translationOptions: "Možnosti překladu",
    translator: "Překladatel",
    uploadTranslationXml: "Nahrát xml překladu"
  },
  treeHeaders: {
    content: "Obsah",
    contentBlueprints: "Šablony obsahu",
    media: "Média",
    cacheBrowser: "Prohlížeč mezipaměti",
    contentRecycleBin: "Koš",
    createdPackages: "Vytvořené balíčky",
    dataTypes: "Datové typy",
    dictionary: "Slovník",
    installedPackages: "Instalované balíčky",
    installSkin: "Instalovat téma",
    installStarterKit: "Instalovat startovní sadu",
    languages: "Jazyky",
    localPackage: "Instalovat místní balíček",
    macros: "Makra",
    mediaTypes: "Typy medií",
    member: "Členové",
    memberGroups: "Skupiny členů",
    memberRoles: "Role",
    memberTypes: "Typy členů",
    documentTypes: "Typy dokumentů",
    relationTypes: "Typy vztahů/vazeb",
    packager: "Balíčky",
    packages: "Balíčky",
    partialViews: "Částečné šablony",
    partialViewMacros: "Makra částečných šablon",
    repositories: "Instalovat z úložiště",
    runway: "Instalovat Runway",
    runwayModules: "Moduly Runway",
    scripting: "Skriptovací soubory",
    scripts: "Skripty",
    stylesheets: "Stylopisy",
    templates: "Šablony",
    logViewer: "Prohlížeč logu",
    users: "Uživatelé",
    settingsGroup: "Nastavení",
    templatingGroup: "Šablony",
    thirdPartyGroup: "Třetí strana",
    userPermissions: "Oprávnění uživatele",
    userTypes: "Typy uživatelů"
  },
  update: {
    updateAvailable: "Nová aktualizace je připrvena",
    updateDownloadText: "%0% je připraven, klikněte zde pro stažení",
    updateNoServer: "Žádné spojení se serverem",
    updateNoServerError: "Chyba při kontrole aktualizace. Zkontrolujte, prosím, trasovací zásobník pro další informace"
  },
  user: {
    access: "Přístupy",
    accessHelp: "Na základě přiřazených skupin a počátečních uzlů má uživatel přístup k následujícím uzlům",
    assignAccess: "Přiřadit přístup",
    administrators: "Administrátor",
    categoryField: "Pole kategorie",
    createDate: "Uživatel byl vytvořen",
    changePassword: "Změnit heslo",
    changePhoto: "Změnit fotku",
    newPassword: "Změnit heslo",
    noLockouts: "nebyl uzamčen",
    noPasswordChange: "Heslo nebylo změněno",
    confirmNewPassword: "Potvrdit heslo",
    changePasswordDescription: "Můžete změnit své heslo pro přístup do administrace Umbraca vyplněním formuláře níže a kliknutím na tlačítko 'Změnit Heslo'",
    contentChannel: "Kanál obsahu",
    createAnotherUser: "Vytvořit dalšího uživatele",
    createUserHelp: "Vytvořte nové uživatele a udělte mu přístup do Umbraco. Po vytvoření nového uživatele bude vygenerováno heslo, které s ním můžete sdílet.",
    descriptionField: "Popis",
    disabled: "Deaktivovat uživatele",
    documentType: "Typ dokumentu",
    editors: "Editor",
    excerptField: "Výtah",
    failedPasswordAttempts: "Neúspěšné pokusy o přihlášení",
    goToProfile: "Přejít na uživatelský profil",
    groupsHelp: "Přidáním skupin přidělte přístup a oprávnění",
    inviteAnotherUser: "Pozvat dalšího uživatele",
    inviteUserHelp: "Pozvěte nové uživatele, a poskytněte jim přístup do Umbraco. Uživatelům bude zaslán e-mail s pozvánkou a s informacemi o tom, jak se přihlásit do Umbraco. Pozvánky mají platnost 72 hodin.",
    language: "Jazyk",
    languageHelp: "Nastavte jazyk, který uvidíte v nabídkách a dialogových oknech",
    lastLockoutDate: "Poslední datum uzamčení",
    lastLogin: "Poslední přihlášení",
    lastPasswordChangeDate: "Heslo bylo naposledy změněno",
    loginname: "Přihlašovací jméno",
    mediastartnode: "Úvodní uzel v knihovně medií",
    mediastartnodehelp: "Omezte knihovnu médií na konkrétní počáteční uzel",
    mediastartnodes: "Úvodní uzly v knihovně medií",
    mediastartnodeshelp: "Omezte knihovnu médií na konkrétní počáteční uzly",
    modules: "Sekce",
    noConsole: "Deaktivovat přistup k Umbracu",
    noLogin: "se dosud nepřihlásil",
    oldPassword: "Staré heslo",
    password: "Heslo",
    resetPassword: "Resetovat heslo",
    passwordChanged: "Vyše heslo bylo změněno!",
    passwordConfirm: "Potvrďte, prosím, nové heslo",
    passwordEnterNew: "Zadejte Vaše nové heslo",
    passwordIsBlank: "Vaše nové heslo nesmí být prázdné!",
    passwordCurrent: "Současné heslo",
    passwordInvalid: "Neplatné současné heslo",
    passwordIsDifferent: "Nové heslo a potvrzující heslo se liší. Zkuste to, prosím, znovu!",
    passwordMismatch: "Potvrzující heslo není stejné jako nové heslo!",
    permissionReplaceChildren: "Nahradit oprávnění podřízených uzlů",
    permissionSelectedPages: "Nyní měníte oprávnění pro stránky:",
    permissionSelectPages: "Vyberte stránky, pro které chcete měnit oprávnění",
    removePhoto: "Odebrat fotografii",
    permissionsDefault: "Výchozí oprávnění",
    permissionsGranular: "Upřesnění oprávnění",
    permissionsGranularHelp: "Nastavte oprávnění pro konkrétní uzly",
    profile: "Profil",
    searchAllChildren: "Prohledat všechny podřízené uzly",
    sectionsHelp: "Přidejte sekce, do kterých mají uživatelé přístup",
    selectUserGroups: "Vybrat skupiny uživatelů",
    noStartNode: "Nebyl vybrán žádný počáteční uzel",
    noStartNodes: "Nebyly vybrány žádné počáteční uzly",
    startnode: "Úvodní uzel v obsahu",
    startnodehelp: "Omezte strom obsahu na konkrétní počáteční uzel",
    startnodes: "Úvodní uzly obsahu",
    startnodeshelp: "Omezte strom obsahu na konkrétní počáteční uzly",
    updateDate: "Uživatel byl naposledy aktualizován",
    userCreated: "byl vytvořen",
    userCreatedSuccessHelp: "Nový uživatel byl úspěšně vytvořen. Pro přihlášení do Umbraco použijte heslo níže.",
    userManagement: "Správa uživatelů",
    username: "Uživatelské jméno",
    userPermissions: "Oprávnění uživatele",
    usergroup: "Uživatelská skupina",
    userInvited: "byl pozván",
    userInvitedSuccessHelp: "Novému uživateli byla zaslána pozvánka s informacemi, jak se přihlásit do Umbraco.",
    userinviteWelcomeMessage: "Dobrý den, vítejte v Umbraco! Za pouhou 1 minutu budete moci používat Umbraco. Jenom od vás potřebujeme, abyste si nastavili heslo.",
    userinviteExpiredMessage: "Vítejte v Umbraco! Vaše pozvánka bohužel vypršela. Obraťte se na svého správce a požádejte jej, aby jí znovu odeslal.",
    writer: "Spisovatel",
    change: "Změnit",
    yourProfile: "Váš profil",
    yourHistory: "Vaše nedávná historie",
    sessionExpires: "Relace vyprší za",
    inviteUser: "Pozvat uživatele",
    createUser: "Vytvořit uživatele",
    sendInvite: "Odeslat pozvánku",
    backToUsers: "Zpět na seznam uživatelů",
    inviteEmailCopySubject: "Umbraco: Pozvánka",
    inviteEmailCopyFormat: `
        <html>
            <head>
                <meta name='viewport' content='width=device-width'>
                <meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
            </head>
            <body class='' style='font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; color: #392F54; line-height: 22px; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background: #1d1333; margin: 0; padding: 0;' bgcolor='#1d1333'>
                <style type='text/css'> @media only screen and (max-width: 620px) {table[class=body] h1 {font-size: 28px !important; margin-bottom: 10px !important; } table[class=body] .wrapper {padding: 32px !important; } table[class=body] .article {padding: 32px !important; } table[class=body] .content {padding: 24px !important; } table[class=body] .container {padding: 0 !important; width: 100% !important; } table[class=body] .main {border-left-width: 0 !important; border-radius: 0 !important; border-right-width: 0 !important; } table[class=body] .btn table {width: 100% !important; } table[class=body] .btn a {width: 100% !important; } table[class=body] .img-responsive {height: auto !important; max-width: 100% !important; width: auto !important; } } .btn-primary table td:hover {background-color: #34495e !important; } .btn-primary a:hover {background-color: #34495e !important; border-color: #34495e !important; } .btn  a:visited {color:#FFFFFF;} </style>
                <table border="0" cellpadding="0" cellspacing="0" class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;" bgcolor="#1d1333">
                    <tr>
                        <td style="font-family: sans-serif; font-size: 14px; vertical-align: top; padding: 24px;" valign="top">
                            <table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;">
                                <tr>
                                    <td background="https://umbraco.com/umbraco/assets/img/application/logo.png" bgcolor="#1d1333" width="28" height="28" valign="top" style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
                                        <!--[if gte mso 9]> <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:30px;height:30px;"> <v:fill type="tile" src="https://umbraco.com/umbraco/assets/img/application/logo.png" color="#1d1333" /> <v:textbox inset="0,0,0,0"> <![endif]-->
                                        <div> </div>
                                        <!--[if gte mso 9]> </v:textbox> </v:rect> <![endif]-->
                                    </td>
                                    <td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top"></td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
                <table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;' bgcolor='#1d1333'>
                    <tr>
                        <td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
                        <td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 560px; width: 560px; margin: 0 auto; padding: 10px;' valign='top'>
                            <div class='content' style='box-sizing: border-box; display: block; max-width: 560px; margin: 0 auto; padding: 10px;'>
                                <br>
                                <table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; border-radius: 3px; background: #FFFFFF;' bgcolor='#FFFFFF'>
                                    <tr>
                                        <td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 50px;' valign='top'>
                                            <table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
                                                <tr>
                                                    <td style='line-height: 24px; font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'>
                                                        <h1 style='color: #392F54; font-family: sans-serif; font-weight: bold; line-height: 1.4; font-size: 24px; text-align: left; text-transform: capitalize; margin: 0 0 30px;' align='left'>
                                                            Zdravím Vás, %0%,
                                                        </h1>
                                                        <p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
                                                            Byli jste pozváni <a href="mailto:%4%" style="text-decoration: underline; color: #392F54; -ms-word-break: break-all; word-break: break-all;">%1%</a> do CMS Umbraco.
                                                        </p>
                                                        <p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
                                                            Zpráva od <a href="mailto:%1%" style="text-decoration: none; color: #392F54; -ms-word-break: break-all; word-break: break-all;">%1%</a>:
                                                            <br/>
                                                            <em>%2%</em>
                                                        </p>
                                                        <table border='0' cellpadding='0' cellspacing='0' class='btn btn-primary' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; box-sizing: border-box;'>
                                                            <tbody>
                                                                <tr>
                                                                    <td align='left' style='font-family: sans-serif; font-size: 14px; vertical-align: top; padding-bottom: 15px;' valign='top'>
                                                                        <table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td style='font-family: sans-serif; font-size: 14px; vertical-align: top; border-radius: 5px; text-align: center; background: #35C786;' align='center' bgcolor='#35C786' valign='top'>
                                                                                        <a href='%3%' target='_blank' rel='noopener' style='color: #FFFFFF; text-decoration: none; -ms-word-break: break-all; word-break: break-all; border-radius: 5px; box-sizing: border-box; cursor: pointer; display: inline-block; font-size: 14px; font-weight: bold; text-transform: capitalize; background: #35C786; margin: 0; padding: 12px 30px; border: 1px solid #35c786;'>
                                                                                            Kliknutím na tento odkaz přijměte pozvání
                                                                                        </a>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <p style='max-width: 400px; display: block; color: #392F54; font-family: sans-serif; font-size: 14px; line-height: 20px; font-weight: normal; margin: 15px 0;'>Pokud nemůžete kliknout na odkaz, zkopírujte a vložte tuto adresu URL do okna prohlížeče:</p>
                                                            <table border='0' cellpadding='0' cellspacing='0'>
                                                                <tr>
                                                                    <td style='-ms-word-break: break-all; word-break: break-all; font-family: sans-serif; font-size: 11px; line-height:14px;'>
                                                                        <font style="-ms-word-break: break-all; word-break: break-all; font-size: 11px; line-height:14px;">
                                                                            <a style='-ms-word-break: break-all; word-break: break-all; color: #392F54; text-decoration: underline; font-size: 11px; line-height:15px;' href='%3%'>%3%</a>
                                                                        </font>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </p>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                                <br><br><br>
                            </div>
                        </td>
                        <td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
                    </tr>
                </table>
            </body>
    </html>`,
    defaultInvitationMessage: "Zasílám pozvání...",
    deleteUser: "Smazat uživatele",
    deleteUserConfirmation: "Opravdu chcete smazat tento uživatelský účet?",
    stateAll: "Vše",
    stateActive: "Aktivní",
    stateDisabled: "Zakázané",
    stateLockedOut: "Uzamčeno",
    stateInvited: "Pozváno",
    stateInactive: "Neaktivní",
    sortNameAscending: "Jméno (A-Z)",
    sortNameDescending: "Jméno (Z-A)",
    sortCreateDateAscending: "Nejstarší",
    sortCreateDateDescending: "Nejnovější",
    sortLastLoginDateDescending: "Poslední přihlášení",
    noUserGroupsAdded: "Nebyly přidány žádné skupiny uživatelů"
  },
  validation: {
    validation: "Validace",
    validateAsEmail: "Ověřit jako e-mailovou adresu",
    validateAsNumber: "Ověřit jako číslo",
    validateAsUrl: "Ověřit jako URL",
    enterCustomValidation: "...nebo zadat vlastní ověření",
    fieldIsMandatory: "Pole je povinné",
    mandatoryMessage: "Zadat chybovou zprávu pro vlastní validaci (volitelné)",
    validationRegExp: "Zadat regulární výraz",
    validationRegExpMessage: "Zadat chybovou zprávu pro vlastní validaci (volitelné)",
    minCount: "Musíte přidat alespoň",
    maxCount: "Můžete jen mít",
    items: "položky",
    itemsSelected: "vybrané položky",
    invalidDate: "Neplatné datum",
    invalidNumber: "Není číslo",
    invalidEmail: "Neplatný e-mail",
    invalidNull: "Hodnota nemůže být nulová",
    invalidEmpty: "Hodnota nemůže být prázdná",
    invalidPattern: "Hodnota je neplatná, neodpovídá správnému vzoru",
    customValidation: "Vlastní ověření",
    entriesShort: "Minimálně %0% záznamů, vyžaduje <strong>%1%</strong> více.",
    entriesExceed: "Maximálně %0% záznamů, <strong>%1%</strong> příliš mnoho."
  },
  healthcheck: {
    checkSuccessMessage: "Hodnota je nastavena na doporučenou hodnotu: '%0%'.",
    checkErrorMessageDifferentExpectedValue: "Očekávaná hodnota '%1%' pro '%2%' v konfiguračním souboru '%3%', ale nalezeno '%0%'.",
    checkErrorMessageUnexpectedValue: "Nalezena neočekávaná hodnota '%0%' pro '%2%' v konfiguračním souboru '%3%'.",
    macroErrorModeCheckSuccessMessage: "MacroErrors jsou nastaveny na '%0%'.",
    macroErrorModeCheckErrorMessage: "MakroErrors jsou nastaveny na '%0%', což zabrání úplnému načtení některých nebo všech stránek na vašem webu, pokud dojde k chybám v makrech. Náprava nastaví hodnotu na '%1%'.",
    httpsCheckValidCertificate: "Certifikát vašeho webu je platný.",
    httpsCheckInvalidCertificate: "Chyba ověření certifikátu: '%0%'",
    httpsCheckExpiredCertificate: "Platnost SSL certifikátu vašeho webu vypršela.",
    httpsCheckExpiringCertificate: "Platnost certifikátu SSL vašeho webu vyprší za %0% dní.",
    healthCheckInvalidUrl: "Chyba při pingování adresy URL %0% - '%1%'",
    httpsCheckIsCurrentSchemeHttps: "Aktuálně prohlížíte web pomocí schématu HTTPS.",
    compilationDebugCheckSuccessMessage: "Režim kompilace ladění je zakázán.",
    compilationDebugCheckErrorMessage: "Režim ladění je aktuálně povolen. Před spuštěním webu se doporučuje toto nastavení deaktivovat.",
    clickJackingCheckHeaderFound: "Bylo nalezeno záhlaví nebo metaznačka <strong>X-Frame-Options</strong>, které určuje, zda může být obsah webu zobrazen na jiném webu pomocí IFRAME.",
    clickJackingCheckHeaderNotFound: "Nebylo nalezeno záhlaví nebo metaznačka <strong>X-Frame-Options</strong>, které určuje, zda může být obsah webu zobrazen na jiném webu pomocí IFRAME.",
    noSniffCheckHeaderFound: "Bylo nalezeno záhlaví nebo metaznačka <strong>X-Content-Type-Options</strong> použitá k ochraně před zranitelnostmi čichání MIME.",
    noSniffCheckHeaderNotFound: "Záhlaví nebo metaznačky <strong>X-Content-Type-Options</strong> použité k ochraně před zranitelnostmi čichání MIME nebyly nalezeny.",
    hSTSCheckHeaderFound: "Záhlaví <strong>Strict-Transport-Security</strong>, také známo jako HSTS-header, bylo nalezeno.",
    hSTSCheckHeaderNotFound: "záhlaví <strong>Strict-Transport-Security</strong> nebylo nalezeno.",
    xssProtectionCheckHeaderFound: "Záhlaví <strong>X-XSS-Protection</strong> bylo nalezeno.",
    xssProtectionCheckHeaderNotFound: "Záhlaví <strong>X-XSS-Protection</strong> bylo nalezeno.",
    excessiveHeadersFound: "Byly nalezeny následující záhlaví odhalující informace o technologii webových stránek: <strong>%0%</strong>.",
    excessiveHeadersNotFound: "Nebyly nalezeny žádné hlavičky odhalující informace o technologii webových stránek.",
    smtpMailSettingsConnectionSuccess: "Nastavení SMTP jsou správně nakonfigurována a služba funguje jak má.",
    notificationEmailsCheckSuccessMessage: "E-mail s upozorněním byl nastaven na <strong>%0%</strong>.",
    notificationEmailsCheckErrorMessage: "E-mail s oznámením je stále nastaven na výchozí hodnotu <strong>%0%</strong>.",
    checkGroup: "Zkontrolovat skupinu",
    helpText: `
        <p>Kontrola vyhodnocuje různé oblasti vašeho webu z hlediska nastavení osvědčených postupů, konfigurace, potenciálních problémů atd. Problémy lze snadno vyřešit stisknutím tlačítka. Můžete přidat své vlastní kontroly, podívejte se na <a href="https://docs.umbraco.com/umbraco-cms/extending/health-check" target="_blank" rel="noopener" class="btn-link -underline">dokumentaci pro více informací</a> o vlastních kontrolách.</p>
        `
  },
  redirectUrls: {
    disableUrlTracker: "Zakázat sledování URL",
    enableUrlTracker: "Povolit sledování URL",
    culture: "Jazyk",
    originalUrl: "Originální URL",
    redirectedTo: "Přesměrováno na",
    redirectUrlManagement: "Správa URL přesměrování",
    panelInformation: "Na tuto položku obsahu přesměrovávají následující adresy URL:",
    noRedirects: "Nebyla provedena žádná přesměrování",
    noRedirectsDescription: "Jakmile bude publikovaná stránka přejmenována nebo přesunuta, bude automaticky provedeno přesměrování na novou stránku.",
    redirectRemoved: "Přesměrování bylo odstraněno.",
    redirectRemoveError: "Chyba při odebírání URL přesměrování.",
    redirectRemoveWarning: "Toto odstraní přesměrování",
    confirmDisable: "Opravdu chcete zakázat sledování URL adres?",
    disabledConfirm: "Sledování URL adres je nyní zakázáno.",
    disableError: "Při deaktivaci sledování URL adres došlo k chybě, další informace naleznete v logu.",
    enabledConfirm: "Sledování URL adres je nyní povoleno.",
    enableError: "Chyba při povolení sledování URL adres, další informace lze nalézt v logu."
  },
  emptyStates: {
    emptyDictionaryTree: "Žádné položky ze slovníku na výběr"
  },
  textbox: {
    characters_left: "Zbývá <strong>%0%</strong> znaků.",
    characters_exceed: "Maximálně %0% znaků, <strong>%1%</strong> je moc."
  },
  recycleBin: {
    contentTrashed: "Obsah s ID: {0} v koši souvisí s původním nadřazeným obsahem s ID: {1}",
    mediaTrashed: "Média s ID: {0} v koši souvisí s původním nadřazeným médiem s ID: {1}",
    itemCannotBeRestored: "Tuto položku nelze automaticky obnovit",
    itemCannotBeRestoredHelpText: "Neexistuje žádné místo, kde lze tuto položku automaticky obnovit. Položku můžete přesunout ručně pomocí stromu níže.",
    wasRestored: "byla obnovena pod"
  },
  relationType: {
    direction: "Směr",
    parentToChild: "Nadřazený s potomkem",
    bidirectional: "Obousměrný",
    parent: "Nadřazená",
    child: "Potomek",
    count: "Počet",
    relations: "Vazby",
    created: "Vytvořeno",
    comment: "Komentář",
    name: "Název",
    noRelations: "Žádné vazby pro tento typ vazby.",
    tabRelationType: "Typ vazby",
    tabRelations: "Vazby"
  },
  dashboardTabs: {
    contentIntro: "Začínáme",
    contentRedirectManager: "Správa přesměrování",
    mediaFolderBrowser: "Obsah",
    settingsWelcome: "Vítejte",
    settingsExamine: "Správa Examine",
    settingsPublishedStatus: "Stav publikování",
    settingsModelsBuilder: "Tvůrce modelů",
    settingsHealthCheck: "Health Check",
    settingsProfiler: "Profilování",
    memberIntro: "Začínáme",
    formsInstall: "Instalovat Umbraco formuláře"
  },
  visuallyHiddenTexts: {
    goBack: "Jít zpět",
    activeListLayout: "Aktivní rozvržení:",
    jumpTo: "Skočit do",
    group: "skupina",
    passed: "prošlo",
    warning: "varování",
    failed: "selhalo",
    suggestion: "návrh",
    checkPassed: "Kontrola prošla",
    checkFailed: "Kontrola selhala",
    openBackofficeSearch: "Otevřít hledání v backoffice",
    openCloseBackofficeHelp: "Otevřít/zavřít nápovědu backoffice",
    openCloseBackofficeProfileOptions: "Otevřít/zavřít možnosti vašeho profilu",
    openContextMenu: "Otevřít kontextové menu pro",
    currentLanguage: "Aktuální jazyk",
    switchLanguage: "Přepnout jazyk na",
    createNewFolder: "Vytvořit novou složku",
    newPartialView: "Částečná šablona",
    newPartialViewMacro: "Makro částečné šablony",
    newMember: "Člen",
    newDataType: "Datový typ",
    redirectDashboardSearchLabel: "Prohledat přesměrování",
    userGroupSearchLabel: "Prohledat skupiny uživatelů",
    userSearchLabel: "Prohledat uživatele",
    createItem: "Vytvořit položku",
    create: "Vytvořit",
    edit: "Upravit",
    name: "Název"
  },
  references: {
    tabName: "Závislosti",
    DataTypeNoReferences: "Tento datový typ nemá žádné závislosti.",
    labelUsedByDocumentTypes: "Použito v dokumentových typech",
    labelUsedByMediaTypes: "Použito v typech médií",
    labelUsedByMemberTypes: "Použito v typech členů",
    usedByProperties: "Použito v ",
    labelUsedByDocuments: "Použito v dokumentech",
    labelUsedByMembers: "Použito ve členech",
    labelUsedByMedia: "Použito v médiích"
  },
  logViewer: {
    logLevels: "Úrovně logování",
    selectAllLogLevelFilters: "Vybrat vše",
    deselectAllLogLevelFilters: "Odznačit vše",
    savedSearches: "Uložená vyhledávání",
    totalItems: "Celkem položek",
    timestamp: "Časové razítko",
    level: "Úroveň",
    machine: "Stroj",
    message: "Zpráva",
    exception: "Výjimka",
    properties: "Vlastnosti",
    searchWithGoogle: "Vyhledat na Googlu",
    searchThisMessageWithGoogle: "Vyhledat zprávu na Googlu",
    searchWithBing: "Vyhledat na Bing",
    searchThisMessageWithBing: "Vyhledat zprávu na Bing",
    searchOurUmbraco: "Prohledat naše Umbraco",
    searchThisMessageOnOurUmbracoForumsAndDocs: "Vyhledat tuto zprávu na našich fórech a dokumentech Umbraco",
    searchOurUmbracoWithGoogle: "Vyhledat Our Umbraco na Googlu",
    searchOurUmbracoForumsUsingGoogle: "Prohledat Our Umbraco fóra pomocí Googlu",
    searchUmbracoSource: "Prohledat Umbraco Source",
    searchWithinUmbracoSourceCodeOnGithub: "Vyhledat ve zdrojovém kódu Umbraco na Github",
    searchUmbracoIssues: "Prohledat Umbraco Issues",
    searchUmbracoIssuesOnGithub: "Prohledat Umbraco Issues na Github",
    deleteThisSearch: "Smazat toto vyhledávání",
    findLogsWithRequestId: "Najít logy s ID požadavku",
    findLogsWithNamespace: "Najít logy se jmenným prostorem",
    findLogsWithMachineName: "Najít logy s názvem stroje",
    open: "Otevřít"
  },
  clipboard: {
    labelForCopyAllEntries: "Kopírovat %0%",
    labelForArrayOfItemsFrom: "%0% z %1%",
    labelForRemoveAllEntries: "Odebrat všechny položky"
  },
  propertyActions: {
    tooltipForPropertyActionsMenu: "Otevřít akce vlastností"
  },
  nuCache: {
    refreshStatus: "Stav obnovení",
    memoryCache: "Cache paměť",
    memoryCacheDescription: `
            Toto tlačítko umožňuje znovu načíst mezipaměť úplným opětovným načtením z databáze (ale tato mezipaměť databáze nebude znovu vytvořena). To je poměrně rychlé. Použijte jej, pokud si myslíte, že mezipaměť paměti nebyla po některých událostech správně obnovena - což by naznačovalo menší problém Umbraco. (poznámka: spustí opětovné načtení na všech serverech v prostředí LB).
    `,
    reload: "Znovu načíst",
    databaseCache: "Cache databáze",
    databaseCacheDescription: `
    Toto tlačítko umožňuje znovu vytvořit mezipaměť databáze, tj. obsah tabulky cmsContentNu. <strong>Znovuvytvoření může být náročné.</strong> Použijte jej, když nestačí obnovení stránky, a domníváte se, že mezipaměť databáze nebyla správně vygenerována - což by naznačovalo možný kritický problém Umbraco.
    `,
    rebuild: "Obnovit",
    internals: "Internals",
    internalsDescription: `
    Toto tlačítko umožňuje spustit kolekci snímků NuCache (po spuštění fullCLR GC).
     Pokud nevíte, co to znamená, pravděpodobně to <em>nebudete</em> muset používat.
    `,
    collect: "Sběr",
    publishedCacheStatus: "Stav publikované mezipaměti",
    caches: "Mezipaměti"
  },
  profiling: {
    performanceProfiling: "Profilování výkonu",
    performanceProfilingDescription: `
                <p> Umbraco aktuálně běží v režimu ladění. To znamená, že můžete použít vestavěný profiler výkonu k vyhodnocení výkonu při vykreslování stránek. </p> <p> Pokud chcete aktivovat profiler pro konkrétní vykreslení stránky, jednoduše při požadavku na stránku jednoduše přidejte <strong>umbDebug=true</strong> do URL.</p> <p> Pokud chcete, aby byl profiler ve výchozím nastavení aktivován pro všechna vykreslení stránky, můžete použít přepínač níže. Ve vašem prohlížeči nastaví soubor cookie, který automaticky aktivuje profiler. Jinými slovy, profiler bude ve výchozím nastavení aktivní pouze ve <em> vašem </em> prohlížeči, ne v ostatních. </p>
        `,
    activateByDefault: "Ve výchozím stavu aktivovat profiler",
    reminder: "Přátelské připomenutí"
  },
  settingsDashboardVideos: {
    trainingHeadline: "Hodiny tréninkových videí Umbraco jsou blíž než si myslíte",
    trainingDescription: `
        <p> Chcete ovládnout Umbraco? Stačí strávit pár minut sledování jednoho z těchto videí o používání Umbraco. Nebo navštivte <a href="http://umbraco.tv" target="_blank" rel="noopener">umbraco.tv</a>, kde najdete ještě více videí o Umbraco </p>
    `,
    getStarted: "Chcete-li začít"
  },
  settingsDashboard: {
    start: "Začněte zde",
    startDescription: "Tato část obsahuje stavební bloky pro váš web Umbraco. Podle níže uvedených odkazů se dozvíte více o práci s položkami v části Nastavení",
    more: "Zjistit více",
    bulletPointOne: `
            Další informace o práci s položkami naleznete v části Nastavení <a class="btn-link -underline" href="https://docs.umbraco.com/umbraco-cms/fundamentals/backoffice/sections" target="_blank" rel="noopener">v sekci Dokumentace</a> v Our Umbraco
        `,
    bulletPointTwo: `
            Zeptejte se na <a class="btn-link -underline" href="https://our.umbraco.com/forum" target="_blank" rel="noopener">fóru komunity</a>
        `,
    bulletPointThree: `
            Podívejte se na naše <a class="btn-link -underline" href="https://umbraco.tv" target="_blank" rel="noopener">výuková videa</a> (některá jsou zdarma, jiná vyžadují předplatné)
        `,
    bulletPointFour: `
            Další informace o našich <a class="btn-link -underline" href="https://umbraco.com/products/" target="_blank" rel="noopener">nástrojích zvyšujících produktivitu a komerční podpoře</a>
        `,
    bulletPointFive: `
            Zjistěte více o možnostech <a class="btn-link -underline" href="https://umbraco.com/training" target="_blank" rel="noopener">školení a certifikace</a>
        `
  },
  startupDashboard: {
    fallbackHeadline: "Vítejte v přátelském CMS",
    fallbackDescription: "Děkujeme, že jste si vybrali Umbraco - myslíme si, že by to mohl být začátek něčeho krásného. I když se to může zpočátku zdát ohromující, udělali jsme hodně pro to, aby byla křivka učení co nejhladší a nejrychlejší."
  },
  formsDashboard: {
    formsHeadline: "Umbraco formuláře",
    formsDescription: "Vytvářejte formuláře pomocí intuitivního rozhraní drag and drop. Od jednoduchých kontaktních formulářů, které odesílají e-maily, až po pokročilé dotazníky, které se integrují do systémů CRM. Vaši klienti to budou milovat!"
  }
};
export {
  e as default
};
//# sourceMappingURL=cs-cz-Jv3dDjZY.js.map
