const e = {
  actions: {
    assigndomain: "Diwylliannau ac Enwau Gwesteia",
    auditTrail: "Trywydd Archwilio",
    browse: "Dewis Nod",
    changeDocType: "Newid Math o Ddogfen",
    changeDataType: "Newid Math o Data",
    copy: "Copïo",
    create: "Creu",
    export: "Allforio",
    createPackage: "Creu Pecyn",
    createGroup: "Creu grŵp",
    delete: "Dileu",
    disable: "Analluogi",
    editSettings: "Golygu gosodiadau",
    emptyrecyclebin: "Gwagu bin ailgylchu",
    enable: "Galluogi",
    exportDocumentType: "Allforio Math o Ddogfen",
    importdocumenttype: "Mewnforio Math o Ddogfen",
    importPackage: "Mewnforio Pecyn",
    liveEdit: "Golygu mewn Cynfas",
    logout: "Gadael",
    move: "Symud",
    notify: "Hysbysiadau",
    protect: "Cyrchiad cyhoeddus",
    publish: "Cyhoeddi",
    unpublish: "Dadgyhoeddi",
    refreshNode: "Ail-lwytho",
    republish: "Ail-gyhoeddi yr holl safle",
    remove: "Dileu",
    rename: "Ailenwi",
    restore: "Adfer",
    chooseWhereToCopy: "Dewis ble i copïo",
    chooseWhereToMove: "Dewis ble i symud",
    toInTheTreeStructureBelow: "Yn y strwythyr goeden isod",
    infiniteEditorChooseWhereToCopy: "Dewis ble i gopïo'r eitem(au) a ddewiswyd",
    infiniteEditorChooseWhereToMove: "Dewis ble i symud yr eitem(au) a ddewiswyd",
    wasMovedTo: "wedi symud i",
    wasCopiedTo: "wedi copïo i",
    wasDeleted: "wedi dileu",
    rights: "Hawliau",
    rollback: "Rolio yn ôl",
    sendtopublish: "Anfon I Gyhoeddi",
    sendToTranslate: "Anfon I Gyfieithu",
    setGroup: "Gosod grŵp",
    sort: "Trefnu",
    translate: "Cyfieithu",
    update: "Diweddaru",
    setPermissions: "Gosod Hawliau",
    unlock: "Datgloi",
    createblueprint: "Creu Templed Gynnwys",
    resendInvite: "Ail-anfon Gwahoddiad",
    editContent: "Golygu cynnwys",
    chooseWhereToImport: "Dewiswch ble i fewnforio",
    toggleHideUnavailable: "Cuddio opsiynau nad ydynt ar gael"
  },
  actionCategories: {
    content: "Cynnwys",
    administration: "Gweinyddu",
    structure: "Strwythyr",
    other: "Arall"
  },
  actionDescriptions: {
    assignDomain: "Caniatáu hawl i osod to assign diwylliannau ac enwau gwesteia",
    auditTrail: "Caniatáu hawl i weld cofnod hanes nod",
    browse: "Caniatáu hawl i weld nod",
    changeDocType: "Caniatáu hawl i newid math o ddogfen ar gyfer nod",
    copy: "Caniatáu hawl i gopïo nod",
    create: "Caniatáu hawl i greu nodau",
    delete: "Caniatáu hawl i ddileu nodau",
    move: "Caniatáu hawl i symud nodau",
    protect: "Caniatáu hawl i osod a newid cyrchiad cyhoeddus ar gyfer nod",
    publish: "Caniatáu hawl i gyhoeddi nod",
    unpublish: "Caniatáu hawl i dadgyhoeddi nod",
    rights: "Caniatáu hawl i newid hawliau ar gyfer nod",
    rollback: "Caniatáu hawl i rolio nod yn ôl at gyflwr blaenorol",
    sendtopublish: "Caniatáu hawl i anfon nod am gymeradwyo cyn cyhoeddi",
    sendToTranslate: "Caniatáu hawl i anfon nod am gyfieithiad",
    sort: "Caniatáu hawl i newid trefn nodau",
    translate: "Caniatáu hawl i gyfiethu nod",
    update: "Caniatáu hawl i achub nod",
    createblueprint: "Caniatáu hawl i greu Templed Cynnwys",
    notify: "Caniatáu mynediad i osod hysbysiadau ar gyfer nodau cynnwys"
  },
  apps: {
    umbContent: "Cynnwys",
    umbInfo: "Gwybodaeth"
  },
  assignDomain: {
    permissionDenied: "Dim hawl.",
    addNew: "Ychwanegu parth newydd",
    addCurrent: "Ychwanegu parth cyfredol",
    remove: "dileu",
    invalidNode: "Nod annilys.",
    invalidDomain: "Fformat parth annilys.",
    duplicateDomain: "Parth wedi'i neilltuo eisoes.",
    language: "Iaith",
    domain: "Parth",
    domainCreated: "Parth newydd '%0%' wedi'i greu",
    domainDeleted: "Parth '%0%' wedi dileu",
    domainExists: "Parth '%0%' wedi neilltuo eisoes",
    domainUpdated: "Parth '%0%' wedi diweddaru",
    orEdit: "Golygu Parthau Cyfredol",
    domainHelpWithVariants: `Parthau dilys yw: "enghraifft.com", "www.enghraifft.com", "enghraifft.com:8080" neu "https://www.enghraifft.com/".
            Mae llwybrau un-lefel mewn parthau wedi'u cefnogi, e.e. "enghraifft.com/cy" neu "/cy".`,
    inherit: "Etifeddu",
    setLanguage: "Diwylliant",
    setLanguageHelp: `Gosod y diwylliant ar gyfer nodau o dan y nod bresennol,<br /> neu etifeddu diwylliant o nodau rhiant. Bydd hyn hefyd<br />
      yn berthnasol i'r nod bresennol, oni bai fod parth isod yn berthnasol hefyd.`,
    setDomains: "Parthau"
  },
  buttons: {
    clearSelection: "Clirio dewisiad",
    select: "Dewis",
    somethingElse: "Gwneud rhywbeth arall",
    bold: "Trwm",
    deindent: "Canslo Mewnoliad Paragraff",
    formFieldInsert: "Mewnosod maes ffurflen",
    graphicHeadline: "Mewnosod pennawd graffig",
    htmlEdit: "Golygu Html",
    indent: "Mewnoli Paragraff",
    italic: "Italig",
    justifyCenter: "Canoli",
    justifyLeft: "Unioni Chwith",
    justifyRight: "Unioni Dde",
    linkInsert: "Mewnosod Dolen",
    linkLocal: "Mewnosod dolen leol (angor)",
    listBullet: "Rhestr Bwled",
    listNumeric: "Rhestr rhifol",
    macroInsert: "Mewnosod macro",
    pictureInsert: "Mewnosod llun",
    publishAndClose: "Chyhoeddi a cau",
    publishDescendants: "Cyhoeddi efo disgynnydd",
    relations: "Golygu perthnasau",
    returnToList: "Dychwelyd i'r rhestr",
    save: "Achub",
    saveAndClose: "Achub a cau",
    saveAndPublish: "Achub a chyhoeddi",
    saveToPublish: "Achub ac anfon am gymeradwyo",
    saveListView: "Achub gwedd rhestr",
    schedulePublish: "Amserlenni",
    saveAndPreview: "Save and preview",
    showPageDisabled: "Rhagolwg wedi analluogi gan nad oes templed wedi'i neilltuo",
    styleChoose: "Dewis arddull",
    styleShow: "Dangos arddulliau",
    tableInsert: "Mewnosod tabl",
    generateModelsAndClose: "Cynhyrchu modelau a cau",
    saveAndGenerateModels: "Achub a chynhyrchu modelau",
    undo: "Dadwneud",
    redo: "Ail-wneud",
    deleteTag: "Dileu tag",
    confirmActionCancel: "Canslo",
    confirmActionConfirm: "Cadarnhau",
    morePublishingOptions: "Mwy opsiynau cyhoeddi",
    submitChanges: "Cyflwyno"
  },
  auditTrailsMedia: {
    delete: "Cyfrwng wedi'i dileu",
    move: "Cyfrwng wedi'i symud",
    copy: "Cyfrwng wedi'i copïo",
    save: "Cyfrwng wedi'i achub"
  },
  auditTrails: {
    atViewingFor: "Dangos am",
    delete: "Cynnwys wedi'i dileu",
    unpublish: "Cynnwys wedi'i dadgyhoeddi",
    unpublishvariant: "Cynnwys wedi'i dadgyhoeddi am y ieithoedd: %0% ",
    publish: "Cynnwys wedi'i Achub a Chyhoeddi",
    publishvariant: "Cynnwys wedi'i Achub a Chyhoeddi am y ieithoedd: %0% ",
    save: "Cynnwys wedi'i achub",
    savevariant: "Cynnwys wedi'i achub am y ieithoedd: %0%",
    move: "Cynnwys wedi'i symud",
    copy: "Cynnwys wedi'i copïo",
    rollback: "Cynnwys wedi'i rolio yn ôl",
    sendtopublish: "Cynnwys wedi'i anfon i Gyhoeddi",
    sendtopublishvariant: "Cynnwys wedi'i anfon i gyhoeddi am y ieithoedd: %0%",
    sort: "Trefnu eitemau blant cyflawnwyd gan ddefnyddiwr",
    custom: "%0%",
    smallCopy: "Copïo",
    smallPublish: "Cyhoeddi",
    smallPublishVariant: "Cyhoeddi",
    smallMove: "Symud",
    smallSave: "Achub",
    smallSaveVariant: "Achub",
    smallDelete: "Dileu",
    smallUnpublish: "Dadgyhoeddi",
    smallUnpublishVariant: "Dadgyhoeddi",
    smallRollBack: "Rolio yn ôl",
    smallSendToPublish: "Anfon i Gyhoeddi",
    smallSendToPublishVariant: "Anfon i Gyhoeddi",
    smallSort: "Tefnu",
    smallCustom: "Arferu",
    historyIncludingVariants: "Hanes (pob amrywiad)",
    contentversionpreventcleanup: "Mae glanhau wedi'i analluogi ar gyfer y fersiwn: %0%",
    contentversionenablecleanup: "Mae glanhau wedi'i alluogi ar gyfer fersiwn:: %0%",
    smallContentVersionPreventCleanup: "Achub",
    smallContentVersionEnableCleanup: "Achub"
  },
  codefile: {
    createFolderIllegalChars: "Mae'r enw'r ffolder methu cynnwys nodau anghyfreithlon.",
    deleteItemFailed: "Methwyd dileu eitem: %0%"
  },
  content: {
    isPublished: "Wedi Cyhoeddi",
    about: "Am y dudlaen yma",
    alias: "Enw arall",
    alternativeTextHelp: "(sut fyddwch chi'n disgrifio'r llun dros y ffôn)",
    alternativeUrls: "Dolenni Amgen",
    clickToEdit: "Cliwich i olygu'r eitem yma",
    createBy: "Creuwyd gan",
    createByDesc: "Awdur gwreiddiol",
    updatedBy: "Diweddarwyd gan",
    createDate: "Creuwyd",
    createDateDesc: "Dyddiad/amser creuwyd y ddogfen yma",
    documentType: "Math o Ddogfen",
    editing: "Yn golygu",
    expireDate: "Dileu am",
    itemChanged: "Mae'r eitem yma wedi cael ei newid ar ôl cyhoeddi",
    itemNotPublished: "Nid yw'r eitem yma wedi cael ei gyhoeddi",
    lastPublished: "Cyhoeddiad ddiwethaf",
    noItemsToShow: "Nid oes unrhyw eitemau i ddangos",
    listViewNoItems: "Nid oes unrhyw eitemau i ddangos yn y rhestr.",
    listViewNoContent: "Nid oes unrhyw gynnwys wedi'i ychwanegu",
    listViewNoMembers: "Nid oes unrhyw aelodau wedi'u ychwanegu",
    mediatype: "Math o Gyfrwng",
    mediaLinks: "Dolen i eitem gyfrwng(au)",
    membergroup: "Grŵp Aelod",
    memberrole: "Rôl",
    membertype: "Math o Aelod",
    noChanges: "Dim newidiadau wedi'u gwneud",
    noDate: "Dim dyddiad wedi'i ddewis",
    nodeName: "Teitl tudalen",
    noMediaLink: "Does dim dolen gan yr eitem gyfrwng yma",
    noProperties: "Ni all unrhyw gynnwys cael ei hychwanegu am eitem hon",
    otherElements: "Priodweddau",
    parentNotPublished: "Mae'r ddogfen yma wedi'i gyhoeddi ond nid yw'n weladwy gan nad yw'r rhiant '%0%' wedi'i gyhoeddi",
    parentCultureNotPublished: "Mae'r diwylliant yma yn cyhoeddedig ond ddim yn weladwy oherwydd mae'n anghyhoeddedig ar rhiant '%0%'",
    parentNotPublishedAnomaly: "Mae'r ddogfen yma wedi'i gyhoeddi ond nid yw'n bodoli yn y storfa",
    getUrlException: "Ni ellir nôl y url",
    routeError: "Mae'r ddogfen yma wedi'i gyhoeddi ond byddai'r url yn gwrthdaro gyda chynnwys %0%",
    routeErrorCannotRoute: "Mae'r ddogfen yma wedi'i gyhoeddi ond mae'r url methu cael ei cyfeirio",
    publish: "Cyhoeddi",
    published: "Wedi cyhoeddi",
    publishedPendingChanges: "Wedi cyhoeddi (newidiadau nes arddodiad)",
    publishStatus: "Statws Cyhoeddi",
    publishDescendantsHelp: "Click <em>Cyhoeddi efo disgynnyddion</em> i cyhoeddi <strong>%0%</strong> ac yr holl eitemau cynnwys o dan ac a thrwy hynny wneud eu cynnwys ar gael i'r cyhoedd.",
    publishDescendantsWithVariantsHelp: "Click <em>Cyhoeddi efo disgynnyddion</em> i cyhoeddi <strong>y ieithoedd a ddewiswyd</strong> ac yr un ieithoedd o'r eitemau o dan a thrwy hynny wneud eu cynnwys ar gael i'r cyhoedd.",
    releaseDate: "Cyhoeddi am",
    unpublishDate: "Dadgyhoeddi am",
    removeDate: "Clirio Dyddiad",
    setDate: "Gosod dyddiad",
    sortDone: "Trefn wedi diweddaru",
    sortHelp: `Er mwyn trefnu'r nodau, llusgwch y nodau neu cliciwch un o benynnau'r colofnau. Gallwch ddewis nifer o nodau gan ddal y botwm "shift" neu "control" wrth ddewis`,
    statistics: "Ystadegau",
    titleOptional: "Teitl (dewisol)",
    altTextOptional: "Testyn amgen (dewisol)",
    captionTextOptional: "Capsiwn (dewisol)",
    type: "Math",
    unpublish: "Dadgyhoeddi",
    unpublished: "Wedi dadgyhoeddi",
    notCreated: "Heb ei greu",
    updateDate: "Golygwyd ddiwethaf",
    updateDateDesc: "Dyddiad/amser golygwyd y ddogfen yma",
    uploadClear: "Dileu ffeil(iau)",
    uploadClearImageContext: "Cliciwch yma i dileu'r llun oddi wrth y eitem cyfrwng",
    uploadClearFileContext: "Cliciwch yma i dileu'r ffeil oddi wrth y eitem cyfrwng",
    urls: "Dolen i ddogfen",
    memberof: "Aeold o grŵp(iau)",
    notmemberof: "Ddim yn aelod o'r grŵp(iau)",
    childItems: "Eitemau blentyn",
    target: "Targed",
    scheduledPublishServerTime: "Mae hyn yn trawsnewid at yr amser ganlynol ar y gweinydd:",
    scheduledPublishDocumentation: '<a href="https://docs.umbraco.com/umbraco-cms/fundamentals/data/scheduled-publishing#timezones" target="_blank" rel="noopener">Beth mae hyn yn golygu?</a>',
    nestedContentDeleteItem: "Ydych chi'n sicr eich bod eisiau dileu'r eitem yma?",
    nestedContentEditorNotSupported: "Mae'r priodwedd %0% yn defnyddio'r golygydd %1% sydd ddim yn cyd-fynd â Chynnwys Amnyth.",
    nestedContentDeleteAllItems: "Wyt ti'n siŵr fod ti eisiau dileu pob eitem?",
    nestedContentNoContentTypes: "Nid oes unrhyw fathau o gynnwys wedi'u ffurfweddu ar gyfer yr eiddo hwn.",
    nestedContentAddElementType: "Ychwanegu teip elfen",
    nestedContentSelectElementTypeModalTitle: "Dewis teip elfen",
    nestedContentGroupHelpText: "Dewis y grŵp dylid arddangos ei briodweddau. Os caiff ei adael yn wag, bydd y grŵp cyntaf ar yr elfen yn cael ei defnyddio.",
    nestedContentTemplateHelpTextPart1: "Rhowch fynegiad angular i werthuso yn erbyn pib eitem am ei enw. Defnyddiwch",
    nestedContentTemplateHelpTextPart2: "i ddangos y mynegai'r eitem",
    addTextBox: "Ychwanegu blwch testun arall",
    removeTextBox: "Dileu'r blwch testun yma",
    contentRoot: "Gwraidd cynnwys",
    includeUnpublished: "Cynnwys eitemau cynnwys heb eu cyhoeddi.",
    isSensitiveValue: "Mae'r gwerth yma'n gudd. Os ydych chi angen hawl i weld y gwerth yma, cysylltwch â gweinyddwr eich gwefan.",
    isSensitiveValue_short: "Mae'r gwerth yma'n gudd.",
    languagesToPublish: "Pa ieithoedd yr hoffech chi eu cyhoeddi? ",
    languagesToSendForApproval: "Pa ieithoedd hoffech chi anfon am gymeradwyaeth?",
    languagesToSchedule: "Pa ieithoedd yr hoffech chi eu hamserlennu?",
    languagesToUnpublish: "Dewiswch yr ieithoedd i'w anghyhoeddi. Bydd anghyhoeddi iaith orfodol yn anghyhoeddi pob iaith.",
    variantsWillBeSaved: "Bydd pob amrywiad newydd yn cael ei arbed.",
    variantsToPublish: "P'un amrywiadau wyt ti eisiau cyhoeddi?",
    variantsToSave: "Dewiswch pa amrywiadau wyt ti eisiau arbed.",
    publishRequiresVariants: "Mae'r amrywiadau canlynol yn ofynnol er mwyn i gyhoeddi:",
    notReadyToPublish: "Ni ddim yn barod i Gyhoeddi",
    readyToPublish: "Barod i Gyhoeddi?",
    readyToSave: "Barod i Arbed?",
    resetFocalPoint: "Ailosod pwynt canolog",
    sendForApproval: "Anfonwch am gymeradwyaeth",
    schedulePublishHelp: "Dewiswch y dyddiad a'r amser i gyhoeddi a / neu anghyhoeddi'r eitem gynnwys.",
    createEmpty: "Creu newydd",
    createFromClipboard: "Gludo o'r clipfwrdd",
    nodeIsInTrash: "Mae'r eitem yma yn y Bin Ailgylchu",
    nestedContentNoGroups: "Nid yw'r math o elfen a ddewiswyd yn cynnwys unrhyw grwpiau a gefnogir (nid yw tabiau'n cael eu cefnogi gan y golygydd hwn, naill ai eu newid i grwpiau neu ddefnyddio golygydd y Rhestr Bloc).",
    variantSaveNotAllowed: "Ni chaniateir arbed",
    variantPublishNotAllowed: "Ni chaniateir cyhoeddi",
    variantSendForApprovalNotAllowed: "Ni chaniateir anfon am gymeradwyaeth",
    variantScheduleNotAllowed: "Ni chaniateir amserlennu",
    variantUnpublishNotAllowed: "Ni chaniateir dad-gyhoeddi",
    saveModalTitle: "Achub"
  },
  blueprints: {
    createBlueprintFrom: "Creu Templed Cynnwys newydd o '%0%'",
    blankBlueprint: "Gwag",
    selectBlueprint: "Dewis Templed Cynnwys",
    createdBlueprintHeading: "Templed Cynnwys wedi'i greu",
    createdBlueprintMessage: "Creuwyd Templed Cynnwys o '%0%'",
    duplicateBlueprintMessage: "Mae Templed Cynnwys gyda'r un enw yn bodoli eisoes",
    blueprintDescription: "Mae Templed Cynnwys yn gynnwys sydd wedi'i ddiffinio o flaen llaw y gellir ei ddewis gan olygwr i'w ddefnyddio fel sail ar gyfer creu cynnwys newydd"
  },
  media: {
    clickToUpload: "Cliciwch i lanlwytho",
    orClickHereToUpload: "neu cliciwch yma i ddewis ffeiliau",
    disallowedFileType: "Ni ellir lanlwytho'r ffeil yma, nid yw math y ffeil yn wedi'i gymeradwyo",
    maxFileSize: "Maint ffeil uchaf",
    mediaRoot: "Gwraidd gyfrwng",
    moveToSameFolderFailed: "Ni all y ffolderi rhiant a chyrchfan fod yr un peth",
    createFolderFailed: "Methwyd creu ffolder o dan id rhiant %0%",
    renameFolderFailed: "Methwyd ailenwi'r ffolder gyda id %0%",
    dragAndDropYourFilesIntoTheArea: "Llusgo a gollwng eich ffeil(iau) i mewn i'r ardal",
    uploadNotAllowed: "Ni chaniateir llwytho i fyny yn y lleoliad hwn.",
    disallowedMediaType: "Ni ellir lanlwytho'r ffeil yma, ni chaniateir y math cyfrwng gydag alias '%0%' yma",
    invalidFileName: "Ni ellir lanlwytho'r ffeil yma, nid oes ganddi enw ffeil dilys",
    fileSecurityValidationFailure: "Mae un neu fwy o ddilysiadau diogelwch ffeil wedi methu"
  },
  member: {
    createNewMember: "Creu aelod newydd",
    allMembers: "Pob Aelod",
    memberGroupNoProperties: "Nid oes gan grwpiau aelodau unrhyw eiddo ychwanegol ar gyfer golygu.",
    duplicateMemberLogin: "Mae aelod gyda'r mewngofnodi hwn yn bodoli yn barod",
    memberHasGroup: "Mae'r aelod yn y grŵp '%0%' yn barod",
    memberHasPassword: "Mae gan yr aelod gyfrinair yn barod",
    memberLockoutNotEnabled: "Nid yw cloi allan wedi'i alluogi ar gyfer yr aelod hwn",
    memberNotInGroup: "Nid yw'r aelod yn y grŵp '%0%'",
    "2fa": "Prawf Dilysu Dau Gam"
  },
  contentType: {
    copyFailed: "Wedi methu copïo'r fath cynnwys",
    moveFailed: "Wedi methu symud y fath cynnwys"
  },
  mediaType: {
    copyFailed: "Wedi methu copïo'r fath cyfrwng",
    moveFailed: "Wedi methu symud y fath cyfrwng",
    autoPickMediaType: "Dewis awtomatig"
  },
  memberType: {
    copyFailed: "Wedi methu copïo'r fath aelod"
  },
  create: {
    chooseNode: "Ble hoffwch greu eitem newydd %0%",
    createUnder: "Creu eitem o dan",
    createContentBlueprint: "Dewiswch y fath o ddogfen hoffwch greu templed dogfen ar ei gyfer",
    enterFolderName: "Rhoi enw ffolder i mewn",
    updateData: "Dewiswch fath a theitl",
    noDocumentTypes: "Nid oes unrhyw fathau o ddogfennau caniataol ar gael am greu cynnwys fan hyn. Rhaid i chi alluogi'r rhain yn <strong>Mathau o Ddogfennau</strong> o fewn y adran <strong>Gosodiadau</strong>, gan olygu y opsiwn <strong>Mathau o nod blentyn caniataol</strong> o dan <strong>Caniatadau</strong>",
    noDocumentTypesAtRoot: "Nid oes unrhyw fathau o ddogfennau ar gael. Rhaid i chi creu rhain yn <strong>Mathau o Ddogfennau</strong> tu fewn y adran <strong>Gosodiadau</strong>.",
    noDocumentTypesWithNoSettingsAccess: "Nid yw'r dudalen a ddewiswyd yn y goeden gynnwys yn caniatáu i unrhyw dudalennau gael eu creu oddi tani.",
    noDocumentTypesEditPermissions: "Golygu caniatâd ar gyfer y math hwn o ddogfen",
    noDocumentTypesCreateNew: "Creu Math o Ddogfen newydd",
    noDocumentTypesAllowedAtRoot: "Nid oes unrhyw fathau o ddogfennau caniataol ar gael am greu cynnwys fan hyn. Rhaid i chi alluogi'r rhain yn <strong>Mathau o Ddogfennau</strong> o fewn y adran <strong>Gosodiadau</strong>, gan olygu y opsiwn <strong>Caniatáu fel gwraidd</strong> o dan <strong>Caniatadau</strong>",
    noMediaTypes: `Nid oes unrhyw fathau o gyfrwng caniataol ar gael. Rhaid i chi alluogi'r rhain yn yr adran gosodiadau o dan <strong>"mathau o gyfrwng"</strong>.`,
    noMediaTypesWithNoSettingsAccess: "Nid yw'r cyfryngau a ddewiswyd yn y goeden yn caniatáu i unrhyw gyfryngau eraill gael eu creu oddi tano.",
    noMediaTypesEditPermissions: "Golygu caniatâd ar gyfer y math hwn o gyfryngau",
    documentTypeWithoutTemplate: "Math o Ddogfen heb dempled",
    documentTypeWithTemplate: "Math o Ddogfen efo dempled",
    documentTypeWithTemplateDescription: "Y diffiniad data ar gyfer tudalen gynnwys y gellir ei chreu gan olygyddion yn y goeden gynnwys ac sydd ar gael yn uniongyrchol trwy URL.",
    documentType: "Math o Ddogfen",
    documentTypeDescription: "Y diffiniad data ar gyfer cydran gynnwys y gellir ei chreu gan olygyddion yn y goeden gynnwys a'i ddewis ar dudalennau eraill ond nid oes ganddo URL uniongyrchol.",
    elementType: "Math o Elfen",
    elementTypeDescription: "Yn diffinio'r sgema ar gyfer set o eiddo ailadroddus, er enghraifft, mewn golygydd eiddo 'Rhestr Bloc' neu 'Cynnwys Amnyth'.",
    composition: "Cyfansoddiad",
    compositionDescription: "Yn diffinio set o eiddo, y gellir ei hailddefnyddio, a'i chynnwys yn y diffiniad o sawl Math o Ddogfen arall. Er enghraifft, set o 'Gosodiadau Tudalen Cyffredin'.",
    folder: "Ffolder",
    folderDescription: "Yn cael ei defnyddio i drefnu'r Mathau o Ddogfennau, Cyfansoddiadau a Mathau Elfen a grëir yn y goeden Math o Ddogfen hon.",
    newFolder: "Ffolder newydd",
    newDataType: "Math o ddata newydd",
    newJavascriptFile: "Ffeil JavaScript newydd",
    newEmptyPartialView: "Rhan-wedd wag newydd",
    newPartialViewMacro: "Macro rhan-wedd newydd",
    newPartialViewFromSnippet: "Rhan-wedd newydd o damaid",
    newPartialViewMacroFromSnippet: "Macro rhan-wedd wag newydd o damaid",
    newPartialViewMacroNoMacro: "Macro rhan-wedd newydd (heb macro)",
    newStyleSheetFile: "Ffeil ddalen arddull newydd",
    newRteStyleSheetFile: "Ffeil ddalen arddull Golygydd Testun Cyfoethog newydd"
  },
  dashboard: {
    browser: "Pori eich gwefan",
    dontShowAgain: "- Cuddio",
    nothinghappens: "Os nad yw Umbraco yn agor, efallai byddwch angen galluogi popups o'r safle yma",
    openinnew: "wedi agor mewn ffenestr newydd",
    restart: "Ailgychwyn",
    visit: "Ymweld â",
    welcome: "Croeso"
  },
  prompt: {
    stay: "Aros",
    discardChanges: "Hepgor newidiadau",
    unsavedChanges: "Mae gennych chi newidiadau sydd heb eu achub",
    unsavedChangesWarning: "Ydych chi'n sicr eich bod eisiau llywio i ffwrdd o'r dudalen yma? - mae gennych chi newidiadau sydd heb eu achub",
    confirmListViewPublish: "Bydd cyhoeddi yn gwneud yr eitemau a ddewiswyd yn weladwy ar y wefan.",
    confirmListViewUnpublish: "Bydd anghyhoeddi yn tynnu'r eitemau a ddewiswyd a'u holl ddisgynyddion o'r safle.",
    confirmUnpublish: "Bydd dadgyhoeddi yn dileu'r dudalen yma a phob un o'i phlant o'r safle.",
    doctypeChangeWarning: "Mae gennych chi newidiadau heb eu cadw. Bydd gwneud newidiadau i'r Math o Ddogfen yn taflu'r newidiadau i ffwrdd."
  },
  bulk: {
    done: "Wedi gwneud",
    deletedItem: "Wedi dileu eitem %0%",
    deletedItems: "Wedi dileu %0% eitem",
    deletedItemOfItem: "Wedi dileu %0% allan o %1% eitem",
    deletedItemOfItems: "Wedi dileu %0% allan o %1% o eitemau",
    publishedItem: "Wedi cyhoeddi eitem %0%",
    publishedItems: "Wedi cyhoeddi %0% o eitemau",
    publishedItemOfItem: "Wedi cyhoeddi %0% allan o %1% eitem",
    publishedItemOfItems: "Wedi cyhoeddi %0% allan o %1% eitemau",
    unpublishedItem: "Wedi dadgyhoeddi eitem %0%",
    unpublishedItems: "Wedi dadgyhoeddi %0% o eitemau",
    unpublishedItemOfItem: "Wedi dadgyhoeddi %0% allan o %1% eitem",
    unpublishedItemOfItems: "Wedi dadgyhoeddi %0% allan o %1% o eitemau",
    movedItem: "Wedi symud eitem %0%",
    movedItems: "Wedi symud %0% o eitemau",
    movedItemOfItem: "Wedi symud %0% allan o %1% eitem",
    movedItemOfItems: "Wedi symud %0% allan o %1% o eitemau",
    copiedItem: "Wedi copïo eitem %0%",
    copiedItems: "Wedi copïo %0% o eitemau",
    copiedItemOfItem: "Wedi copïo %0% allan o %1% eitem",
    copiedItemOfItems: "Wedi copïo %0% allan o %1% eitemau"
  },
  defaultdialogs: {
    nodeNameLinkPicker: "Teitl y ddolen",
    urlLinkPicker: "Dolen",
    anchorLinkPicker: "Angor / llinyn ymholi",
    anchorInsert: "Enw",
    closeThisWindow: "Cau'r ffenestr yma",
    confirmdelete: "Ydych chi'n sicr eich bod eisiau dileu",
    confirmdeleteNumberOfItems: "Wyt ti'n siŵr fod ti eisiau dileu <strong>%0%</strong> yn seiliedig ar <strong>%1%</strong>",
    confirmdisable: "Ydych chi'n sicr eich bod eisiau analluogi",
    confirmremove: "Wyt ti'n siŵr fod ti eisiau dileu",
    confirmremoveusageof: "Ydych chi'n siŵr bod chi am gael gwared ar y defnydd o <strong>%0%</strong>",
    confirmlogout: "Ydych chi'n sicr?",
    confirmSure: "Ydych chi'n sicr?",
    cut: "Torri",
    editDictionary: "Golygu Eitem Geiriadur",
    editLanguage: "Golygu Iaith",
    editSelectedMedia: "Golygu cyfrwng a dewiswyd",
    editWebhook: "Golygu bachyn gwe",
    insertAnchor: "Mewnosod dolen leol",
    insertCharacter: "Mewnosod nod",
    insertgraphicheadline: "Mewnosod pennawd graffig",
    insertimage: "Mewnosod llun",
    insertlink: "Mewnosod dolen",
    insertMacro: "Cliciwch i ychwanegu Macro",
    inserttable: "Mewnosod tabl",
    languagedeletewarning: "Bydd hyn yn dileu'r iaith",
    languageChangeWarning: "Gall newid y diwylliant ar gyfer iaith fod yn weithrediad drud a bydd yn arwain at ailadeiladu'r storfa cynnwys a'r mynegeion",
    lastEdited: "Golygwyd ddiwethaf",
    link: "Dolen",
    linkinternal: "Dolen fewnol",
    linklocaltip: 'Wrth ddefnyddio dolenni leol, defnyddiwch "#" o flaen y ddolen',
    linknewwindow: "Agor mewn ffenestr newydd?",
    macroDoesNotHaveProperties: "Nid yw'r macro yma yn cynnwys unrhyw briodweddau gallwch chi olygu",
    paste: "Gludo",
    permissionsEdit: "Golygu hawliau ar gyfer",
    permissionsSet: "Gosod hawliau ar gyfer",
    permissionsSetForGroup: "Gosod hawliau ar gyfer %0% ar gyfer y grŵp defnyddwyr %1%",
    permissionsHelp: "Dewiswch y grŵpiau defnyddwyr yr ydych eisiau gosod hwaliau ar eu cyfer",
    recycleBinDeleting: "Mae'r eitemau yn y bin ailgylchu yn cael eu dileu. Peidiwch â chau'r ffenestr yma wrth i'r gweithrediad gymryd lle",
    recycleBinIsEmpty: "Mae'r bin ailgylchu yn awr yn wag",
    recycleBinWarning: "Pan gaiff eitemau eu dileu o'r bin ailgylchu, byddent yn diflannu am byth",
    regexSearchError: "Mae problem gyda gwasanaeth gwe <a target='_blank' rel='noopener' href='http://regexlib.com'>regexlib.com</a> ar hyn o bryd, nid oes gennym reolaeth dros hyn. Mae'n ddrwg iawn gennym ni am yr anghyfleustra.",
    regexSearchHelp: "Chwiliwch am fynegiad cyson er mwyn ychwanegu dilysiad i faes ffurflen. Enghraifft: 'email, 'zip-code' 'url'",
    removeMacro: "Dileu Macro",
    requiredField: "Maes Gofynnol",
    sitereindexed: "Safle wedi'i ail-fynegi",
    siterepublished: "Mae storfa'r wefan wedi'i ddiweddaru. Mae holl gynnwys cyhoeddi wedi'i ddiweddaru, ac mae'r holl gynnwys sydd heb ei gyhoeddi yn dal i fod heb ei gyhoeddi",
    siterepublishHelp: "Bydd storfa'r wefan yn cael ei adnewyddu. Bydd holl gynnwys cyhoeddi yn cael ei ddiweddaru, ac bydd holl gynnwys sydd heb ei gyhoeddi yn dal i fod heb ei gyhoeddi.",
    tableColumns: "Nifer o golofnau",
    tableRows: "Nifer o resi",
    thumbnailimageclickfororiginal: "Cliciwch ar y llun i weld y maint llawn",
    treepicker: "Dewis eitem",
    viewCacheItem: "Gweld Eitem Storfa",
    relateToOriginalLabel: "Perthnasu at y gwreiddiol",
    includeDescendants: "Cynnwys disgynyddion",
    theFriendliestCommunity: "Y gymuned fwyaf cyfeillgar",
    linkToPage: "Dolen i dudalen",
    openInNewWindow: "Agor y ddolen ddogfen mewn ffenestr neu tab newydd",
    linkToMedia: "Dolen i gyfrwng",
    selectContentStartNode: "Dewis nod cychwyn cynnwys",
    selectEvent: "Dewis digwyddiad",
    selectMedia: "Dewis cyfrwng",
    selectMediaType: "Dewis y math o gyfrwng",
    selectIcon: "Dewis eicon",
    selectItem: "Dewis eitem",
    selectLink: "Dewis dolen",
    selectMacro: "Dewis macro",
    selectContent: "Dewis cynnwys",
    selectContentType: "Dewiswch y math o gynnwys",
    selectMediaStartNode: "Dewis nod cychwyn cyfrwng",
    selectMember: "Dewis aelod",
    selectMemberGroup: "Dewis grŵp aelod",
    selectMemberType: "Dewiswch fath aelod",
    selectNode: "Dewis nod",
    selectSections: "Dewis adran",
    selectUser: "Dewis defnyddiwr",
    selectUsers: "Dewis defnyddwyr",
    noIconsFound: "Dim eiconau wedi'u darganfod",
    noMacroParams: "Does dim paramedrau ar gyfer y macro yma",
    noMacros: "Does dim macro ar gael i fewnosod",
    externalLoginProviders: "Darparwyr mewngofnodi allanol",
    exceptionDetail: "Manylion Eithriad",
    stacktrace: "Trywydd stac",
    innerException: "Eithriad Fewnol",
    linkYour: "Dolenni eich",
    unLinkYour: "Dad-ddolenni eich",
    account: "cyfrif",
    selectEditor: "Dewiswch olygwr",
    selectEditorConfiguration: "Dewiswch ffurfweddiad",
    selectSnippet: "Dewiswch damaid",
    variantdeletewarning: "Bydd hyn yn dileu'r nod a'i holl ieithoedd. Os mai dim ond un iaith yr ydych am ei dileu, ewch i'w anghyhoedd yn lle.",
    propertyuserpickerremovewarning: "Bydd hyn yn cael gwared ar y defnyddiwr <strong>%0%</strong>.",
    userremovewarning: "bydd hyn yn cael gwared ar y defnyddiwr <strong>%0%</strong> o'r grŵp <strong>%1%</strong>",
    yesRemove: "Ydw, dileu",
    selectLanguages: "Dewiswch ieithoedd",
    deleteLayout: "Rydych chi'n dileu'r gosodiad",
    deletingALayout: "Bydd addasu'r gosodiad yn arwain at golli data ar gyfer unrhyw gynnwys presennol sy'n seiliedig ar y ffurfweddiad hwn."
  },
  dictionary: {
    noItems: "Nid oes unrhyw eitemau geiriadur.",
    importDictionaryItemHelp: `
      I fewnforio eitem geiriadur, dewch o hyd i'r ffeil ".udt" ar eich cyfrifiadur trwy glicio
      ar y botwm "Mewnforio" (bydd gofyn i chi am gadarnhad ar y sgrin nesaf)
    `,
    itemDoesNotExists: "Nid yw eitem geiriadur yn bodoli.",
    parentDoesNotExists: "Nid yw eitem rhiant yn bodoli.",
    noItemsInFile: "Nid oes unrhyw eitemau geiriadur yn y ffeil hon.",
    noItemsFound: "Ni chanfuwyd unrhyw eitemau geiriadur.",
    createNew: "Creu eitem geiriadur"
  },
  dictionaryItem: {
    description: "Golygwch y fersiynau iaith gwahanol ar gyfer yr eitem geiriadur '%0%' islaw<br/>Gallwch ychwanegu ieithoedd ychwanegol o dan 'ieithoedd' yn y ddewislen ar y chwith",
    displayName: "Enw Diwylliant",
    changeKeyError: "Mae'r allwedd '%0%' yn bodoli eisoes.",
    overviewTitle: "Trosolwg Geiriadur"
  },
  examineManagement: {
    configuredSearchers: "Chwilwyr wedi'u Ffurfweddu",
    configuredSearchersDescription: "Yn dangos priodweddau ac offer ar gyfer unrhyw Chwiliwr wedi'i ffurfweddu (h.y. fel chwiliwr aml-fynegai)",
    fieldValues: "Gwerthoedd maes",
    healthStatus: "Statws iechyd",
    healthStatusDescription: "Statws iechyd y mynegai ac os gellir ei ddarllen",
    indexers: "Mynegewyr",
    indexInfo: "Gwybodaeth mynegai",
    indexInfoDescription: "Yn rhestru priodweddau'r mynegai",
    manageIndexes: "Rheoli mynegeion Examine",
    manageIndexesDescription: "Yn caniatáu ichi weld manylion pob mynegai ac yn darparu rhai offer ar gyfer rheoli'r mynegeion",
    rebuildIndex: "Ailadeiladu mynegai ",
    rebuildIndexWarning: `
            Bydd hyn yn achosi i'r mynegai gael ei ailadeiladu.<br />
            Yn dibynnu ar faint o gynnwys sydd yn eich gwefan, gallai hyn gymryd cryn amser.<br />
            Ni argymhellir ailadeiladu mynegai ar adegau o draffig gwefan uchel neu pan fydd golygyddion yn golygu cynnwys.
            `,
    searchers: "Chwilwyr",
    searchDescription: "Chwiliwch y mynegai a gweld y canlyniadau",
    tools: "Offer",
    toolsDescription: "Offer i reoli'r mynegai",
    fields: "meysydd",
    indexCannotRead: "Ni ellir darllen yr mynegai a bydd angen ei ailadeiladu",
    processIsTakingLonger: "Mae'r broses yn cymryd mwy o amser na'r disgwyl, gwiriwch y log Umbraco i weld os mae wedi bod unrhyw wall yn ystod y gweithrediad hwn",
    indexCannotRebuild: "Ni ellir ailadeiladu'r mynegai hwn oherwydd nad yw wedi'i aseinio",
    iIndexPopulator: "IIndexPopulator",
    contentInIndex: "Cynnwys yn y mynegai",
    noResults: "Ni ddarganfuwyd unrhyw ganlyniadau",
    searchResultsFound: "Dangos %0% - %1% o %2% canlyniad(au) - Tudalen %3% o %4%"
  },
  placeholders: {
    username: "Darparwch eich enw defnyddiwr",
    password: "Darparwch eich cyfrinair",
    confirmPassword: "Cadarnhewch eich cyfrinair",
    nameentity: "Enwch y %0%...",
    entername: "Darparwch enw...",
    enteremail: "Darparwch ebost...",
    enterusername: "Darparwch enw defnyddiwr...",
    label: "Label...",
    enterDescription: "Darparwch ddisgrifiad...",
    search: "Teipiwch i chwilio...",
    filter: "Teipiwch i hidlo...",
    enterTags: "Teipiwch i ychwanegu tagiau (gwasgwch enter ar ôl pob tag)...",
    email: "Darparwch eich ebost",
    enterMessage: "Darparwch neges...",
    usernameHint: "Mae eich enw defnyddiwr fel arfer eich cyfeiriad ebost",
    anchor: "#gwerth neu ?allwedd=gwerth",
    enterAlias: "Darparwch enw arall...",
    generatingAlias: "Yn generadu enw arall...",
    a11yCreateItem: "Creu eitem",
    a11yEdit: "Golygu",
    a11yName: "Enw"
  },
  editcontenttype: {
    createListView: "Creu gwedd rhestr pwrpasol",
    removeListView: "Dileu gwedd rhestr pwrpasol",
    aliasAlreadyExists: "Mae math o gynnwys, math o gyfrwng neu math o aeold gyda'r enw arall yma'n bodoli eisoes"
  },
  renamecontainer: {
    renamed: "Wedi ailenwi",
    enterNewFolderName: "Darparwch enw ffolder newydd yma",
    folderWasRenamed: "%0% wedi ailenwi i %1%"
  },
  editdatatype: {
    addPrevalue: "Ychwanegu cyn-werth",
    dataBaseDatatype: "Math o ddata cronfa ddata",
    guid: "GUID golygydd priodwedd",
    renderControl: "Golygydd priodwedd",
    rteButtons: "Botymau",
    rteEnableAdvancedSettings: "Galluogi gosodiadau datblygedig ar gyfer",
    rteEnableContextMenu: "Galluogi dewislen cyd-destun",
    rteMaximumDefaultImgSize: "Maint fwyaf diofyn llun wedi'i fewnosod",
    rteRelatedStylesheets: "Taflenni arddull perthnasol",
    rteShowLabel: "Dangos label",
    rteWidthAndHeight: "Lled ac uchder",
    selectFolder: "Dewiswch y ffolder i symud",
    inTheTree: "i'r strwythyr goeden isod",
    wasMoved: "wedi symud o dan",
    hasReferencesDeleteConsequence: "Bydd dileu <strong>%0%</strong> yn dileu'r briodweddau a'i data o'r eitemau canlynol",
    acceptDeleteConsequence: "Rwy'n deall y weithred hon yn dileu'r holl briodweddau a data sy'n seiliedig ar Fath o Ddata hon",
    canChangePropertyEditorHelp: "Mae newid golygydd eiddo ar fath o ddata, â gwerthoedd wedi'u storio, wedi'i analluogi. I ganiatáu hyn gallwch newid y gosodiad Umbraco:CMS:DataTypes:CanBeChanged yn appssettings.json."
  },
  errorHandling: {
    errorButDataWasSaved: "Mae eich data wedi'i achub, ond cyn i chi allu cyhoeddi'r dudalen yma, mae yna wallau yr ydych angen eu gwirio yn gyntaf:",
    errorChangingProviderPassword: "Nid yw'r darparwr aeoldaeth bresennol yn cefnogi newid cyfrinair (EnablePasswordRetrieval angen cael ei osod i true)",
    errorExistsWithoutTab: "%0% yn bodoli eisoes",
    errorHeader: "Roedd yna wallau:",
    errorHeaderWithoutTab: "Roedd yna wallau:",
    errorInPasswordFormat: "Dylai'r cyfrinair fod o leiaf %0% nod o hyd a chynnwys o leiaf %1% nod(au) sydd ddim yn llythyren na rhif",
    errorIntegerWithoutTab: "%0% angen bod yn gyfanrif",
    errorMandatory: "Mae'r maes %0% yn y tab %1% yn ofynnol",
    errorMandatoryWithoutTab: "%0% yn faes ofynnol",
    errorRegExp: "%0% yn %1% mewn fformat annilys",
    errorRegExpWithoutTab: "%0% mewn fformat annilys"
  },
  errors: {
    receivedErrorFromServer: "Derbynwyd gwall o'r gweinydd",
    dissallowedMediaType: "Mae'r math o ffeil yma wedi'i wahardd gan y gweinyddwr",
    codemirroriewarning: "NODYN! Er bod CodeMirror wedi'i alluogi gan y ffurfwedd, mae o wedi'i analluogi mewn Internet Explorer gan nad yw'n ddigon cadarn.",
    contentTypeAliasAndNameNotNull: "Darparwch yr enw ac yr enw arall ar y math o briodwedd newydd!",
    filePermissionsError: "Mae yna broblem gyda hawliau darllen/ysgrifennu i ffeil neu ffolder penodol",
    macroErrorLoadingPartialView: "Gwall yn llwytho sgript Rhan-Wedd (ffeil: %0%)",
    missingTitle: "Darparwch deitl",
    missingType: "Dewiswch fath",
    pictureResizeBiggerThanOrg: "Rydych ar fîn gwneud y llun yn fwy 'na'r maint gwreiddiol. Ydych chi'n sicr eich bod eisiau parhau?",
    startNodeDoesNotExists: "Nod gychwynnol wedi'i ddileu, cysylltwch â'ch gweinyddwr",
    stylesMustMarkBeforeSelect: "Marciwch gynnwys cyn newid arddull",
    stylesNoStylesOnPage: "Dim arddulliau gweithredol ar gael",
    tableColMergeLeft: "Symudwch y cyrchwr ar ochr chwith y ddwy gell yr ydych eisiau cyfuno",
    tableSplitNotSplittable: "Ni allwch hollti cell sydd heb ei gyfuno.",
    propertyHasErrors: "Mae gan briodwedd hon gwallau",
    defaultError: "Mae methiant anhysbys wedi digwydd",
    concurrencyError: "Methiant cydsyniadau optimistaidd, gwrthrych wedi'i addasu"
  },
  general: {
    options: "Dewisiadau",
    about: "Amdano",
    action: "Gweithred",
    actions: "Gweithredoedd",
    add: "Ychwanegu",
    alias: "Enw arall",
    all: "Holl",
    areyousure: "Ydych chi'n sicr?",
    back: "Yn ôl",
    backToOverview: "Yn ôl i'r trosolwg",
    border: "Ffin",
    by: "wrth",
    cancel: "Canslo",
    cellMargin: "Ymyl cell",
    choose: "Dewis",
    clear: "Clirio",
    close: "Cau",
    closewindow: "Cau Ffenest",
    closepane: "Cau Cwarel",
    comment: "Sylw",
    confirm: "Cadarnhau",
    constrain: "Gorfodi",
    constrainProportions: "Gorfodi cyfraneddau",
    content: "Cynnwys",
    continue: "Bwrw ymlaen",
    copy: "Copïo",
    create: "Creu",
    cropSection: "Adran tocio",
    database: "Cronfa ddata",
    date: "Dyddiad",
    default: "Diofyn",
    delete: "Dileu",
    deleted: "Wedi dileu",
    deleting: "Yn dileu...",
    design: "Cynllun",
    dictionary: "Geiriadur",
    dimensions: "Dimensiynau",
    discard: "Gwaredu",
    down: "I lawr",
    download: "Lawrlwytho",
    edit: "Golygu",
    edited: "Golygwyd",
    elements: "Elfennau",
    email: "Ebost",
    error: "Gwall",
    field: "Maes",
    findDocument: "Canfod",
    first: "Cyntaf",
    focalPoint: "Canolbwynt",
    general: "Cyffredinol",
    generic: "Generig",
    groups: "Grŵpiau",
    group: "Grŵp",
    height: "Uchder",
    help: "Help",
    hide: "Cuddio",
    history: "Hanes",
    icon: "Eicon",
    id: "Id",
    import: "Mewnforio",
    excludeFromSubFolders: "Search only this folder Chwilio yn ffolder hwn yn unig",
    info: "Gwybodaeth",
    innerMargin: "Ymyl mewnol",
    insert: "Mewnosod",
    install: "Gosod",
    invalid: "Annilys",
    justify: "Unioni",
    label: "Label",
    language: "Iaith",
    last: "Olaf",
    layout: "Gosodiad",
    links: "Dolenni",
    loading: "Yn llwytho",
    locked: "Wedi cloi",
    login: "Mewngofnodi",
    logoff: "Allgofnodi",
    logout: "Allgofnodi",
    macro: "Macro",
    mandatory: "Gofynnol",
    message: "Neges",
    move: "Symud",
    name: "Enw",
    new: "Newydd",
    next: "Nesaf",
    no: "Na",
    of: "o",
    off: "I ffwrdd",
    ok: "Iawn",
    open: "Agor",
    on: "Ymlaen",
    or: "neu",
    orderBy: "Trefnu wrth",
    password: "Cyfrinair",
    path: "Llwybr",
    pleasewait: "Un eiliad os gwelwch yn dda...",
    previous: "Blaenorol",
    properties: "Priodweddau",
    rebuild: "Ailadeiladu",
    reciept: "Ebost i dderbyn data ffurflen",
    recycleBin: "Bin Ailgylchu",
    recycleBinEmpty: "Mae eich bin ailgylchu yn wag",
    reload: "Ail-lwytho",
    remaining: "Ar ôl",
    remove: "Dileu",
    rename: "Ailenwi",
    renew: "Adnewyddu",
    required: "Gofynnol",
    retrieve: "Adfer",
    retry: "Ceisio eto",
    rights: "Hawliau",
    scheduledPublishing: "Cyhoeddi ar amserlen",
    search: "Chwilio",
    searchNoResult: "Mae'n ddrwg gennym ni, ni all ganfod beth roeddwch chi'n chwilio amdano.",
    noItemsInList: "Dim eitemau wedi'u hychwanegu",
    server: "Gweinydd",
    settings: "Gosodiadau",
    show: "Dangos",
    showPageOnSend: "Dangos y dudlaen wrth Anfon",
    size: "Maint",
    sort: "Trefnu",
    status: "Statws",
    submit: "Cyflwyno",
    success: "Llwyddiant",
    type: "Math",
    typeToSearch: "Math i chwilio...",
    under: "o dan",
    up: "I fyny",
    update: "Diweddaru",
    upgrade: "Uwchraddio",
    upload: "Lanlwytho",
    url: "Url",
    user: "Defnyddiwr",
    username: "Enw defnyddiwr",
    value: "Gwerth",
    view: "Gwedd",
    welcome: "Croeso...",
    width: "Lled",
    yes: "Ie",
    folder: "Ffolder",
    searchResults: "Canlyniadau chwilio",
    reorder: "Ail-drefnu",
    reorderDone: "Rydw i wedi gorffen ail-drefnu",
    preview: "Rhagolwg",
    changePassword: "Newid cyfrinair",
    to: "i",
    listView: "Gwedd rhestr",
    saving: "Yn achub...",
    current: "presennol",
    embed: "Mewnblannu",
    selected: "dewiswyd",
    other: "Arall",
    articles: "Erthyglau",
    videos: "Fideos",
    avatar: "Avatar am",
    media: "Cyfryngau",
    nodeName: "Enw Nôd",
    readMore: "Darllen fwy",
    revert: "Dychwelyd",
    shared: "Cyfrannol",
    typeName: "Enw Fath",
    validate: "Dilysu",
    header: "Pennawd",
    systemField: "maes system",
    lastUpdated: "Diweddarwyd Diwethaf",
    change: "Newid",
    umbracoInfo: "Gwybodaeth Umbraco",
    skipToMenu: "Neidio i'r dewislen",
    skipToContent: "Neidio i'r cynnwys",
    primary: "Prif"
  },
  colors: {
    blue: "Glas"
  },
  shortcuts: {
    addTab: "Ychwanegu tab",
    addGroup: "Ychwanegu grŵp",
    addProperty: "Ychwanegu priodwedd",
    addEditor: "Ychwanegu golygydd",
    addTemplate: "Ychwanegu templed",
    addChildNode: "Ychwanegu nod blentyn",
    addChild: "Ychwanegu plentyn",
    editDataType: "Golygu math o ddata",
    navigateSections: "Llywio adrannau",
    shortcut: "Llwybrau byr",
    showShortcuts: "dangos llwybrau byr",
    toggleListView: "Toglo gwedd rhestr",
    toggleAllowAsRoot: "Toglo caniatáu fel gwraidd",
    commentLine: "Sylwi/Dad-sylwi llinellau",
    removeLine: "Dileu llinell",
    copyLineUp: "Copïo llinellau i fyny",
    copyLineDown: "Copïo llinellau i lawr",
    moveLineUp: "Symud Llinellau I Fyny",
    moveLineDown: "Symud Llinellau I Lawr",
    generalHeader: "Cyffredinol",
    editorHeader: "Golygydd",
    toggleAllowCultureVariants: "Toglo caniatáu amrywiadau diwylliant"
  },
  graphicheadline: {
    backgroundcolor: "Lliw cefndir",
    bold: "Trwm",
    color: "Lliw ffont",
    font: "Ffont",
    text: "Testun"
  },
  headers: {
    page: "Tudalen"
  },
  installer: {
    databaseErrorWebConfig: "Methu cadw'r ffeil web.config. Addaswch y llinyn cysylltu â llaw os gwelwch yn dda.",
    databaseErrorCannotConnect: "Ni all y gosodydd gysylltu â'r gronfa ddata.",
    databaseFound: "Canfwyd eich cronfa ddata ac mae'n cael ei adnabod fel",
    databaseHeader: "Ffurfwedd gronfa ddata",
    licenseText: "Trwy glicio ar y botwm nesaf (neu addasu'r umbracoConfigurationStatus yn web.config), rydych chi'n derbyn y drwydded ar gyfer y feddalwedd hon fel y nodir yn y blwch isod. Sylwch fod y dosbarthiad Umbraco hwn yn cynnwys dwy drwydded wahanol, y drwydded MIT ffynhonnell agored ar gyfer y fframwaith a thrwydded radwedd Umbraco sy'n cwmpasu'r UI.",
    theEndInstallFailed: `.
    `,
    databaseInstall: `
      Gwasgwch y botwm <strong>gosod</strong> i osod y gronfa ddata %0% Umbraco
    `,
    databaseInstallDone: "Mae Umbraco %0% yn awr wedi copïo i'ch gronfa ddata. Gwasgwch <strong>Nesaf</strong> i fwrw ymlaen.",
    databaseNotFound: `<p>Cronfa ddata heb ei ganfod! Gwiriwch fod y gwybodaeth yn y "llinyn gyswllt" o'r ffeil "web.config" yn gywir.</p>
              <p>Er mwyn parhau, newidiwch y ffeil "web.config" (gan ddefnyddio Visual Studio neu eich hoff olygydd testun), rholiwch at y gwaelod, ychwanegwch y llinyn gyswllt ar gyfer eich cronfa ddata yn yr allwedd o'r enw "UmbracoDbDSN" ac achub y ffeil. </p>
              <p>
              Cliciwch y botwm <strong>ceisio eto</strong> pan rydych wedi
              gorffen.<br /><a href="https://our.umbraco.com/documentation/Reference/Config/webconfig/" target="_blank" rel="noopener">
			              Mwy o wybodaeth am newid y ffeil web.config yma</a>.</p>`,
    databaseText: `Er mwyn cwblhau'r cam yma, rhaid i chi berchen gwybodaeth am eich gweinydd gronfa ddata ("llinyn gyswllt").<br />
        Cysylltwch â'ch darparwr gwe (ISP) os oes angen.
        Os ydych chi'n gosod ar beiriant leol neu weinydd, efallai bydd angen gwybodaeth o'ch gweinyddwr system arnoch.`,
    databaseUpgrade: `
      <p>
      Gwasgwch y botwm <strong>uwchraddio</strong> i uwchraddio eoch gronfa ddata i Umbraco %0%</p>
      <p>
      Peidiwch â phoeni - ni fydd unrhyw gynnwys yn cael ei ddileu a bydd popeth yn parhau i weithio wedyn!
      </p>
      `,
    databaseUpgradeDone: `Mae eich cronfa ddata wedi'u uwchraddio at y fersiwn terfynol %0%.<br />Gwasgwch <strong>Nesaf</strong> i
      barhau. `,
    databaseUpToDate: "Mae eich cronfa ddata bresennol wedi diweddaru eisoes!. Cliciwch <strong>nesaf</strong> i barhau gyda'r dewin ffurfwedd",
    defaultUserChangePass: "<strong>Mae angen newid cyfrinair y defnyddiwr Diofyn!</strong>",
    defaultUserDisabled: "<strong>Mae'r defnyddiwr Diofyn wedi'u analluogi neu does dim hawliau i Umbraco!</strong></p><p>Does dim angen unrhyw weithredoedd pellach. Cliciwch <strong>Nesaf</strong> i barhau.",
    defaultUserPassChanged: "<strong>Mae cyfrinair y defnyddiwr Diofyn wedi'i newid yn llwyddiannus ers y gosodiad!</strong></p><p>Does dim angen unrhyw weithredoedd pellach. Cliciwch <strong>Nesaf</strong> i barhau.",
    defaultUserPasswordChanged: "Mae'r cyfrinair wedi'i newid!",
    greatStart: "Cewch gychwyn gwych, gwyliwch ein fideos rhaglith",
    None: "Heb osod eto.",
    permissionsAffectedFolders: "Ffeiliau a ffolderi wedi'u effeithio",
    permissionsAffectedFoldersMoreInfo: "Mwy o wybodaeth am osod hawliau ar gyfer Umbraco yma",
    permissionsAffectedFoldersText: "Rydych angen caniatáu i ASP.NET newid hawliau ar y ffeiliau/ffolderi canlynol",
    permissionsAlmostPerfect: `<strong>Mae eich gosodiadau hawliau bron a bod yn berffaith!</strong><br /><br />
        Gallwch redeg Umbraco heb broblemau, ond ni fydd yn bosibl i chi osod pecynnau sydd wedi'u hargymell er mwyn cymryd mantais llawn o Umbraco.`,
    permissionsHowtoResolve: "Sut i Gywiro",
    permissionsHowtoResolveLink: "Cliciwch yma i ddarllen y ferswin destun",
    permissionsHowtoResolveText: "Gwyliwch ein <strong>fideo tiwtorial</strong> ar osod hawliau ffolder ar gyfer Umbraco neu darllenwch y fersiwn destun.",
    permissionsMaybeAnIssue: `<strong>Gall eich gosodiadau hawliau fod yn broblem!</strong>
      <br/><br />
      Gallwch redeg Umbraco heb broblemau, ond ni fydd yn bosibl i chi greu ffolderi neu gosod pecynnau sydd wedi'u hargymell er mwyn cymryd mantais llawn o Umbraco.`,
    permissionsNotReady: `<strong>Nid yw eich gosodiadau hawliau yn barod ar gyfer Umbraco!</strong>
          <br /><br />
          Er mwyn rhedeg Umbraco, bydd angen i chi ddiweddaru eich gosodiadau hawliau.`,
    permissionsPerfect: `<strong>Mae eich gosodiadau hawliau yn berffaith!</strong><br /><br />
              Rydych yn barod i redeg Umbraco a gosod pecynnau!`,
    permissionsResolveFolderIssues: "Yn datrys y broblem ffolder",
    permissionsResolveFolderIssuesLink: "Dilynwch y ddolen yma ar gyfer mwy o wybodaethar broblemau gyda ASP.NET a chreu ffolderi",
    permissionsSettingUpPermissions: "Gosod hawliau ffolderi",
    permissionsText: `
      Mae Umbraco angen hawliau ysgrifennu/newid er mwyn creu rhai ffolderi ar gyfer cadw ffeiliau fel lluniau a PDFs.
      Mae Umbraco hefyd yn cadw data dros-dro (storfa) ar gyfer mwyhau perfformiad eich gwefan.
    `,
    runwayFromScratch: "Rydw i eisiau ail-gychwyn",
    runwayFromScratchText: `
        Mae eich gwefan yn hollol wag ar hyn o bryd, felly mae hynny'n berffaith os rydych chi eisiau cychwyn eto a chreu eich mathau o ddogfennau a thempledi eich hunain.
        (<a href="https://umbraco.tv/documentation/videos/for-site-builders/foundation/document-types">dysgwch sut</a>)
        Gallwch ddewis i osod Runway yn hwyrach os hoffwch chi. Ewch at yr adran Datblygwr a dewiswch Pecynnau.
      `,
    runwayHeader: "Rydych newydd osod platfform glân Umbraco. Beth hoffwch chi wneud nesaf?",
    runwayInstalled: "Mae Runway wedi'i osod",
    runwayInstalledText: `
      Mae gennych chi'r sylfaen yn ei lle. Dewiswchpa fodylau yr hoffwch osod ar ei phen.<br />
      Dyma ein rhestr o fodylau yr ydym yn argymell, ticiwch y rhai hoffwch chi'u gosod,  neu gwelwch yr <a href="#" onclick="toggleModules(); return false;" id="toggleModuleList">holl restr o fodylau</a>
      `,
    runwayOnlyProUsers: "Dim ond wedi'i argymell ar gyfer defnyddwyr brofiadol",
    runwaySimpleSite: "Hoffwn i gychwyn gyda gwefan syml",
    runwaySimpleSiteText: `
      <p>
        Mae "Runway" yn wefan syml sy'n darparu mathau o ddogfennau a thempledi syml. Gall y gosodwr osod Runway i chi yn awtomatig,
        ond gallwch olygu, estyn neu ei ddileu yn hawdd. Nid yw'n angenrheidiol a gallwch ddefnyddio Umbraco yn berffaith heb. Ond,
        mae Runwayyn cynnig sylfaen hawdd wedi'i seilio ar arferion gorau er mwyn i chi gychwyn yn gyflymach nag erioed.
        Os rydych chi'n dewis gosod Runway, gallwch ddewis blociau adeiliadu syml o'r enw Modylau Runway er mwyn mwyhau eich tudalennau Runway.
        </p>
        <small>
        <em>Wedi cynnwys gyda Runway:</em> Tudalen Hafan, Tudalen Cychwyn Allan, Tudalen Gosod Modylau.<br />
        <em>Modylau Dewisol:</em> Llywio Dop, Map o'r wefan, Cysylltu, Oriel.
        </small>
      `,
    runwayWhatIsRunway: "Beth yw Runway",
    step1: "Cam 1/5 Derbyn trwydded",
    step2: "Cam 2/5: Ffurfwedd Gronfa Ddata",
    step3: "Cam 3/5: Dilysu Hawliau Ffeiliau",
    step4: "Cam 4/5: Gwirio Diogelwch Umbraco",
    step5: "Cam 5/5: Mae Umbraco yn barod i chi gychwyn",
    thankYou: "Diolch am ddewis Umbraco",
    theEndBrowseSite: `<h3>Porwch eich safle newydd</h3>
Rydych wedi gosod Runway, felly beth am weld sut mae eich gwefan newydd yn edrych.`,
    theEndFurtherHelp: `<h3>Cymorth a gwyboaeth bellach</h3>
Cewch gymorth o'n cymuned gwobrwyol, porwch drwy ein dogfennaeth neu gwyliwch fideos yn rhad ac am ddim ar sut i adeiladu gwefan syml, sut i ddefnyddio pecynnau a chanllaw cyflym i dermeg Umbraco`,
    theEndHeader: "Mae Umbraco wedi'i osod %0% ac mae'n barod i'w ddefnyddio",
    theEndInstallSuccess: `Gallwch gychwyn <strong>yn syth</strong> wrth glicio ar y botwm "Cychwyn Umbraco" isod. <br />Os ydych yn <strong>newydd i Umbraco</strong>,
gallwch ddarganfod digonedd o adnoddau ar ein tudalennau cychwyn allan.`,
    theEndOpenUmbraco: `<h3>Cychwyn Umbraco</h3>
Er mwyn gweinyddu eich gwefan, agorwch swyddfa gefn Umbraco a dechreuwch ychwangeu cynnwys, diweddaru'r templedi a thaflenni arddull neu ychwanegu nodweddion newydd`,
    Unavailable: "Methwyd cysylltu â'r gronfa ddata.",
    Version3: "Umbraco Fersiwn 3",
    Version4: "Umbraco Fersiwn 4",
    watch: "Gwylio",
    welcomeIntro: `Bydd y dewin yma yn eich llywio drwy'r broses o ffurfweddi <strong>Umbraco %0%</strong> ar gyfer gosodiad ffres neu uwchraddio o ferswin 3.0.
                                <br /><br />
                                Gwasgwch <strong>"nesaf"</strong> i gychwyn y dewin.`
  },
  language: {
    cultureCode: "Côd Diwylliant",
    displayName: "Enw Diwylliant"
  },
  lockout: {
    lockoutWillOccur: "Rydych wedi segura a bydd allgofnodi awtomatig yn digwydd mewn",
    renewSession: "Adnewyddwch rwan er mwyn achub eich gwaith"
  },
  login: {
    greeting0: "Croeso",
    greeting1: "Croeso",
    greeting2: "Croeso",
    greeting3: "Croeso",
    greeting4: "Croeso",
    greeting5: "Croeso",
    greeting6: "Croeso",
    instruction: "Mewngofnodwch isod",
    signInWith: "Mewngofnodwch gyda",
    timeout: "Sesiwn wedi cyrraedd terfyn amser",
    userFailedLogin: "Wps! Mae mewngofnodi wedi methu. Gwiriwch eich manylion a thrio eto.",
    bottomText: '<p style="text-align:right;">&copy; 2001 - %0% <br /><a href="https://umbraco.com" style="text-decoration: none" target="_blank" rel="noopener">Umbraco.com</a></p> ',
    forgottenPassword: "Wedi anghofio eich cyfrinair?",
    forgottenPasswordInstruction: "Bydd ebost yn cael ei anfon i'r cyfeiriad darparwyd gyda dolen i ailosod eich cyfrinair",
    requestPasswordResetConfirmation: "Bydd ebost gyda chyfarwyddiadau ailosod cyfrinair yn cael ei anfon at y cyfeiriad darparwyd os yw'n cyfateb â'n cofnodion",
    showPassword: "Dangos cyfrinair",
    hidePassword: "Cuddio cyfrinair",
    returnToLogin: "Dychwelyd i'r ffurflen mewngofnodi",
    setPasswordInstruction: "Darparwch gyfrinair newydd",
    setPasswordConfirmation: "Mae eich cyfrinair wedi'i ddiweddaru",
    resetCodeExpired: "Mae'r ddolen rydych wedi clicio arno naill ai yn annilys neu wedi dod i ben",
    resetPasswordEmailCopySubject: "Umbraco: Ailosod Cyfrinair",
    resetPasswordEmailCopyFormat: `
        <html>
			<head>
				<meta name='viewport' content='width=device-width'>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
			</head>
			<body class='' style='font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; color: #392F54; line-height: 22px; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background: #1d1333; margin: 0; padding: 0;' bgcolor='#1d1333'>
				<style type='text/css'> @media only screen and (max-width: 620px) {table[class=body] h1 {font-size: 28px !important; margin-bottom: 10px !important; } table[class=body] .wrapper {padding: 32px !important; } table[class=body] .article {padding: 32px !important; } table[class=body] .content {padding: 24px !important; } table[class=body] .container {padding: 0 !important; width: 100% !important; } table[class=body] .main {border-left-width: 0 !important; border-radius: 0 !important; border-right-width: 0 !important; } table[class=body] .btn table {width: 100% !important; } table[class=body] .btn a {width: 100% !important; } table[class=body] .img-responsive {height: auto !important; max-width: 100% !important; width: auto !important; } } .btn-primary table td:hover {background-color: #34495e !important; } .btn-primary a:hover {background-color: #34495e !important; border-color: #34495e !important; } .btn  a:visited {color:#FFFFFF;} </style>
				<table border="0" cellpadding="0" cellspacing="0" class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;" bgcolor="#1d1333">
					<tr>
						<td style="font-family: sans-serif; font-size: 14px; vertical-align: top; padding: 24px;" valign="top">
							<table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;">
								<tr>
									<td background="https://umbraco.com/umbraco/assets/img/application/logo.png" bgcolor="#1d1333" width="28" height="28" valign="top" style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
										<!--[if gte mso 9]> <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:30px;height:30px;"> <v:fill type="tile" src="https://umbraco.com/umbraco/assets/img/application/logo.png" color="#1d1333" /> <v:textbox inset="0,0,0,0"> <![endif]-->
										<div> </div>
										<!--[if gte mso 9]> </v:textbox> </v:rect> <![endif]-->
									</td>
									<td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top"></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;' bgcolor='#1d1333'>
					<tr>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
						<td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 560px; width: 560px; margin: 0 auto; padding: 10px;' valign='top'>
							<div class='content' style='box-sizing: border-box; display: block; max-width: 560px; margin: 0 auto; padding: 10px;'>
								<br>
								<table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; border-radius: 3px; background: #FFFFFF;' bgcolor='#FFFFFF'>
									<tr>
										<td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 50px;' valign='top'>
											<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
												<tr>
													<td style='line-height: 24px; font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'>
														<h1 style='color: #392F54; font-family: sans-serif; font-weight: bold; line-height: 1.4; font-size: 24px; text-align: left; text-transform: capitalize; margin: 0 0 30px;' align='left'>
															Ailosod cyfrinair wedi dymuno
														</h1>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Eich enw defnyddiwr ar gyfer swyddfa gefn Umbraco yw: <strong>%0%</strong>
														</p>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
																<tbody>
																	<tr>
																		<td style='font-family: sans-serif; font-size: 14px; vertical-align: top; border-radius: 5px; text-align: center; background: #35C786;' align='center' bgcolor='#35C786' valign='top'>
																			<a href='%1%' target='_blank' rel='noopener' style='color: #FFFFFF; text-decoration: none; -ms-word-break: break-all; word-break: break-all; border-radius: 5px; box-sizing: border-box; cursor: pointer; display: inline-block; font-size: 14px; font-weight: bold; text-transform: capitalize; background: #35C786; margin: 0; padding: 12px 30px; border: 1px solid #35c786;'>
																				Cliciwch y ddolen yma er mwyn ailosod eich cyfrinair
																			</a>
																		</td>
																	</tr>
																</tbody>
															</table>
														</p>
														<p style='max-width: 400px; display: block; color: #392F54; font-family: sans-serif; font-size: 14px; line-height: 20px; font-weight: normal; margin: 15px 0;'>Os na allwch glicio ar y ddolen yma, copïwch a gludwch y URL i mewn i'ch porwr:</p>
															<table border='0' cellpadding='0' cellspacing='0'>
																<tr>
																	<td style='-ms-word-break: break-all; word-break: break-all; font-family: sans-serif; font-size: 11px; line-height:14px;'>
																		<font style="-ms-word-break: break-all; word-break: break-all; font-size: 11px; line-height:14px;">
																			<a style='-ms-word-break: break-all; word-break: break-all; color: #392F54; text-decoration: underline; font-size: 11px; line-height:15px;' href='%1%'>%1%</a>
																		</font>
																	</td>
																</tr>
															</table>
														</p>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
								<br><br><br>
							</div>
						</td>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
					</tr>
				</table>
			</body>
		</html>
	`,
    "2faTitle": "Un cam olaf",
    "2faText": "Rydych chi wedi galluogi dilysu 2-ffactor ac mae'n rhaid i chi wirio pwy ydych chi.",
    "2faMultipleText": "Dewiswch ddarparwr 2 ffactor",
    "2faCodeInput": "Cod dilysu",
    "2faCodeInputHelp": "Rhowch y cod dilysu os gwelwch yn dda",
    "2faInvalidCode": "Cod annilys wedi'i nodi",
    mfaSecurityCodeSubject: "Umbraco: Cod Diogelwch",
    mfaSecurityCodeMessage: "Eich cod diogelwch yw: %0%"
  },
  main: {
    dashboard: "Dashfwrdd",
    sections: "Adrannau",
    tree: "Cynnwys"
  },
  moveOrCopy: {
    choose: "Dewis tudalen uwchben...",
    copyDone: "%0% wedi copïo i %1%",
    copyTo: "Dewiswch ble ddylai'r ddogfen %0% gael ei gopïo i isod",
    moveDone: "%0% wedi ei symud i %1%",
    moveTo: "Dewiswch ble ddylai'r ddogfen %0% gael ei symud i isod",
    nodeSelected: "wedi ei ddewis fel gwraidd eich cynnwys newydd, cliciwch 'iawn' isod.",
    noNodeSelected: "Dim nod wedi'i ddewis eto, dewiswch nod yn y rhestr uchod yn gyntaf cyn clicio 'iawn'",
    notAllowedByContentType: "Nid yw'r nod bresennol yn cael ei ganiatáu o dan y nod ddewiswyd oherwydd ei fath",
    notAllowedByPath: "Ni all y nod bresennol gael ei symud i un o'i is-dudalennau",
    notAllowedAtRoot: "Ni all y nod bresennol fodoli ar y gwraidd",
    notValid: "Nid yw'r gweithred wedi'i ganiatáu gan nad oes gennych ddigon o hawliau ar gyfer 1 neu fwy o ddogfennau blentyn.",
    relateToOriginal: "Perthnasu eitemau wedi'u copïo at y rhai gwreiddiol"
  },
  notifications: {
    editNotifications: "Golygu eich hysbysiad ar gyfer %0%",
    notificationsSavedFor: "Gosodiad hysbysiadau wedi cadw am %0%",
    notifications: "Hysbysiadau"
  },
  packager: {
    actions: "Gweithredoedd",
    created: "Creu",
    createPackage: "Creu pecyn",
    chooseLocalPackageText: `
      Dewiswch becyn o'ch peiriant, gan glicio ar y botwm<br />
         Pori a darganfod y pecyn. Fel arfer, mae gen becynnau Umbraco estyniadau ".umb" neu ".zip".
      `,
    deletewarning: "Bydd hwn yn dileu'r pecyn",
    includeAllChildNodes: "Cynhwyswch yr holl nodau plentyn",
    packageLicense: "Trwydded",
    installed: "Wedi'i osod",
    installedPackages: "Pecynnau wedi'u gosod",
    noPackages: "Nid oes gennych unrhyw becynnau wedi'u gosod",
    noPackagesDescription: "Nid oes gennych unrhyw becynnau wedi'u gosod. Naill ai gosodwch becyn leol wrth ddewis o'ch peiriant, neu porwch drwy pecynnau sydd ar gael wrth ddefnyddio'r eicon <strong>'Pecynnau'</strong> yng nghornel dop, dde eich sgrîn",
    noConfigurationView: "Nid oes gan y pecyn hwn unrhyw olwg cyfluniad",
    noPackagesCreated: "Nid oes unrhyw becynnau wedi'u creu eto",
    packageContent: "Cynnwys y Pecyn",
    packageSearch: "Chwilio am becynnau",
    packageSearchResults: "Canlyniadau ar gyfer",
    packageNoResults: "Ni allwn ddarganfod unrhyw beth ar gyfer",
    packageNoResultsDescription: "Ceisiwch chwilio am becyn arall neu porwch drwy'r categorïau",
    packagesPopular: "Poblogaidd",
    packagesNew: "Pecynnau newydd",
    packageHas: "yn cynnwys",
    packageKarmaPoints: "pwyntiau karma",
    packageInfo: "Gwybodaeth",
    packageOwner: "Perchennog",
    packageContrib: "Cyfranwyr",
    packageCreated: "Creuwyd",
    packageCurrentVersion: "Fersiwn bresennol",
    packageNetVersion: "Fersiwn .NET",
    packageDownloads: "Lawrlwythiadau",
    packageLikes: "Hoffi",
    packageCompatibility: "Cydweddoldeb",
    packageCompatibilityDescription: "Mae'r pecyn yma yn gydnaws â'r fersiynau canlynol o Umbraco, fel y mae aelodau'r gymued yn adrodd yn ôl. Ni all warantu cydweddoldeb cyflawn ar gyfer fersiynau sydd wedi'u hadrodd o dan 100%",
    packageExternalSources: "Ffynonellau allanol",
    packageAuthor: "Awdur",
    packageDocumentation: "Dogfennaeth",
    packageMetaData: "Meta ddata pecynnau",
    packageName: "Enw pecyn",
    packageNoItemsHeader: "Does dim eitemau o fewn y pecyn",
    packageNoItemsText: `Nid yw'r pecyn yma yn cynnwys unrhyw eitemau i ddadosod.<br/><br/>
      Gallwch ddileu hyn yn ddiogel o'r system wrth glicio "dadosod pecyn" isod.`,
    packageOptions: "Dewisiadau pecyn",
    packageReadme: "Readme pecyn",
    packageRepository: "Ystorfa pecyn",
    packageUninstallConfirm: "Cadarnhau dadosod pecyn",
    packageUninstalledHeader: "Pecyn wedi dadosod",
    packageUninstalledText: "Cafodd y pecyn ei ddadosod yn llwyddiannus",
    packageUninstallHeader: "Dadosod pecyn",
    packageUninstallText: `Gallwch ddi-ddewis eitemau dydych chi ddim eisiau dileu, rwan, isod. Wrth glicio "cadarnhau dadosod" bydd yr holl eitemau ddewiswyd yn cael eu dileu.<br />
      <span style="color: Red; font-weight: bold;">Rhybudd:</span> bydd unrhyw ddogfennau, cyfrwng ayyb sy'n dibynnu ar yr eitemau yr ydych am ddileu yn torri, a gall arwain at system ansefydlog,
      felly dadosodwch gyda gofal. Os oes unrhyw amheuaeth, cysylltwch ag awdur y pecyn.`,
    packageVersion: "Fersiwn pecyn",
    verifiedToWorkOnUmbracoCloud: "Wedi gwirio i weithio ar Umbraco Cloud",
    installInstructions: "Cyfarwyddiadau gosod",
    packagesPromoted: "Wedi'i hyrwyddo",
    packageMigrationsRun: "Rhedeg ymfudiadau pecyn tra'n aros",
    packageMigrationsComplete: "Mae mudo pecynnau wedi'u cwblhau'n llwyddiannus.",
    packageMigrationsNonePending: "Mae'r holl fudiadau pecyn wedi'u cwblhau'n llwyddiannus."
  },
  paste: {
    doNothing: "Gludo gyda fformatio llawn (Heb ei argymell)",
    errorMessage: "Mae'r testun yr ydych yn ceisio gludo yn cynnwys nodauneu fformatio arbennig. Gall hyn gael ei achosi gan ludo testun o Microsoft Word. Gall Umbraco ddileu nodau neu fformatio arbennig yn awtomatig, fel bod y cynnwys sy'n cael ei ludo yn fwy addas ar gyfer y we.",
    removeAll: "Gludo fel testun crai heb unrhyw fformatio",
    removeSpecialFormattering: "Gludo, ond dileu fformatio (Wedi'i hargymell)"
  },
  publicAccess: {
    paGroups: "Amddiffyniad yn seiliedig grŵp",
    paGroupsHelp: "Os ydych chi am ganiatáu mynediad i bob aelod o grwpiau aelodau penodol",
    paGroupsNoGroups: "Mae angen i chi greu grŵp aelod cyn y gallwch ddefnyddio dilysiad grŵp",
    paErrorPage: "Tudalen Wall",
    paErrorPageHelp: "Wedi'i ddefnyddio pan mae defnyddwyr wedi mewngofnodi, ond nid oes ganddynt hawliau",
    paHowWould: "Dewiswch sut i gyfyngu hawliau at y dudalen yma",
    paIsProtected: "%0% wedi amddiffyn rwan",
    paIsRemoved: "Amddiffyniad wedi dileu o %0%",
    paLoginPage: "Tudalen Mewngofnodi",
    paLoginPageHelp: "Dewiswch y dudalen sy'n cynnwys y ffurflen mewngofnodi",
    paRemoveProtection: "Dileu Amddiffyniad",
    paSelectPages: "Dewiswch y tudalennau sy'n cynnwys ffurflenni mewngofnodi a negeseuon gwall",
    paRemoveProtectionConfirm: "Ydych chi'n siŵr eich bod chi am gael gwared ar yr amddiffyniad o'r dudalen <strong>%0%</strong>?",
    paSelectGroups: "Dewiswch y grwpiau sydd â mynediad i'r dudalen <strong>%0%</strong>",
    paSelectMembers: "Dewiswch yr aelodau sydd â mynediad i'r dudalen <strong>%0%</strong>",
    paMembers: "Amddiffyn aelodau penodol",
    paMembersHelp: "Os ydych am ganiatáu mynediad i aelodau penodol"
  },
  publish: {
    invalidPublishBranchPermissions: "Caniatâd annigonol gan ddefnyddwyr i gyhoeddi'r holl ddogfennau disgynyddion",
    contentPublishedFailedIsTrashed: "Methwyd cyhoeddi %0% oherwydd mae'r eitem yn y bin ailgylchu.",
    contentPublishedFailedAwaitingRelease: "Methwyd cyhoeddi %0% oherwydd mae'r eitem wedi ei amserlenni ar gyfer rhyddhad.",
    contentPublishedFailedExpired: "Methwyd cyhoeddi %0% oherwydd mae'r eitem wedi terfynu.",
    contentPublishedFailedInvalid: "Methwyd cyhoeddi %0% oherwydd nid oedd y priodweddau canlynol:  %1%  yn pasio'r rheolau dilysu.",
    contentPublishedFailedByEvent: "Methwyd cyhoeddi %0% oherwydd cafodd y gweithred ei ganslo gan 3-ydd parti.",
    contentPublishedFailedByParent: "Methwyd cyhoeddi %0% oherwydd mae yna dudlaen rhiant sydd heb ei gyhoeddi.",
    contentPublishedFailedByMissingName: "%0% ni ellir ei gyhoeddi, oherwydd ei enw ar goll.",
    contentPublishedFailedReqCultureValidationError: "Methodd y dilysiad ar gyfer yr iaith ofynnol '%0%'. Roedd yr iaith wedi cael ei arbed ond nid ei chyhoeddi.",
    inProgress: "Cyhoeddi ar waith - arhoswch...",
    inProgressCounter: "%0% allan o %1% o dudalennau wedi eu cyhoeddi...",
    nodePublish: "%0% wedi ei gyhoeddi",
    nodePublishAll: "%0% ac eu is-dudalennau wedi'u cyhoeddi",
    publishAll: "Cyhoeddi %0% ac ei holl is-dudalennau",
    publishHelp: `Cliciwch <em>Cyhoeddi</em> er mwyn cyhoeddi <strong>%0%</strong> a felly yn gwneud i'r cynnwys berthnasol fod ar gael i'r cyhoedd.<br/><br />
      Gallwch gyhoeddi'r dudalen yma ac ei holl is-dudalennau wrth dicio <em>Cynnwys tudalennau heb eu cyhoeddi</em> isod.
      `
  },
  colorpicker: {
    noColors: "Nid ydych chi wedi ffurfweddu unrhyw liwiau sydd wedi'u cymeradwyo"
  },
  contentPicker: {
    allowedItemTypes: "Gallwch ond ddewis eitemau o'r math(au): %0%",
    pickedTrashedItem: "Rydych wedi dewis eitem gynnwys sydd naill ai wedi'i ddileu neu yn y bin ailgylchu",
    pickedTrashedItems: "Rydych wedi dewis eitemau gynnwys sydd naill ai wedi'u dileu neu yn y bin ailgylchu",
    specifyPickerRootTitle: "Nodi gwraidd",
    defineRootNode: "Dewiswch nod gwraidd",
    defineXPathOrigin: "Nodi gwraidd efo XPath",
    defineDynamicRoot: "Nodi Gwraidd Dynamig",
    configurationStartNodeTitle: "Nod cychwyn",
    configurationXPathTitle: "Ymholiad XPath"
  },
  dynamicRoot: {
    configurationTitle: "Ymholiad Gwraidd Dynamig",
    pickDynamicRootOriginTitle: "Dewiswch darddiad",
    pickDynamicRootOriginDesc: "Diffiniwch darddiad eich Ymholiad Gwraidd Dynamig",
    originRootTitle: "Gwraidd",
    originRootDesc: "Nod gwraidd y sesiwn olygu hon",
    originParentTitle: "Rhiant",
    originParentDesc: "Nod rhiant y ffynhonnell yn y sesiwn olygu hon",
    originCurrentTitle: "Cyfredol",
    originCurrentDesc: "Y nod cynnwys sy'n ffynhonnell ar gyfer y sesiwn olygu hon",
    originSiteTitle: "Gwefan",
    originSiteDesc: "Canfod nod agosaf gydag enw gwesteiwr",
    originByKeyTitle: "Nod penodol",
    originByKeyDesc: "Dewiswch Nod penodol fel tarddiad yr ymholiad hwn",
    pickDynamicRootQueryStepTitle: "Atodwch y cam i'r ymholiad",
    pickDynamicRootQueryStepDesc: "Diffiniwch y cam nesaf yn eich Ymholiad Gwraidd Dynamig",
    queryStepNearestAncestorOrSelfTitle: "Hynafiad Agosaf Neu Hunan",
    queryStepNearestAncestorOrSelfDesc: "Holwch yr hynafiad agosaf neu hunan sy'n cyd-fynd ag un o'r mathau sydd wedi'u ffurfweddu",
    queryStepFurthestAncestorOrSelfTitle: "Hynafiad Pellaf Neu Hunan",
    queryStepFurthestAncestorOrSelfDesc: "Holwch yr hynafiad pellaf neu'r hunan sy'n cyd-fynd ag un o'r mathau sydd wedi'u ffurfweddu",
    queryStepNearestDescendantOrSelfTitle: "Disgynnydd Agosaf Neu Hunan",
    queryStepNearestDescendantOrSelfDesc: "Holwch y disgynnydd agosaf neu'r hunan sy'n cyd-fynd ag un o'r mathau sydd wedi'u ffurfweddu",
    queryStepFurthestDescendantOrSelfTitle: "Disgynnydd Pellaf Neu Hunan",
    queryStepFurthestDescendantOrSelfDesc: "Holwch y disgynnydd pellaf neu'r hunan sy'n cyd-fynd ag un o'r mathau sydd wedi'u ffurfweddu",
    queryStepCustomTitle: "Arferiad",
    queryStepCustomDesc: "Ymholiad gan ddefnyddio Cam Ymholiad arferiad",
    addQueryStep: "Ychwanegu cam ymholiad",
    queryStepTypes: "Sy'n cyfateb i'r mathau: ",
    noValidStartNodeTitle: "Dim cynnwys cyfatebol",
    noValidStartNodeDesc: "Nid yw ffurfweddiad yr eiddo hwn yn cyfateb i unrhyw gynnwys. Creu'r cynnwys coll neu cysylltwch â'ch gweinyddwr i addasu gosodiadau Gwraidd Dynamig ar gyfer yr eiddo hwn.",
    cancelAndClearQuery: "Canslo a chlirio ymholiad"
  },
  mediaPicker: {
    pickedTrashedItem: "Rydych wedi dewis eitem gyfrwng sydd naill ai wedi'i ddileu neu yn y bin ailgylchu",
    pickedTrashedItems: "Rydych wedi dewis eitemau gyfrwng sydd naill ai wedi'u dileu neu yn y bin ailgylchu",
    deletedItem: "Eitem wedi'i ddileu",
    trashed: "Yn sbwriel",
    openMedia: "Agor mewn Llyfrgell Cyfryngau",
    changeMedia: "Newid Eitem Gyfrwng",
    editMediaEntryLabel: "Golygu %0% ar %1%",
    confirmCancelMediaEntryCreationHeadline: "Gwaredu cread?",
    confirmCancelMediaEntryCreationMessage: "Ydych chi'n siŵr eich bod chi am ganslo'r cread?",
    confirmCancelMediaEntryHasChanges: "Rydych chi wedi gwneud newidiadau i'r cynnwys hwn. Ydych chi'n siŵr eich bod chi am eu gwaredu?",
    confirmRemoveAllMediaEntryMessage: "Dileu pob cyfryngau?",
    tabClipboard: "Clipfwrdd",
    notAllowed: "Ni chaniateir",
    openMediaPicker: "Agor dewisydd cyfryngau"
  },
  propertyEditorPicker: {
    title: "Dewiswch Olygydd Eiddo",
    openPropertyEditorPicker: "Dewiswch Olygydd Eiddo"
  },
  relatedlinks: {
    enterExternal: "Darparwch ddolen allanol",
    chooseInternal: "Dewiswch dudalen fewnol",
    caption: "Capsiwn",
    link: "Dolen",
    newWindow: "Agor mewn ffenestr newydd",
    captionPlaceholder: "Darparwch y capsiwn arddangos",
    externalLinkPlaceholder: "Darparwch y ddolen"
  },
  imagecropper: {
    reset: "Ailosod tocio",
    updateEditCrop: "Wedi gwneud",
    undoEditCrop: "Dadwneud golygion",
    customCrop: "Diffiniad defnyddiwr"
  },
  rollback: {
    headline: "Dewis fersiwn i gymharu efo fersiwn bresennol",
    changes: "Newidiadau",
    diffHelp: "May hyn yn dangos y gwahaniaeth rhwng y fersiwn bresennol ac y fersiwn dewiswyd<br />Ni fydd testun <del>coch</del> yn cael ei ddangos yn y fersiwn dewiswyd. , <ins>mae gwyrdd yn golygu wedi'i ychwanegu</ins>",
    documentRolledBack: "Dogfen wedi'i rolio yn ôl",
    htmlHelp: "Mae hyn yn dangos y fersiwn dewiswyd ar ffurf HTML, os hoffwch weld y gwahaniaeth rhwng 2 fersiwn ar yr un pryd, defnyddiwch y wedd gwahaniaethol",
    rollbackTo: "Rolio yn ôl at",
    selectVersion: "Dewis fersiwn",
    view: "Gwedd",
    pagination: "Yn dangos fersiwn %0% i %1% o %2% fersiynau.",
    versions: "Fersiynau",
    currentDraftVersion: "Fersiwn drafft cyfredol",
    currentPublishedVersion: "Fersiwn cyhoeddedig cyfredol",
    created: "Wedi creu",
    currentVersion: "Fersiwn gyfredol",
    noDiff: "Nid oes unrhyw wahaniaethau rhwng y fersiwn (drafft) gyfredol a'r fersiwn a ddewiswyd"
  },
  scripts: {
    editscript: "Golygu ffeil sgript"
  },
  sections: {
    content: "Cynnwys",
    forms: "Ffurflenni",
    media: "Cyfrwng",
    member: "Aelodau",
    packages: "Pecynnau",
    settings: "Gosodiadau",
    translation: "Cyfieithiad",
    users: "Defnyddwyr",
    marketplace: "Marchnad"
  },
  help: {
    tours: "Teithiau",
    theBestUmbracoVideoTutorials: "Y fideos tiwtorial Umbraco gorau",
    umbracoForum: "Ymweld â our.umbraco.com",
    umbracoTv: "Ymweld â umbraco.tv",
    umbracoLearningBase: "Gwyliwch ein fideos tiwtorial am ddim",
    umbracoLearningBaseDescription: "ar Ganolfan Ddysgu Umbraco"
  },
  settings: {
    defaulttemplate: "Templed diofyn",
    importDocumentTypeHelp: 'Er mwyn mewnforio math o ddogfen, darganfyddwch y ffeil ".udt" ar ecih cyfrifiadur wrth glicio ar y botwn "Pori" a cliciwch "Mewnforio" (byddwch yn cael eich gofyn i gadarnhau ar y sgrîn nesaf)',
    newtabname: "Teitl Tab Newydd",
    nodetype: "Math o nod",
    objecttype: "Math",
    stylesheet: "Taflen arddull",
    script: "Sgript",
    tab: "Tab",
    tabname: "Teitl Tab",
    tabs: "Tabiau",
    contentTypeEnabled: "Math o Gynnwys Meistr wedi'i alluogi",
    contentTypeUses: "Mae'r Math o Gynnwys yma yn defnyddio",
    noPropertiesDefinedOnTab: `Dim priodweddau wedi'u diffinio ar y tab yma. Cliciwch ar y ddolen "ychwanegu priodwedd newydd" ar y topi greu priodwedd newydd.`,
    createMatchingTemplate: "Creu templedi cydweddol",
    addIcon: "Ychwanegu eicon"
  },
  sort: {
    sortOrder: "Trefn",
    sortCreationDate: "Dyddiad creu",
    sortDone: "Trefnu wedi'i gwblhau.",
    sortHelp: "Llusgwch yr eitemau gwahanol i fyny neu i lawr isod er mwyn gosod sut dylen nhw gael eu trefnu. Neu cliciwch ar beniadau'r golofnau i drefnu'r holl gasgliad o eitemau",
    sortPleaseWait: "Arhoswch. Mae'r eitemau yn cael eu trefnu, gall hyn gymryd amser.",
    sortEmptyState: "Nid oes gan y nod hwn nodau plentyn i trefnu"
  },
  speechBubbles: {
    validationFailedHeader: "Dilysiad",
    validationFailedMessage: "Rhaid i wallau dilysu gael eu trwsio cyn gall yr eitem gael ei achub",
    operationFailedHeader: "Wedi methu",
    operationSavedHeader: "Wedi achub",
    operationSavedHeaderReloadUser: "Wedi achub. I weld y newidiadau, ail-lwythwch eich porwr",
    invalidUserPermissionsText: "Diffyg hawliau defnyddiwr, ni ellir cwblhau'r gweithred",
    operationCancelledHeader: "Wedi canslo",
    operationCancelledText: "Gweithred wedi'i ganslo gan ymestyniad 3-ydd parti",
    contentTypeDublicatePropertyType: "Math o briodwedd yn bodoli eisoes",
    contentTypePropertyTypeCreated: "Math o briodwedd wedi'i greu",
    contentTypePropertyTypeCreatedText: "Enw: %0% <br /> Math o ddata: %1%",
    contentTypePropertyTypeDeleted: "math o briodwedd wedi'i ddileu",
    contentTypeSavedHeader: "Math o Ddogfen wedi'u achub",
    contentTypeTabCreated: "Tab wedi'i greu",
    contentTypeTabDeleted: "Tab wedi'i ddileu",
    contentTypeTabDeletedText: "Tab gyda id: %0% wedi'i ddileu",
    cssErrorHeader: "Taflen arddull heb ei achub",
    cssSavedHeader: "Taflen arddull wedi'i achub",
    cssSavedText: "Taflen arddull wedi'i achub heb unrhyw wallau",
    dataTypeSaved: "Math o ddata wedi'i achub",
    dictionaryItemSaved: "Eitem geiriadur wedi'i achub",
    editContentPublishedHeader: "Cynnwys wedi'i gyhoeddi",
    editContentPublishedText: "ac yn weladwy ar y wefan",
    editMultiContentPublishedText: "%0% dogfennau wedi'i gyhoeddi ac yn gweledig ar y wefan",
    editVariantPublishedText: "%0% gyhoeddi ac yn gweledig ar y wefan",
    editMultiVariantPublishedText: "%0% dogfennau wedi'i gyhoeddi am yr ieithoedd %1% ac yn gweledig ar y wefan",
    editContentSavedHeader: "Cynnwys wedi'i achub",
    editContentSavedText: "Cofiwch gyhoeddi er mwyn i'r newidiadau fod yn weladwy",
    editContentScheduledSavedText: "Mae amserlen ar gyfer cyhoeddi wedi'i diweddaru",
    editVariantSavedText: "%0% wedi arbed",
    editContentSendToPublish: "Wedi'i anfon am gymeradwyo",
    editContentSendToPublishText: "Newidiadau wedi'u hanfon am gymeradwyo",
    editVariantSendToPublishText: "%0% newidiadau wedi'u hanfon am gymeradwyo",
    editMediaSaved: "Cyfrwng wedi'i achub",
    editMediaSavedText: "Cyfrwng wedi'i achub heb unrhyw wallau",
    editMemberSaved: "Aelod wedi'i achub",
    editStylesheetPropertySaved: "Priodwedd taflen arddull wedi'i achub",
    editStylesheetSaved: "Taflen arddull wedi'i achub",
    editTemplateSaved: "Templed wedi'i achub",
    editUserError: "Gwall yn achub y defnyddiwr (gwiriwch y log)",
    editUserSaved: "Defnyddiwr wedi'i achub",
    editUserTypeSaved: "math o ddefnyddiwr wedi'i achub",
    editUserGroupSaved: "Grŵp defnyddwyr wedi'i achub",
    editCulturesAndHostnamesSaved: "Diwylliannau ac enwau gwesteia wedi'i achub",
    editCulturesAndHostnamesError: "Gwall wrth achub diwylliannau ac enwau gwesteia",
    fileErrorHeader: "Ffeil heb ei achub",
    fileErrorText: "Ni ellir achub y ffeil. Gwiriwch hawliau'r ffeil",
    fileSavedHeader: "Ffeil wedi'i achub",
    fileSavedText: "Ffeil wedi'i achub heb unrhyw wallau",
    languageSaved: "Iaith wedi'i achub",
    mediaTypeSavedHeader: "Math o Gyfrwng wedi'i achub",
    memberTypeSavedHeader: "Math o Aelod wedi'i achub",
    memberGroupSavedHeader: "Grŵp Aelod wedi'i achub",
    templateErrorHeader: "Templed heb ei achub",
    templateErrorText: "Sicrhewch nad oes gennych 2 dempled gyda'r un enw arall",
    templateSavedHeader: "Templed wedi'i achub",
    templateSavedText: "Templed wedi'i achub heb unrhyw wallau!",
    contentUnpublished: "Cynnwys wedi'i ddadgyhoeddi",
    contentCultureUnpublished: "amrywiad cynnwys %0% wedi'i dadgyhoeddi",
    contentMandatoryCultureUnpublished: "Roedd yr iaith orfodol '%0%' wedi'i dadgyhoeddi. Mae'r holl ieithoedd ar gyfer yr eitem gynnwys hon bellach wedi'i dadgyhoeddi.",
    partialViewSavedHeader: "Rhan-wedd wedi'i achub",
    partialViewSavedText: "Rhan-wedd wedi'i achub heb unrhyw wallau!",
    partialViewErrorHeader: "Rhan-wedd heb ei achub",
    partialViewErrorText: "Bu gwall yn ystod achub y ffeil.",
    permissionsSavedFor: "Hawliau wedi'u hachub ar gyfer",
    deleteUserGroupsSuccess: "Wedi dileu %0% o rwpiau defnwyddwr",
    deleteUserGroupSuccess: "%0% wedi'i ddileu",
    enableUsersSuccess: "%0% o ddefnyddwyr wedi'u galluogi",
    disableUsersSuccess: "Wedi analluogi %0% o ddefnyddwyr",
    enableUserSuccess: "%0% yn awr wedi galluogi",
    disableUserSuccess: "%0% yn awr wedi analluogi",
    setUserGroupOnUsersSuccess: "Grwpiau defnyddiwr wedi'u gosod",
    unlockUsersSuccess: "Wedi datgloi %0% o ddefnyddwyr",
    unlockUserSuccess: "%0% yn awr wedi datgloi",
    memberExportedSuccess: "Allforwyd yr aelod at ffeil",
    memberExportedError: "Bu gwall yn ystod allforio'r aelod",
    deleteUserSuccess: "Defnyddiwr %0% wedi'i ddileu",
    resendInviteHeader: "Gawhodd defnyddiwr",
    resendInviteSuccess: "Gwahoddiad wedi'i ail-anfon at %0%",
    contentReqCulturePublishError: "Methu cyhoeddi'r ddogfen gan nad yw'r gofynnol '%0%' wedi cael ei gyhoeddi",
    contentCultureValidationError: "Methodd dilysiad ar gyfer iaith '%0%'",
    documentTypeExportedSuccess: "Mae'r math dogfen wedi ei allforio i ffeil",
    documentTypeExportedError: "Digwyddodd gwall wrth allforio'r math dogfen",
    scheduleErrReleaseDate1: "Ni all y dyddiad rhyddhau fod yn y gorffennol",
    scheduleErrReleaseDate2: "Ni all drefnu'r ddogfen i'w chyhoeddi gan nad yw'r gofynnol '%0%' wedi cael ei gyhoeddi",
    scheduleErrReleaseDate3: "Ni all drefnu'r ddogfen i'w chyhoeddi oherwydd mae ganddo'r gofynnol '%0%' ddyddiad cyhoeddi yn hwyrach nag iaith nad yw'n orfodol",
    scheduleErrExpireDate1: "Ni all y dyddiad terfyn fod yn y gorffennol",
    scheduleErrExpireDate2: "Ni all y dyddiad terfyn fod cyn y dyddiad rhyddhau",
    folderUploadNotAllowed: "Mae'r ffeil hon yn cael ei lanlwytho fel rhan o ffolder, ond ni chaniateir creu ffolder newydd yma",
    folderCreationNotAllowed: "Ni chaniateir creu ffolder newydd yma",
    editBlueprintSavedHeader: "Templed Cynnwys wedi'i gadw",
    editBlueprintSavedText: "Mae newidiadau wedi'u cadw'n llwyddiannus",
    memberGroupNameDuplicate: "Mae Grŵp Aelodau arall gyda'r un enw yn bodoli yn barod",
    dictionaryItemExportedSuccess: "Allforiwyd eitem(au) geiriadur i ffeil",
    dictionaryItemExportedError: "Mae gwall wedi digwydd wrth allforio'r eitem(au) geiriadur",
    dictionaryItemImported: "Mae'r eitem(au) geiriadur canlynol wedi ei mewnforio!",
    publishWithNoDomains: "Nid yw parthau wedi'u ffurfweddu ar gyfer gwefan amlieithog, cysylltwch â gweinyddwr, gweler y log am ragor o wybodaeth",
    publishWithMissingDomain: "Nid oes parth wedi ei ffurfweddu ar gyfer %0%, cysylltwch â gweinyddwr, gweler y log am fwy o wybodaeth",
    preventCleanupEnableError: "Digwyddodd gwall wrth alluogi glanhau fersiwn ar gyfer %0%",
    preventCleanupDisableError: "Digwyddodd gwall wrth analluogi glanhau fersiwn ar gyfer %0%",
    copySuccessMessage: "Mae gwybodaeth eich system wedi'i chopïo'n llwyddiannus i'r clipfwrdd",
    cannotCopyInformation: "Methu â chopïo gwybodaeth eich system i'r clipfwrdd",
    webhookSaved: "Bachyn gwe wedi arbed"
  },
  stylesheet: {
    addRule: "Ychwanegu ardull",
    editRule: "Golygu ardull",
    editorRules: "Ardull golygydd testun cyfoethog",
    editorRulesHelp: "Diffiniwch yr arddulliau a ddylai fod ar gael yn y golygydd testun cyfoethog ar gyfer y daflen arddull hon",
    editstylesheet: "Golygu taflen arddull",
    editstylesheetproperty: "Golygu priodwedd taflen arddull",
    nameHelp: "Enw ar gyfer adnabod y priodwedd arddull yn y golygydd testun gyfoethog",
    preview: "Rhagolwg",
    previewHelp: "Sut fydd y testun yn edrych yn y golygydd testun cyfoethog.",
    selector: "Dewisydd",
    selectorHelp: "Yn defnyddio cystrawen CSS e.e: h1, .coch, .glas",
    styles: "Arddulliau",
    stylesHelp: 'Dyled y CSS ei gymhwyso yn y golygydd testun cyfoethog, e.g. "color:red;"',
    tabCode: "Côd",
    tabRules: "Golygydd"
  },
  template: {
    deleteByIdFailed: "Methwyd dileu templed efo'r ID %0%",
    edittemplate: "Golygu templed",
    insertSections: "Adrannau",
    insertContentArea: "Mewnosod ardal cynnwys",
    insertContentAreaPlaceHolder: "Mewnosod dalfan ar gyfer ardal cynnwys",
    insert: "Mewnosod",
    insertDesc: "Dewiswch beth i fewnosod i mewn i'ch templed",
    insertDictionaryItem: "Eitem geiriadaur",
    insertDictionaryItemDesc: "Mae eitem geiriadur yn ddalfan ar gyfer darn o destun y gall gael ei gyfieithu, sy'n ei wneud yn hawdd i greu dyluniadau ar gyfer gwefannau aml-ieithog.",
    insertMacro: "Macro",
    insertMacroDesc: `
      Mae Macro yn gydran ffurfweddol sy'n wych ar gyfer
      darnau o'ch dyluniad sy'n cael eu ail-ddefnyddio, ble mae angen y dewis i ddarparu paramedrau,
      er enghraifft orielau, ffurflenni a rhestri.
    `,
    insertPageField: "Gwerth",
    insertPageFieldDesc: "Yn dangos gwerth maes penodol o'r dudalen bresennol, gyda'r dewisiadau i newid y gwerth neu syrthio'n ôl at werthoedd eraill.",
    insertPartialView: "Rhan-wedd",
    insertPartialViewDesc: `
      Mae rhan-wedd yn ffeil templed ar wahân y gall gael ei ddatganu o fewn templed arall,
      mae'n wych ar gyfer ail-ddefnyddio côd neu ar gyfer gwahanu templedi cymhleth i mewn i ffeiliau gwahanol.
    `,
    mastertemplate: "Templed Meistr",
    noMaster: "Dim meistr",
    renderBody: "Datganu templed blentyn",
    renderBodyDesc: `
            Yn datganu cynnwys templed blentyn, wrth fewnosod dalfan
            <code>@RenderBody()</code>.
            `,
    defineSection: "Diffiniwch adran benodol",
    defineSectionDesc: `
            Yn diffinio rhan o'ch templed fel adran benodol gan ei lapio mewn
            <code>@section { ... }</code>. Gall hyn gael ei ddatganu mewn adran
            benodol o rhiant y templed yma, wrth ddefnyddio <code>@RenderSection</code>.
            `,
    renderSection: "Datganu adran benodol",
    renderSectionDesc: `
            Yn datganu adran benodol o dempled blentyn, wrth fewnosod dalfan <code>@RenderSection(name)</code>.
            mae hyn yn datganu  adran o dempled blentyn sydd wedi'i lapio mewn diffiniad berthnasol o <code>@section [name]{ ... }</code>.
            `,
    sectionName: "Enw Adran",
    sectionMandatory: "Mae Adran yn ofynnol",
    sectionMandatoryDesc: `
            Os yn ofynnol, rhaid i'r templed blentyn gynnwys diffiniad adran <code>@section</code>, fel arall bydd gwall yn cael ei ddangos.
        `,
    queryBuilder: "Adeiladwr ymholiad",
    itemsReturned: "o eitemau wedi dychwelyd, mewn",
    iWant: "Rydw i eisiau",
    allContent: "holl gynnwys",
    contentOfType: `cynnwys o'r fath "%0%"`,
    from: "o",
    websiteRoot: "fy wefan",
    where: "ble",
    and: "ac",
    is: "yn",
    isNot: "ddim yn",
    before: "cyn",
    beforeIncDate: "cyn (gan gynnwys y dyddiad dewiswyd)",
    after: "ar ôl",
    afterIncDate: "ar ôl (gan gynnwys y dyddiad dewiswyd)",
    equals: "yn gyfartal i",
    doesNotEqual: "ddim yn gyfartal i",
    contains: "yn cynnwys",
    doesNotContain: "ddim yn cynnwys",
    greaterThan: "yn fwy na",
    greaterThanEqual: "yn fwy na neu yn gyfartal i",
    lessThan: "llai na",
    lessThanEqual: "llai na neu yn gyfartal i",
    id: "Id",
    name: "Enw",
    createdDate: "Dyddiad Creu",
    lastUpdatedDate: "Dyddiad Diweddariad Ddiwethaf",
    orderBy: "trefnu wrth",
    ascending: "esgynnol",
    descending: "disgynnol",
    template: "Templed",
    runtimeModeProduction: "."
  },
  grid: {
    media: "Llun",
    macro: "Macro",
    insertControl: "Dewis math o gynnwys",
    chooseLayout: "Dewis cynllun",
    addRows: "Ychwanegu rhes",
    addElement: "Ychwanegu cynnwys",
    dropElement: "Gollwng cynnwys",
    settingsApplied: "Gosodiadau wedi'u hymgeisio",
    contentNotAllowed: "Nid yw'r cynnwys yma wedi'i ganiatáu yma",
    contentAllowed: "Caniateir y cynnwys yma",
    clickToEmbed: "Cliciwch i fewnblannu",
    clickToInsertImage: "Cliciwch i fewnosod llun",
    clickToInsertMacro: "Cliciwch i fewnosod macro",
    placeholderWriteHere: "Ysgrifennwch yma...",
    gridLayouts: "Cynlluniau Grid",
    gridLayoutsDetail: "Cynlluniau yw'r holl ardal weithio gyfan ar gyfer y golygydd grid, fel arfer rydych ddim ond angen un neu ddau gynllun gwahanol",
    addGridLayout: "Ychwanegu Cynllun Grid",
    editGridLayout: "Golygu Cynllun Grid",
    addGridLayoutDetail: "Newid y cynllun wrth osod lledau colofnau ac ychwanegu adrannau ychwanegol",
    rowConfigurations: "Ffurfweddau rhes",
    rowConfigurationsDetail: "Mae rhesi yn gelloedd sydd wedi'u trefnu yn llorweddol",
    addRowConfiguration: "Ychwanegu Ffurfwedd rhes",
    editRowConfiguration: "Golygu Ffurfwedd rhes",
    addRowConfigurationDetail: "Newidiwch y rhes wrth osod lledau colofn ac ychwanegu adrannau ychwanegol",
    noConfiguration: "Nid oes ffurfwedd pellach ar gael",
    columns: "Colofnau",
    columnsDetails: "Cyfanswm y nifer o golofnau yn y cynllun grid",
    settings: "Gosodiadau",
    settingsDetails: "Ffurfweddu pa osodiadau gall olygyddion eu newid",
    styles: "Ardduliau",
    stylesDetails: "Ffurfweddu pa arddulliau gall olygyddion eu newid",
    allowAllEditors: "Caniatáu pob golygydd",
    allowAllRowConfigurations: "Caniatáu holl ffurfweddi rhes",
    maxItems: "Uchafswm o eitemau",
    maxItemsDescription: "Gadewch yn wag neu gosod i 0 ar gyfer diderfyn",
    setAsDefault: "Gosod fel diofyn",
    chooseExtra: "Dewis ychwanegol",
    chooseDefault: "Dewis diofyn",
    areAdded: "wedi'u hychwanegu",
    warning: "Rhybudd",
    youAreDeleting: "Rydych chi'n dileu'r ffurfwedd rhes",
    deletingARow: "Bydd dileu enw ffurfwedd rhes yn arwain at golli data ar gyfer unrhyw gynnwys cynfodol sy'n seiliedig ar ffurfwedd hwn.",
    deleteLayout: "Rydych chi'n dileu'r gosodiad",
    deletingALayout: "Bydd addasu cynllun yn arwain at golli data ar gyfer unrhyw gynnwys presennol sy'n seiliedig ar y ffurfweddiad hwn."
  },
  contentTypeEditor: {
    compositions: "Cyfansoddiadau",
    group: "Grŵp",
    groupReorderSameAliasError: `Ni allwch symud y grŵp %0% i'r tab hwn oherwydd bydd y grŵp yn cael yr un alias â thab: "%1%". Ail-enwi'r grŵp i barhau.`,
    noGroups: "Nid ydych wedi ychwanegu unrhyw grwpiau",
    addGroup: "Ychwanegu grŵp",
    inheritedFrom: "Wedi etifeddu o",
    addProperty: "Ychwanegu priodwedd",
    requiredLabel: "Label gofynnol",
    enableListViewHeading: "Caniatáu gwedd rhestr",
    enableListViewDescription: "Ffurfweddi yr eitem gynnwys i ddangos rhestr trefnadwy a chwiladwy o'i phlant, ni fydd y plant yn cael eu dangos yn y goeden",
    allowedTemplatesHeading: "Templedi Caniateir",
    allowedTemplatesDescription: "Dewiswch pa olygoddion templedi sy'n cael defnyddio cynnwys o'r fath yma",
    allowAsRootHeading: "Caniatáu fel gwraidd",
    allowAsRootDescription: "Caniatáu golygyddion i greu cynnwys o'r fath yma yng ngwraidd y goeden gynnwys",
    childNodesHeading: "Mathau o nod blentyn caniateir",
    childNodesDescription: "Caniatáu cynnwys o'r mathau benodol i gael eu creu o dan cynnwys o'r fath yma",
    chooseChildNode: "Dewis nod blentyn",
    compositionsDescription: "Etifeddu tabiau a phriodweddau o fath o ddogfen sy'n bodoli eisoes. Bydd tabiau newydd yn cael eu ychwanegu at y fath o ddogfen bresennol neu eu cyfuno os mae tab gyda enw yr union yr un fath yn bodoli eisoes.",
    compositionInUse: "Mae'r math o gynnwys yma wedi'i ddefnyddio mewn cyfansoddiad, felly ni ellir ei gyfansoddi ei hunan.",
    noAvailableCompositions: "Nid oes unrhyw fathau o gynnwys ar gael i'w defnyddio fel cyfansoddiad.",
    compositionRemoveWarning: "Bydd dileu cyfansoddiad yn dileu'r holl ddata eiddo priodwedd gysylltiedig. Ar ôl i chi arbed y math o ddogfen, bydd ddim ffordd nôl.",
    availableEditors: "Golygyddion ar gael",
    reuse: "Ail-ddefnyddio",
    editorSettings: "Gosodiadau golygydd",
    searchResultSettings: "Ffurfweddau sydd ar gael",
    searchResultEditors: "Creu ffurfwedd newydd",
    configuration: "Ffurfwedd",
    yesDelete: "Iawn, dileu",
    movedUnderneath: "wedi symud islaw",
    copiedUnderneath: "wedi copïo islaw",
    folderToMove: "Dewiswch y ffolder i symud",
    folderToCopy: "Dewiswch y ffolder i gopïo",
    structureBelow: "i yn y strwythyr goeden isod",
    allDocumentTypes: "Holl Fathau o Ddogfennau",
    allDocuments: "Holl Ddogfennau",
    allMediaItems: "Holl eitemau gyfrwng",
    usingThisDocument: "sy'n defnyddio'r fath o ddogfen yma fydd yn cael eu dileu yn barhaol, cadarnhewch os hoffwch ddileu'r rhain hefyd.",
    usingThisMedia: "sy'n defnyddio'r fath o gyfrwng yma fydd yn cael eu dileu yn barhaol, cadarnhewch os hoffwch ddileu'r rhain hefyd.",
    usingThisMember: "sy'n defnyddio'r fath o aelod yma fydd yn cael eu dileu yn barhaol, cadarnhewch os hoffwch ddileu'r rhain hefyd.",
    andAllDocuments: "a phob dogfen sy'n defnyddio'r fath yma",
    andAllMediaItems: "a phob eitem gyfrwng sy'n defnyddio'r fath yma",
    andAllMembers: "a phob aelod sy'n defnyddio'r fath yma",
    memberCanEdit: "Aeloed yn gallu golygu",
    memberCanEditDescription: "Caniatáu i'r gwerth briodwedd yma gael ei olygu gan yr aelod ar eu tudalen broffil",
    isSensitiveData: "Yn ddata sensitif",
    isSensitiveDataDescription: "Cuddio'r priodwedd yma o'r golygyddion cynnwys sydd heb hawliau i weld gwybodaeth sensitif",
    showOnMemberProfile: "Dangos ar broffil aelod",
    showOnMemberProfileDescription: "Caniatáu i'r gwerth briodwedd yma gael ei ddangos ar y dudalen broffil aelod",
    tabHasNoSortOrder: "does dim rhif trefnu gan y tab",
    compositionUsageHeading: "Ble mae'r cyfansoddiad yma'n cael ei ddefnyddio?",
    compositionUsageSpecification: "Mae'r cyfansoddiad yma yn cael ei ddefnyddio'n bresennol yng nghyfansoddiad o'r mathau o gynnwys ganlynol:",
    variantsHeading: "Caniatáu amrywiadau",
    cultureVariantHeading: "Caniatáu amrywiad  yn ôl ddiwylliant",
    segmentVariantHeading: "Caniatáu segmentiad",
    cultureVariantLabel: "Amrywio gan ddiwylliant",
    segmentVariantLabel: "Amrywio gan segmentiad",
    variantsDescription: "Caniatáu i olygyddion greu cynnwys o'r math hwn mewn gwahanol ieithoedd",
    cultureVariantDescription: "Caniatáu golygyddion i greu cynnwys o ieithoedd gwahanol",
    segmentVariantDescription: "Caniatáu golygyddion i greu segmentiadau o'r cynnwys hwn",
    allowVaryByCulture: "Caniatáu amrywio yn ôl diwylliant",
    allowVaryBySegment: "Caniatáu segmentiad",
    elementType: "Math o elfen",
    elementHeading: "Yn fath Elfen",
    elementDescription: "Mae math Elfen i fod i gael ei ddefnyddio er enghraifft mewn Cynnwys Nythu, ac nid yn y goeden",
    elementCannotToggle: "Ni ellir newid math o ddogfen i fath Elfen ar ôl mae'n cael ei defnyddio i greu un neu fwy o eitemau cynnwys.",
    elementDoesNotSupport: "Nid yw hyn yn berthnasol ar gyfer math Elfen",
    propertyHasChanges: "Rydych wedi gwneud newidiadau i'r eiddo hwn. Ydych chi'n siŵr eich bod chi am eu taflu?",
    displaySettingsHeadline: "Ymddangosiad",
    displaySettingsLabelOnTop: "Label uwchben (lled-llawn)",
    confirmDeleteTabMessage: "?",
    confirmDeleteGroupMessage: "?",
    confirmDeletePropertyMessage: "?",
    confirmDeleteTabNotice: "Bydd hyn hefyd yn dileu'r holl eitemau o dan y tab hwn.",
    confirmDeleteGroupNotice: "Bydd hyn hefyd yn dileu'r holl eitemau o dan y grŵp hwn.",
    addTab: "Ychwanegu tab",
    convertToTab: "Trawsnewid i dab",
    tabDirectPropertiesDropZone: "Llusgwch eiddo yma i'w gosod yn syth ar y tab",
    removeChildNode: "Rydych chi'n cael gwared ar y nod plentyn",
    removeChildNodeWarning: "Bydd tynnu nod plentyn yn cyfyngu ar opsiynau'r golygydd i greu gwahanol fathau o gynnwys o dan nod.",
    usingEditor: "bydd defnyddio'r golygydd hwn yn cael ei ddiweddaru gyda'r gosodiadau newydd.",
    historyCleanupHeading: "Glanhau hanes",
    historyCleanupDescription: "Caniatáu diystyru'r gosodiadau glanhau hanes byd-eang.",
    historyCleanupKeepAllVersionsNewerThanDays: "Cadwch bob fersiwn yn fwy newydd na dyddiau",
    historyCleanupKeepLatestVersionPerDayForDays: "Cadwch y fersiwn diweddaraf y dydd am ddyddiau",
    historyCleanupPreventCleanup: "Atal glanhau",
    historyCleanupEnableCleanup: "Galluogi glanhau",
    historyCleanupGloballyDisabled: " Mae glanhau fersiynau cynnwys hanesyddol wedi'u hanalluogi'n fyd-eang. Ni fydd y gosodiadau hyn yn dod i rym cyn iddo gael ei alluogi.",
    changeDataTypeHelpText: "Mae newid math o ddata gyda gwerthoedd storio wedi'i analluogi. I ganiatáu hyn gallwch newid y gosodiad Umbraco:CMS:DataTypes:CanBeChanged yn appssettings.json."
  },
  webhooks: {
    addWebhook: "Creu bachyn gwe",
    addWebhookHeader: "Ychwanegu pennyn bachyn gwe",
    addDocumentType: "Ychwanegu Math o Ddogfen",
    addMediaType: "Ychwanegu Math o Gyfrwng",
    createHeader: "Creu pennawd",
    deliveries: "Danfoniadau",
    noHeaders: "Nid oes penawdau bachyn gwe wedi'u hychwanegu",
    noEventsFound: "Ni chanfuwyd unrhyw ddigwyddiadau.",
    enabled: "Wedi'i alluogi",
    events: "Digwyddiadau",
    event: "Digwyddiad",
    url: "Url",
    types: "Mathau",
    webhookKey: "Allwedd bachyn gwe",
    retryCount: "Cyfrif o Ailgeision",
    toggleDebug: "Togl modd dadfygio am ragor o wybodaeth.",
    statusNotOk: "Cod statws ddim yn OK",
    urlDescription: "Yr url i'w alw pan fydd y bachyn gwe yn cael ei sbarduno.",
    eventDescription: "Y digwyddiadau y dylid sbarduno'r bachyn gwe.",
    contentTypeDescription: "Sbardunwch y bachyn gwe am fath penodol o gynnwys yn unig.",
    enabledDescription: "A yw'r bachyn gwe wedi'i alluogi?",
    headersDescription: "Penawdau arferu i'w cynnwys yn y cais bachyn gwe.",
    contentType: "Math o Gynnwys",
    headers: "Penawdau",
    selectEventFirst: "Dewiswch ddigwyddiad yn gyntaf."
  },
  languages: {
    addLanguage: "Ychwanegu iaith",
    mandatoryLanguage: "Iath gorfodol",
    mandatoryLanguageHelp: "Rhaid llenwi eiddo ar yr iaith hon cyn y gellir cyhoeddi'r nod.",
    defaultLanguage: "Iaith diofyn",
    defaultLanguageHelp: "Gall wefan Umbraco ddim ond cael un iaith ddiofyn.",
    changingDefaultLanguageWarning: "Gall newid iaith ddiofyn arwain at golli cynnwys diofyn.",
    fallsbackToLabel: "Syrthio yn ôl i",
    noFallbackLanguageOption: "Dim iaith cwympo yn ôl",
    fallbackLanguageDescription: "Er mwyn caniatáu i gynnwys amlieithog ddisgyn yn ôl i iaith arall os nad yw'n bresennol yn yr iaith y gofynnwyd amdani, dewiswch hi yma.",
    fallbackLanguage: "Iaith cwympo yn ôl",
    none: "dim",
    culture: "Cod ISO",
    invariantPropertyUnlockHelp: " yn cael ei rannu ar draws ieithoedd a segmentau.",
    invariantCulturePropertyUnlockHelp: " yn cael ei rannu ar draws pob iaith.",
    invariantSegmentPropertyUnlockHelp: " yn cael ei rannu ar draws pob segment.",
    invariantLanguageProperty: "Wedi'i rannu: Ieithoedd",
    invariantSegmentProperty: "Wedi'i rannu: Segments"
  },
  macro: {
    addParameter: "Ychwanegu paramedr",
    editParameter: "Golygu paramedr",
    enterMacroName: "Rhowch enw macro",
    parameters: "Paramedrau",
    parametersDescription: "Diffiniwch y paramedrau a ddylai fod ar gael wrth ddefnyddio'r macro hwn.",
    selectViewFile: "Dewiswch ffeil macro golwg rhannol"
  },
  modelsBuilder: {
    buildingModels: "Adeiladu modelau",
    waitingMessage: "gall hyn gymryd amser, peidiwch â phoeni",
    modelsGenerated: "Modelau wedi'u generadu",
    modelsGeneratedError: "Methwyd generadu modelau",
    modelsExceptionInUlog: "Methwyd generadu modelau, gweler yr eithriadau yn y log Umbraco"
  },
  templateEditor: {
    addDefaultValue: "Ychwanegu gwerth diofyn",
    defaultValue: "Gwerth diofyn",
    alternativeField: "Maes rolio yn ôl",
    alternativeText: "Gwerth diofyn",
    casing: "Cyflwr",
    encoding: "Amgodiad",
    chooseField: "Dewis maes",
    convertLineBreaks: "Trawsnewid torriadau llinellau",
    convertLineBreaksHelp: "Cyfnewid torriadau llinellau gyda tag html 'br'",
    customFields: "Meysydd bersonol",
    dateOnly: "Dyddiad yn unig",
    formatAsDate: "Fformatio ar ffurf dyddiad",
    htmlEncode: "Amgodi HTML",
    htmlEncodeHelp: "Bydd yn cyfnewid nodau arbennig gyda'u nodau HTML cyfatebol.",
    insertedAfter: "Bydd yn cael ei fewnosod ar ôl y gwerth maes",
    insertedBefore: "Bydd yn cael ei fewnosod cyn y gwerth maes",
    lowercase: "Llythrennau bach",
    none: "Dim",
    outputSample: "Sampl allbwn",
    postContent: "Mewnosod ar ôl maes",
    preContent: "Mewnosod cyn maes",
    recursive: "Ailadroddus",
    recursiveDescr: "Iawn, gwnewch yn ailadroddus",
    standardFields: "Meysydd Safonol",
    uppercase: "Llythrennau bras",
    urlEncode: "Amgodi URL",
    urlEncodeHelp: "Bydd yn fformatio nodau arbennig o fewn URL",
    usedIfAllEmpty: "Bydd ddim ond yn cael ei ddefnyddio pan mae'r gwerthoedd maes uchod yn wag",
    usedIfEmpty: "Bydd y maes yma ddim ond yn cael ei ddefnyddio os mae'r maes gynradd yn wag",
    withTime: "Dyddiad ac amser"
  },
  translation: {
    details: "Manylion cyfieithiad",
    DownloadXmlDTD: "Lawrlwytho XML DTD",
    fields: "Meysydd",
    includeSubpages: "Cynnwys is-dudalennau",
    mailBody: `
      Helo %0%

      mae hyn yn ebost awtomatig i'ch hysbysu fod y ddogfen '%1%'
      wedi'i hanfon am gyfieithiad i mewn i '%5%' gan %2%.

      Ewch at http://%3%/translation/details.aspx?id=%4% i olygu.

      Neu mewngofnodwch i Umbraco i gael trosolwg o'ch tasgau cyfieithu
      http://%3%

      Mwynhewch eich diwrnod!

      Hwyl fawr oddi wrth y robot Umbraco
    `,
    noTranslators: "Dim defnyddwyr cyfieithu wedi'u darganfod. Creuwch ddefnyddiwr cyfieithu cyn i chi gychwyn anfon cynnwys am gyfieithiadau",
    pageHasBeenSendToTranslation: "Mae'r dudalen '%0%' wedi cael ei anfon am gyfieithiad",
    sendToTranslate: "Anfon y dudalen '%0%' am gyfieithiad",
    totalWords: "Cyfanswm o eiriau",
    translateTo: "Cyfieithu i",
    translationDone: "Cyfieithiad wedi'i gwblhau.",
    translationDoneHelp: "Gallwch ragolygu'r tudalennau yr ydych newydd gyfieithu gan glicio isod. Os mae'r dudalen gwreiddiol wedi'i ganfod, byddwch yn cael cymhariaeth o'r 2 dudalen.",
    translationFailed: "Cyfieithiad wedi methu, mae'n bosib fod y ffeil XML wedi llygru",
    translationOptions: "Dewisiadau cyfieithu",
    translator: "Cyfieithydd",
    uploadTranslationXml: "Lanlwytho cyfieithiad XML"
  },
  treeHeaders: {
    content: "Cynnwys",
    contentBlueprints: "Templedi Cynnwys",
    media: "Cyfrwng",
    cacheBrowser: "Porwr Storfa",
    contentRecycleBin: "Bin Ailgylchu",
    createdPackages: "Pecynnau wedi'u creu",
    dataTypes: "Mathau o Ddata",
    dictionary: "Geiriadur",
    installedPackages: "Pecynnau wedi'u gosod",
    installSkin: "Gosod croen",
    installStarterKit: "Gosod cit gychwynol",
    languages: "Ieithoedd",
    localPackage: "Gosod pecyn leol",
    macros: "Macros",
    mediaTypes: "Mathau o Gyfrwng",
    member: "Aelodau",
    memberGroups: "Grwpiau Aelodau",
    memberRoles: "Grwpiau Rolau",
    memberTypes: "Mathau o Aelod",
    documentTypes: "Mathau o Ddogfen",
    relationTypes: "Math o Berthynas",
    packager: "Pecynnydd",
    packages: "Pecynnau",
    partialViews: "Rhan-weddi",
    partialViewMacros: "Ffeiliau Rhan-wedd Macro",
    repositories: "Gosod o ystorfa",
    runway: "Gosod Runway",
    runwayModules: "Modylau Runway",
    scripting: "Ffeiliau Sgriptio",
    scripts: "Sgriptiau",
    stylesheets: "Taflenni arddull",
    templates: "Templedi",
    logViewer: "Gwyliwr Log",
    users: "Defnyddwyr",
    settingsGroup: "Gosodiadau",
    templatingGroup: "Templedi",
    thirdPartyGroup: "Trydydd parti",
    webhooks: "Bachau gwe"
  },
  update: {
    updateAvailable: "Diweddariad newydd yn barod",
    updateDownloadText: "%0% yn barod, cliciwch yma i lawrlwytho",
    updateNoServer: "Dim cysylltiad at y gweinydd",
    updateNoServerError: "Gwall yn chwilio am ddiweddariad. Ceisiwch wirio'r trywydd stac am fwy o wybodaeth"
  },
  user: {
    access: "Mynediad",
    accessHelp: "Ar sail y grwpiau aelodaeth ac y nodau cychwyn, mae gan y defnyddiwr hawliau at y nodau ganlynol",
    assignAccess: "Neilltuo hawl",
    administrators: "Gweinyddwr",
    categoryField: "Maes categori",
    createDate: "Defnyddiwr wedi'i greu",
    changePassword: "Newidiwch Eich Cyfrinair",
    changePhoto: "Newidiwch lun",
    newPassword: "Cyfrinair newydd",
    newPasswordFormatLengthTip: "O leiaf %0% nod(au) i fynd!",
    newPasswordFormatNonAlphaTip: "Dylai fod o leiaf %0% nod(au) arbennig yno.",
    noLockouts: "ddim wedi cloi allan",
    noPasswordChange: "Nid yw'r cyfrinair wedi'i newid",
    confirmNewPassword: "Cadarnhau cyfrinair newydd",
    changePasswordDescription: "Gallwch newid eich cyfrinair i gyrchu Swyddfa Gefn Umbracogan lenwi allan y ffurflen isod a chlicio'r botwm 'Newid Cyfrinair'",
    contentChannel: "Sianel Gynnwys",
    createAnotherUser: "Creu defnyddiwr arall",
    createUserHelp: "Creu defnyddwyr newydd i roi hawliau iddynt gyrchu Umbraco. Pan mae defnyddiwr newydd yn cael ei greu, bydd cyfrinair yn cael ei generadu y gallwch chi rannu gyda'r defnyddiwr.",
    descriptionField: "Maes disgrifiad",
    disabled: "Analluogi Defnyddiwr",
    documentType: "Math o Ddogfen",
    editors: "Golygydd",
    excerptField: "Maes dyfyniad",
    failedPasswordAttempts: "Nifer o fethiannau ceisio mewngofnodi",
    goToProfile: "Ewch at broffil defnyddiwr",
    groupsHelp: "Ychwanegu grwpiau i neilltuo mynediad a hawliau",
    inviteAnotherUser: "Gwahodd defnyddiwr arall",
    inviteUserHelp: "Gwahodd defnyddwyr newydd i roi hawliau iddynt gyrchu Umbraco. Bydd gwahoddiad ebost yn cael ei anfon at y defnyddiwr gyda gwybodaeth ar sut i fewngofnodi i Umbraco. Mae gwahoddiadau yn para am 72 awr.",
    language: "Iaith",
    languageHelp: "Gosod yr iaith fyddwch chi'n gweld yn y dewislenni a'r deialogau",
    lastLockoutDate: "Dyddiad cloi allan diweddaraf",
    lastLogin: "Mewngofnodi diweddaraf",
    lastPasswordChangeDate: "Cyfrinair wedi'i newid ddiwethaf",
    loginname: "Enw defnyddiwr",
    mediastartnode: "Nod gychwynol gyfrwng",
    mediastartnodehelp: "Cyfyngu'r llyfrgell gyfrwng at nod gychwynol benodol",
    mediastartnodes: "Nodau gychwynol gyfrwng",
    mediastartnodeshelp: "Cyfyngu'r llyfrgell gyfrwng at nodau gychwynol benodol",
    modules: "Adrannau",
    noConsole: "Analluogi Mynediad Umbraco",
    noLogin: "ddim wedi mewngofnodi eto",
    oldPassword: "Hen gyfrinair",
    password: "Cyfrinair",
    resetPassword: "Ailosod cyfrinair",
    passwordChanged: "Mae eich cyfrinair wedi'i newid!",
    passwordChangedGeneric: "Cyfrinair wedi'i newid",
    passwordConfirm: "Cadarnhewch y cyfrinair newydd",
    passwordEnterNew: "Darparwch eich cyfrinair newydd",
    passwordIsBlank: "Ni all eich cyfrinair newydd fod yn wag!",
    passwordCurrent: "Cyfrinair bresennol",
    passwordInvalid: "Cyfrinair bresennol annilys",
    passwordIsDifferent: "Roedd gwahaniaeth rhwng y cyfrinair newydd ac y cyfrinair i gadarnhau. Ceisiwch eto!",
    passwordMismatch: "Nid yw'r cyfrinair cadarnhau yn cyfateb â'r cyfrinair newydd!",
    permissionReplaceChildren: "Cyfnewid hawliau nod blentyn",
    permissionSelectedPages: "Rydych ar hyn o bryd yn newid hawliau ar gyfer y tudalennau:",
    permissionSelectPages: "Dewis tudalennau i newid eu hawliau",
    removePhoto: "Dileu llun",
    permissionsDefault: "Hawliau diofyn",
    permissionsGranular: "Hawliau gronynnog",
    permissionsGranularHelp: "Gosod hawliau ar gyfer nodau penodol",
    profile: "Proffil",
    searchAllChildren: "Chwilio holl blant",
    sectionsHelp: "Ychwanegu adrannau i roi hawliau i ddefnyddwyr",
    selectUserGroups: "Dewis grwpiau defnyddwir",
    noStartNode: "Dim nod gychwynol wedi'i ddewis",
    noStartNodes: "Dim nodau cychwynol wedi'u dewis",
    startnode: "Nod gynnwys gychwynol",
    startnodehelp: "Cyfyngu'r goeden gynnwys i nod gychwynol benodol",
    startnodes: "Nodau cynnwys gychwynol",
    startnodeshelp: "Cyfyngu'r goeden gynnwys i nodau gychwynol benodol",
    updateDate: "Defnyddiwr wedi diweddaru ddiwethaf",
    userCreated: "wedi ei greu",
    userCreatedSuccessHelp: "Mae'r defnyddiwr newydd wedi'i greu. Er mwyn mewngofnodi i Umbraco defnyddiwch y cyfrinair isod.",
    userManagement: "Rheoli defnyddwyr",
    username: "Enw",
    userPermissions: "Hawliau defnyddiwr",
    usergroup: "Grŵp defnyddiwr",
    userInvited: "wedi'i wahodd",
    userInvitedSuccessHelp: "Mae gwahoddiad wedi cael ei anfon at y defnyddiwr newydd gyda manylion ar sut i fewngofnodi i Umbraco.",
    userinviteWelcomeMessage: "Helo a chroeso i Umbraco! Mewn 1 munud yn unig, byddech chi'n barod i fynd, rydym dim ond angen gosod cyfrinair.",
    userinviteExpiredMessage: "Croeso i Umbraco! Yn anffodus, mae eich gwahoddiad wedi terfynu. Cysylltwch â'ch gweinyddwr a gofynnwch iddynt ail-anfon.",
    writer: "Ysgrifennydd",
    change: "Newid",
    yourProfile: "Eich proffil",
    yourHistory: "Eich hanes diweddar",
    sessionExpires: "Sesiwn yn terfynu mewn",
    inviteUser: "Gwahodd defnyddiwr",
    createUser: "Creu defnyddiwr",
    sendInvite: "Anfon gwahoddiad",
    backToUsers: "Yn ôl at ddefnyddwyr",
    inviteEmailCopySubject: "Umbraco: Gwahoddiad",
    inviteEmailCopyFormat: `
        <html>
			<head>
				<meta name='viewport' content='width=device-width'>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
			</head>
			<body class='' style='font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; color: #392F54; line-height: 22px; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background: #1d1333; margin: 0; padding: 0;' bgcolor='#1d1333'>
				<style type='text/css'> @media only screen and (max-width: 620px) {table[class=body] h1 {font-size: 28px !important; margin-bottom: 10px !important; } table[class=body] .wrapper {padding: 32px !important; } table[class=body] .article {padding: 32px !important; } table[class=body] .content {padding: 24px !important; } table[class=body] .container {padding: 0 !important; width: 100% !important; } table[class=body] .main {border-left-width: 0 !important; border-radius: 0 !important; border-right-width: 0 !important; } table[class=body] .btn table {width: 100% !important; } table[class=body] .btn a {width: 100% !important; } table[class=body] .img-responsive {height: auto !important; max-width: 100% !important; width: auto !important; } } .btn-primary table td:hover {background-color: #34495e !important; } .btn-primary a:hover {background-color: #34495e !important; border-color: #34495e !important; } .btn  a:visited {color:#FFFFFF;} </style>
				<table border="0" cellpadding="0" cellspacing="0" class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;" bgcolor="#1d1333">
					<tr>
						<td style="font-family: sans-serif; font-size: 14px; vertical-align: top; padding: 24px;" valign="top">
							<table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;">
								<tr>
									<td background="https://umbraco.com/umbraco/assets/img/application/logo.png" bgcolor="#1d1333" width="28" height="28" valign="top" style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
										<!--[if gte mso 9]> <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:30px;height:30px;"> <v:fill type="tile" src="https://umbraco.com/umbraco/assets/img/application/logo.png" color="#1d1333" /> <v:textbox inset="0,0,0,0"> <![endif]-->
										<div> </div>
										<!--[if gte mso 9]> </v:textbox> </v:rect> <![endif]-->
									</td>
									<td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top"></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;' bgcolor='#1d1333'>
					<tr>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
						<td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 560px; width: 560px; margin: 0 auto; padding: 10px;' valign='top'>
							<div class='content' style='box-sizing: border-box; display: block; max-width: 560px; margin: 0 auto; padding: 10px;'>
								<br>
								<table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; border-radius: 3px; background: #FFFFFF;' bgcolor='#FFFFFF'>
									<tr>
										<td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 50px;' valign='top'>
											<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
												<tr>
													<td style='line-height: 24px; font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'>
														<h1 style='color: #392F54; font-family: sans-serif; font-weight: bold; line-height: 1.4; font-size: 24px; text-align: left; text-transform: capitalize; margin: 0 0 30px;' align='left'>
															Helo %0%,
														</h1>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Rydych wedi cael eich gwahodd gan <a href="mailto:%4%" style="text-decoration: underline; color: #392F54; -ms-word-break: break-all; word-break: break-all;">%1%</a> i'r Swyddfa Gefn Umbraco.
														</p>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Neges oddi wrth <a href="mailto:%1%" style="text-decoration: none; color: #392F54; -ms-word-break: break-all; word-break: break-all;">%1%</a>:
															<br/>
															<em>%2%</em>
														</p>
														<table border='0' cellpadding='0' cellspacing='0' class='btn btn-primary' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; box-sizing: border-box;'>
															<tbody>
																<tr>
																	<td align='left' style='font-family: sans-serif; font-size: 14px; vertical-align: top; padding-bottom: 15px;' valign='top'>
																		<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
																			<tbody>
																				<tr>
																					<td style='font-family: sans-serif; font-size: 14px; vertical-align: top; border-radius: 5px; text-align: center; background: #35C786;' align='center' bgcolor='#35C786' valign='top'>
																						<a href='%3%' target='_blank' rel='noopener' style='color: #FFFFFF; text-decoration: none; -ms-word-break: break-all; word-break: break-all; border-radius: 5px; box-sizing: border-box; cursor: pointer; display: inline-block; font-size: 14px; font-weight: bold; text-transform: capitalize; background: #35C786; margin: 0; padding: 12px 30px; border: 1px solid #35c786;'>
																							Cliciwch y ddolen yma i dderbyn y gwahoddiad
																						</a>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
															</tbody>
														</table>
														<p style='max-width: 400px; display: block; color: #392F54; font-family: sans-serif; font-size: 14px; line-height: 20px; font-weight: normal; margin: 15px 0;'>Os na allwch chi glicio ar y ddolen, copiwch a gludwch y URL i mewn i'ch porwr:</p>
															<table border='0' cellpadding='0' cellspacing='0'>
																<tr>
																	<td style='-ms-word-break: break-all; word-break: break-all; font-family: sans-serif; font-size: 11px; line-height:14px;'>
																		<font style="-ms-word-break: break-all; word-break: break-all; font-size: 11px; line-height:14px;">
																			<a style='-ms-word-break: break-all; word-break: break-all; color: #392F54; text-decoration: underline; font-size: 11px; line-height:15px;' href='%3%'>%3%</a>
																		</font>
																	</td>
																</tr>
															</table>
														</p>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
								<br><br><br>
							</div>
						</td>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
					</tr>
				</table>
			</body>
    </html>`,
    defaultInvitationMessage: "Yn ail-anfon y gwahoddiad...",
    deleteUser: "Dileu Defnyddiwr",
    deleteUserConfirmation: "Ydych chi'n sicr eich bod eisiau dileu'r cyfrif defnyddiwr yma?",
    stateAll: "Pob",
    stateActive: "Gweithredol",
    stateDisabled: "Wedi analluogi",
    stateLockedOut: "Wedi cloi allan",
    stateInvited: "Wedi gwahodd",
    stateInactive: "Anactif",
    sortNameAscending: "Enw (A-Y)",
    sortNameDescending: "Enw (Y-A)",
    sortCreateDateAscending: "Hynaf",
    sortCreateDateDescending: "Diweddaraf",
    sortLastLoginDateDescending: "Mewngofnodi diweddaraf",
    noUserGroupsAdded: "No user groups have been added",
    duplicateLogin: "Mae defnyddiwr gyda'r mewngofnodi hwn eisoes yn bodoli",
    passwordRequiresDigit: "Rhaid bod gan y cyfrinair o leiaf un digid ('0'-'9')",
    passwordRequiresLower: "Rhaid bod gan y cyfrinair o leiaf un llythrennau bach ('a'-'z')",
    passwordRequiresNonAlphanumeric: "Rhaid i'r cyfrinair gynnwys o leiaf un nod nad yw'n alffaniwmerig",
    passwordRequiresUniqueChars: "Rhaid i'r cyfrinair ddefnyddio o leiaf %0% o nodau gwahanol",
    passwordRequiresUpper: "Rhaid bod gan y cyfrinair o leiaf un priflythrennau ('A'-'Z')",
    passwordTooShort: "Rhaid i'r cyfrinair fod o leiaf %0% nod",
    languagesHelp: "Cyfyngu ar yr ieithoedd y mae gan ddefnyddwyr fynediad i olygu",
    allowAccessToAllLanguages: "Caniatáu mynediad i bob iaith",
    userHasPassword: "Mae gan y defnyddiwr set cyfrinair yn barod",
    userHasGroup: "Mae'r defnyddiwr yn y grŵp '%0%' yn barod ",
    userLockoutNotEnabled: "Nid yw cloi allan wedi'i alluogi ar gyfer y defnyddiwr hwn",
    userNotInGroup: "Nid yw'r defnyddiwr yn y grŵp '%0%'",
    configureTwoFactor: "Ffurfweddu Dau-Ffactor",
    stateApproved: "Cymeradwy",
    "2faDisableText": "Os ydych chi am analluogi'r darparwr dau ffactor hwn, yna rhaid i chi nodi'r cod a ddangosir ar eich dyfais ddilysu:",
    "2faProviderIsEnabled": "Mae'r darparwr dau ffactor hwn wedi'i alluogi",
    "2faProviderIsDisabledMsg": "Mae'r darparwr dau-ffactor hwn bellach wedi'i analluogi",
    "2faProviderIsNotDisabledMsg": "Aeth rhywbeth o'i le wrth geisio analluogi'r darparwr dau ffactor hwn",
    "2faDisableForUser": "Ydych chi am analluogi'r darparwr dau ffactor hwn ar gyfer y defnyddiwr hwn?",
    emailRequired: "Angenrheidiol - rhowch gyfeiriad e-bost ar gyfer y defnyddiwr hwn",
    nameRequired: "Angenrheidiol - rhowch enw ar gyfer y defnyddiwr hwn"
  },
  validation: {
    validation: "Dilysiad",
    validateAsEmail: "Dilysu fel cyfeiriad ebost",
    validateAsNumber: "Dilysu fel rhif",
    validateAsUrl: "Dilysu fel URL",
    enterCustomValidation: "...neu darparwch ddilysiad bersonol",
    fieldIsMandatory: "Maes yn ofynnol",
    mandatoryMessage: "Darparwch neges gwall dilysiad arferu (opsiynol)",
    validationRegExp: "Darparwch fynegiad rheoliadd",
    validationRegExpMessage: "Darparwch neges gwall dilysiad arferu (opsiynol)",
    minCount: "Mae angen i chi ychwanegu o leiaf",
    maxCount: "gallwch ddim ond gael",
    addUpTo: "Adio lan i",
    items: "o eitemau",
    urls: "url(s)",
    urlsSelected: "url(s) wedi'i ddewis",
    itemsSelected: "o eitemau wedi'u dewis",
    invalidDate: "Dyddiad annilys",
    invalidNumber: "Ddim yn rif",
    invalidNumberStepSize: "Ddim yn faint cam dilys",
    invalidEmail: "Ebost annilys",
    invalidNull: "Ni all y gwerth fod yn null",
    invalidEmpty: "Ni all y gwerth fod yn gwag",
    invalidPattern: "Mae'r gwerth yn annilys, nid yw'n cyfateb i'r patrwm cywir",
    customValidation: "Dilysiad arferu",
    entriesShort: "Lleiafswm o %0% gofnodion, angen <strong>%1%</strong> mwy.",
    entriesExceed: "Uchafswm o %0% gofnodion, <strong>%1%</strong> gormod.",
    invalidMemberGroupName: "Enw grŵp aelod annilys",
    invalidUserGroupName: "Enw grŵp defnyddiwr annilys",
    invalidToken: "Tocyn annilys",
    invalidUsername: "Enw defnyddiwr annilys",
    duplicateEmail: "Mae e-bost '%0%' wedi'i gymryd yn barod",
    duplicateUserGroupName: "Mae enw grŵp defnyddiwr '%0%' wedi'i gymryd yn barod",
    duplicateMemberGroupName: "Mae enw grŵp aelod '%0%' wedi'i gymryd yn barod",
    duplicateUsername: "Mae'r enw defnyddiwr '%0%' wedi'i gymryd yn barod",
    entriesAreasMismatch: "Nid yw'r gofynion maint cynnwys yn cael eu bodloni ar gyfer un maes neu fwy."
  },
  healthcheck: {
    checkSuccessMessage: "Gwerth wedi'i osod at y gwerth argymhellwyd: '%0%'.",
    checkErrorMessageDifferentExpectedValue: "Yn disgwyl y gwerth '%1%' ar gyfer '%2%' yn y ffeil ffurfweddu '%3%', ond darganfyddwyd '%0%'.",
    checkErrorMessageUnexpectedValue: "Darganfyddwyd gwerth annisgwyl '%0%' ar gyfer '%2%' yn y ffeil ffurfweddu '%3%'.",
    macroErrorModeCheckSuccessMessage: "Gwallau Macro wedi gosod at '%0%'.",
    macroErrorModeCheckErrorMessage: "Gwallau Macro wedi gosod at '%0%' a fydd yn atal rhai neu holl dudalennau yn eich safle rhag llwytho'n gyfan gwbl os oes unrhyw wallau o fewn macros. Bydd cywiro hyn yn gosod y gwerth at '%1%'.",
    httpsCheckValidCertificate: "Mae tystysgrif eich gwefan yn ddilys.",
    httpsCheckInvalidCertificate: "Gwall dilysu tystysgrif: '%0%'",
    httpsCheckExpiredCertificate: "Mae tystysgrif SSL eich gwefan wedi terfynu.",
    httpsCheckExpiringCertificate: "Mae tystysgrif SSL eich gwefan am derfynu mewn %0% diwrnod.",
    healthCheckInvalidUrl: "Gwall yn pingio'r URL %0% - '%1%'",
    httpsCheckIsCurrentSchemeHttps: "Rydych yn bresennol %0% yn gweld y wefan yn defnyddio'r cynllun HTTPS.",
    compilationDebugCheckSuccessMessage: "Modd casgliad dadfygio wedi'i analluogi.",
    compilationDebugCheckErrorMessage: "Modd casgliad dadfygio wedi'i alluogi. Argymhellwyd analluogi'r gosodiad yma cyn mynd yn fyw.",
    clickJackingCheckHeaderFound: "Mae'r peniad neu meta-tag <strong>X-Frame-Options</strong> sy'n cael ei ddefnyddio i reoli os mae safle'n gallu cael ei osod o fewn IFRAME gan safle arall wedi'i ganfod.",
    clickJackingCheckHeaderNotFound: "Nid yw'r peniad neu meta-tag <strong>X-Frame-Options</strong> sy'n cael ei ddefnyddio i reoli os mae safle'n gallu cael ei osod o fewn IFRAME gan safle arall wedi'i ganfod.",
    noSniffCheckHeaderFound: "Mae'r peniad neu meta-tag <strong>X-Content-Type-Options</strong> sy'n cael ei ddefnyddio i amddiffyn yn erbyn gwendidau sniffio MIME wedi'i ganfod.",
    noSniffCheckHeaderNotFound: "Nid yw'r peniad neu meta-tag <strong>X-Content-Type-Options</strong> sy'n cael ei ddefnyddio i amddiffyn yn erbyn gwendidau sniffio MIME wedi'i ganfod.",
    hSTSCheckHeaderFound: "Mae'r peniad <strong>Strict-Transport-Security</strong>, hefyd wedi'i adnabod fel HSTS-header, wedi'i ganfod.",
    hSTSCheckHeaderNotFound: "Nid yw'r peniad <strong>Strict-Transport-Security</strong> wedi'i ganfod.",
    hSTSCheckHeaderFoundOnLocalhost: "Darganfuwyd y pennyn <strong>Strict-Transport-Security</strong>, a elwir hefyd yn HSTS-header. <strong>Ni ddylai'r pennyn hwn fod yn bresennol ar localhost.</strong>",
    hSTSCheckHeaderNotFoundOnLocalhost: "Ni ddaethpwyd o hyd i'r pennyn <strong>Strict-Transport-Security</strong>. Ni ddylai'r pennyn hwn fod yn bresennol ar localhost.",
    xssProtectionCheckHeaderFound: "Mae'r peniad <strong>X-XSS-Protection</strong> wedi'i ganfod.",
    xssProtectionCheckHeaderNotFound: "Nid yw'r peniad <strong>X-XSS-Protection</strong> wedi'i ganfod.",
    excessiveHeadersFound: "Mae'r peniadau canlynol sy'n datgelu gwynodaeth am dechnoleg eich gwefan wedi'u canfod: <strong>%0%</strong>.",
    excessiveHeadersNotFound: "Dim peniadau sy'n datgelu gwynodaeth am dechnoleg eich gwefan wedi'u canfod.",
    smtpMailSettingsConnectionSuccess: "Gosodiadau SMTP wedi ffurfweddu'n gywir ac mae'r gwasanaeth yn gweithio fel y disgwylir.",
    notificationEmailsCheckSuccessMessage: "Ebost hysbusu wedi'i osod at <strong>%0%</strong>.",
    notificationEmailsCheckErrorMessage: "Ebost hysbusu yn dal wedi'i osod at y gwerth diofyn o <strong>%0%</strong>.",
    checkGroup: "Gwiriwch y grŵp",
    helpText: `
            <p>Mae'r gwiriwr iechyd yn gwerthuso gwahanol rannau o'ch gwefan ar gyfer gosodiadau arfer gorau, cyfluniad, problemau posibl, ac ati. Gallwch chi drwsio problemau yn hawdd trwy wasgu botwm.
            Gallwch chi ychwanegu eich gwiriadau iechyd eich hun, edrych ar <a href="https://docs.umbraco.com/umbraco-cms/extending/health-check" target="_blank" rel="noopener" class="btn-link -underline">y ddogfennaeth i gael mwy o wybodaeth</a> am wiriadau iechyd arferu.</p>
            `,
    httpsCheckConfigurationRectifyNotPossible: "Mae gosodiad ap 'Umbraco:CMS:Global:UseHttps' wedi'i osod i 'false' yn eich ffeil appSettings.json. Unwaith y byddwch yn cyrchu'r wefan hon gan ddefnyddio'r cynllun HTTPS, dylid gosod hwnnw i 'true'.",
    httpsCheckConfigurationCheckResult: "Mae'r gosodiad ap 'Umbraco:CMS:Global:UseHttps' wedi'i osod i '%0%' yn eich ffeil appSettings.json, mae eich cwcis %1% wedi'u marcio'n ddiogel.",
    umbracoApplicationUrlCheckResultTrue: ".",
    umbracoApplicationUrlCheckResultFalse: "Nid yw gosodiad ap 'Umbraco:CMS:WebRouting:UmbracoApplicationUrl' wedi'i osod.",
    smtpMailSettingsNotFound: "Nid oedd modd dod o hyd i'r ffurfweddiad 'Umbraco:CMS:Global:Smtp'.",
    smtpMailSettingsHostNotConfigured: "Nid oedd modd dod o hyd i'r ffurfweddiad 'Umbraco:CMS:Global:Smtp:Host'.",
    smtpMailSettingsConnectionFail: "Methwyd cyrraedd y gweinydd SMTP a ffurfweddwyd gyda gwesteiwr '%0%' a phorth '%1%'. Gwiriwch i sicrhau bod y gosodiadau SMTP yn y ffurfweddiad 'Umbraco:CMS:Global:Smtp' yn gywir."
  },
  redirectUrls: {
    disableUrlTracker: "Analluogi olinydd URL",
    enableUrlTracker: "Galluogi olinydd URL",
    culture: "Diwylliant",
    originalUrl: "URL gwreiddiol",
    redirectedTo: "Ailgyfeirwyd I",
    redirectUrlManagement: "Gweinyddu Ailgyfeirio URLs",
    panelInformation: "Mae'r URLs ganlynol yn ailgyfeirio at yr eitem gynnwys yma:",
    noRedirects: "Dim ailgyfeiriadau wedi'u gwneud",
    noRedirectsDescription: "Pan mae tudalen wedi'i gyhoeddi yn cael ei ailenwi neu symud bydd ailgyfeiriad yn cael ei greu yn awtomatig at y dudalen newydd.",
    redirectRemoved: "URL ailgyfeirio wedi'i ddileu.",
    redirectRemoveError: "Gwall yn dileu'r URL.",
    redirectRemoveWarning: "Bydd hyn yn dileu'r ailgyfeiriad",
    confirmDisable: "Ydych chi'n sicr eich bod eisiau analluogi'r olinydd URL?",
    disabledConfirm: "Mae'r olinydd URL wedi cael ei analluogi.",
    disableError: "Gwall yn ystod analluogi'r olinydd URL, gall fwy o wybodaeth gael ei ddarganfod yn eich ffeil log.",
    enabledConfirm: "Mae'r olinydd URL wedi cael ei alluogi.",
    enableError: "Gwall yn ystod galluogi'r olinydd URL, gall fwy o wybodaeth gael ei ddarganfod yn eich ffeil log."
  },
  emptyStates: {
    emptyDictionaryTree: "Dim eitemau Geiriadur i ddewis ohonynt"
  },
  textbox: {
    characters_left: "o nodau ar ôl",
    characters_exceed: "Uchafswm o %0% nodau cyfrannol, <strong>%1%</strong> gormod."
  },
  recycleBin: {
    contentTrashed: "Wedi chwalu cynnwys gyda Id: {0} yn berthnasol i gynnwys rhiant gwreiddiol gyda Id: {1}",
    mediaTrashed: "Wedi chwalu cyfrwng gyda Id: {0} yn berthnasol i gyfrwng rhiant gwreiddiol gyda Id: {1}",
    itemCannotBeRestored: "Ni ellir adfer yr eitem yma yn awtomatig",
    itemCannotBeRestoredHelpText: "Nid oes unrhyw leoliad lle gellir adfer yr eitem hon yn awtomatig. Gallwch chi symud yr eitem â llaw gan ddefnyddio'r goeden isod.",
    wasRestored: "oedd adferwyd o dan"
  },
  relationType: {
    direction: "Cyfeiriad",
    parentToChild: "Rhiant i plentyn",
    bidirectional: "Deugyfeiriadol",
    parent: "Rhiant",
    child: "Plentyn",
    count: "Cyfrif",
    relations: "Cysylltiadau",
    created: "Creu",
    comment: "Sylw",
    name: "Enw",
    noRelations: "Dim cysylltiadau ar gyfer y math hwn o berthynas.",
    tabRelationType: "Math o Berthynas",
    tabRelations: "Cysylltiadau",
    relation: "Perthynas",
    isDependency: "A yw Dibyniaeth",
    dependency: "Ydw",
    noDependency: "Nac ydw"
  },
  dashboardTabs: {
    contentIntro: "Dechrau Arni",
    contentRedirectManager: "Rheolaeth Ailgyfeirio URL",
    mediaFolderBrowser: "Cynnwys",
    settingsWelcome: "Croeso",
    settingsExamine: "Rheolaeth Examine",
    settingsPublishedStatus: "Statws Cyhoeddedig",
    settingsModelsBuilder: "Adeiladwr Modelau",
    settingsHealthCheck: "Gwiriad Iechyd",
    settingsProfiler: "Proffilio",
    memberIntro: "Dechrau Arni",
    formsInstall: "Gosod Ffurflenni Umbraco",
    settingsAnalytics: "Data telemetreg"
  },
  visuallyHiddenTexts: {
    goBack: "Mynd yn ôl",
    activeListLayout: "Cynllun gweithredol:",
    jumpTo: "Neidio i",
    group: "grŵp",
    passed: "pasio",
    warning: "rhybudd",
    failed: "methu",
    suggestion: "awgrym",
    checkPassed: "Gwiriad wedi'i basio",
    checkFailed: "Gwiriad wedi'i methu",
    openBackofficeSearch: "Agor chwiliad swyddfa gefn",
    openCloseBackofficeHelp: "Agor/Cau cymorth swyddfa gefn",
    openCloseBackofficeProfileOptions: "Agor/Cau eich opsiynau proffil",
    assignDomainDescription: "Sefydli Diwylliannau ac Enwau Gwesteia am %0%",
    createDescription: "Creu nod newydd o dan %0%",
    protectDescription: "Sefydli Mynediad Cyhoeddus ar %0%",
    rightsDescription: "Sefydli Caniataid ar %0%",
    sortDescription: " Newid y trefniad am %0%",
    createblueprintDescription: "Creu templed cynnwys yn seiliedig ar %0%",
    openContextMenu: "Agor dewislen cyd-destun ar gyfer",
    currentLanguage: "Iaith gyfredol",
    switchLanguage: "Newid iaith i",
    createNewFolder: "Creu ffolder newydd",
    newPartialView: "Golwg Rhannol",
    newPartialViewMacro: "Macro Golwg Rhannol",
    newMember: "Aelod",
    newDataType: "Math o ddata",
    redirectDashboardSearchLabel: "Chwilio'r dangosfwrdd ailgyfeirio",
    userGroupSearchLabel: "Chwilio'r adran grŵp defnyddwyr",
    userSearchLabel: "Chwilio'r adran defnyddwyr",
    createItem: "Creu eitem",
    create: "Creu",
    edit: "Golygu",
    name: "Enw",
    addNewRow: "Ychwanegu rhes newydd",
    tabExpand: "Gweld mwy o opsiynau",
    searchOverlayTitle: "Chwilio'r swyddfa gefn Umbraco",
    searchOverlayDescription: "Chwilio am nodau gynnwys, nodau cyfryngau ayyb. ar draws y swyddfa gefn.",
    searchInputDescription: "Pryd mae canlyniadau awtocyflawni ar gael, gwasgwch y saethau lan a lawr, neu ddefnyddio'r fysell tab ac y fysell enter i ddewis.",
    path: "Llwybr:",
    foundIn: "Wedi'i ddarganfod yn",
    hasTranslation: "Wedi cyfieithu",
    noTranslation: "Cyfieithiad ar goll",
    dictionaryListCaption: "Eitemau geiriadur",
    contextMenuDescription: "Dewis un o'r opsiynau i olygu'r nod",
    contextDialogDescription: "Gwneud gweithred %0% ar y nod %1%",
    addImageCaption: "Ychwanegu capsiwn am y llun",
    searchContentTree: "Chwilio'r coeden cynnwys",
    maxAmount: "Uchafswm",
    expandChildItems: "Ehangu eitemau plentyn ar gyfer",
    openContextNode: "Agor nod cyd-destun ar gyfer"
  },
  references: {
    tabName: "Cyfeiriadau",
    DataTypeNoReferences: "This Data Type has no references. Nid oes gan y Math o Ddata hwn unrhyw gyferiadau.",
    labelUsedByDocumentTypes: "Defnyddir mewn Mathau o Ddogfennau",
    labelUsedByMediaTypes: "Defnyddir mewm Mathau o Gyfrwng",
    labelUsedByMemberTypes: "Defnyddir mewn Mathau o Aelod",
    usedByProperties: "Defnyddir gan",
    itemHasNoReferences: "Nid oes gan yr eitem hon unrhyw gyfeiriadau.",
    labelUsedByItems: "Cyfeirir ato gan yr eitemau canlynol",
    labelDependsOnThis: "Mae'r eitemau canlynol yn dibynnu ar hyn",
    labelUsedItems: "Cyfeirir at yr eitemau canlynol",
    labelUsedDescendants: "Mae gan yr eitemau disgynnol canlynol ddibyniaethau",
    labelDependentDescendants: "Mae gan yr eitemau disgynnol canlynol ddibyniaethau",
    deleteWarning: "Mae'r eitem hon neu ei disgynyddion yn cael ei chyfeirnodi. Gall dileu arwain at ddolenni wedi'u torri ar eich gwefan.",
    unpublishWarning: "Mae'r eitem hon neu ei disgynyddion yn cael ei chyfeirnodi. Gall dadgyhoeddi arwain at ddolenni wedi'u torri ar eich gwefan. Cymerwch y camau priodol.",
    deleteDisabledWarning: "Mae'r eitem hon neu ei disgynyddion yn cael ei chyfeirnodi. Felly, mae dileu wedi'i analluogi.",
    listViewDialogWarning: "Mae'r eitemau canlynol yr ydych yn ceisio eu %0% yn cael eu cyfeirio gan gynnwys arall."
  },
  logViewer: {
    deleteSavedSearch: "Dileu Chwiliad Cadwedig",
    logLevels: "Lefelau Log",
    selectAllLogLevelFilters: "Dewiswch y cyfan",
    deselectAllLogLevelFilters: "Dad-ddewiswch bawb",
    savedSearches: "Chwiliadau Cadwedig",
    saveSearch: "Arbed Chwiliad",
    saveSearchDescription: "Rhoi enw cyfeillgar am eich ymholiad chwilio",
    filterSearch: "Hidlo Chwiliad",
    totalItems: "Cyfanswm o Eitemau",
    timestamp: "Stamp Amser",
    level: "Lefel",
    machine: "Peiriant",
    message: "Neges",
    exception: "Eithriad",
    properties: "Priodweddau",
    searchWithGoogle: "Chwilio efo Google",
    searchThisMessageWithGoogle: "Chwiliwch y neges hon efo Google",
    searchWithBing: "Chwilio efo Bing",
    searchThisMessageWithBing: "Chwiliwch y neges hon efo Bing",
    searchOurUmbraco: "Chwilio Our Umbraco",
    searchThisMessageOnOurUmbracoForumsAndDocs: "Chwiliwch y neges hon arno Our Umbraco fforymau a dogfennau",
    searchOurUmbracoWithGoogle: "Chwilio Our Umbraco efo Google",
    searchOurUmbracoForumsUsingGoogle: "Chwilio Our Umbraco fforymau efo Google",
    searchUmbracoSource: "Chwilio'r cod gwreiddiol Umbraco",
    searchWithinUmbracoSourceCodeOnGithub: "Chwilio tu fewn y cod gwreiddiol Umbraco ar Github",
    searchUmbracoIssues: "Chwilio Problemau Umbraco",
    searchUmbracoIssuesOnGithub: "Chwilio Problemau Umbraco ar Github",
    deleteThisSearch: "Dileu chwiliad hon",
    findLogsWithRequestId: "Darganfod logiau efo ID y Cais",
    findLogsWithNamespace: "Darganfod logiau efo Namespace",
    findLogsWithMachineName: "Darganfod logiau efo Enw Peiriant",
    open: "Agor",
    polling: "Diweddaru",
    every2: "Pob 2 eiliad",
    every5: "Pob 5 eiliad",
    every10: "Pob 10 eiliad",
    every20: "Pob 20 eiliad",
    every30: "Pob 30 eiliad",
    pollingEvery2: "Diweddaru pob 2e",
    pollingEvery5: "Diweddaru pob 5e",
    pollingEvery10: "Diweddaru pob 10e",
    pollingEvery20: "Diweddaru pob 20e",
    pollingEvery30: "Diweddaru pob 30e"
  },
  clipboard: {
    labelForCopyAllEntries: "Copi %0%",
    labelForArrayOfItemsFrom: "%0% o %1%",
    labelForArrayOfItems: "Casgliad o %0%",
    labelForRemoveAllEntries: "Dileu pob eitem",
    labelForClearClipboard: "Clirio y clipfwrdd"
  },
  propertyActions: {
    tooltipForPropertyActionsMenu: "Agor Gweithredoedd Priodweddau",
    tooltipForPropertyActionsMenuClose: "Cau Gweithredoedd Priodweddau"
  },
  nuCache: {
    refreshStatus: "Adnewyddu statws",
    memoryCache: "Cuddstôr Cof",
    memoryCacheDescription: `
                Mae'r botwm hwn yn caniatáu ichi ail-lwytho'r cuddstôr mewn-cof, gan ail-lwytho fo o'r stôr cronfa ddata
                (ond nid yw'n ailadeiladu stôr cronfa ddata hwnna). Mae hyn yn gymharol o gyflym.
                Defnyddio fo pan ti'n feddwl nad yw'r stôr gof wedi'i hadnewyddu'n iawn, ar ôl i rai digwyddiad
                digwydd&mdash;a fyddai'n arwydd o broblem fach efo Umbraco.
                (nodyn: mae hyn yn achosi ail-lwytho ar pob gweinydd mewn amgylchedd LB).
        `,
    reload: "Ail-lwytho",
    databaseCache: "Cuddstôr Cronfa Ddata ",
    databaseCacheDescription: `
            Mae'r botwm hwn yn caniatáu ichi ailadeiladu'r cuddstôr cronfa ddata, h.y. y cynnwys o'r tabl cmsContentNu.
            <strong>Gall ailadeiladu fod yn ddrud.</strong>
            Defnyddio fo pan mae ail-lwytho ddim yn ddigon, a ti'n feddwl mai'r stôr cronfa ddata heb gael ei
            chynhyrchu'n iawn&mdash;a fyddai'n arwydd o broblem gritigol efo Umbraco.
        `,
    rebuild: "Ailadeiladu",
    internals: "Mewnol",
    internalsDescription: `
        Mae'r botwm hwn yn caniatáu ichi sbarduno casgliad cipluniau o NuCache (ar ôl rhedeg fullCLR GC)
        Oni bai chi'n gwybod beth mae hynny'n ei olygu, mae'n debyg <em>nad</em> oes angeni chi ei defnyddio.
        `,
    collect: "Casglu",
    publishedCacheStatus: "Statws Cuddstôr Cyhoeddedig",
    caches: "Cuddstorau"
  },
  profiling: {
    performanceProfiling: "Proffilio perfformiad",
    performanceProfilingDescription: `
                <p>
                    Mae Umbraco yn rhedeg mewn modd dadfygio. Mae hyn yn golygu y gallwch chi ddefnyddio'r proffiliwr perfformiad adeiledig i asesu'r perfformiad wrth rendro tudalennau.
                </p>
                <p>
                    OS ti eisiau actifadu'r proffiliwr am rendro tudalen penodol, bydd angen ychwanegu <strong>umbDebug=true</strong> i'r ymholiad wrth geisio am y tudalen
                </p>
                <p>
                    Os ydych chi am i'r proffiliwr gael ei actifadu yn ddiofyn am bob rendrad tudalen, gallwch chi ddefnyddio'r togl isod.
                    Bydd e'n gosod cwci yn eich porwr, sydd wedyn yn actifadu'r proffiliwr yn awtomatig.
                    Mewn geiriau eraill, bydd y proffiliwr dim ond yn actif yn ddiofyn yn eich porwr <em>chi</em> - nid porwr pawb eraill.
                </p>
        `,
    activateByDefault: "Actifadu y proffiliwr yn ddiofyn",
    reminder: "Nodyn atgoffa cyfeillgar",
    reminderDescription: `
            <p>
                Ni ddylech chi fyth adael i safle cynhyrchu redeg yn y modd dadfygio. Mae'r modd dadfygio yn gallu cael ei diffodd trwy ychwanegu'r gosodiad <strong>debug="false"</strong> ar yr elfen <strong>grynhoi</strong> yn web.config.
            </p>
        `,
    profilerEnabledDescription: `
            <p>
                Mae Umbraco ddim yn rhedeg mewn modd dadfygio ar hyn o bryd, felly nid allwch chi ddefnyddio'r proffiliwer adeiledig. Dyma sut y dylai fod ar gyfer safle cynhyrchu.
            </p>
            <p>
                Mae'r modd dadfygio yn gallu cael ei throi arno gan ychwanegu'r gosodiad <strong>debug="true"</strong> ar yr elfen <strong>grynhoi</strong> yn web.config.
            </p>
        `
  },
  settingsDashboardVideos: {
    trainingHeadline: "Oriau o fideos hyfforddiant Umbraco ddim ond un clic i fwrdd",
    trainingDescription: `
                <P>Eisiau meistroli Umbraco? Treuliwch gwpl o funudau yn dysgu rhai o'r arferion gorau gan wylio un o'r fideos hyn am sut i ddefnyddio Umbraco. Ac ymweld â <a href="http://umbraco.tv" target="_blank" rel="noopener">umbraco.tv</a> am fwy o fideos am Umbraco</p>
            `,
    getStarted: "I roi cychwyn i chi"
  },
  settingsDashboard: {
    start: "Dechrau yma",
    startDescription: "Mae'r adran hon yn cynnwys y blociau adeiladu am eich safle Umbraco. Dilyn y dolenni isod i ddarganfod fwy am weithio gyda'r eitemau yn yr adran Gosodiadau",
    more: "Ddarganfod fwy",
    bulletPointOne: `
            Darllenwch fwy am weithio efo'r eitemau yn yr adran Gosodiadau <a class="btn-link -underline" href="https://docs.umbraco.com/umbraco-cms/fundamentals/backoffice/sections/" target="_blank" rel="noopener">fewn yr adran Dogfennaeth</a> o Our Umbraco
        `,
    bulletPointTwo: `
            Gofynnwch gwestiwn yn y <a class="btn-link -underline" href="https://our.umbraco.com/forum" target="_blank" rel="noopener">Fforwm Cymunedol</a>
        `,
    bulletPointFour: `
            Darganfyddwch fwy am ein <a class="btn-link -underline" href="https://umbraco.com/products/" target="_blank" rel="noopener">hoffer hybu cynhyrchiant a chefnogaeth fasnachol</a>
        `,
    bulletPointFive: `
            Darganfyddwch fwy am gyfleoedd <a class="btn-link -underline" href="https://umbraco.com/training/" target="_blank" rel="noopener">hyfforddi ac ardystio</a>
        `,
    bulletPointTutorials: `
            Gwyliwch ein <a class="btn-link -underline" href="https://umbra.co/ulb" target="_blank" rel="noopener">fideos tiwtorial rhad ac am ddim ar Ganolfan Ddysgu Umbraco</a>
        `
  },
  startupDashboard: {
    fallbackHeadline: "Croeso i'r SRC cyfeillgar",
    fallbackDescription: "Diolch am ddewis Umbraco - rydyn ni'n credu y gallai hyn fod dechreuad i rywbeth prydferth. Er y gallai deilo'n llethol ar y dechrau, rydym wedi gwneud llawer i wneud y gromlin ddysgu mor llyfn a chyflym a phosib."
  },
  formsDashboard: {
    formsHeadline: "Ffurflenni Umbraco",
    formsDescription: "Creu ffurflenni gan ddefnyddio rhyngwyneb llusgo a gollwng sythweledol. O ffurflenni cyswllt syml sy'n anfon e-byst, i holiaduron mwy datblygedig sy'n integreiddio efo systemau CRM. Bydd eich cleientiaid wrth ei modd!"
  },
  blockEditor: {
    headlineCreateBlock: "Creu bloc newydd",
    headlineAddSettingsElementType: "Atodwch adran gosodiadau",
    headlineAddCustomView: "Dewis golygfa",
    headlineAddCustomStylesheet: "Dewis taflen arddull",
    headlineAddThumbnail: "Dewis delwedd bawd",
    labelcreateNewElementType: "Creu newydd",
    labelCustomStylesheet: "Taflen arddull arferu",
    addCustomStylesheet: "Ychwanegu taflen arddull",
    headlineEditorAppearance: "Ymddangosiad y golygydd",
    headlineDataModels: "Modelau data",
    headlineCatalogueAppearance: "Ymddangosiad y catalog",
    labelBackgroundColor: "Lliw cefndir",
    labelIconColor: "Lliw eicon",
    labelContentElementType: "Model Cynnwys",
    labelLabelTemplate: "Label",
    labelCustomView: "Golygfa arferu",
    labelCustomViewInfoTitle: "Ddangos disgrifiad golygfa arferu",
    labelCustomViewDescription: "Trosysgrifo sut mae'r bloc hwn yn ymddangos yn yr UI y swyddfa gefn. Dewis ffeil .html sy'n cynnwys eich cyflwyniad.",
    labelSettingsElementType: "Model gosodiadau",
    labelEditorSize: "Maint y golygydd troshaen",
    addCustomView: "Ychwanegu golygfa arferu",
    addSettingsElementType: "Ychwanegu gosodiadau",
    confirmDeleteBlockMessage: "Ydych chi'n siŵr eich bod chi am ddileu'r cynnwys o <strong>%0%</strong>.",
    confirmDeleteBlockTypeMessage: "Ydych chi'n siŵr eich bod chi am ddileu'r cyfluniad bloc o <strong>%0%</strong>.",
    confirmDeleteBlockTypeNotice: "Bydd cynnwys y bloc hwn yn dal i fod yn bresennol, ni fydd golygu'r cynnwys hwn ar gael mwyach a bydd yn cael ei ddangos fel cynnwys heb gefnogaeth.",
    blockConfigurationOverlayTitle: "Cyfluniad o '%0%'",
    thumbnail: "Delwedd bawd",
    addThumbnail: "Ychwanegu delwedd bawd",
    tabCreateEmpty: "Creu gwag",
    tabClipboard: "Clipfwrdd",
    tabBlockSettings: "Gosodiadau",
    headlineAdvanced: "Datblygedig",
    forceHideContentEditor: "Gorfodi cuddio'r golygydd cynnwys",
    blockHasChanges: "Rydych chi wedi gwneud newidiadau i'r cynnwys hwn. Wyt ti'n siŵr eich bod chi am eu taflu ei fwrdd?",
    confirmCancelBlockCreationHeadline: "Gwaredu cread?",
    confirmCancelBlockCreationMessage: "Ydych chi'n siŵr eich bod chi'n am ganslo'r cread?",
    elementTypeDoesNotExistHeadline: "Gwall!",
    elementTypeDoesNotExistDescription: "Nid yw'r Math Elfen y bloc hwn yn bodoli mwyach",
    addBlock: "Ychwanegu cynnwys",
    addThis: "Ychwanegu %0%",
    propertyEditorNotSupported: "Priodwedd '%0%' yn defnyddio'r golygydd '%1%' sydd ddim yn cael ei gefnogi mewn blociau.",
    confirmDeleteBlockGroupMessage: " and all the Block configurations of this?",
    confirmDeleteBlockGroupNotice: "Bydd cynnwys y Blociau hyn yn dal i fod yn bresennol, ni fydd golygu'r cynnwys hwn ar gael mwyach a bydd yn cael ei ddangos fel cynnwys heb ei gefnogi.",
    elementTypeDoesNotExist: "Nid oes modd ei olygu oherwydd nad yw ElementType yn bodoli.",
    forceHideContentEditorHelp: "Cuddiwch y botwm golygu cynnwys a'r golygydd cynnwys rhag troshaen y Golygydd Bloc",
    focusParentBlock: "Gosod ffocws ar y bloc cynhwysydd",
    areaIdentification: "Adnabyddiaeth",
    areaValidation: "Dilysiad",
    areaValidationEntriesShort: " time(s).",
    areaValidationEntriesExceed: " time(s).",
    areaNumberOfBlocks: "Nifer y blociau",
    areaDisallowAllBlocks: "Dim ond yn caniatáu mathau penodol o flociau",
    areaAllowedBlocks: "Mathau o flociau a ganiateir",
    areaAllowedBlocksHelp: "Diffiniwch y mathau o flociau a ganiateir yn y maes hwn, ac yn ddewisol faint o bob math a ddylai fod yn bresennol.",
    confirmDeleteBlockAreaMessage: "Ydych chi'n siŵr eich bod am ddileu'r ardal hon?",
    confirmDeleteBlockAreaNotice: "Bydd unrhyw flociau sy'n cael eu creu yn yr ardal hon ar hyn o bryd yn cael eu dileu.",
    layoutOptions: "Opsiynau gosodiad",
    structuralOptions: "Strwythurol",
    sizeOptions: "Opsiynau maint",
    sizeOptionsHelp: "Diffiniwch un neu fwy o opsiynau maint, mae hyn yn galluogi newid maint y Bloc",
    allowedBlockColumns: "Rhychwant colofnau sydd ar gael",
    allowedBlockColumnsHelp: "Diffiniwch y nifer gwahanol o golofnau y caniateir i'r bloc hwn rychwantu ar eu traws. Nid yw hyn yn atal Blociau rhag cael eu gosod mewn Ardaloedd o rychwant colofnau llai.",
    allowedBlockRows: "Rhychwant rhesi sydd ar gael",
    allowedBlockRowsHelp: "Diffiniwch yr ystod o resi cynllun y mae'r bloc hwn yn gallu ymestyn ar eu traws.",
    allowBlockInRoot: "Caniatáu yn y gwraidd",
    allowBlockInRootHelp: "Gwnewch y bloc hwn ar gael yng ngwraidd y cynllun.",
    allowBlockInAreas: "Caniatáu mewn ardaloedd",
    allowBlockInAreasHelp: "Gwnewch y bloc hwn ar gael o fewn Blociau eraill.",
    areas: "Ardaloedd",
    areasLayoutColumns: "Colofnau Grid ar gyfer Ardaloedd",
    areasLayoutColumnsHelp: "Diffiniwch faint o golofnau fydd ar gael ar gyfer ardaloedd. Os na chaiff ei ddiffinio, bydd nifer y colofnau a ddiffinnir ar gyfer y cynllun cyfan yn cael eu defnyddio.",
    areasConfigurations: "Ardaloedd",
    areasConfigurationsHelp: "Er mwyn galluogi blociau i nythu o fewn y bloc hwn, diffiniwch un neu fwy o ardaloedd ar gyfer blociau i nythu ynddynt. Ardaloedd yn dilyn eu cynllun eu hunain gwrach ei ddiffinio gan y Colofnau Grid ar gyfer Ardaloedd. Gellir addasu rhychwant pob colofn Ardal a rhychwant rhes trwy ddefnyddio'r teclyn trin graddfa yn y gornel dde isaf.",
    invalidDropPosition: " ni chaniateir yn y fan hon.",
    defaultLayoutStylesheet: "Taflen arddull gosodiad diofyn",
    confirmPasteDisallowedNestedBlockHeadline: "Gwrthodwyd cynnwys a wrthodwyd",
    confirmPasteDisallowedNestedBlockMessage: "Roedd y cynnwys a fewnosodwyd yn cynnwys cynnwys na caniateir, nad yw wedi'i greu. Hoffech chi gadw gweddill y cynnwys hwn beth bynnag?",
    areaAliasHelp: `Bydd yr alias yn cael ei argraffu gan GetBlockGridHTML(), defnyddiwch yr alias i dargedu'r Elfen sy'n cynrychioli'r ardal hon. Ex. .umb-block-grid__area[data-area-alias="MyAreaAlias"] { ... }`,
    scaleHandlerButtonTitle: "Llusgwch i raddfa",
    areaCreateLabelTitle: "Creu Label Botwm",
    areaCreateLabelHelp: "Trosysgrifo'r label ar fotwm creu yr Ardal hon.",
    showSizeOptions: "Dangos opsiynau newid maint",
    addBlockType: "Ychwanegu Bloc",
    addBlockGroup: "Ychwanegu grŵp",
    pickSpecificAllowance: "Dewiswch grŵp neu Floc",
    allowanceMinimum: "Gosod y gofyniad lleiaf ar gyfer y lwfans hwn",
    allowanceMaximum: "Gosod y gofyniad uchaf ar gyfer y lwfans hwn",
    block: "Gosod uchafswm y gofyniad ar gyfer y lwfans hwn",
    tabBlock: "Bloc",
    tabBlockTypeSettings: "Gosodiadau",
    tabAreas: "Ardaloedd",
    tabAdvanced: "Uwch",
    headlineAllowance: "Lwfans",
    getSampleHeadline: "Gosod Cyfluniad Sampl",
    getSampleDescription: "Bydd hyn yn ychwanegu Blociau sylfaenol ac yn eich helpu i ddechrau gyda'r Golygydd Grid Bloc. Fe gewch Blociau ar gyfer Pennawd, Testun Cyfoethog, Delwedd, yn ogystal â Chynllun Dwy Golofn.",
    getSampleButton: "Gosod",
    gridInlineEditing: "Golygu mewnol",
    gridInlineEditingHelp: "Yn galluogi golygu mewnol ar gyfer yr Eiddo cyntaf. Gellir golygu priodweddau ychwanegol yn y droshaen.",
    areaAllowedBlocksEmpty: "Yn ddiofyn, caniateir pob math bloc mewn Ardal, Defnyddiwch yr opsiwn hwn i ganiatáu mathau dethol yn unig.",
    actionEnterSortMode: "Modd trefnu",
    actionExitSortMode: "Gadael modd trefnu",
    areaAliasIsNotUnique: "Rhaid i'r Enw Arall, yr Ardal hwn, fod yn unigryw i gymharu ag Ardaloedd eraill yn y Bloc hwn.",
    configureArea: "Ffurfweddu ardal",
    deleteArea: "Dileu ardal",
    addColumnSpanOption: "Ychwanegu opsiwn rhychwantu %0% colofn",
    insertBlock: "Mewnosod Bloc",
    labelInlineMode: "Arddangos yn fewnol â'r testun"
  },
  contentTemplatesDashboard: {
    whatHeadline: "Beth yw Templedi Gynnwys",
    whatDescription: "Mae Templedi Gynnwys yn gynnwys cyn-diffiniedig sydd yn gallu cael ei ddewis wrth greu nod cynnwys newydd.",
    createHeadline: "Sut ydw i'n creu Templed Gynnwys?",
    createDescription: `
                <p>Mae yna ddwy ffordd i greu Templed Gynnwys:</p>
                <ul>
                    <li>Gliciwch-de ar nod cynnwys a dewis "Creu Templed Gynnwys" i greu Templed Gynnwys newydd.</li>
                    <li>Gliciwch-de ar y goeden Templedi Gynnwys yn yr adran Gosodiadau a dewis y Math of Dogfen ti eisiau creu Templed Gynnwys am.</li>
                </ul>
                <p>Unwaith y rhoddir enw, gall golygyddion ddechrau defnyddio'r Templed Gynnwys fel sylfaen am ei thudalen newydd.</p>
            `,
    manageHeadline: "Sut ydw i'n rheoli Templedi Gynnwys",
    manageDescription: `Gallwch chi olygu a dileu Templedi Gynnwys o'r goeden "Templedi Gynnwys" yn yr adran Gosodiadau. Ehangwch y Math o Ddogfen mae'r Templed Gynnwys yn seiliedig arno a chlicio fo i'w golygu neu ddileu.`
  },
  preview: {
    endLabel: "Diweddu",
    endTitle: "Diwedd modd rhagolwg",
    openWebsiteLabel: "Rhagolwg y wefan",
    openWebsiteTitle: "Agor y wefan mewn modd rhagolwg",
    returnToPreviewHeadline: "Rhagolwg y wefan?",
    returnToPreviewDescription: "Rydych chi wedi dod â'r modd rhagolwg i ben, a ydych chi am ei alluogi eto i weld y fersiwn ddiweddaraf o'ch gwefan sydd wedi'i chadw?",
    returnToPreviewAcceptButton: "Rhagolwg fersiwn ddiweddaraf",
    returnToPreviewDeclineButton: "Gweld fersiwn cyhoeddedig",
    viewPublishedContentHeadline: "Gweld fersiwn cyhoeddedig?",
    viewPublishedContentDescription: "Rydych chi yn y Modd Rhagolwg, a ydych chi eisiau gadael er mwyn gweld fersiwn gyhoeddedig eich gwefan?",
    viewPublishedContentAcceptButton: "Gweld fersiwn cyhoeddedig",
    viewPublishedContentDeclineButton: "Aros mewn modd rhagolwg"
  },
  permissions: {
    FolderCreation: "Creu ffolder",
    FileWritingForPackages: "Ysgrifennu ffeiliau ar gyfer pecynnau",
    FileWriting: "Ysgrifennu ffeil",
    MediaFolderCreation: "Creu ffolder cyfryngau"
  },
  treeSearch: {
    searchResult: "yr eitem wedi'i dychwelyd ",
    searchResults: "yr eitemau wedi'i dychwelyd"
  },
  analytics: {
    consentForAnalytics: "Caniatâd ar gyfer data telemetreg",
    analyticsLevelSavedSuccess: "Lefel telemetreg wedi'i chadw!",
    analyticsDescription: ` yn casglu unrhyw ddata personol megis cynnwys, cod, gwybodaeth defnyddiwr, a bydd yr holl ddata yn gwbl ddienw.
       `,
    minimalLevelDescription: "Byddwn ond yn anfon ID safle dienw i roi gwybod i ni bod y wefan yn bodoli.",
    basicLevelDescription: "Byddwn yn anfon ID safle dienw, fersiwn Umbraco, a phecynnau wedi'u gosod",
    detailedLevelDescription: `
          Byddwn yn anfon:
          `
  }
};
export {
  e as default
};
//# sourceMappingURL=cy-gb-DvpdM5H5.js.map
