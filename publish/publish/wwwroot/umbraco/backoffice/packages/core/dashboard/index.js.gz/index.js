import { UMB_SECTION_PATH_PATTERN as a } from "@umbraco-cms/backoffice/section";
import { UmbPathPattern as o } from "@umbraco-cms/backoffice/router";
const P = new o("dashboard/:dashboardPathname", a);
export {
  P as UMB_DASHBOARD_PATH_PATTERN
};
//# sourceMappingURL=index.js.map
