import e from "./de-de-BvN3dGj6.js";
const o = {
  // NOTE: Imports and re-exports the German (Germany) localizations, so that any German (Switzerland) localizations can be override them. [LK]
  ...e
};
export {
  o as default
};
//# sourceMappingURL=de-ch-DQyGkOBo.js.map
