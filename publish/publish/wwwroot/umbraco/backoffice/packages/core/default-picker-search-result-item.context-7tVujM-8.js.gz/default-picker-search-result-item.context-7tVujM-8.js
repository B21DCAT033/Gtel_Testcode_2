import { UmbContextToken as o } from "@umbraco-cms/backoffice/context-api";
import { UmbContextBase as r } from "@umbraco-cms/backoffice/class-api";
const a = new o(
  "UmbPickerSearchResultItemContext"
);
class e extends r {
  constructor(t) {
    super(t, a);
  }
}
const m = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  UmbDefaultPickerSearchResultItemContext: e,
  api: e
}, Symbol.toStringTag, { value: "Module" }));
export {
  a as U,
  e as a,
  m as d
};
//# sourceMappingURL=default-picker-search-result-item.context-7tVujM-8.js.map
