import { UmbContextToken as e } from "@umbraco-cms/backoffice/context-api";
const t = new e(
  "UmbTreeContext"
);
export {
  t as U
};
//# sourceMappingURL=default-tree.context-token-C7a9fWg9.js.map
