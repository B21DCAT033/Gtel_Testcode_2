import { a as E, U as t, a as I } from "../bulk-delete.action-wZYSm2uv.js";
import { UmbEntityBulkActionDefaultElement as U } from "../entity-bulk-action.element-Df4eBq9_.js";
import { U as B, b as A, a as e, c as o } from "../constants-CXkPsy0q.js";
export {
  B as UMB_ENTITY_BULK_ACTION_DEFAULT_KIND_MANIFEST,
  A as UMB_ENTITY_BULK_ACTION_DELETE_KIND,
  e as UMB_ENTITY_BULK_ACTION_DELETE_KIND_MANIFEST,
  o as UMB_ENTITY_BULK_ACTION_TRASH_KIND,
  E as UmbDeleteEntityBulkAction,
  t as UmbEntityBulkActionBase,
  U as UmbEntityBulkActionDefaultElement,
  I as api
};
//# sourceMappingURL=index.js.map
