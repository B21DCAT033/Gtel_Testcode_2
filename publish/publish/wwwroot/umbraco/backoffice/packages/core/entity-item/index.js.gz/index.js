import { U as m, U as n } from "../entity-item-ref.element-Bl6X4pWB.js";
export {
  m as UmbEntityItemRefElement,
  n as element
};
//# sourceMappingURL=index.js.map
