import { U as a, a as o } from "../entity.context-C8qVKYoi.js";
export {
  a as UMB_ENTITY_CONTEXT,
  o as UmbEntityContext
};
//# sourceMappingURL=index.js.map
