const e = {
  actions: {
    assigndomain: "Administrar dominios",
    auditTrail: "Historial",
    browse: "Nodo de Exploración",
    changeDocType: "Cambiar tipo de documento",
    copy: "Copiar",
    create: "Crear",
    createPackage: "Crear Paquete",
    createGroup: "Crear grupo",
    delete: "Borrar",
    disable: "Deshabilitar",
    emptyrecyclebin: "Vaciar Papelera",
    enable: "Activar",
    exportDocumentType: "Exportar Documento (tipo)",
    importdocumenttype: "Importar Documento (tipo)",
    importPackage: "Importar Paquete",
    liveEdit: "Editar en vivo",
    logout: "Cerrar sesión",
    move: "Mover",
    notify: "Notificaciones",
    protect: "Acceso Público",
    publish: "Publicar",
    unpublish: "Retirar publicación",
    refreshNode: "Recargar Nodos",
    republish: "Republicar sitio completo",
    rename: "Renombrar",
    restore: "Restaurar",
    chooseWhereToMove: "Elige dónde mover",
    toInTheTreeStructureBelow: "En el árbol de contenido",
    rights: "Permisos",
    rollback: "Deshacer",
    sendtopublish: "Enviar a Publicar",
    sendToTranslate: "Enviar a Traducir",
    setGroup: "Establecer grupo",
    sort: "Ordenar",
    translate: "Traducir",
    update: "Actualizar",
    setPermissions: "Establecer permisos",
    unlock: "Desbloquear",
    createblueprint: "Crear Plantilla de Contenido"
  },
  actionCategories: {
    content: "Contenido",
    administration: "Administración",
    structure: "Estructura",
    other: "Otro"
  },
  actionDescriptions: {
    assignDomain: "Permitir acceso para asignar cultura y dominios",
    auditTrail: "Permitir acceso para ver el historial de un nodo",
    browse: "Permitir acceso para ver un nodo",
    changeDocType: "Permitir acceso para cambiar el tipo de documento de un nodo",
    copy: "Permitir acceso para copiar un nodo",
    create: "Permitir acceso para crear nodos",
    delete: "Permitir acceso para borrar nodos",
    move: "Permitir acceso para mover un nodo",
    protect: "Permitir acceso para establecer y cambiar el acceso público a un nodo",
    publish: "Permitir acceso para publicar un nodo",
    rights: "Permitir acceso para cambiar los permisos para un nodo",
    rollback: "Permitir acceso para revertir cambios a un nodo a un estado anterior",
    sendtopublish: "Permitir acceso para enviar un nodo a revisión antes de publicarlo",
    sendToTranslate: "Permitir acceso para enviar un nodo a traducir",
    sort: "Permitir acceso a ordenar nodos",
    translate: "Permitir acceso para traducir un nodo",
    update: "Permitir acceso para guardar un nodo",
    createblueprint: "Permitir acceso para crear una Plantilla de Contenido"
  },
  apps: {
    umbContent: "Contenido",
    umbInfo: "Información"
  },
  assignDomain: {
    permissionDenied: "Permiso denegado.",
    addNew: "Añadir nuevo dominio",
    remove: "quitar",
    invalidNode: "Nodo no válido.",
    invalidDomain: "Formato de dominio no válido.",
    duplicateDomain: "Este dominio ya ha sido asignado.",
    language: "Idioma",
    domain: "Dominio",
    domainCreated: "El nuevo dominio %0% ha sido creado",
    domainDeleted: "El dominio %0% ha sido borrado",
    domainExists: "El dominio'%0%' ya ha sido asignado",
    domainUpdated: "El dominio %0% ha sido actualizado",
    orEdit: "Editar dominios actuales",
    inherit: "Heredar",
    setLanguage: "Idioma",
    setLanguageHelp: `Configura el idioma para los nodos por debajo del nodo actual,<br /> o hereda el idioma de los nodos padres. También se aplicará<br />
      para el nodo actual, a menos que un dominio por debajo lo aplique también.`,
    setDomains: "Dominios"
  },
  auditTrails: {
    atViewingFor: "Visualización de"
  },
  buttons: {
    clearSelection: "Deshacer selección",
    select: "Seleccionar",
    somethingElse: "Hacer otra cosa",
    bold: "Negrita",
    deindent: "Cancelar Sangría del Párrafo ",
    formFieldInsert: "Insertar campo de formulario",
    graphicHeadline: "Insertar gráfico de titular",
    htmlEdit: "Editar Html",
    indent: "Sangría",
    italic: "Cursiva",
    justifyCenter: "Centrar",
    justifyLeft: "Alinear a la Izquierda",
    justifyRight: "Alinear a la Derecha",
    linkInsert: "Insertar Link",
    linkLocal: "Insertar link local (ancla)",
    listBullet: "Lista en Viñetas",
    listNumeric: "Lista Numérica",
    macroInsert: "Insertar macro",
    pictureInsert: "Insertar imagen",
    relations: "Editar relaciones",
    returnToList: "Volver al listado",
    save: "Guardar",
    saveAndPublish: "Guardar y publicar",
    saveToPublish: "Guardar y enviar para aprobación",
    saveListView: "Guardar vista de lista",
    saveAndPreview: "Previsualizar",
    showPageDisabled: "La previsualización está deshabilitada porque no hay ninguna plantilla asignada",
    styleChoose: "Elegir estilo",
    styleShow: "Mostrar estilos",
    tableInsert: "Insertar tabla",
    saveAndGenerateModels: "Guardar y generar modelos",
    undo: "Deshacer",
    redo: "Rehacer"
  },
  content: {
    isPublished: "Está publicado",
    about: "Acerca de",
    alias: "Link alternativo",
    alternativeTextHelp: "(como describe la imagen sobre el teléfono)",
    alternativeUrls: "Vínculos Alternativos",
    clickToEdit: "Clic para editar esta entrada",
    createBy: "Creado por",
    createByDesc: "Autor original",
    updatedBy: "Actualizado por",
    createDate: "Creado",
    createDateDesc: "Fecha/hora de creación del documento",
    documentType: "Tipo de Documento",
    editing: "Editando",
    expireDate: "Remover el",
    itemChanged: "Esta entrada ha sido modificada después de haber sido publicada",
    itemNotPublished: "Esta entrada no esta publicada",
    lastPublished: "Último publicado",
    noItemsToShow: "No hay elementos para mostrar",
    listViewNoItems: "No hay elementos para mostrar en la lista.",
    listViewNoContent: "No se ha añadido contenido",
    listViewNoMembers: "No se ha añadido ningún miembro",
    mediatype: "Tipo de Medio",
    mediaLinks: "Enlazar a medio",
    membergroup: "Miembro de Grupo",
    memberrole: "Rol",
    membertype: "Tipo de miembro",
    noDate: "Sin fecha",
    nodeName: "Título de la página",
    otherElements: "Propiedades",
    parentNotPublished: "Este documento ha sido publicado pero no es visible porque el padre '%0%' no esta publicado",
    parentNotPublishedAnomaly: "Ups: este documento está publicado pero no está en la caché (error interno)",
    getUrlException: "No se pudo obtener la URL",
    routeError: "Este documento está publicado pero tu URL colisionará con contenido %0%",
    publish: "Publicar",
    publishStatus: "Estado de la Publicación",
    releaseDate: "Publicar el",
    unpublishDate: "Retirar publicación el",
    removeDate: "Fecha de Eliminación",
    sortDone: "El Orden esta actualizado",
    sortHelp: 'Para organizar los nodos, simplemente arrastra los nodos o realice un clic en uno de los encabezados de columna. Puedes seleccionar múltiple nodos manteniendo presionados "Shift" o "Control" mientras seleccionas',
    statistics: "Estadísticas",
    titleOptional: "Título (opcional)",
    altTextOptional: "Texto alternativo (opcional)",
    type: "Tipo",
    unpublish: "Ocultar",
    updateDate: "Última actualización",
    updateDateDesc: "Fecha/hora este documento fue modificado",
    uploadClear: "Eliminar archivo",
    urls: "Vínculo al documento",
    memberof: "Miembro de grupo(s)",
    notmemberof: "No es miembro de grupo(s)",
    childItems: "Nodos hijo",
    target: "Destino",
    scheduledPublishServerTime: "Esto se traduce en la siguiente hora en el servidor:",
    scheduledPublishDocumentation: '<a href="https://docs.umbraco.com/umbraco-cms/fundamentals/data/scheduled-publishing#timezones" target="_blank" rel="noopener">¿Esto qué significa?</a>',
    nestedContentDeleteItem: "¿Estás seguro que quieres eliminar este elemento?",
    nestedContentEditorNotSupported: "Propiedad %0% utiliza editor %1% que no está soportado por Nested Content.",
    addTextBox: "Añadir otra caja de texto",
    removeTextBox: "Eliminar caja de texto",
    contentRoot: "Raíz de contenido",
    saveModalTitle: "Guardar"
  },
  blueprints: {
    createBlueprintFrom: "Crear nueva Plantilla de Contenido desde <em>%0%</em>",
    blankBlueprint: "Vacía",
    selectBlueprint: "Seleccionar Plantilla de Contenido",
    createdBlueprintHeading: "Plantilla de Contenido creada",
    createdBlueprintMessage: "Plantilla de Contenido creada desde '%0%'",
    duplicateBlueprintMessage: "Otra Plantilla de Contenido con este nombre ya existe",
    blueprintDescription: "Una Plantilla de Contenido es contenido predefinido que un editor puede usar como base para crear nuevo contenido"
  },
  media: {
    clickToUpload: "Haz clic para subir archivos"
  },
  member: {
    createNewMember: "Crear nuevo miembro",
    allMembers: "Todos los miembros"
  },
  create: {
    chooseNode: "¿Dónde quieres crear el nuevo %0%",
    createUnder: "Crear debajo de",
    createContentBlueprint: "Selecciona el Tipo de Documento para el que quieres crear una plantilla de contenido",
    updateData: "Elige un tipo y un título",
    noDocumentTypes: 'No hay disponibles tipos de documentos permitidos. Debes habilitarlos en la sección "Ajustes" en <strong>"Tipos de documentos"</strong>.',
    noMediaTypes: 'No hay disponibles tipos de medios permitidos. Debes habilitarlos en la sección "Ajustes" en <strong>"Tipos de medios"</strong>.',
    documentTypeWithoutTemplate: "Tipo de Documento sin plantilla",
    newFolder: "Nueva carpeta",
    newDataType: "Nuevo tipo de dato",
    newJavascriptFile: "Nuevo archivo javascript",
    newEmptyPartialView: "Nueva plantilla parcial vacía",
    newPartialViewMacro: "Nueva vista parcial de macro",
    newPartialViewFromSnippet: "Nueva vista parcial desde snippet",
    newPartialViewMacroFromSnippet: "Nueva vista parcial de macro desde snippet",
    newPartialViewMacroNoMacro: "Nueva vista parcial de macro (sin macro)"
  },
  dashboard: {
    browser: "Navega en tu sitio Web",
    dontShowAgain: "No volver a mostrar",
    nothinghappens: "Si Umbraco no se ha abierto tendrás que permitir ventanas emergentes para este sitio Web",
    openinnew: "se ha abierto en una nueva ventana",
    restart: "Reinicio",
    visit: "Visita",
    welcome: "Bienvenido"
  },
  prompt: {
    stay: "Permanecer",
    discardChanges: "Descartar cambios",
    unsavedChanges: "Tienes cambios no guardados",
    unsavedChangesWarning: "¿Estás seguro que quieres abandonar la página? Tienes cambios no guardados"
  },
  bulk: {
    done: "Hecho",
    deletedItem: "Borrado %0% elemento",
    deletedItems: "Borrados %0% elementos",
    deletedItemOfItem: "Borrado %0% de %1% elemento",
    deletedItemOfItems: "Borrados %0% de %1% elementos",
    publishedItem: "Publicado %0% elemento",
    publishedItems: "Publicados %0% elementos",
    publishedItemOfItem: "Publicado %0% de %1% elemento",
    publishedItemOfItems: "Publicados %0% de %1% elementos",
    unpublishedItem: "Ocultar %0% elemento",
    unpublishedItems: "Ocultar %0% elementos",
    unpublishedItemOfItem: "Ocultado %0% de %1% elemento",
    unpublishedItemOfItems: "Ocultados %0% de %1% elementos",
    movedItem: "Mover %0% elemento",
    movedItems: "Mover %0% elementos",
    movedItemOfItem: "Movido %0% de %1% elemento",
    movedItemOfItems: "Movidos %0% de %1% elementos",
    copiedItem: "Copiar %0% elemento",
    copiedItems: "Copiar %0% elementos",
    copiedItemOfItem: "Copiado %0% de %1% elemento",
    copiedItemOfItems: "Copiado %0% de %1% elementos"
  },
  defaultdialogs: {
    nodeNameLinkPicker: "Título del vínculo",
    urlLinkPicker: "Vínculo",
    anchorInsert: "Nombre",
    assignDomain: "Administrar dominios",
    closeThisWindow: "Cerrar esta ventana",
    confirmdelete: "Estás seguro que quieres borrar",
    confirmdisable: "Estás seguro que quieres deshabilitar",
    confirmlogout: "¿Estás seguro?",
    confirmSure: "¿Estás seguro?",
    cut: "Cortar",
    editDictionary: "Editar entrada del Diccionario",
    editLanguage: "Editar idioma",
    insertAnchor: "Agregar enlace interno",
    insertCharacter: "Insertar carácter",
    insertgraphicheadline: "Insertar titular gráfico",
    insertimage: "Insertar imagen",
    insertlink: "Insertar enlace",
    insertMacro: "Insertar macro",
    inserttable: "Insertar tabla",
    lastEdited: "Última edición",
    link: "Enlace",
    linkinternal: "Enlace interno",
    linklocaltip: 'Al usar enlaces locales, insertar "#" delante del enlace',
    linknewwindow: "¿Abrir en nueva ventana?",
    macroDoesNotHaveProperties: "Esta macro no contiene ninguna propiedad que pueda editar",
    paste: "Pegar",
    permissionsEdit: "Editar permisos para",
    permissionsSet: "Establecer permisos para",
    permissionsSetForGroup: "Establecer permisos para %0% para grupo %1%",
    permissionsHelp: "Selecciona el grupo de usuarios para el cual quieres establecer permisos",
    recycleBinDeleting: "Se está vaciando la papelera. No cierres esta ventana mientras se ejecuta este proceso",
    recycleBinIsEmpty: "La papelera está vacía",
    recycleBinWarning: "No podrás recuperar los elementos una vez sean borrados de la papelera",
    regexSearchError: "El servicio web <a target='_blank' rel='noopener' href='http://regexlib.com'>regexlib.com</a> está experimentando algunos problemas en estos momentos, de los cuales no somos responsables. Pedimos disculpas por las molestias.",
    regexSearchHelp: "Buscar una expresión regular para agregar validación a un campo de formulario. Ejemplo: 'correo electrónico', 'código postal', 'URL'.",
    removeMacro: "Eliminar macro",
    requiredField: "Campo obligatorio",
    sitereindexed: "El sitio ha sido reindexado",
    siterepublished: "Se ha actualizado la caché y se ha publicado el contenido del sitio web.",
    siterepublishHelp: "La caché del sitio web será actualizada. Todos los contenidos publicados serán actualizados, mientras el contenido no publicado permanecerá no publicado.",
    tableColumns: "Número de columnas",
    tableRows: "Número de filas",
    thumbnailimageclickfororiginal: "Haz clic sobre la imagen para verla a tamaño completo.",
    treepicker: "Seleccionar elemento",
    viewCacheItem: "Ver elemento en la caché",
    relateToOriginalLabel: "Relacionar con original",
    includeDescendants: "Incluir descendientes",
    theFriendliestCommunity: "La amigable comunidad",
    linkToPage: "Enlazar a página",
    openInNewWindow: "Abre el documento enlazado en una nueva ventana o pestaña",
    linkToMedia: "Enlazar a medio",
    selectContentStartNode: "Selecciona nodo de inicio de contenido",
    selectMedia: "Selecciona medio",
    selectIcon: "Selecciona icono",
    selectItem: "Selecciona elemento",
    selectLink: "Selecciona enlace",
    selectMacro: "Selecciona macro",
    selectContent: "Selecciona contenido",
    selectMediaStartNode: "Selecciona nodo de inicio de medios",
    selectMember: "Selecciona miembro",
    selectMemberGroup: "Selecciona grupo de miembros",
    selectNode: "Selecciona nodo",
    selectLanguages: "Seleccionar idiomas",
    selectSections: "Selecciona secciones",
    selectUsers: "Selecciona usuarios",
    noIconsFound: "No se encontraron iconos",
    noMacroParams: "No hay parámetros para esta macro",
    noMacros: "No hay macros disponibles para insertar",
    externalLoginProviders: "Proveedores de login externo",
    exceptionDetail: "Detalles de la Excepción",
    stacktrace: "Stacktrace",
    innerException: "Excepción interna",
    linkYour: "Enlaza tu",
    unLinkYour: "Desenlaza tu",
    account: "Cuenta",
    selectEditor: "Selecciona editor",
    selectSnippet: "Selecciona snippet"
  },
  dictionary: {
    importDictionaryItemHelp: `
      Para importar un elemento del diccionario, busque el archivo ".udt" en su computadora haciendo clic en el
      Botón "Importar" (se le pedirá confirmación en la siguiente pantalla)
    `,
    itemDoesNotExists: "El elemento del diccionario no existe.",
    parentDoesNotExists: "El elemento principal no existe.",
    noItems: "No hay elementos del diccionario.",
    noItemsInFile: "No hay elementos de diccionario en este archivo.",
    noItemsFound: "No se encontraron elementos del diccionario.",
    createNew: "Crear elemento de diccionario"
  },
  dictionaryItem: {
    description: "Editar las diferentes versiones lingüísticas para la entrada en el diccionario '%0%' debajo",
    displayName: "nombre de la cultura",
    changeKeyError: "La clave '%0%' ya existe."
  },
  placeholders: {
    username: "Escribe tu nombre de usuario",
    password: "Escribe tu contraseña",
    confirmPassword: "Confirma tu contraseña",
    nameentity: "Nombre del %0%...",
    entername: "Escribe un nombre...",
    enteremail: "Introduce tu email...",
    enterusername: "Introduce tu nombre de usuario...",
    label: "Etiqueta...",
    enterDescription: "Introduce una descripción...",
    search: "Escribe tu búsqueda...",
    filter: "Escribe para filtrar resultados...",
    enterTags: "Teclea para crear etiquetas (pulsa enter después de cada etiqueta)...",
    email: "Introduce tu email....",
    enterMessage: "Introduce un mensaje...",
    usernameHint: "Tu nombre de usuario normalmente es tu e-mail"
  },
  editcontenttype: {
    createListView: "Crear un tipo de listado personalizado",
    removeListView: "Quitar el tipo de listado personalizado"
  },
  renamecontainer: {
    renamed: "Renombrado",
    enterNewFolderName: "Introduce un nuevo nombre para la carpeta aquí",
    folderWasRenamed: "%0% fue renombrada a %1%"
  },
  editdatatype: {
    addPrevalue: "añadir valor preestablecido",
    dataBaseDatatype: `Base de datos
`,
    guid: "Tipo de datos GUID",
    renderControl: "Renderizar control",
    rteButtons: "Botones",
    rteEnableAdvancedSettings: "Habilitar la configuración avanzada para",
    rteEnableContextMenu: "Habilitar menú contextual",
    rteMaximumDefaultImgSize: "Por defecto, el tamaño máximo de imágenes insertado",
    rteRelatedStylesheets: `Relacionados con el estilo de las páginas
`,
    rteShowLabel: "Mostrar etiqueta",
    rteWidthAndHeight: `anchura y altura
`,
    selectFolder: "Selecciona carpeta para mover",
    inTheTree: "a la estructura de contenido",
    wasMoved: "se movió debajo"
  },
  errorHandling: {
    errorButDataWasSaved: "Se ha guardado la información pero debes solucionar los siguientes errores para poder publicar:",
    errorChangingProviderPassword: "La composición actual del proveedor no es compatible con el cambio de la contraseña (Habilitar la contraseña de recuperación es necesaria para que sea cierta)",
    errorExistsWithoutTab: "%0% ya existe",
    errorHeader: "Se han encontrado los siguientes errores:",
    errorHeaderWithoutTab: "Se han encontrado los siguientes errores:",
    errorInPasswordFormat: "La clave debe tener como mínimo %0% caracteres y %1% carácter(es) no alfanuméricos",
    errorIntegerWithoutTab: "%0% debe ser un número entero",
    errorMandatory: "Debes llenar los campos del %0% al %1%",
    errorMandatoryWithoutTab: "Debes llenar el campo %0%",
    errorRegExp: "Debes poner el formato correcto del %0% al %1% ",
    errorRegExpWithoutTab: "Debes poner un formato correcto en %0%"
  },
  errors: {
    receivedErrorFromServer: "Se recibió un error desde el servidor",
    dissallowedMediaType: "El tipo de archivo especificado ha sido deshabilitado por el administrador",
    codemirroriewarning: "NOTA: Aunque CodeMirror esté activado en los ajustes de configuración, no se muestra en Internet Explorer debido a que no es lo suficientemente estable.'",
    contentTypeAliasAndNameNotNull: "Debes rellenar el alias y el nombre en el tipo de propiedad",
    filePermissionsError: "Hay un problema de lectura y escritura al acceder a un archivo o carpeta",
    macroErrorLoadingPartialView: "Error cargando Vista Parcial (archivo: %0%)",
    missingTitle: `Por favor, introduzca un título
`,
    missingType: "Por favor, elige un tipo ",
    pictureResizeBiggerThanOrg: "Estás a punto de hacer la foto más grande que el tamaño original. ¿Estás seguro de que desea continuar?",
    startNodeDoesNotExists: `Startnode suprimido, por favor, póngase en contacto con su administrador
`,
    stylesMustMarkBeforeSelect: "Por favor, marca el contenido antes de cambiar de estilo",
    stylesNoStylesOnPage: "No actives estilos disponibles",
    tableColMergeLeft: "Por favor, coloca el cursor a la izquierda de las dos celdas que quieres combinar",
    tableSplitNotSplittable: `No se puede dividir una celda que no ha sido combinada.
`
  },
  general: {
    about: "Acerca de",
    action: "Acción",
    actions: "Acciones",
    add: "Añadir",
    alias: "Alias",
    areyousure: "¿Estás seguro?",
    border: "Borde",
    by: "o",
    cancel: "Cancelar",
    cellMargin: "Margen de la celda",
    choose: "Elegir",
    close: "Cerrar",
    closewindow: "Cerrar ventana",
    comment: "Comentario",
    confirm: "Confirmar",
    constrainProportions: "Mantener proporciones",
    continue: "Continuar",
    copy: "Copiar",
    create: "Crear",
    database: "Base de datos",
    date: "Fecha",
    default: "Por defecto",
    delete: "Borrar",
    deleted: "Borrado",
    deleting: "Borrando...",
    design: "Diseño",
    dictionary: "Diccionario",
    dimensions: "Dimensiones",
    down: "Abajo",
    download: "Descargar",
    edit: "Editar",
    edited: "Editado",
    elements: "Elementos",
    email: "Mail",
    error: "Error",
    findDocument: "Buscar",
    first: "Primero",
    groups: "Grupos",
    height: "Altura",
    help: "Ayuda",
    hide: "Ocultar",
    icon: "Icono",
    import: "Importar",
    innerMargin: "Margen interno",
    insert: "Insertar",
    install: "Instalar",
    invalid: "Inválido",
    justify: "Justificar",
    label: "Etiqueta",
    language: "Idioma",
    last: "Último",
    layout: "Diseño",
    loading: "Cargando",
    locked: "Bloqueado",
    login: "Iniciar sesión",
    logoff: "Cerrar sesión",
    logout: "Cerrar sesión",
    macro: "Macro",
    mandatory: "Obligatorio",
    message: "Mensaje",
    move: "Mover",
    name: "Nombre",
    new: "Nuevo",
    next: "Próximo",
    no: "No",
    of: "de",
    off: "Desactivado",
    ok: "OK",
    open: "Abrir",
    on: "Activado",
    or: "o",
    orderBy: "Ordenar por",
    password: "Contraseña",
    path: "Ruta",
    pleasewait: "Un momento por favor...",
    previous: "Anterior",
    properties: "Propiedades",
    reciept: "Mail para recibir los datos del formulario",
    recycleBin: "Papelera",
    recycleBinEmpty: "Tu papelera está vacía",
    remaining: "Restantes",
    remove: "Eliminar",
    rename: "Renombrar",
    renew: "Renovar",
    required: "Requerido",
    retrieve: "Recuperar",
    retry: "Reintentar",
    rights: "Permisos",
    search: "Buscar",
    searchNoResult: "Perdona, pero no podemos encontrar lo que buscas",
    noItemsInList: "No se han añadido elementos",
    server: "Servidor",
    show: "Mostrar",
    showPageOnSend: "Mostrar página al enviar",
    size: "Tamaño",
    sort: "Ordenar",
    status: "Estado",
    submit: "Aceptar",
    type: "Tipo",
    typeToSearch: "Tipo que buscar...",
    up: "Arriba",
    update: "Actualizar",
    upgrade: "Actualizar",
    upload: "Subir",
    url: "URL",
    user: "Usuario",
    username: "Nombre de usuario",
    value: "Valor",
    view: "Ver",
    welcome: "Bienvenido...",
    width: "Ancho",
    yes: "Si",
    folder: "Carpeta",
    searchResults: "Resultados de búsqueda",
    reorder: "Reordenar",
    reorderDone: "He terminado de ordenar",
    preview: "Prever",
    changePassword: "Cambiar contraseña",
    to: "a",
    listView: "Vista de lista",
    saving: "Guardando...",
    current: "actual",
    embed: "Insertar",
    selected: "seleccionado"
  },
  colors: {
    blue: "Azul"
  },
  shortcuts: {
    addGroup: "Añadir pestaña",
    addProperty: "Añadir propiedad",
    addEditor: "Añadir editor",
    addTemplate: "Añadir platilla",
    addChildNode: "Añadir nodo hijo",
    addChild: "Añadir hijo",
    editDataType: "Editar tipo de dato",
    navigateSections: "Navegar secciones",
    shortcut: "Atajos",
    showShortcuts: "mostrar atajos",
    toggleListView: "Activar/Desactivar vista de lista",
    toggleAllowAsRoot: "Activar/Desactivar permitir como raíz",
    commentLine: "Comentar/Descomentar líneas",
    removeLine: "Eliminar línea",
    copyLineUp: "Copiar líneas arriba",
    copyLineDown: "Copiar líneas abajo",
    moveLineUp: "Mover líneas arriba",
    moveLineDown: "Mover líneas abajo",
    generalHeader: "General",
    editorHeader: "Editor"
  },
  graphicheadline: {
    backgroundcolor: "Color de fondo",
    bold: "Negritas",
    color: "Color del texto",
    font: "Fuente",
    text: "Texto"
  },
  headers: {
    page: "Página"
  },
  installer: {
    databaseErrorCannotConnect: "El instalador no puede conectar con la base de datos.",
    databaseFound: "Tu base de datos ha sido encontrada y ha sido identificada como",
    databaseHeader: "Configuración de la base de datos",
    databaseInstall: "Pulsa el botón <strong> instalar </ strong> para instalar %0% la base de datos de Umbraco",
    databaseInstallDone: "Se ha copiado Umbraco %0% a la base de datos. Pulsa <strong>Próximo</strong> para continuar",
    databaseText: 'Para completar este paso, debes conocer la información correspondiente a tu servidor de base de datos ("cadena de conexión").<br /> Por favor, contacta con tu ISP si es necesario. Si estás realizando la instalación en una máquina o servidor local, quizás necesites información de tu administrador de sistemas.',
    databaseUpgrade: "<p> Pincha en <strong>actualizar</strong> para actualizar la base de datos a Umbraco %0%</p> <p> Ningún contenido será borrado de la base de datos y seguirá funcionando después de la actualización </p> ",
    databaseUpgradeDone: "La base de datos ha sido actualizada a la versión 0%.<br />Pincha en <strong>Próximo</strong> para continuar. ",
    databaseUpToDate: "La base de datos está actualizada. Pincha en <strong>próximo</strong> para continuar con el asistente de configuración",
    defaultUserChangePass: "<strong>La contraseña del usuario por defecto debe ser cambiada</strong>",
    defaultUserDisabled: "<strong>El usuario por defecto ha sido deshabilitado o ha perdido el acceso a Umbraco!</strong></p><p>Pincha en <strong>Próximo</strong> para continuar.",
    defaultUserPassChanged: "<strong>¡La contraseña del usuario por defecto ha sido cambiada desde que se instaló!</strong></p><p>No hay que realizar ninguna tarea más. Pulsa <strong>Siguiente</strong> para proseguir.",
    defaultUserPasswordChanged: "¡La contraseña se ha cambiado!",
    greatStart: "Ten un buen comienzo, visita nuestros videos de introducción",
    None: "No ha sido instalado.",
    permissionsAffectedFolders: "Archivos y directorios afectados",
    permissionsAffectedFoldersMoreInfo: "Mas información en configurar los permisos para Umbraco aquí",
    permissionsAffectedFoldersText: "Necesitas dar permisos de modificación a ASP.NET para los siguientes archivos/directorios",
    permissionsAlmostPerfect: "<strong>¡Tu configuración de permisos es casi perfecta!</strong><br /><br /> Puedes ejecutar Umbraco sin problemas, pero no podrás instalar paquetes que es algo recomendable para explotar el potencial de Umbraco.",
    permissionsHowtoResolve: "Como Resolver",
    permissionsHowtoResolveLink: "Pulsa aquí para leer la versión de texto",
    permissionsHowtoResolveText: "Mira nuestros <strong>video tutoriales</strong> acerca de cómo configurar los permisos de los directorios para Umbraco o lee la versión de texto.",
    permissionsMaybeAnIssue: "<strong>¡La configuración de tus permisos podría ser un problema!</strong> <br/><br /> Puedes ejecutar Umbraco sin problemas, pero no serás capaz de crear directorios o instalar paquetes que es algo recomendable para explotar el potencial de Umbraco.",
    permissionsNotReady: "<strong>¡Tu configuración de permisos no está lista para Umbraco!</strong> <br /><br /> Para ejecutar Umbraco, necesitarás actualizar tu configuración de permisos.",
    permissionsPerfect: "<strong>¡Tu configuración de permisos es perfecta!</strong><br /><br /> ¡Estás listo para ejecutar Umbraco e instalar paquetes!",
    permissionsResolveFolderIssues: "Resolviendo problemas con directorios",
    permissionsResolveFolderIssuesLink: "Sigue este enlace para más información sobre problemas con ASP.NET y creación de directorios",
    permissionsSettingUpPermissions: "Configurando los permisos de directorios",
    permissionsText: "Umbraco necesita permisos de lectura/escritura en algunos directorios para poder almacenar archivos tales como imágenes y PDFs. También almacena datos en la caché para mejorar el rendimiento de tu sitio web",
    runwayFromScratch: "Quiero empezar de cero",
    runwayFromScratchText: 'Tu sitio web está completamente vacío en estos momentos, lo cual es perfecto si quieres empezar de cero y crear tus propios tipos de documentos y plantillas (<a href="https://umbraco.tv/documentation/videos/for-site-builders/foundation/document-types">aprende cómo</a>). Todavía podrás elegir instalar Runway más adelante. Por favor ve a la sección del Desarrollador y elige Paquetes.',
    runwayHeader: "Acabas de configurar una nueva plataforma Umbraco. ¿Qué deseas hacer ahora?",
    runwayInstalled: "Se ha instalado Runway",
    runwayInstalledText: 'Tienes puestos los cimientos. Selecciona los módulos que desees instalar sobre ellos.<br /> Esta es nuestra lista de módulos recomendados, selecciona los que desees instalar, o mira la <a href="#" onclick="toggleModules(); return false;" id="toggleModuleList">lista completa de módulos</a> ',
    runwayOnlyProUsers: "Sólo recomendado para usuarios expertos",
    runwaySimpleSite: "Quiero empezar con un sitio web sencillo",
    runwaySimpleSiteText: '<p> "Runway" es un sitio web sencillo que contiene unos tipos de documentos y plantillas básicos. El instalador puede configurar Runway por ti de forma automática, pero fácilmente puedes editarlo, extenderlo o eliminarlo. No es necesario y puedes usar Umbraco perfectamente sin él. Sin embargo, Runway ofrece unos cimientos sencillos basados en buenas prácticas para iniciarte más rápido que nunca. Si eliges instalar Runway, puedes seleccionar bloques de construcción básicos llamados Módulos de Runway de forma opcional para realzar tus páginas de Runway. </> <small> <em>Incluido con Runway:</em> Página de inicio, página de Cómo empezar, página de Instalación de módulos.<br /> <em>Módulos opcionales:</em> Navegación superior, Mapa del sitio, Contacto, Galería. </small> ',
    runwayWhatIsRunway: "¿Qué es Runway?",
    step1: "Paso 1 de 5. Aceptar los términos de la licencia",
    step2: "Paso 2 de 5. Configuración de la base de datos",
    step3: "Paso 3 de 5. Autorizar / validar permiso en los archivos",
    step4: "Paso 4 de 5. Configurar seguridad en Umbraco",
    step5: "Paso 5 de 5. Umbraco está listo para ser usado",
    thankYou: "Gracias por elegir Umbraco",
    theEndBrowseSite: "<h3>Navega a tu nuevo sitio</h3> Has instalado Runway, por qué no ves el aspecto de tu nuevo sitio web.",
    theEndFurtherHelp: "<h3>Más ayuda e información</h3> Consigue ayuda de nuestra premiada comunidad, navega por la documentación o mira algunos videos gratuitos de cómo crear un sitio sencillo, cómo utilizar los paquetes y una guía rápida de la terminología de Umbraco",
    theEndHeader: "Umbraco %0% ha sido instalado y está listo para ser usado",
    theEndInstallSuccess: 'Puedes <strong>empezar inmediatamente</strong> pulsando el botón "Lanzar Umbraco" de debajo. <br />Si eres <strong>nuevo con Umbraco</strong>, puedes encontrar cantidad de recursos en nuestras páginas de cómo empezar.',
    theEndOpenUmbraco: "<h3>Lanzar Umbraco</h3> Para administrar tu sitio web, simplemente abre el backoffice de Umbraco y empieza a añadir contenido, a actualizar plantillas y hojas de estilo o a añadir nueva funcionalidad",
    Unavailable: "No se ha podido establecer la conexión con la base de datos",
    Version3: "Umbraco versión 3",
    Version4: "Umbraco versión 4",
    watch: "Mirar",
    welcomeIntro: 'El asistente de configuración te guiará en los pasos para instalar <strong>Umbraco %0%</strong> o actualizar la versión 3.0 a <strong>Umbraco %0%</strong>. <br /><br />  Pincha en <strong>"próximo"</strong> para empezar con el asistente de configuración.'
  },
  language: {
    cultureCode: "Código de cultura",
    displayName: "Nombre de cultura"
  },
  lockout: {
    lockoutWillOccur: "No ha habido ninguna actividad y tu sesión se cerrará en ",
    renewSession: "Renovar tu sesión para guardar sus cambios"
  },
  login: {
    greeting0: "Bienvenido",
    greeting1: "Bienvenido",
    greeting2: "Bienvenido",
    greeting3: "Bienvenido",
    greeting4: "Bienvenido",
    greeting5: "Bienvenido",
    greeting6: "Bienvenido",
    instruction: "Iniciar sesión",
    timeout: "La sesión ha caducado",
    bottomText: '<p style="text-align:right;">&copy; 2001 - %0% <br /><a href="https://umbraco.com" style="text-decoration: none" target="_blank" rel="noopener">umbraco.com</a></p> ',
    forgottenPassword: "¿Olvidaste tu contraseña?",
    forgottenPasswordInstruction: "Enviaremos un email a la dirección especificada con un enlace para restaurar tu contraseña",
    requestPasswordResetConfirmation: "Un email con instrucciones para restaurar tu contraseña será enviado a la dirección especificada si ésta está registrada.",
    returnToLogin: "Volver al formulario de acceso",
    setPasswordInstruction: "Por favor, introduce una nueva contraseña",
    setPasswordConfirmation: "Tu contraseña ha sido actualizada",
    resetCodeExpired: "El enlace pulsado es inválido o ha caducado",
    resetPasswordEmailCopySubject: "Umbraco: Restaurar contraseña",
    resetPasswordEmailCopyFormat: `
        <html>
			<head>
				<meta name='viewport' content='width=device-width'>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
			</head>
			<body class='' style='font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; color: #392F54; line-height: 22px; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background: #1d1333; margin: 0; padding: 0;' bgcolor='#1d1333'>
				<style type='text/css'> @media only screen and (max-width: 620px) {table[class=body] h1 {font-size: 28px !important; margin-bottom: 10px !important; } table[class=body] .wrapper {padding: 32px !important; } table[class=body] .article {padding: 32px !important; } table[class=body] .content {padding: 24px !important; } table[class=body] .container {padding: 0 !important; width: 100% !important; } table[class=body] .main {border-left-width: 0 !important; border-radius: 0 !important; border-right-width: 0 !important; } table[class=body] .btn table {width: 100% !important; } table[class=body] .btn a {width: 100% !important; } table[class=body] .img-responsive {height: auto !important; max-width: 100% !important; width: auto !important; } } .btn-primary table td:hover {background-color: #34495e !important; } .btn-primary a:hover {background-color: #34495e !important; border-color: #34495e !important; } .btn  a:visited {color:#FFFFFF;} </style>
				<table border="0" cellpadding="0" cellspacing="0" class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;" bgcolor="#1d1333">
					<tr>
						<td style="font-family: sans-serif; font-size: 14px; vertical-align: top; padding: 24px;" valign="top">
							<table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;">
								<tr>
									<td background="https://umbraco.com/umbraco/assets/img/application/logo.png" bgcolor="#1d1333" width="28" height="28" valign="top" style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
										<!--[if gte mso 9]> <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:30px;height:30px;"> <v:fill type="tile" src="https://umbraco.com/umbraco/assets/img/application/logo.png" color="#1d1333" /> <v:textbox inset="0,0,0,0"> <![endif]-->
										<div> </div>
										<!--[if gte mso 9]> </v:textbox> </v:rect> <![endif]-->
									</td>
									<td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top"></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;' bgcolor='#1d1333'>
					<tr>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
						<td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 560px; width: 560px; margin: 0 auto; padding: 10px;' valign='top'>
							<div class='content' style='box-sizing: border-box; display: block; max-width: 560px; margin: 0 auto; padding: 10px;'>
								<br>
								<table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; border-radius: 3px; background: #FFFFFF;' bgcolor='#FFFFFF'>
									<tr>
										<td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 50px;' valign='top'>
											<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
												<tr>
													<td style='line-height: 24px; font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'>
														<h1 style='color: #392F54; font-family: sans-serif; font-weight: bold; line-height: 1.4; font-size: 24px; text-align: left; text-transform: capitalize; margin: 0 0 30px;' align='left'>
															Restauración de contraseña requerida
														</h1>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
														  Tu nombre de usuario para acceder al área de administración es: <strong>%0%</strong>
														</p>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
																<tbody>
																	<tr>
																		<td style='font-family: sans-serif; font-size: 14px; vertical-align: top; border-radius: 5px; text-align: center; background: #35C786;' align='center' bgcolor='#35C786' valign='top'>
																			<a href='%1%' target='_blank' rel='noopener' style='color: #FFFFFF; text-decoration: none; -ms-word-break: break-all; word-break: break-all; border-radius: 5px; box-sizing: border-box; cursor: pointer; display: inline-block; font-size: 14px; font-weight: bold; text-transform: capitalize; background: #35C786; margin: 0; padding: 12px 30px; border: 1px solid #35c786;'>
																				Pulsa este enlace para restaurar tu contraseña
																			</a>
																		</td>
																	</tr>
																</tbody>
															</table>
														</p>
														<p style='max-width: 400px; display: block; color: #392F54; font-family: sans-serif; font-size: 14px; line-height: 20px; font-weight: normal; margin: 15px 0;'>Si no puedes pulsar en el enlace, copia y pega esta dirección URL en tu navegador:</p>
															<table border='0' cellpadding='0' cellspacing='0'>
																<tr>
																	<td style='-ms-word-break: break-all; word-break: break-all; font-family: sans-serif; font-size: 11px; line-height:14px;'>
																		<font style="-ms-word-break: break-all; word-break: break-all; font-size: 11px; line-height:14px;">
																			<a style='-ms-word-break: break-all; word-break: break-all; color: #392F54; text-decoration: underline; font-size: 11px; line-height:15px;' href='%1%'>%1%</a>
																		</font>
																	</td>
																</tr>
															</table>
														</p>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
								<br><br><br>
							</div>
						</td>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
					</tr>
				</table>
			</body>
		</html>
	`
  },
  main: {
    dashboard: "Panel de Administración",
    sections: "Secciones",
    tree: "Contenido"
  },
  moveOrCopy: {
    choose: "Elige una página arriba...",
    copyDone: "%0% ha sido copiado al %1%",
    copyTo: "Selecciona donde el documento %0% debe ser copiado abajo",
    moveDone: "%0% ha sido movido a %1%",
    moveTo: "Selecciona debajo donde mover el documento %0%",
    nodeSelected: "ha sido seleccionado como raíz de tu nuevo contenido, haga clic sobre 'ok' debajo.",
    noNodeSelected: "No ha seleccionado ningún nodo. Selecciona un nodo en la lista mostrada arriba antes de pinchar en 'continuar'",
    notAllowedByContentType: "No se puede colgar el nodo actual bajo el nodo elegido debido a tu tipo",
    notAllowedByPath: "El nodo actual no puede moverse a ninguna de sus subpáginas",
    notAllowedAtRoot: "El nodo actual no puede existir en la raíz",
    notValid: "Acción no permitida. No tienes permisos suficientes para uno o más subnodos.'",
    relateToOriginal: "Relacionar elemento copiado al original"
  },
  notifications: {
    editNotifications: "Edita tu notificación para %0%",
    notificationsSavedFor: "Notificaciones guardadas para %0%",
    notifications: "Notificaciones"
  },
  packager: {
    actions: "Acciones",
    created: "Creada",
    createPackage: "Crear paquete",
    chooseLocalPackageText: 'Elige un paquete de tu máquina, seleccionando el botón Examinar<br />y localizando el paquete. Los paquetes de Umbraco normalmente tienen la extensión ".umb" o ".zip".',
    packageLicense: "Licencia",
    installed: "Instalada",
    installedPackages: "Paquetes instalados",
    noPackages: "No tienes instalado ningún paquete",
    noPackagesDescription: "No tienes instalado ningún paquete. Puedes instalar un paquete local seleccionándolo desde tu ordenador o navegar por los paquetes disponibles usando el icono <strong>'Paquetes'</strong> en la zona superior derecha de tu pantalla",
    packageSearch: "Buscar paquetes",
    packageSearchResults: "Resultados para",
    packageNoResults: "No pudimos encontrar nada para",
    packageNoResultsDescription: "Por favor, prueba buscando por otro paquete o navega por las categorías",
    packagesPopular: "Popular",
    packagesNew: "Novedades",
    packageHas: "tiene",
    packageKarmaPoints: "puntos de karma",
    packageInfo: "Información",
    packageOwner: "Propietario",
    packageContrib: "Contribuidores",
    packageCreated: "Creado",
    packageCurrentVersion: "Versión actual",
    packageNetVersion: "Versión .NET",
    packageDownloads: "Descargas",
    packageLikes: "Me Gusta",
    packageCompatibility: "Compatibilidad",
    packageCompatibilityDescription: "Este paquete es compatible con las siguientes versiones de Umbraco, declaradas según miembros de la comunidad. No se puede garantizar compatibilidad completa para versiones declaradas debajo del 100%",
    packageExternalSources: "Fuentes externas",
    packageAuthor: "Autor",
    packageDocumentation: "Documentación",
    packageMetaData: "Meta datos del paquete",
    packageName: "Nombre del paquete",
    packageNoItemsHeader: "El paquete no contiene ningún elemento",
    packageNoItemsText: 'Este archivo de paquete no contiene ningún elemento para desinstalar.<br /><br />Puedes eliminarlo del sistema de forma segura seleccionando la opción "desinstalar paquete" de abajo.',
    packageOptions: "Opciones del paquete",
    packageReadme: "Léeme del paquete",
    packageRepository: "Repositorio de paquetes",
    packageUninstallConfirm: "Confirma la desinstalación",
    packageUninstalledHeader: "El paquete ha sido desinstalado",
    packageUninstalledText: "El paquete se ha desinstalado correctamente",
    packageUninstallHeader: "Desinstalar paquete",
    packageUninstallText: 'Debajo puedes deseleccionar elementos que no desees eliminar en este momento. Cuando eliges "confirmar la desinstalación" todos los elementos marcados serán eliminados.<br /> <span style="color: Red; font-weight: bold;">Nota:</span> cualquier documento, archivo etc dependiente de los elementos eliminados, dejará de funcionar, y puede conllevar inestabilidad en el sistema, por lo que lleva cuidado al desinstalar elementos. En caso de duda, contacta con el autor del paquete.',
    packageVersion: "Versión del paquete"
  },
  paste: {
    doNothing: "Pegar con formato completo (No recomendado)",
    errorMessage: "El texto que estás intentando pegar contiene caracteres o formato especial. El problema puede ser debido al copiar texto desde Microsoft Word. Umbraco puede eliminar estos caracteres o formato especial automáticamente, de esa manera el contenido será más adecuado para la web.",
    removeAll: "Pegar como texto sin formato",
    removeSpecialFormattering: "Pegar, pero quitando el formato (Recomendado)"
  },
  publicAccess: {
    paAdvanced: "Protección basada en roles",
    paAdvancedHelp: "Si deseas controlar el acceso a la página usando autenticación basada en roles,<br /> usando los grupos de miembros de Umbraco.",
    paAdvancedNoGroups: "Necesitas crear un grupo de miembros antes de poder usar autenticación basada en roles",
    paErrorPage: "Página de error",
    paErrorPageHelp: "Usada cuando alguien hace login, pero no tiene acceso",
    paHowWould: "Elige cómo restringir el acceso a esta página",
    paIsProtected: "%0% está protegido",
    paIsRemoved: "Protección borrada de %0%",
    paLoginPage: "Página de login",
    paLoginPageHelp: "Elige la página que contenga el formulario de login",
    paRemoveProtection: "Borrar protección",
    paSelectPages: "Elige las páginas que contendrán el formulario de login y mensajes de error",
    paSelectRoles: "Elige los roles que tendrán acceso a esta página",
    paSetLogin: "Elige el login y contraseña para esta página",
    paSimple: "Protección de usuario único",
    paSimpleHelp: "Si sólo necesita configurar una protección simple usando un único login y contraseña"
  },
  publish: {
    contentPublishedFailedAwaitingRelease: `

      %0% no se puede publicar porque este elemento está programado para publicarse.
    `,
    contentPublishedFailedExpired: `
      %0% no se pudo publicar porque el elemento ha caducado.
    `,
    contentPublishedFailedInvalid: `
      %0% no se pudo publicar porque estas propiedades:  %1%  no pasaron las reglas de validación.
    `,
    contentPublishedFailedByEvent: "%0% no se pudo publicar debido a que una extensión de otro proveedor ha cancelado la acción.",
    contentPublishedFailedByParent: `
      %0% no se pudo publicar porque una página padre no está publicada.
    `,
    includeUnpublished: "Incluir las páginas hija sin publicar",
    inProgress: "Publicación en progreso - por favor, espera...",
    inProgressCounter: "Se han publicado %0% de %1% páginas...",
    nodePublish: "%0% se ha publicado",
    nodePublishAll: "%0% y sus subpáginas se han publicado",
    publishAll: "Publicar %0% y todas sus subpáginas",
    publishHelp: "Pulsa en <em>aceptar</em> para publicar <strong>%0%</strong> y por lo tanto, hacer que tu contenido esté disponible al público.<br/><br /> Puedes publicar esta página y todas sus subpáginas marcando <em>publicar todos los hijos</em> debajo. "
  },
  colorpicker: {
    noColors: "No has configurado ningún color"
  },
  contentPicker: {
    pickedTrashedItem: "Has seleccionado un elemento borrado o en la papelera de reciclaje",
    pickedTrashedItems: "Has seleccionado unos elementos borrados o en la papelera de reciclaje"
  },
  mediaPicker: {
    pickedTrashedItem: "Has seleccionado un elemento borrado o en la papelera de reciclaje",
    pickedTrashedItems: "Has seleccionado unos elementos borrados o en la papelera de reciclaje"
  },
  relatedlinks: {
    enterExternal: "añadir un enlace externo",
    chooseInternal: "elegir un enlace interno",
    caption: "Título",
    link: "Enlace",
    newWindow: "Abrir en una nueva ventana",
    captionPlaceholder: "Introduce texto",
    externalLinkPlaceholder: "Introduce el enlace"
  },
  imagecropper: {
    reset: "Reiniciar"
  },
  rollback: {
    diffHelp: "Esto muestra las diferencias entre la versión actual y la versión seleccionada<br /><del>Red</del> el texto de la versión seleccionada no se mostrará. , <ins>el verde significa añadido</ins>",
    documentRolledBack: "Se ha recuperado la última versión del documento.",
    htmlHelp: "Esto muestra la versión seleccionada como html, si deseas ver la diferencia entre 2 versiones al mismo tiempo, por favor usa la vista diff",
    rollbackTo: "Volver a",
    selectVersion: "Elige versión",
    view: "Ver"
  },
  scripts: {
    editscript: "Editar fichero de script"
  },
  sections: {
    concierge: "Conserje",
    content: "Contenido",
    courier: "Mensajero",
    developer: "Desarrollador",
    installer: "Asistente de configuración de Umbraco",
    media: "Media",
    member: "Miembros",
    newsletters: "Boletín informativo",
    settings: "Ajustes",
    statistics: "Estadísticas",
    translation: "Traducción",
    users: "Usuarios",
    help: "Ayuda",
    packages: "Paquetes"
  },
  help: {
    theBestUmbracoVideoTutorials: "Los mejores tutoriales en video para Umbraco"
  },
  settings: {
    defaulttemplate: "Plantilla por defecto",
    importDocumentTypeHelp: 'Para importar un tipo de documento encuentra el fichero ".udt" en tu ordenador haciendo clic sobre el botón "Navegar" y pulsando "Importar" (se te solicitará confirmación en la siguiente pantalla)',
    newtabname: "Nuevo nombre de la pestaña",
    nodetype: "Tipo de nodo",
    objecttype: "Tipo",
    stylesheet: "Hoja de estilos",
    script: "Script",
    tab: "Pestaña",
    tabname: "Nombre de la pestaña",
    tabs: "Pestañas",
    contentTypeEnabled: "Tipo de Contenido Maestro activado",
    contentTypeUses: "Este Tipo de Contenido usa",
    noPropertiesDefinedOnTab: 'No existen propiedades para esta pestaña. Haz clic en el enlace "añadir nueva propiedad" para crear una nueva propiedad.',
    addIcon: "Añadir icono"
  },
  sort: {
    sortOrder: "Ordenar",
    sortCreationDate: "Fecha Creado",
    sortDone: "Ordenación completa",
    sortHelp: "Arrastra las diferentes páginas debajo para colocarlas como deberían estar o haz clic en las cabeceras de las columnas para ordenar todas las páginas",
    sortPleaseWait: "Espera por favor, las páginas están siendo ordenadas. El proceso puede durar un poco."
  },
  speechBubbles: {
    validationFailedHeader: "Validación",
    validationFailedMessage: "Los errores de validación deben ser arreglados antes de que el elemento pueda ser guardado",
    operationFailedHeader: "Fallo",
    operationSavedHeader: "Guardado",
    invalidUserPermissionsText: "Insuficientes permisos de usuario, no se pudo completar la operación",
    operationCancelledHeader: "Cancelado",
    operationCancelledText: "La operación fue cancelada fue cancelada por un complemento de terceros",
    contentPublishedFailedByEvent: "La publicación fue cancelada por un complemento de terceros",
    contentTypeDublicatePropertyType: "El tipo de propiedad ya existe",
    contentTypePropertyTypeCreated: "Tipo de propiedad creado",
    contentTypePropertyTypeCreatedText: "Nombre: %0% <br /> Tipo de Dato: %1%",
    contentTypePropertyTypeDeleted: "Tipo de propiedad eliminado",
    contentTypeSavedHeader: "Tipo de contenido guardado",
    contentTypeTabCreated: "Pestaña creada",
    contentTypeTabDeleted: "Pestaña eliminada",
    contentTypeTabDeletedText: "Pestaña con id: %0% eliminada",
    cssErrorHeader: "La hoja de estilos no se ha guardado",
    cssSavedHeader: "Hoja de estilos guardada",
    cssSavedText: "La hoja de estilos se ha guardado sin errores",
    dataTypeSaved: "Tipo de dato guardado",
    dictionaryItemSaved: "Elemento del diccionario guardado",
    editContentPublishedFailedByParent: "La publicación ha fallado porque la página padre no está publicada",
    editContentPublishedHeader: "Contenido publicado",
    editContentPublishedText: "y visible en el sitio web",
    editContentSavedHeader: "Contenido guardado",
    editContentSavedText: "Recuerda publicar para hacer los cambios visibles",
    editContentSendToPublish: "Mandado para ser aprobado",
    editContentSendToPublishText: "Los cambios se han mandado para ser aprobados",
    editMediaSaved: "Medio guardado",
    editMediaSavedText: "Medio guardado sin errores",
    editMemberSaved: "Miembro guardado",
    editStylesheetPropertySaved: "Propiedad de la hoja de estilos guardada",
    editStylesheetSaved: "Hoja de estilos guardada",
    editTemplateSaved: "Plantilla guardada",
    editUserError: "Error grabando usuario (comprueba el log)",
    editUserSaved: "Usuario grabado",
    editUserTypeSaved: "Tipo de usuario guardado",
    editUserGroupSaved: "Grupo de usuario guardado",
    fileErrorHeader: "El archivo no se ha guardado",
    fileErrorText: "El archivo no se ha grabado. Por favor, comprueba los permisos de los ficheros",
    fileSavedHeader: "Archivo guardado",
    fileSavedText: "Archivo grabado sin errores",
    languageSaved: "Lenguaje guardado",
    mediaTypeSavedHeader: "Tipo de medio guardado",
    memberTypeSavedHeader: "Tipo de miembro guardado",
    templateErrorHeader: "La plantilla no se ha guardado",
    templateErrorText: "Por favor, asegúrate de que no hay 2 plantillas con el mismo alias",
    templateSavedHeader: "Plantilla guardada",
    templateSavedText: "Plantilla guardada sin errores",
    contentUnpublished: "Contenido oculto",
    partialViewSavedHeader: "Vista parcial guardada",
    partialViewSavedText: "Vista parcial guardada sin errores",
    partialViewErrorHeader: "Vista parcial no guardada",
    partialViewErrorText: "Error guardando el archivo.",
    permissionsSavedFor: "Permisos guardados para",
    deleteUserGroupsSuccess: "Borrados %0% grupos de usuario",
    deleteUserGroupSuccess: "%0% fue borrado",
    enableUsersSuccess: "%0% usuarios activados",
    disableUsersSuccess: "%0% usuarios desactivados",
    enableUserSuccess: "%0% usuario activado",
    disableUserSuccess: "%0% desactivado",
    setUserGroupOnUsersSuccess: "Grupos de usuario establecidos",
    unlockUsersSuccess: "%0% usuarios desbloqueados",
    unlockUserSuccess: "%0% está desbloqueado"
  },
  stylesheet: {
    aliasHelp: "Usa sintaxis CSS, p.ej.: h1, .redHeader, .blueTex",
    editstylesheet: "Editar hoja de estilos",
    editstylesheetproperty: "Editar propiedades de la hoja de estilos",
    nameHelp: "Nombre para identificar la propiedad del estilo en el editor de texto rico",
    preview: "Previsualizar",
    styles: "Estilos"
  },
  template: {
    edittemplate: "Editar plantilla",
    insertSections: "Secciones",
    insertContentArea: "Insertar área de contenido",
    insertContentAreaPlaceHolder: "Insertar marcador de posición de área de contenido",
    insert: "Insertar",
    insertDesc: "Elige que insertar en tu plantilla",
    insertDictionaryItem: "Insertar objeto del diccionario",
    insertDictionaryItemDesc: "Un objeto de diccionario es una variable para un texto traducible, lo que facilita crear sitios multi idioma.",
    insertMacro: "Insertar macro",
    insertMacroDesc: `
            Una Macro es un componente configurable que es genial como partes reutilizables de tu diseño,
            donde necesites una forma de proporcionar parámetros,
            como galerías, formularios y listas.
        `,
    insertPageField: "Insertar campo de página de Umbraco",
    insertPageFieldDesc: "Muestra el valor de una propiedad de la página actual, con opciones para modificar el valor o usar valores alternativos.",
    insertPartialView: "Vista parcial",
    insertPartialViewDesc: `
            Una vista parcial es una platilla separada que puede ser mostrada dentro de otra plantilla.
            Es útil para reutilizar código o para distribuir plantillas complejas en archivos separados.
        `,
    mastertemplate: "Plantilla principal",
    noMaster: "Sin principal",
    renderBody: "Mostrar plantilla hija",
    renderBodyDesc: `
          Muestra el contenido de una plantilla hija, insertando <code>@RenderBody()</code> como sustituto.
      `,
    defineSection: "Define una sección nombrada",
    defineSectionDesc: `
          Define una parte de tu plantilla como sección nombrada rodeándola en
          <code>@section { ... }</code>. Esto se puede mostrar en un área específica de la plantilla madre usando <code>@RenderSection</code>.
      `,
    renderSection: "Muestra una sección nombrada",
    renderSectionDesc: `
          Muestra un area nombrada de una plantilla hija insertando <code>@RenderSection(name)</code> placeholder.
          Esto muestra un area de una plantilla hija rodeada de la correspondiente definición <code>@section [name]{ ... }</code>.
      `,
    sectionName: "Nombre de sección",
    sectionMandatory: "Sección es obligatoria",
    sectionMandatoryDesc: `
            Si está marcada como obligatoria, la plantilla hija debe contener una definición de <code>@section</code> o se mostrará un error.
    `,
    queryBuilder: "Constructor de consultas",
    itemsReturned: "elementos devueltos, en",
    iWant: "Quiero",
    allContent: "todo contenido",
    contentOfType: 'contenido de tipo "%0%"',
    from: "desde",
    websiteRoot: "mi sitio web",
    where: "donde",
    and: "y",
    is: "es",
    isNot: "no es",
    before: "antes",
    beforeIncDate: "antes (incluyendo fecha seleccionada)",
    after: "después",
    afterIncDate: "después (incluyendo fecha seleccionada)",
    equals: "igual a",
    doesNotEqual: "no igual a",
    contains: "contiene",
    doesNotContain: "no contiene",
    greaterThan: "mayor que",
    greaterThanEqual: "mayor o igual ",
    lessThan: "menor que",
    lessThanEqual: "menor o igual a",
    id: "Id",
    name: "Nombre",
    createdDate: "Creado en",
    lastUpdatedDate: "Última actualización",
    orderBy: "ordenar por",
    ascending: "ascendente",
    descending: "descendente",
    quickGuide: "Guía rápida sobre las etiquetas de plantilla de Umbraco",
    template: "Plantilla"
  },
  grid: {
    media: "Imagen",
    macro: "Macro",
    insertControl: "Insertar control",
    chooseLayout: "Elige configuración",
    addRows: "Añade más filas",
    addElement: "Añadir contenido",
    dropElement: "Soltar contenido",
    settingsApplied: "Configuración aplicada",
    contentNotAllowed: "Contenido no permitido aquí",
    contentAllowed: "Contenido permitido aquí",
    clickToEmbed: "Pulsa para insertar",
    clickToInsertImage: "Pulsa para insertar imagen",
    placeholderWriteHere: "Escribe aquí...",
    gridLayouts: "Plantillas de Grid",
    gridLayoutsDetail: "Las plantillas son el área de trabajo para el editor de grids, normalmente sólo necesitas una o dos plantillas diferentes",
    addGridLayout: "Añadir plantilla de grid",
    addGridLayoutDetail: "Ajusta la plantilla configurando la anchura de las columnas y añadiendo más secciones",
    rowConfigurations: "Configuraciones de filas",
    rowConfigurationsDetail: "Las filas son celdas predefinidas que se disponen horizontalmente",
    addRowConfiguration: "Añade una configuración de fila",
    addRowConfigurationDetail: "Ajusta la fila configurando los anchos de cada celda y añadiendo más celdas",
    columns: "Columnas",
    columnsDetails: "Número total de columnas en la plantilla del grid",
    settings: "Configuración",
    settingsDetails: "Configura qué ajustes pueden cambiar los editores",
    styles: "Estilos",
    stylesDetails: "Configura qué estilos pueden cambiar los editores",
    allowAllEditors: "Permitir todos los controles de edición",
    allowAllRowConfigurations: "Permitir todas las configuraciones de fila",
    maxItemsDescription: "Dejar en blanco o establece en 0 para ilimitada",
    maxItems: "Artículos máximos",
    setAsDefault: "Establecer por defecto",
    chooseExtra: "Elegir extra",
    chooseDefault: "Elegir por defecto",
    areAdded: "son añadidos"
  },
  contentTypeEditor: {
    compositions: "Composiciones",
    noGroups: "No has añadido ninguna pestaña",
    inheritedFrom: "Heredado de",
    addProperty: "Añadir propiedad",
    requiredLabel: "Etiqueta requerida",
    enableListViewHeading: "Activar vista de lista",
    enableListViewDescription: "Configura la página para mostrar una lista de sus hijas que puedes ordenar y buscar, los hijas no se mostrarán en el árbol de contenido",
    allowedTemplatesHeading: "Platillas permitidas",
    allowedTemplatesDescription: "Elige que plantillas se permite a los editores utilizar en contenido de este tipo",
    allowAsRootHeading: "Permitir como raíz",
    allowAsRootDescription: "Permite a los editores crear contenido de este tipo en la raíz del árbol de contenido",
    childNodesHeading: "Tipos de nodos hijos permitidos",
    childNodesDescription: "Permite contenido de los tipos permitidos ser creados debajo de este tipo de contenido ",
    chooseChildNode: "Elegir nodo hijo",
    compositionsDescription: "Heredar pestañas y propiedades de un tipo de documento existente. Nuevas pestañas serán añadidas al tipo de documento actual o mezcladas si una pestaña con nombre idéntico ya existe.",
    compositionInUse: "Este tipo de contenido es usado en una composición, y por tanto no puede no puede ser compuesto.",
    noAvailableCompositions: "No hay tipos de contenido disponibles para usar como composición.",
    availableEditors: "Editores disponibles",
    reuse: "Reusar",
    editorSettings: "Configuración de editor",
    configuration: "Configuración",
    yesDelete: "Si, borrar",
    movedUnderneath: "se movió debajo",
    copiedUnderneath: "se copió debajo",
    folderToMove: "Selecciona la carpeta a mover",
    folderToCopy: "Selecciona la carpeta a copiar",
    structureBelow: "en la estructura de árbol debajo",
    allDocumentTypes: "Todos tipos de documentos",
    allDocuments: "Todos los documentos",
    allMediaItems: "Todos los tipos de medio",
    usingThisDocument: "usar este tipo de documento lo borrará permanentemente, por favor confirma que quieres borrarlos también.",
    usingThisMedia: "usar este tipo de media lo borrará permanentemente, por favor confirma que quieres borrarlos también.",
    usingThisMember: "usar este tipo de miembro lo borrará permanentemente, por favor confirma que quieres borrarlos también.",
    andAllDocuments: "y todos los documentos usando este tipo",
    andAllMediaItems: "y todos los medios usando este tipo",
    andAllMembers: "y todos los miembros usando este tipo",
    memberCanEdit: "Miembro puede editar",
    showOnMemberProfile: "Mostrar en perfil de miembro",
    tabHasNoSortOrder: "pestaña no tiene orden"
  },
  languages: {
    addLanguage: "Agregar idioma",
    culture: "Código ISO",
    mandatoryLanguage: "Idioma obligatorio",
    mandatoryLanguageHelp: `
      Las propiedades en este idioma deben completarse antes de que se pueda publicar el nodo.
    `,
    defaultLanguage: "Idioma predeterminado",
    defaultLanguageHelp: "Un sitio de Umbraco solo puede tener un conjunto de idiomas predeterminado.",
    changingDefaultLanguageWarning: "Cambiar el idioma predeterminado puede provocar que falte el contenido predeterminado.",
    fallsbackToLabel: "Vuelve a caer",
    noFallbackLanguageOption: "Sin lenguaje alternativo",
    fallbackLanguageDescription: `
      Para permitir que el contenido multilingüe retroceda a otro idioma si no está presente en el idioma solicitado, selecciónelo aquí.
    `,
    fallbackLanguage: "Idioma de retroceso",
    none: "ninguno"
  },
  modelsBuilder: {
    buildingModels: "Construyendo modelos",
    waitingMessage: "esto puede llevar un rato, no te preocupes",
    modelsGenerated: "Modelos generados",
    modelsGeneratedError: "Los modelos no se pudieron generar",
    modelsExceptionInUlog: "La generación de los modelos has fallado, ve la excepción en U log"
  },
  templateEditor: {
    addDefaultValue: "Añadir valor por defecto",
    defaultValue: "Valor por defecto",
    alternativeField: "Campo opcional",
    alternativeText: "Texto opcional",
    casing: "MAYÚSCULA/minúscula",
    chooseField: "Elegir campo",
    convertLineBreaks: "Convertir a salto de línea",
    convertLineBreaksHelp: "Reemplaza los saltos de línea con la etiqueta HTML &lt;br&gt;",
    customFields: "Campos personalizados",
    dateOnly: "Si, solamente la fecha",
    formatAsDate: "Cambiar formato a fecha",
    htmlEncode: "Codificar HTML",
    htmlEncodeHelp: "Se reemplazarán los caracteres especiales por tu código HTML equivalente.",
    insertedAfter: "Será insertado después del valor del campo",
    insertedBefore: "Será insertado antes del valor del campo",
    lowercase: "Minúscula",
    none: "Ninguno/ninguna",
    outputSample: "Ejemplo de salida",
    postContent: "Insertar después del campo",
    preContent: "Insertar antes del campo",
    recursive: "Recursivo",
    recursiveDescr: "Sí, hacerlo recursivo",
    standardFields: "Campos estándar",
    uppercase: "Mayúscula",
    urlEncode: "Codificar URL",
    urlEncodeHelp: "Formateará los caracteres especiales de las URLs",
    usedIfAllEmpty: "Sólo será usado cuando el campo superior esté vacío",
    usedIfEmpty: "Este campo será usado únicamente si el campo primario está vacío",
    withTime: "Si, con el tiempo. Separador:"
  },
  translation: {
    details: "Detalles de traducción",
    DownloadXmlDTD: "Descargar xml DTD",
    fields: "Campos",
    includeSubpages: "Incluir subpáginas",
    mailBody: `
        Hola %0%.

        Este mail se ha generado automáticamente para informale que %2% has solicitado que el documento '%1%' sea traducido en '%5%'.

        Para editarlo, vaya a la dirección http://%3%/translation/details.aspx?id=%4% o inicia sesión en Umbraco y ve a http://%3% para ver las tareas pendientes de traducir.

        Espero que tenga un buen dia.

        Saludos de parte de el robot de Umbraco
    `,
    noTranslators: "No se encontraron usuarios traductores. Por favor, crea un usuario traductor antes de empezar a mandar contenido para tu traducción",
    pageHasBeenSendToTranslation: "La página '%0%' se ha mandado a traducción",
    sendToTranslate: "Manda la página '%0%' a traducción",
    totalWords: "Total de palabras",
    translateTo: "Traducir a",
    translationDone: "Traducción hecha.",
    translationDoneHelp: "Puedes previsualizar las páginas que acabas de traducir, pulsando debajo. Si la página original existe, se mostrará una comparación de las 2 páginas.",
    translationFailed: "La traducción ha fallado. El archivo xml es inválido ",
    translationOptions: "Opciones para traducir",
    translator: "Traductor",
    uploadTranslationXml: "Subir traducción xml"
  },
  treeHeaders: {
    content: "Contenido",
    contentBlueprints: "Plantillas de Contenido",
    media: "Media",
    cacheBrowser: "Caché del navegador",
    contentRecycleBin: "Papelera de reciclaje",
    createdPackages: "Paquetes creados",
    dataTypes: "Tipos de datos",
    dictionary: "Diccionario",
    installedPackages: "Paquetes instalados",
    installSkin: "Instalar skin",
    installStarterKit: "Instalar starter kit",
    languages: "Idiomas",
    localPackage: "Instalar paquete local",
    macros: "Macros",
    mediaTypes: "Tipos de medios",
    member: "Miembros",
    memberGroups: "Grupos de miembros",
    memberRoles: "Roles",
    memberTypes: "Tipos de miembros",
    documentTypes: "Tipos de documento",
    relationTypes: "Tipos de relaciones",
    packager: "Paquetes",
    packages: "Paquetes",
    partialViews: "Vistas Parciales",
    partialViewMacros: "Vistas Parciales para Macros",
    repositories: "Instalar desde repositorio",
    runway: "Instalar pasarela",
    runwayModules: "Módulos pasarela",
    scripting: "Ficheros de script",
    scripts: "Scripts",
    stylesheets: "Hojas de estilo",
    templates: "Plantillas",
    logViewer: "Visor de registro",
    users: "Usuarios",
    settingsGroup: "Ajustes"
  },
  update: {
    updateAvailable: "Existe una nueva actualización",
    updateDownloadText: "%0% esta listo, pulsa aquí para descargar",
    updateNoServer: "No hay conexión al servidor",
    updateNoServerError: 'Error al comprobar la actualización. Por favor revisa "trace-stack" para conseguir más información.'
  },
  user: {
    access: "Acceso",
    accessHelp: "Basado en los grupos asignados y los nodos iniciales, el usuario tiene acceso a los siguientes nodos.",
    assignAccess: "Asignar acceso",
    administrators: "Administrador",
    categoryField: "Campo de categoría",
    changePassword: "Cambiar contraseña",
    changePhoto: "Cambiar foto",
    newPassword: "Nueva contraseña",
    noLockouts: "no ha sido bloqueado",
    noPasswordChange: "La contraseña no se ha cambiado",
    confirmNewPassword: "Confirma nueva contraseña",
    changePasswordDescription: "Puedes cambiar tu contraseña para acceder al 'back office' de Umbraco rellenando el siguiente formulario y haciendo clic en el botón 'Cambiar contraseña'",
    contentChannel: "Canal de contenido",
    createAnotherUser: "Crear otro usuario",
    createUserHelp: "Crear nuevos usuarios para darles acceso a Umbraco. Cuando un nuevo usuario es creado, una nueva contraseña será generada y la podrás compartir con el usuario.",
    descriptionField: "Campo descriptivo",
    disabled: "Deshabilitar usuario",
    documentType: "Tipo de documento",
    editors: "Editor",
    excerptField: "Campo de citas",
    failedPasswordAttempts: "Intentos de acceso fallidos",
    goToProfile: "Ir a perfil de usuario",
    groupsHelp: "Añadir grupos para asignar acceso y permisos",
    inviteAnotherUser: "Invitar otro usuario",
    inviteUserHelp: "Invita nuevos usuarios para darles acceso a Umbraco. Un email de invitación será enviado al usuario con información sobre cómo acceder a Umbraco.",
    language: "Idioma",
    languageHelp: "Establecer el idioma que verás en menús y diálogos",
    lastLockoutDate: "Última fecha bloqueado",
    lastLogin: "Último acceso",
    lastPasswordChangeDate: "Última contraseña cambiada",
    loginname: "Acceso",
    mediastartnode: "Nodo de comienzo en la biblioteca de medios",
    mediastartnodehelp: "Limitar la biblioteca de medios al siguiente nodo de inicio",
    mediastartnodes: "Nodos de inicio para Medios",
    mediastartnodeshelp: "Limitar la biblioteca de medios a los siguientes nodos de inicio",
    modules: "Secciones",
    noConsole: "Deshabilitar acceso a Umbraco",
    noLogin: "no se ha conectado aún",
    oldPassword: "Contraseña antigua",
    password: "Contraseña",
    resetPassword: "Reiniciar contraseña",
    passwordChanged: "Tu contraseña ha sido cambiada",
    passwordConfirm: "Por favor confirma tu nueva contraseña",
    passwordEnterNew: "Introduce tu nueva contraseña",
    passwordIsBlank: "La nueva contraseña no puede estar vacía",
    passwordCurrent: "Contraseña actual",
    passwordInvalid: "Contraseña actual inválida",
    passwordIsDifferent: "La nueva contraseña no coincide con la contraseña de confirmación. Por favor, vuele a intentarlo!",
    passwordMismatch: "La contraseña de confirmación no coincide con la nueva contraseña!",
    permissionReplaceChildren: "Reemplazar los permisos de los nodos hijo",
    permissionSelectedPages: "Estás modificando los permisos para las páginas:",
    permissionSelectPages: "Selecciona las páginas para modificar sus permisos",
    removePhoto: "Eliminar imagen",
    permissionsDefault: "Permisos por defecto",
    permissionsGranular: "Permisos granulares",
    permissionsGranularHelp: "Establecer permisos para nodos específicos",
    profile: "Perfil",
    searchAllChildren: "Buscar en todos los hijos",
    languagesHelp: "Limite los idiomas a los que los usuarios tienen acceso para editar",
    allowAccessToAllLanguages: "Permitir el acceso a todos los idiomas",
    sectionsHelp: "Añadir secciones para dar acceso a usuarios",
    selectUserGroups: "Seleccionar grupos de usuarios",
    noStartNode: "Nodo de inicio no seleccionado",
    noStartNodes: "Nodos de inicio no seleccionado",
    startnode: "Nodo de comienzo en contenido",
    startnodehelp: "Limitar el árbol de contenido a un nodo de inicio específico",
    startnodes: "Nodos de inicio de contenido",
    startnodeshelp: "Limitar el árbol de contenido a unos nodos de inicio específicos",
    updateDate: "Última actualización en usuario",
    userCreated: "ha sido creado",
    userCreatedSuccessHelp: "Se ha creado el nuevo usuario con éxito. Para acceder a Umbraco usa la contraseña siguiente.",
    userManagement: "Administración de usuario",
    username: "Nombre de usuario",
    userPermissions: "Permisos de usuarios",
    usergroup: "Grupo de usuario",
    userInvited: "ha sido invitado",
    userInvitedSuccessHelp: "Se ha enviado una invitación al nuevo usuario con detalles sobre cómo acceder a Umbraco.",
    userinviteWelcomeMessage: "¡Hola y bienvenido a Umbraco!. En un minuto todo estará listo para empezar, sólo necesitamos que configures tu contraseña.",
    writer: "Redactor",
    change: "Cambiar",
    yourProfile: "Tu perfil",
    yourHistory: "Tu historial reciente",
    sessionExpires: "La sesión caduca en",
    inviteUser: "Invitar usuario",
    createUser: "Crear usuario",
    sendInvite: "Enviar invitación",
    backToUsers: "Volver a usuarios",
    inviteEmailCopySubject: "Umbraco: Invitación",
    inviteEmailCopyFormat: `
        <html>
			<head>
				<meta name='viewport' content='width=device-width'>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
			</head>
			<body class='' style='font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; color: #392F54; line-height: 22px; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background: #1d1333; margin: 0; padding: 0;' bgcolor='#1d1333'>
				<style type='text/css'> @media only screen and (max-width: 620px) {table[class=body] h1 {font-size: 28px !important; margin-bottom: 10px !important; } table[class=body] .wrapper {padding: 32px !important; } table[class=body] .article {padding: 32px !important; } table[class=body] .content {padding: 24px !important; } table[class=body] .container {padding: 0 !important; width: 100% !important; } table[class=body] .main {border-left-width: 0 !important; border-radius: 0 !important; border-right-width: 0 !important; } table[class=body] .btn table {width: 100% !important; } table[class=body] .btn a {width: 100% !important; } table[class=body] .img-responsive {height: auto !important; max-width: 100% !important; width: auto !important; } } .btn-primary table td:hover {background-color: #34495e !important; } .btn-primary a:hover {background-color: #34495e !important; border-color: #34495e !important; } .btn  a:visited {color:#FFFFFF;} </style>
				<table border="0" cellpadding="0" cellspacing="0" class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;" bgcolor="#1d1333">
					<tr>
						<td style="font-family: sans-serif; font-size: 14px; vertical-align: top; padding: 24px;" valign="top">
							<table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;">
								<tr>
									<td background="https://umbraco.com/umbraco/assets/img/application/logo.png" bgcolor="#1d1333" width="28" height="28" valign="top" style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
										<!--[if gte mso 9]> <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:30px;height:30px;"> <v:fill type="tile" src="https://umbraco.com/umbraco/assets/img/application/logo.png" color="#1d1333" /> <v:textbox inset="0,0,0,0"> <![endif]-->
										<div> </div>
										<!--[if gte mso 9]> </v:textbox> </v:rect> <![endif]-->
									</td>
									<td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top"></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;' bgcolor='#1d1333'>
					<tr>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
						<td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 560px; width: 560px; margin: 0 auto; padding: 10px;' valign='top'>
							<div class='content' style='box-sizing: border-box; display: block; max-width: 560px; margin: 0 auto; padding: 10px;'>
								<br>
								<table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; border-radius: 3px; background: #FFFFFF;' bgcolor='#FFFFFF'>
									<tr>
										<td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 50px;' valign='top'>
											<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
												<tr>
													<td style='line-height: 24px; font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'>
														<h1 style='color: #392F54; font-family: sans-serif; font-weight: bold; line-height: 1.4; font-size: 24px; text-align: left; text-transform: capitalize; margin: 0 0 30px;' align='left'>
															Hi %0%,
														</h1>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Has sido invitado por <a href="mailto:%1%" style="text-decoration: underline; color: #392F54; -ms-word-break: break-all; word-break: break-all;">%1%</a> a Umbraco Administración.
														</p>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Mensaje de <a href="mailto:%1%" style="text-decoration: none; color: #392F54; -ms-word-break: break-all; word-break: break-all;">%1%</a>:
															<br/>
															<em>%2%</em>
														</p>
														<table border='0' cellpadding='0' cellspacing='0' class='btn btn-primary' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; box-sizing: border-box;'>
															<tbody>
																<tr>
																	<td align='left' style='font-family: sans-serif; font-size: 14px; vertical-align: top; padding-bottom: 15px;' valign='top'>
																		<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
																			<tbody>
																				<tr>
																					<td style='font-family: sans-serif; font-size: 14px; vertical-align: top; border-radius: 5px; text-align: center; background: #35C786;' align='center' bgcolor='#35C786' valign='top'>
																						<a href='%3%' target='_blank' rel='noopener' style='color: #FFFFFF; text-decoration: none; -ms-word-break: break-all; word-break: break-all; border-radius: 5px; box-sizing: border-box; cursor: pointer; display: inline-block; font-size: 14px; font-weight: bold; text-transform: capitalize; background: #35C786; margin: 0; padding: 12px 30px; border: 1px solid #35c786;'>
																							Pulsa este enlace para aceptar la invitación
																						</a>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
															</tbody>
														</table>
														<p style='max-width: 400px; display: block; color: #392F54; font-family: sans-serif; font-size: 14px; line-height: 20px; font-weight: normal; margin: 15px 0;'>Si no puedes pulsar el enlace, Copia y pega esta URL en tu navegador:</p>
															<table border='0' cellpadding='0' cellspacing='0'>
																<tr>
																	<td style='-ms-word-break: break-all; word-break: break-all; font-family: sans-serif; font-size: 11px; line-height:14px;'>
																		<font style="-ms-word-break: break-all; word-break: break-all; font-size: 11px; line-height:14px;">
																			<a style='-ms-word-break: break-all; word-break: break-all; color: #392F54; text-decoration: underline; font-size: 11px; line-height:15px;' href='%3%'>%3%</a>
																		</font>
																	</td>
																</tr>
															</table>
														</p>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
								<br><br><br>
							</div>
						</td>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
					</tr>
				</table>
			</body>
    </html>`
  },
  validation: {
    validation: "Validación",
    validateAsEmail: "Validar como email",
    validateAsNumber: "Validar como número",
    validateAsUrl: "Validar como URL",
    enterCustomValidation: "...o introduce tu propia validación",
    fieldIsMandatory: "Campo obligatorio",
    validationRegExp: "Introduce una expresión regular",
    minCount: "Necesitas añadir al menos",
    maxCount: "Sólo puedes tener",
    items: "elementos",
    itemsSelected: "elementos seleccionados",
    invalidDate: "Fecha no válida",
    invalidNumber: "No es un número",
    invalidEmail: "Email no válido"
  },
  healthcheck: {
    checkSuccessMessage: "El valor fue establecido en el valor recomendado: '%0%'.",
    checkErrorMessageDifferentExpectedValue: "Valor esperado '%1%' para '%2%' en fichero de configuración '%3%', pero se encontró '%0%'.",
    checkErrorMessageUnexpectedValue: "Se encontró un valor inesperado '%0%' para '%2%' en fichero de configuración '%3%'.",
    macroErrorModeCheckSuccessMessage: "MacroErrors establecidos en '%0%'.",
    macroErrorModeCheckErrorMessage: "MacroErrors están establecidos en '%0%' lo que prevendrá que algunas o todas las página de tu sitio no carguen completamente si hay algún error en una macro. Rectifica esto estableciendo un valor de '%1%'.",
    httpsCheckValidCertificate: "El certificado de tu sitio es válido.",
    httpsCheckInvalidCertificate: "Error validando certificado: '%0%'",
    httpsCheckExpiredCertificate: "El certificado SSL de tu sitio ha caducado.",
    httpsCheckExpiringCertificate: "El certificado SSL de tu sitio caducará en %0% días.",
    healthCheckInvalidUrl: "Error haciendo ping a la URL %0% - '%1%'",
    httpsCheckIsCurrentSchemeHttps: "Actualmente estás %0% viendo el sitio usando el esquema HTTPS.",
    compilationDebugCheckSuccessMessage: "Modo Debug en compilación está desactivado.",
    compilationDebugCheckErrorMessage: "Modo Debug en compilación está activado. Se recomienda desactivarlo antes de publicar el sitio.",
    clickJackingCheckHeaderFound: "El header or meta-tag <strong>X-Frame-Options</strong> usado para controlar si un sitio puede ser IFRAMEd por otra fue encontrado.",
    clickJackingCheckHeaderNotFound: "El header or meta-tag <strong>X-Frame-Options</strong> usado para controlar si un sitio puede ser IFRAMEd por otra no se ha encontrado.",
    excessiveHeadersFound: "The following headers revealing information about the website technology were found: <strong>%0%</strong>.",
    excessiveHeadersNotFound: "No se ha encontrado ninguna cabecera que revele información sobre la tecnología del sitio.",
    smtpMailSettingsConnectionSuccess: "Los valores SMTP están configurados correctamente y el servicio opera con normalidad.",
    notificationEmailsCheckSuccessMessage: "Email de notificación has sido configurado como <strong>%0%</strong>.",
    notificationEmailsCheckErrorMessage: "El email de notificación está todavía configurado en tuvalor por defecto: <strong>%0%</strong>."
  },
  redirectUrls: {
    disableUrlTracker: "Desactivar URL tracker",
    enableUrlTracker: "Activar URL tracker",
    originalUrl: "URL Original",
    redirectedTo: "Redirigido a To",
    noRedirects: "No se ha creado ninguna redirección",
    noRedirectsDescription: "Cuando una página es renombrada o movida, una redirección a la nueva página es automáticamente creada.",
    redirectRemoved: "Redirección URL eliminada.",
    redirectRemoveError: "Error borrando la redirección URL.",
    confirmDisable: "¿Seguro que quieres desactivar URL tracker?",
    disabledConfirm: "URL tracker ha sido desactivado.",
    disableError: "Error desactivando URL tracker, más información se puede encontrar en los logs.",
    enabledConfirm: "URL tracker ha sido activado.",
    enableError: "Error activando URL tracker, más información se puede encontrar en los logs."
  },
  emptyStates: {
    emptyDictionaryTree: "No hay elementos de Diccionario para elegir"
  },
  textbox: {
    characters_left: "caracteres restantes"
  },
  logViewer: {
    selectAllLogLevelFilters: "Seleccionar todo",
    deselectAllLogLevelFilters: "Deseleccionar todo"
  }
};
export {
  e as default
};
//# sourceMappingURL=es-es-Dwcyx_Da.js.map
