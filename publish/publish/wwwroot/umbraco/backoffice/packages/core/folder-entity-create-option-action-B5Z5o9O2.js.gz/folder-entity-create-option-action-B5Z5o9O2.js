import { UmbCreateFolderEntityAction as o } from "@umbraco-cms/backoffice/tree";
class i extends o {
  constructor(e, t) {
    super(e, { ...t, meta: { ...t.meta } });
  }
}
export {
  i as UmbFolderCreateOptionAction,
  i as api
};
//# sourceMappingURL=folder-entity-create-option-action-B5Z5o9O2.js.map
