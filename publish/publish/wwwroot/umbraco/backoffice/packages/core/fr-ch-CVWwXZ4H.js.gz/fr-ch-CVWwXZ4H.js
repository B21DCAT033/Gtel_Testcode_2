import r from "./fr-fr-BTNJAZQp.js";
const o = {
  // NOTE: Imports and re-exports the French (France) localizations, so that any French (Switzerland) localizations can be override them. [LK]
  ...r
};
export {
  o as default
};
//# sourceMappingURL=fr-ch-CVWwXZ4H.js.map
