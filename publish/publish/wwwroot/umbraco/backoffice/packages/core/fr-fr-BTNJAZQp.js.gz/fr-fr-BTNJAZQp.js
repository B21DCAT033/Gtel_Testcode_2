const e = {
  actions: {
    assigndomain: "Culture et noms d'hôte",
    auditTrail: "Informations d'audit",
    browse: "Parcourir",
    changeDocType: "Changer le type de document",
    copy: "Copier",
    create: "Créer",
    export: "Exporter",
    createPackage: "Créer un package",
    createGroup: "Créer un groupe",
    delete: "Supprimer",
    disable: "Désactiver",
    emptyrecyclebin: "Vider la corbeille",
    enable: "Activer",
    exportDocumentType: "Exporter le type de document",
    importdocumenttype: "Importer un type de document",
    importPackage: "Importer un package",
    liveEdit: "Editer dans Canvas",
    logout: "Déconnexion",
    move: "Déplacer",
    notify: "Notifications",
    protect: "Accès public",
    publish: "Publier",
    unpublish: "Dépublier",
    refreshNode: "Rafraîchir",
    republish: "Republier le site tout entier",
    rename: "Renommer",
    restore: "Récupérer",
    chooseWhereToCopy: "Choisissez où copier",
    chooseWhereToMove: "Choisissez où déplacer",
    chooseWhereToImport: "Choisissez où importer",
    toInTheTreeStructureBelow: "dans l'arborescence ci-dessous",
    wasMovedTo: "a été déplacé vers",
    wasCopiedTo: "a été copié vers",
    wasDeleted: "a été supprimé",
    rights: "Permissions",
    rollback: "Version antérieure",
    sendtopublish: "Envoyer pour publication",
    sendToTranslate: "Envoyer pour traduction",
    setGroup: "Spécifier le groupe",
    sort: "Trier",
    translate: "Traduire",
    update: "Mettre à jour",
    setPermissions: "Spécifier les permissions",
    unlock: "Débloquer",
    createblueprint: "Créer un modèle de contenu",
    resendInvite: "Envoyer à nouveau l'invitation"
  },
  actionCategories: {
    content: "Contenu",
    administration: "Administration",
    structure: "Structure",
    other: "Autre"
  },
  actionDescriptions: {
    assignDomain: "Permettre d'attribuer la culture et des noms d'hôte",
    auditTrail: "Permettre d'accéder au journal d'historique d'un noeud",
    browse: "Permettre d'accéder à un noeud",
    changeDocType: "Permettre de modifier le type de document d'un noeud",
    copy: "Permettre de copier un noeud",
    create: "Permettre de créer des noeuds",
    delete: "Permettre de supprimer des noeuds",
    move: "Permettre de déplacer un noeud",
    protect: "Permettre de définir et modifier l'accès public à un noeud",
    publish: "Permettre de publier un noeud",
    unpublish: "Permettre d'annuler la publication d'un noeud",
    rights: "Permettre de modifier les permissions pour un noeud",
    rollback: "Permettre de revenir à une situation antérieure",
    sendtopublish: "Permettre d'envoyer un noeud pour approbation avant publication",
    sendToTranslate: "Permettre d'envoyer un noeud à la traduction",
    sort: "Permettre de modifier l'ordonnancement des noeuds",
    translate: "Permettre de traduire un noeud",
    update: "Permettre de sauvegarder un noeud",
    createblueprint: "Permettre la création d'un Modèle de Contenu"
  },
  apps: {
    umbContent: "Contenu",
    umbInfo: "Info"
  },
  assignDomain: {
    permissionDenied: "Permission refusée.",
    addNew: "Ajouter un nouveau domaine",
    remove: "Supprimer",
    invalidNode: "Noeud invalide.",
    invalidDomain: "Domaine invalide.",
    duplicateDomain: "Domaine déjà assigné.",
    language: "Langue",
    domain: "Domaine",
    domainCreated: "Nouveau domaine '%0%' créé",
    domainDeleted: "Domaine '%0%' supprimé",
    domainExists: "Domaine '%0%' déjà assigné",
    domainUpdated: "Domaine '%0%' mis à jour",
    orEdit: "Editer les domaines actuels",
    domainHelpWithVariants: `Noms de domaines valides: "example.com", "www.example.com", "example.com:8080", ou "https://www.example.com/".
     De plus, les chemins d'un niveau sous le domaine sont également supportés, eg. "example.com/en" ou "/en".`,
    inherit: "Hériter",
    setLanguage: "Culture",
    setLanguageHelp: `Définir la culture pour les noeuds enfants du noeud courant,<br /> ou hériter de la culture des noeuds parents. S'appliquera aussi<br />
      au noeud courant, à moins qu'un domaine ci-dessous soit aussi d'application.`,
    setDomains: "Domaines"
  },
  buttons: {
    clearSelection: "Vider la sélection",
    select: "Choisir",
    somethingElse: "Faire autre chose",
    bold: "Gras",
    deindent: "Annuler l'indentation de paragraphe",
    formFieldInsert: "Insérer un champ de formulaire",
    graphicHeadline: "Insérer un entête graphique",
    htmlEdit: "Editer le HTML",
    indent: "Indenter le paragraphe",
    italic: "Italique",
    justifyCenter: "Centrer",
    justifyLeft: "Justifier à gauche",
    justifyRight: "Justifier à droite",
    linkInsert: "Insérer un lien",
    linkLocal: "Insérer un lien local (ancre)",
    listBullet: "Liste à puces",
    listNumeric: "Liste numérique",
    macroInsert: "Insérer une macro",
    pictureInsert: "Insérer une image",
    publishAndClose: "Publier et fermer",
    publishDescendants: "Publier avec les descendants",
    relations: "Editer les relations",
    returnToList: "Retourner à la liste",
    save: "Sauver",
    saveAndClose: "Sauver et fermer",
    saveAndPublish: "Sauver et publier",
    saveToPublish: "Sauver et envoyer pour approbation",
    saveListView: "Sauver la mise en page de la liste",
    schedulePublish: "Planifier",
    saveAndPreview: "Prévisualiser",
    showPage: "Prévisualiser",
    showPageDisabled: "La prévisualisation est désactivée car aucun modèle n'a été assigné.",
    styleChoose: "Choisir un style",
    styleShow: "Afficher les styles",
    tableInsert: "Insérer un tableau",
    generateModelsAndClose: "Générer les modèles et fermer",
    saveAndGenerateModels: "Sauver et générer les modèles",
    undo: "Défaire",
    redo: "Refaire",
    deleteTag: "Supprimer un tag",
    confirmActionCancel: "Annuler",
    confirmActionConfirm: "Confirmer",
    morePublishingOptions: "Options de publication supplémentaires"
  },
  auditTrailsMedia: {
    delete: "Media supprimé",
    move: "Media déplacé",
    copy: "Media copié",
    save: "Media sauvegardé"
  },
  auditTrails: {
    atViewingFor: "Aperçu pour",
    delete: "Contenu supprimé",
    unpublish: "Contenu dé-publié",
    unpublishvariant: "Contenu dé-publié pour les langues : %0% ",
    publish: "Contenu publié",
    publishvariant: "Contenu publié pour les langues : %0% ",
    save: "Contenu sauvegardé",
    savevariant: "Contenu sauvegardé pour les langues : %0%",
    move: "Contenu déplacé",
    copy: "Contenu copié",
    rollback: "Contenu restauré",
    sendtopublish: "Contenu envoyé pour publication",
    sendtopublishvariant: "Contenu envoyé pour publication pour les langues : %0%",
    sort: "Ordonnancement des sous-éléments réalisé par l'utilisateur",
    smallCopy: "Copier",
    smallPublish: "Publier",
    smallPublishVariant: "Publier",
    smallMove: "Déplacer",
    smallSave: "Sauvegarder",
    smallSaveVariant: "Sauvegarder",
    smallDelete: "Supprimer",
    smallUnpublish: "Annuler publication",
    smallUnpublishVariant: "Annuler publication",
    smallRollBack: "Restaurer",
    smallSendToPublish: "Envoyer pour publication",
    smallSendToPublishVariant: "Envoyer pour publication",
    smallSort: "Ordonner",
    historyIncludingVariants: "Historique (toutes variantes)"
  },
  codefile: {
    createFolderIllegalChars: "Le nom du dossier ne peut pas contenir de caractères illégaux.",
    deleteItemFailed: "Echec de la suppression de l'élément : %0%"
  },
  content: {
    isPublished: "A été publié",
    about: "A propos de cette page",
    alias: "Alias",
    alternativeTextHelp: "(comment décririez-vous l'image oralement)",
    alternativeUrls: "Liens alternatifs",
    clickToEdit: "Cliquez pour éditer cet élément",
    createBy: "Créé par",
    createByDesc: "Auteur original",
    updatedBy: "Mis à jour par",
    createDate: "Créé",
    createDateDesc: "Date/heure à laquelle ce document a été créé",
    documentType: "Type de Document",
    editing: "Edition",
    expireDate: "Expire le",
    itemChanged: "Cet élément a été modifié après la publication",
    itemNotPublished: "Cet élément n'est pas publié",
    lastPublished: "Dernière publication",
    noItemsToShow: "Il n'y a aucun élément à afficher",
    listViewNoItems: "Il n'y a aucun élément à afficher dans cette liste.",
    listViewNoContent: "Aucun contenu n'a encore été ajouté",
    listViewNoMembers: "Aucun membre n'a encore été ajouté",
    mediatype: "Type de Média",
    mediaLinks: "Lien vers des média(s)",
    membergroup: "Groupe de membres",
    memberrole: "Rôle",
    membertype: "Type de membre",
    noChanges: "Aucune modification n'a été faite",
    noDate: "Aucune date choisie",
    nodeName: "Titre de la page",
    noMediaLink: "Ce média n'a pas de lien",
    noProperties: "Aucun contenu ne peut être ajouté pour cet élément",
    otherElements: "Propriétés",
    parentNotPublished: "Ce document est publié mais n'est pas visible car son parent '%0%' n'est pas publié",
    parentCultureNotPublished: "Cette culture est publiée mais n'est pas visible car elle n'est pas publiée pour le parent '%0%'",
    parentNotPublishedAnomaly: "Ce document est publié mais n'est pas présent dans le cache",
    getUrlException: "Oups: impossible d'obtenir cet URL (erreur interne - voir fichier log)",
    routeError: "Ce document est publié mais son URL entrerait en collision avec le contenu %0%",
    routeErrorCannotRoute: "Ce document est publié mais son URL ne peut pas être routé",
    publish: "Publier",
    published: "Publié",
    publishedPendingChanges: "Publié (changements en cours)",
    publishStatus: "Statut de publication",
    publishDescendantsHelp: "Cliquez sur <em>Publier avec ses descendants</em> pour publier <strong>%0%</strong> et tous les éléments de contenu en-dessous, rendant de ce fait leur contenu accessible publiquement.",
    publishDescendantsWithVariantsHelp: "Cliquez sur <em>Publier avec ses descendants</em> pour publier <strong>les langues sélectionnées</strong> et les mêmes langues des éléments de contenu en-dessous, rendant de ce fait leur contenu accessible publiquement.",
    releaseDate: "Publié le",
    unpublishDate: "Dépublié le",
    removeDate: "Supprimer la date",
    setDate: "Défininir la date",
    sortDone: "Ordre de tri mis à jour",
    sortHelp: `Pour trier les noeuds, faites-les simplement glisser à l'aide de la souris ou cliquez sur les entêtes de colonne. Vous pouvez séléctionner plusieurs noeuds en gardant la touche "shift" ou "ctrl" enfoncée pendant votre séléction.`,
    statistics: "Statistiques",
    titleOptional: "Titre (optionnel)",
    altTextOptional: "Texte alternatif (optionnel)",
    captionTextOptional: "Légende (optionnel)",
    type: "Type",
    unpublish: "Dépublier",
    unpublished: "Dépublié",
    notCreated: "Non créé",
    updateDate: "Dernière édition",
    updateDateDesc: "Date/heure à laquelle ce document a été édité",
    uploadClear: "Supprimer le(s) fichier(s)",
    urls: "Lien vers un document",
    memberof: "Membre du/des groupe(s)",
    notmemberof: "Pas membre du/des groupe(s)",
    childItems: "Eléments enfants",
    target: "Cible",
    scheduledPublishServerTime: "Ceci se traduit par l'heure suivante sur le serveur :",
    scheduledPublishDocumentation: `<a href="https://docs.umbraco.com/umbraco-cms/fundamentals/data/scheduled-publishing#timezones" target="_blank" rel="noopener">Qu'est-ce que cela signifie?</a>`,
    nestedContentDeleteItem: "Etes-vous certain(e) de vouloir supprimer cet élément?",
    nestedContentDeleteAllItems: "Etes-vous certain(e) de vouloir supprimer tous les éléments?",
    nestedContentEditorNotSupported: "La propriété %0% utilise l'éditeur %1% qui n'est pas supporté par Nested Content.",
    nestedContentNoContentTypes: "Aucun type de contenu n'est configuré pour cette propriété.",
    nestedContentAddElementType: "Ajouter un type d'élément",
    nestedContentSelectElementTypeModalTitle: "Sélectionner un type d'élément",
    nestedContentNoGroups: "Le type d'élément sélectionné ne contient aucun groupe supporté (les onglets/tabs ne sont pas supportés par cet éditeur, changez-les en groupes ou utilisez l'éditeur Block List).",
    addTextBox: "Ajouter un autre champ texte",
    removeTextBox: "Enlever ce champ texte",
    contentRoot: "Racine du contenu",
    includeUnpublished: "Inclure les brouillons : publier également les éléments de contenu non publiés.",
    isSensitiveValue: "Cette valeur est masquée. Si vous avez besoin de pouvoir accéder à cette valeur, veuillez prendre contact avec l'administrateur du site web.",
    isSensitiveValue_short: "Cette valeur est masquée.",
    languagesToPublish: "Quelles langues souhaitez-vous publier?",
    languagesToSendForApproval: "Quells langues souhaitez-vous envoyer pour approbation?",
    languagesToSchedule: "Quelles langues souhaitez-vous planifier?",
    languagesToUnpublish: "Sélectionnez les langues à dépublier. La dépublication d'une langue obligatoire provoquera la dépublication de toutes les langues.",
    readyToPublish: "Prêt.e à publier?",
    readyToSave: "Prêt.e à sauvegarder?",
    sendForApproval: "Envoyer pour approbation",
    schedulePublishHelp: "Sélectionnez la date et l'heure de publication/dépublication de l'élément de contenu.",
    createEmpty: "Créer nouveau",
    createFromClipboard: "Copier du clipboard",
    saveModalTitle: "Sauver"
  },
  blueprints: {
    createBlueprintFrom: "Créer un nouveau Modèle de Contenu à partir de <em>%0%</em>",
    blankBlueprint: "Vide",
    selectBlueprint: "Sélectionner un Modèle de Contenu",
    createdBlueprintHeading: "Modèle de Contenu créé",
    createdBlueprintMessage: "Un modèle de Contenu a été créé à partir de '%0%'",
    duplicateBlueprintMessage: "Un autre Modèle de Contenu existe déjà avec le même nom",
    blueprintDescription: "Un Modèle de Contenu est du contenu pré-défini qu'un éditeur peut sélectionner et utiliser comme base pour la création de nouveau contenu"
  },
  media: {
    clickToUpload: "Cliquez pour télécharger",
    orClickHereToUpload: "ou cliquez ici pour choisir un fichier",
    disallowedFileType: "Ce fichier ne peut pas ête chargé, il n'est pas d'un type de fichier autorisé.",
    invalidFileName: "Ce fichier ne peut pas être chargé, le nom du fichier n'est pas valide",
    maxFileSize: "La taille maximum de fichier est",
    mediaRoot: "Racine du média",
    moveToSameFolderFailed: "Les dossiers parent et destination ne peuvent pas être identiques",
    createFolderFailed: "Echec de la création d'un dossier sous le parent avec l'id %0%",
    renameFolderFailed: "Echec du changement de nom du dossier avec l'id %0%",
    dragAndDropYourFilesIntoTheArea: "Glissez et déposez vos fichiers dans la zone"
  },
  member: {
    createNewMember: "Créer un nouveau membre",
    allMembers: "Tous les membres",
    memberGroupNoProperties: "Les groupes de membres n'ont pas de propriétés supplémentaires modifiables."
  },
  contentType: {
    copyFailed: "Echec de la copie du type de contenu",
    moveFailed: "Echec du déplacement du type de contenu"
  },
  mediaType: {
    copyFailed: "Echec de la copie du type de media",
    moveFailed: "Echec du déplacement du type de media"
  },
  memberType: {
    copyFailed: "Echec de la copie du type de membre"
  },
  create: {
    chooseNode: "Où voulez-vous créer le nouveau %0%",
    createUnder: "Créer un élément sous",
    createContentBlueprint: "Sélectionnez le type de document pour lequel vous souhaitez créer un modèle de contenu",
    enterFolderName: "Introduisez un nom de dossier",
    updateData: "Choisissez un type et un titre",
    noDocumentTypes: "Il n'y a aucun type de document disponible pour créer du contenu ici. Vous devez d'abord les activer dans <strong>Types de documents</strong> sous la section <strong>Paramètres</strong>, en modifiant les <strong>Types de noeuds enfants autorisés</strong> sous les <strong>Permissions</strong>.",
    noDocumentTypesAtRoot: "Il n'y a aucun type de document disponible pour créer du contenu ici. Vous devez d'abord les activer dans <strong>Types de documents</strong> sous la section <strong>Paramètres</strong>.",
    noDocumentTypesWithNoSettingsAccess: "La page sélectionnée dans l'arborescence de contenu n'autorise pas la création de pages sous elle.",
    noDocumentTypesEditPermissions: "Modifier les permissions pour ce type de document",
    noDocumentTypesCreateNew: "Créer un nouveau type de document",
    noDocumentTypesAllowedAtRoot: "Il n'y a aucun type de document disponible pour créer du contenu ici. Vous devez d'abord les activer dans <strong>Types de documents</strong> sous la section <strong>Paramètres</strong>, en modifiant l'option <strong>Autoriser comme racine</strong> sous les <strong>Permissions</strong>.",
    noMediaTypes: "Il n'y a aucun type de média disponible pour créer un media ici. Vous devez d'abord les activer dans <strong>Types de médias</strong> dans la section <strong>Paramètres</strong>, en modifiant les <strong>Types de noeuds enfants autorisés</strong> sous les <strong>Permissions</strong>.",
    noMediaTypesWithNoSettingsAccess: "Le media sélectionné dans l'arborescence n'autorise pas la création d'un autre media sous lui.",
    noMediaTypesEditPermissions: "Modifier les permissions pour ce type de media",
    documentTypeWithoutTemplate: "Type de document sans modèle",
    newFolder: "Nouveau répertoire",
    newDataType: "Nouveau type de données",
    newJavascriptFile: "Nouveau fichier javascript",
    newEmptyPartialView: "Nouvelle vue partielle vide",
    newPartialViewMacro: "Nouvelle macro pour vue partielle",
    newPartialViewFromSnippet: "Nouvelle vue partielle à partir d'un snippet",
    newPartialViewMacroFromSnippet: "Nouvelle macro pour vue partielle à partir d'un snippet",
    newPartialViewMacroNoMacro: "Nouvelle macro pour vue partielle (sans macro)",
    newStyleSheetFile: "Nouveau fichier de feuille de style",
    newRteStyleSheetFile: "Nouveau fichier de feuille de style pour l'éditeur de texte"
  },
  dashboard: {
    browser: "Parcourir votre site",
    dontShowAgain: "- Cacher",
    nothinghappens: "Si Umbraco ne s'ouvre pas, peut-être devez-vous autoriser l'ouverture des popups pour ce site.",
    openinnew: "s'est ouvert dans une nouvelle fenêtre",
    restart: "Redémarrer",
    visit: "Visiter",
    welcome: "Bienvenue"
  },
  prompt: {
    stay: "Rester",
    discardChanges: "Invalider les changements",
    unsavedChanges: "Vous avez des changements en cours",
    unsavedChangesWarning: "Etes-vous certain(e) de vouloir quitter cette page? - vous avez des changements en cours",
    confirmListViewPublish: "La publication rendra les éléments sélectionnés visibles sur le site.",
    confirmListViewUnpublish: "La suppression de la publication supprimera du site les éléments sélectionnés et tous leurs descendants.",
    confirmUnpublish: "La suppression de la publication supprimera du site cette page ainsi que tous ses descendants.",
    doctypeChangeWarning: "Vous avez des modifications en cours. Modifier le Type de Document fera disparaître ces modifications."
  },
  bulk: {
    done: "Terminé",
    deletedItem: "%0% élément supprimé",
    deletedItems: "%0% éléments supprimés",
    deletedItemOfItem: "%0% élément sur %1% supprimé",
    deletedItemOfItems: "%0% éléments sur %1% supprimés",
    publishedItem: "%0% élément publié",
    publishedItems: "%0% éléments publiés",
    publishedItemOfItem: "%0% élément sur %1% publié",
    publishedItemOfItems: "%0% éléments sur %1% publiés",
    unpublishedItem: "%0% élément dépublié",
    unpublishedItems: "%0% éléments dépubliés",
    unpublishedItemOfItem: "%0% élément sur %1% dépublié",
    unpublishedItemOfItems: "%0% éléments sur %1% dépubliés",
    movedItem: "%0% élément déplacé",
    movedItems: "%0% éléments déplacés",
    movedItemOfItem: "%0% élément sur %1% déplacé",
    movedItemOfItems: "%0% éléments sur %1% déplacés",
    copiedItem: "%0% élément copié",
    copiedItems: "%0% éléments copiés",
    copiedItemOfItem: "%0% élément sur %1% copié",
    copiedItemOfItems: "%0% éléments sur %1% copiés"
  },
  defaultdialogs: {
    nodeNameLinkPicker: "Titre du lien",
    urlLinkPicker: "Lien",
    anchorLinkPicker: "Ancrage / requête",
    anchorInsert: "Nom",
    closeThisWindow: "Fermer cette fenêtre",
    confirmdelete: "Êtes-vous certain(e) de vouloir supprimer",
    confirmdeleteNumberOfItems: "Êtes-vous certain(e) de vouloir supprimer <strong>%0%</strong> des <strong>%1%</strong> éléments",
    confirmdisable: "Êtes-vous certain(e) de vouloir désactiver",
    confirmlogout: "Êtes-vous certain(e)?",
    confirmSure: "Êtes-vous certain(e)?",
    cut: "Couper",
    editDictionary: "Editer une entrée du Dictionnaire",
    editLanguage: "Modifier la langue",
    editSelectedMedia: "Modifier le media sélectionné",
    insertAnchor: "Insérer un lien local (ancre)",
    insertCharacter: "Insérer un caractère",
    insertgraphicheadline: "Insérer un entête graphique",
    insertimage: "Insérer une image",
    insertlink: "Insérer un lien",
    insertMacro: "Insérer une macro",
    inserttable: "Insérer un tableau",
    languagedeletewarning: "Ceci supprimera la langue",
    languageChangeWarning: "Modifier la culture d'une langue peut être une opération lourde qui aura pour conséquence la réinitialisation de la cache de contenu et des index",
    lastEdited: "Dernière modification",
    link: "Lien",
    linkinternal: "Lien interne",
    linklocaltip: "Si vous utilisez des ancres, insérez # au début du lien",
    linknewwindow: "Ouvrir dans une nouvelle fenêtre?",
    macroDoesNotHaveProperties: "Cette macro ne contient aucune propriété éditable",
    paste: "Coller",
    permissionsEdit: "Editer les permissions pour",
    permissionsSet: "Définir les permissions pour",
    permissionsSetForGroup: "Définir les permissions pour %0% pour le groupe d'utilisateurs %1%",
    permissionsHelp: "Sélectionnez les groupes d'utilisateurs pour lesquels vous souhaitez définir les permissions",
    recycleBinDeleting: "Les éléments dans la corbeille sont en cours de suppression. Veuillez ne pas fermer cette fenêtre avant que cette opération ne soit terminée.",
    recycleBinIsEmpty: "La corbeille est maintenant vide",
    recycleBinWarning: "Les éléments supprimés de la corbeille seront supprimés définitivement",
    regexSearchError: "Le webservice <a target='_blank' rel='noopener' href='http://regexlib.com'>regexlib.com</a> rencontre actuellement des problèmes sur lesquels nous n'avons aucun contrôle. Nous sommes sincèrement désolés pour le désagrément.",
    regexSearchHelp: "Rechercher une expression régulière à ajouter pour la validation d'un champ de formulaire. Exemple: 'email, 'zip-code', 'URL'.",
    removeMacro: "Supprimer la macro",
    requiredField: "Champ obligatoire",
    sitereindexed: "Le site a été réindéxé",
    siterepublished: "Le cache du site a été mis à jour. Tous les contenus publiés sont maintenant à jour. Et tous les contenus dépubliés sont restés invisibles.",
    siterepublishHelp: "Le cache du site va être mis à jour. Tous les contenus publiés seront mis à jour. Et tous les contenus dépubliés resteront invisibles.",
    tableColumns: "Nombre de colonnes",
    tableRows: "Nombre de lignes",
    thumbnailimageclickfororiginal: "Cliquez sur l'image pour la voir en taille réelle",
    treepicker: "Sélectionner un élément",
    viewCacheItem: "Voir l'élément de cache",
    relateToOriginalLabel: "Lier à l'original",
    includeDescendants: "Inclure les descendants",
    theFriendliestCommunity: "La communauté la plus amicale",
    linkToPage: "Lier à la page",
    openInNewWindow: "Ouvre le document lié dans une nouvelle fenêtre ou un nouvel onglet",
    linkToMedia: "Lier à un media",
    selectContentStartNode: "Sélectionner le noeud de base du contenu",
    selectMedia: "Sélectionner le media",
    selectMediaType: "Sélectionner le type de media",
    selectIcon: "Sélectionner l'icône",
    selectItem: "Sélectionner l'élément",
    selectLink: "Sélectionner le lien",
    selectMacro: "Sélectionner la macro",
    selectContent: "Sélectionner le contenu",
    selectContentType: "Sélectionner le type de contenu",
    selectMediaStartNode: "Sélectionner le noeud de base des media",
    selectMember: "Sélectionner le membre",
    selectMemberGroup: "Sélectionner le groupe de membres",
    selectMemberType: "Sélectionner le type de membre",
    selectNode: "Sélectionner le noeud",
    selectSections: "Sélectionner les sections",
    selectUsers: "Sélectionner les utilisateurs",
    noIconsFound: "Aucune icone n'a été trouvée",
    noMacroParams: "Il n'y a pas de paramètres pour cette macro",
    noMacros: "Il n'y a pas de macro disponible à insérer",
    externalLoginProviders: "Fournisseurs externes d'identification",
    exceptionDetail: "Détails de l'exception",
    stacktrace: "Trace d'exécution",
    innerException: "Exception interne",
    linkYour: "Liez votre",
    unLinkYour: "Enlevez votre",
    account: "compte",
    selectEditor: "Sélectionner un éditeur",
    selectSnippet: "Selectionner un snippet",
    variantdeletewarning: "Ceci supprimera le noeud et toutes ses langues. Si vous souhaitez supprimer une langue spécifique, vous devriez plutôt supprimer la publication du noeud dans cette langue-là."
  },
  dictionary: {
    importDictionaryItemHelp: `
      Pour importer un élément de dictionnaire, trouvez le fichier ".udt" sur votre ordinateur en cliquant sur le bouton "Importer" (une confirmation vous sera demandée dans l'écran suivant)
    `,
    itemDoesNotExists: "L'élément de dictionnaire n'existe pas.",
    parentDoesNotExists: "L'élément parent n'existe pas.",
    noItems: "Il n'y a pas d'élément dans le dictionnaire.",
    noItemsInFile: "Il n'y a pas d'élément de dictionnaire dans ce fichier.",
    createNew: "Créer un élément de dictionnaire"
  },
  dictionaryItem: {
    description: "Editez les différentes versions de langues pour l'élément de dictionnaire '%0%' ci-dessous.",
    displayName: "Nom de Culture",
    changeKeyError: "La clé '%0%' existe déjà.",
    overviewTitle: "Aperçu du dictionaire"
  },
  examineManagement: {
    configuredSearchers: "Recherches configurées",
    configuredSearchersDescription: "Affiche les propriétés et les outils de chaque Recherche configurée (e.g. une recherche multi-index)",
    fieldValues: "Valeurs du champ",
    healthStatus: "Etat de santé",
    healthStatusDescription: "L'état de santé de l'index et s'il peut être lu",
    indexers: "Indexeurs",
    indexInfo: "Info Index",
    indexInfoDescription: "Liste les propriétés de l'index",
    manageIndexes: "Gérer les index d'Examine",
    manageIndexesDescription: "Vous permet de voir les détails de chaque index et fournit des outils pour gérer les index",
    rebuildIndex: "Reconstruire l'index",
    rebuildIndexWarning: `
      Ceci provoquera la reconstruction de l'index.<br />
      Cela pourrait prendre un certain temps en fonction de la quantité de contenu présente dans votre site.<br />
      Il est déconseillé de reconstruire un index pendant les périodes de trafic intense sur le site web ou quand les éditeurs sont en train d'éditer du contenu.
     `,
    searchers: "Recherches",
    searchDescription: "Rechercher dans l'index et afficher les résultats",
    tools: "Outils",
    toolsDescription: "Outils pour gérer l'index",
    fields: "champs",
    indexCannotRead: "L'index ne peut pas être lu et devra être reconstruit",
    processIsTakingLonger: "Le processus dure plus de temps que prévu, vérifiez les logs Umbraco afin de voir s'il y a eu des erreurs pendant cette opératon",
    indexCannotRebuild: "Cet index ne peut pas être reconstruit parce qu'on ne lui a pas assigné de",
    iIndexPopulator: "IIndexPopulator"
  },
  placeholders: {
    username: "Votre nom d'utilisateur",
    password: "Votre mot de passe",
    confirmPassword: "Confirmation de votre mot de passe",
    nameentity: "Nommer %0%...",
    entername: "Entrez un nom...",
    enteremail: "Entrez un email...",
    enterusername: "Entrez un nom d'utilisateur...",
    label: "Libellé...",
    enterDescription: "Entrez une description...",
    search: "Rechercher...",
    filter: "Filtrer...",
    enterTags: "Ajouter des tags (appuyer sur enter entre chaque tag)...",
    email: "Entrez votre email",
    enterMessage: "Entrez un message...",
    usernameHint: "Votre nom d'utilisateur est généralement votre adresse email",
    anchor: "#value ou ?key=value",
    enterAlias: "Introduisez l'alias...",
    generatingAlias: "Génération de l'alias...",
    a11yCreateItem: "Créer un élément",
    a11yEdit: "Modifier",
    a11yName: "Nom"
  },
  editcontenttype: {
    createListView: "Créer une liste personnalisée",
    removeListView: "Supprimer la liste personnalisée",
    aliasAlreadyExists: "Il existe déjà un type de contenu, un tye de media ou un type de membre avec cet alias"
  },
  renamecontainer: {
    renamed: "Renommé",
    enterNewFolderName: "Entrez un nouveau nom de répertoire ici",
    folderWasRenamed: "%0% a été renommé en %1%"
  },
  editdatatype: {
    addPrevalue: "Ajouter une valeur de base",
    dataBaseDatatype: "Type de donnée en base de donées",
    guid: "GUID du Property Editor",
    renderControl: "Property editor",
    rteButtons: "Boutons",
    rteEnableAdvancedSettings: "Activer les paramètres avancés pour",
    rteEnableContextMenu: "Activer le menu contextuel",
    rteMaximumDefaultImgSize: "Taille maximale par défaut des images insérées",
    rteRelatedStylesheets: "CSS associées",
    rteShowLabel: "Afficher le libellé",
    rteWidthAndHeight: "Largeur et hauteur",
    selectFolder: "Sélectionnez le répertoire où déplacer",
    inTheTree: "dans l'arborescence ci-dessous",
    wasMoved: "a été déplacé sous",
    hasReferencesDeleteConsequence: "La suppression de <strong>%0%</strong> supprimera les propriétés et leurs données des éléments suivants",
    acceptDeleteConsequence: "Je comprends que cette action va supprimer les propriétés et les données basées sur ce Type de Données"
  },
  errorHandling: {
    errorButDataWasSaved: "Vos données ont été sauvegardées, mais avant de pouvoir publier votre page, il y a des erreurs que vous devez d'abord corriger :",
    errorChangingProviderPassword: "Le Membership Provider n'autorise pas le changement des mots de passe (EnablePasswordRetrieval doit être défini à true)",
    errorExistsWithoutTab: "%0% existe déjà",
    errorHeader: "Des erreurs sont survenues :",
    errorHeaderWithoutTab: "Des erreurs sont survenues :",
    errorInPasswordFormat: "Le mot de passe doit contenir un minimum de %0% caractères et contenir au moins %1% caractère(s) non-alphanumerique",
    errorIntegerWithoutTab: "%0% doit être un entier",
    errorMandatory: "Le champ %0% dans l'onglet %1% est obligatoire",
    errorMandatoryWithoutTab: "%0% est un champ obligatoire",
    errorRegExp: "%0% dans %1% n'est pas correctement formaté",
    errorRegExpWithoutTab: "%0% n'est pas correctement formaté"
  },
  errors: {
    receivedErrorFromServer: "Le serveur a retourné une erreur",
    dissallowedMediaType: "Le type de fichier spécifié n'est pas autorisé par l'administrateur",
    codemirroriewarning: "NOTE ! Même si CodeMirror est activé dans la configuration, il est désactivé dans Internet Explorer car il n'est pas suffisamment stable dans ce navigateur.",
    contentTypeAliasAndNameNotNull: "Veuillez remplir l'alias et le nom de la nouvelle propriété!",
    filePermissionsError: "Il y a un problème de droits en lecture/écriture sur un fichier ou dossier spécifique",
    macroErrorLoadingPartialView: "Erreur de chargement du script d'une Partial View (fichier : %0%)",
    missingTitle: "Veuillez entrer un titre",
    missingType: "Veuillez choisir un type",
    pictureResizeBiggerThanOrg: "Vous allez définir une taille d'image supérieure à sa taille d'origine. Êtes-vous certain(e) de vouloir continuer?",
    startNodeDoesNotExists: "Noeud de départ supprimé, contactez votre administrateur",
    stylesMustMarkBeforeSelect: "Veuillez sélectionner du contenu avant de changer le style",
    stylesNoStylesOnPage: "Aucun style actif disponible",
    tableColMergeLeft: "Veuillez placer le curseur à la gauche des deux cellules que vous voulez fusionner",
    tableSplitNotSplittable: "Vous ne pouvez pas scinder une cellule qui n'a pas été fusionnée.",
    propertyHasErrors: "Cette propriété n'est pas valide"
  },
  general: {
    options: "Options",
    about: "A propos",
    action: "Action",
    actions: "Actions",
    add: "Ajouter",
    alias: "Alias",
    all: "Tout",
    areyousure: "Êtes-vous certain(e)?",
    back: "Retour",
    backToOverview: "Retour à l'aperçu",
    border: "Bord",
    by: "par",
    cancel: "Annuler",
    cellMargin: "Marge de cellule",
    choose: "Choisir",
    close: "Fermer",
    closewindow: "Fermer la fenêtre",
    closepane: "Fermer le panel",
    comment: "Commenter",
    confirm: "Confirmer",
    constrain: "Conserver",
    constrainProportions: "Conserver les proportions",
    content: "Contenu",
    continue: "Continuer",
    copy: "Copier",
    create: "Créer",
    database: "Base de données",
    date: "Date",
    default: "Défaut",
    delete: "Supprimer",
    deleted: "Supprimé",
    deleting: "Suppression...",
    design: "Design",
    dictionary: "Dictionnaire",
    dimensions: "Dimensions",
    down: "Bas",
    download: "Télécharger",
    edit: "Editer",
    edited: "Edité",
    elements: "Eléments",
    email: "Email",
    error: "Erreur",
    field: "Champ",
    findDocument: "Trouver",
    first: "Premier",
    focalPoint: "Point focal",
    general: "Général",
    groups: "Groupes",
    group: "Groupe",
    height: "Hauteur",
    help: "Aide",
    hide: "Cacher",
    history: "Historique",
    icon: "Icône",
    id: "Id",
    import: "Importer",
    info: "Info",
    innerMargin: "Marge intérieure",
    insert: "Insérer",
    install: "Installer",
    invalid: "Non valide",
    justify: "Justifier",
    label: "Libellé",
    language: "Langue",
    last: "Dernier",
    layout: "Mise en page",
    links: "Liens",
    loading: "En cours de chargement",
    locked: "Bloqué",
    login: "Connexion",
    logoff: "Déconnexion",
    logout: "Déconnexion",
    macro: "Macro",
    mandatory: "Obligatoire",
    message: "Message",
    move: "Déplacer",
    name: "Nom",
    new: "Nouveau",
    next: "Suivant",
    no: "Non",
    of: "de",
    off: "Inactif",
    ok: "OK",
    open: "Ouvrir",
    on: "Actif",
    or: "ou",
    orderBy: "Trier par",
    password: "Mot de passe",
    path: "Chemin",
    pleasewait: "Un moment s'il vous plaît...",
    previous: "Précédent",
    properties: "Propriétés",
    readMore: "En savoir plus",
    rebuild: "Reconstruire",
    reciept: "Email de réception des données de formulaire",
    recycleBin: "Corbeille",
    recycleBinEmpty: "Votre corbeille est vide",
    reload: "Rafraîchir",
    remaining: "Restant",
    remove: "Enlever",
    rename: "Renommer",
    renew: "Renouveller",
    required: "Requis",
    retrieve: "Retrouver",
    retry: "Réessayer",
    rights: "Permissions",
    scheduledPublishing: "Publication Programmée",
    search: "Rechercher",
    searchNoResult: "Désolé, nous ne pouvons pas trouver ce que vous recherchez",
    noItemsInList: "Aucun élément n'a été ajouté",
    server: "Serveur",
    settings: "Paramètres",
    shared: "Partagé",
    show: "Montrer",
    showPageOnSend: "Afficher la page à l'envoi",
    size: "Taille",
    sort: "Trier",
    status: "Statut",
    submit: "Envoyer",
    type: "Type",
    typeToSearch: "Rechercher...",
    under: "sous",
    up: "Haut",
    update: "Mettre à jour",
    upgrade: "Upgrader",
    upload: "Télécharger",
    url: "URL",
    user: "Utilisateur",
    username: "Nom d'utilisateur",
    value: "Valeur",
    view: "Voir",
    welcome: "Bienvenue...",
    width: "Largeur",
    yes: "Oui",
    folder: "Dossier",
    searchResults: "Résultats de recherche",
    reorder: "Réorganiser",
    reorderDone: "J'ai fini de réorganiser",
    preview: "Prévisualiser",
    changePassword: "Modifier le mot de passe",
    to: "vers",
    listView: "Liste",
    saving: "Sauvegarde...",
    current: "actuel",
    embed: "Intégrer",
    selected: "sélectionné",
    avatar: "Avatar de",
    header: "Entête",
    systemField: "champ système",
    lastUpdated: "Dernière mise à jour"
  },
  colors: {
    blue: "Bleu"
  },
  shortcuts: {
    addGroup: "Ajouter un onglet",
    addProperty: "Ajouter une propriété",
    addEditor: "Ajouter un éditeur",
    addTemplate: "Ajouter un modèle",
    addChildNode: "Ajouter un noeud enfant",
    addChild: "Ajouter un enfant",
    editDataType: "Editer le type de données",
    navigateSections: "Parcourir les sections",
    shortcut: "Raccourcis",
    showShortcuts: "afficher les raccourcis",
    toggleListView: "Activer / Désactiver la vue en liste",
    toggleAllowAsRoot: "Activer / Désactiver l'autorisation comme racine",
    commentLine: "Commenter/Décommenter les lignes",
    removeLine: "Supprimer la ligne",
    copyLineUp: "Copier les lignes vers le haut",
    copyLineDown: "Copier les lignes vers le bas",
    moveLineUp: "Déplacer les lignes vers le haut",
    moveLineDown: "Déplacer les lignes vers le bas",
    generalHeader: "Général",
    editorHeader: "Editeur",
    toggleAllowCultureVariants: "Activer / Désactiver les variantes de culture"
  },
  graphicheadline: {
    backgroundcolor: "Couleur de fond",
    bold: "Gras",
    color: "Couleur de texte",
    font: "Police",
    text: "Texte"
  },
  headers: {
    page: "Page"
  },
  installer: {
    databaseErrorCannotConnect: "Le programme d'installation ne parvient pas à se connecter à la base de données.",
    databaseFound: "Votre base de données a été détectée et est identifiée comme étant",
    databaseHeader: "Configuration de la base de données",
    databaseInstall: `
      Appuyez sur le bouton <strong>installer</strong> pour installer la base de données Umbraco %0%
    `,
    databaseInstallDone: "Umbraco %0% a été copié dans votre base de données. Appuyez sur <strong>Suivant</strong> pour poursuivre.",
    databaseText: `Pour réaliser cette étape, vous devez d'abord connaître des informations concernant votre serveur de base de données ("connection string").<br />
        Veuillez contacter votre fournisseur de services internet si nécessaire.
        Si vous installez Umbraco sur un ordinateur ou un serveur local, vous aurez peut-être besoin de consulter votre administrateur système.`,
    databaseUpgrade: `
      <p>
      Appuyez sur le bouton <strong>Upgrader</strong> pour mettre à jour votre base de données vers Umbraco %0%</p>
      <p>
      N'ayez pas d'inquiétude : aucun contenu ne sera supprimé et tout continuera à fonctionner parfaitement par après !
      </p>
      `,
    databaseUpgradeDone: `Votre base de données a été mise à jour vers la version %0%.<br />Appuyez sur <strong>Suivant</strong> pour
      poursuivre. `,
    databaseUpToDate: "Votre base de données est à jour ! Cliquez sur <strong>Suivant</strong> pour poursuivre la configuration",
    defaultUserChangePass: "<strong>Le mot de passe par défaut doit être modifié !</strong>",
    defaultUserDisabled: "<strong>L'utilisateur par défaut a été désactivé ou n'a pas accès à Umbraco!</strong></p><p>Aucune autre action n'est requise. Cliquez sur <strong>Suivant</strong> pour poursuivre.",
    defaultUserPassChanged: "<strong>Le mot de passe par défaut a été modifié avec succès depuis l'installation!</strong></p><p>Aucune autre action n'est requise. Cliquez sur <strong>Suivant</strong> pour poursuivre.",
    defaultUserPasswordChanged: "Le mot de passe a été modifié !",
    greatStart: "Pour bien commencer, regardez nos vidéos d'introduction",
    None: "Pas encore installé.",
    permissionsAffectedFolders: "Fichiers et dossiers concernés",
    permissionsAffectedFoldersMoreInfo: "Plus d'informations sur la configuration des permissions",
    permissionsAffectedFoldersText: "Vous devez donner à ASP.NET les droits de modification sur les fichiers/dossiers suivants",
    permissionsAlmostPerfect: `<strong>Vos configurations de permissions sont presque parfaites !</strong><br /><br />
        Vous pouvez faire fonctionner Umbraco sans problèmes, mais vous ne serez pas en mesure d'installer des packages, ce qui est hautement recommandé pour tirer pleinement profit d'Umbraco.`,
    permissionsHowtoResolve: "Comment résoudre",
    permissionsHowtoResolveLink: "Cliquez ici pour lire la version texte",
    permissionsHowtoResolveText: "Regardez notre <strong>tutoriel vidéo</strong> sur la définition des permissions des répertoires pour Umbraco, ou lisez la version texte.",
    permissionsMaybeAnIssue: `<strong>Vos configurations de permissions pourraient poser problème !</strong>
      <br/><br />
      Vous pouvez faire fonctionner Umbraco sans problèmes, mais vous ne serez pas en mesure d'installer des packages, ce qui est hautement recommandé pour tirer pleinement profit d'Umbraco.`,
    permissionsNotReady: `<strong>Vos configurations de permissions ne sont pas prêtes pour Umbraco !</strong>
          <br /><br />
          Pour faire fonctionner Umbraco, vous aurez besoin de mettre à jour les permissions sur les fichiers/dossiers.`,
    permissionsPerfect: `<strong>Vos configurations de permissions sont parfaites !</strong><br /><br />
              Vous êtes prêt(e) à faire fonctionner Umbraco et à installer des packages !`,
    permissionsResolveFolderIssues: "Résoudre un problème sur un dossier",
    permissionsResolveFolderIssuesLink: "Suivez ce lien pour plus d'informations sur les problèmes avec ASP.NET et la création de dossiers",
    permissionsSettingUpPermissions: "Définir les permissions de dossier",
    permissionsText: `
      Umbraco nécessite des permissions d'écriture/modification sur certains dossiers pour pouvoir stocker des fichiers comme des images et des PDF.
      Il stocke également des données temporaires (i.e : cache) pour améliorer les performances de votre site.
    `,
    runwayFromScratch: 'Je veux démarrer "from scratch"',
    runwayFromScratchText: `
        Votre site est vide pour le moment, ce qui est parfait si vous voulez commencer "from scratch" et créer vos propres types de documents et modèles d'affichage.
        (<a href="https://umbraco.tv/documentation/videos/for-site-builders/foundation/document-types">Apprenez comment</a>)
        Vous pouvez toujours choisir d'installer Runway plus tard. Pour cela, allez dans la section "Développeur" et sélectionnez "Packages".
      `,
    runwayHeader: "Vous venez de mettre en place une plateforme Umbraco toute nette. Que voulez-vous faire ensuite ?",
    runwayInstalled: "Runway est installé",
    runwayInstalledText: `
      Les fondations en place. Choisissez les modules que vous souhaitez installer par-dessus<br />
      Voici la liste des modules recommandés, cochez ceux que vous souhaitez installer, ou regardez la <a href="#" onclick="toggleModules(); return false;" id="toggleModuleList">liste complète des modules</a>
      `,
    runwayOnlyProUsers: "Recommandé uniquement pour les utilisateurs expérimentés",
    runwaySimpleSite: "Je veux commencer avec un site simple",
    runwaySimpleSiteText: `
      <p>
      "Runway" est un site simple qui fournit des types de documents et des modèles de base. L'installateur peut mettre en place Runway automatiquement pour vous,
        mais vous pouvez facilement l'éditer, l'enrichir, ou le supprimer par la suite. Il n'est pas nécessaire, et vous pouvez parfaitement vous en passer pour utiliser Umbraco. Cela étant dit,
        Runway offre une base facile, fondée sur des bonnes pratiques, pour vous permettre de commencer plus rapidement que jamais.
        Si vous choisissez d'installer Runway, vous pouvez sélectionner en option des blocs de base, appelés Runway Modules, pour enrichir les pages de votre site.
        </p>
        <small>
        <em>Inclus avec Runway :</em> Home page, Getting Started page, Installing Modules page.<br />
        <em>Modules optionnels :</em> Top Navigation, Sitemap, Contact, Gallery.
        </small>
      `,
    runwayWhatIsRunway: "Qu'est-ce que Runway",
    step1: "Etape 1/5 : Accepter la licence",
    step2: "Etape 2/5 : Configuration de la base de données",
    step3: "Etape 3/5 : Validation des permissions de fichiers",
    step4: "Etape 4/5 : Sécurité Umbraco",
    step5: "Etape 5/5 : Umbraco est prêt",
    thankYou: "Merci d'avoir choisi Umbraco",
    theEndBrowseSite: `<h3>Parcourir votre nouveau site</h3>
Vous avez installé Runway, alors pourquoi ne pas jeter un oeil au look de votre nouveau site ?`,
    theEndFurtherHelp: `<h3>Aide et informations complémentaires</h3>
Obtenez de l'aide de notre communauté "award winning", parcourez la documentation ou regardez quelques vidéos gratuites sur la manière de construire un site simple, d'utiliser les packages ainsi qu'un guide rapide sur la terminologie Umbraco`,
    theEndHeader: "Umbraco %0% est installé et prêt à être utilisé",
    theEndInstallSuccess: `Vous pouvez <strong>démarrer instantanément</strong> en cliquant sur le bouton "Lancer Umbraco" ci-dessous.<br />
Si vous <strong>débutez avec Umbraco</strong>, vous pouvez trouver une foule de ressources dans nos pages "Getting Started".`,
    theEndOpenUmbraco: `<h3>Lancer Umbraco</h3>
Pour gérer votre site, ouvrez simplement le backoffice Umbraco et commencez à ajouter du contenu, à mettre à jour les modèles d'affichage et feuilles de styles ou à ajouter de nouvelles fonctionnalités`,
    Unavailable: "La connexion à la base de données a échoué.",
    Version3: "Umbraco Version 3",
    Version4: "Umbraco Version 4",
    watch: "Regarder",
    welcomeIntro: `Cet assistant vous guidera tout au long du processus de configuration d'<strong>Umbraco %0%</strong>, qu'il s'agisse d'une nouvelle installation ou d'une mise à jour à partir de la version 3.0
      <br /><br />
      Appuyez sur <strong>"suivant"</strong> pour commencer l'assistant.`
  },
  language: {
    cultureCode: "Code de la Culture",
    displayName: "Nom de la culture"
  },
  lockout: {
    lockoutWillOccur: "Vous avez été inactif et la déconnexion aura lieu automatiquement dans",
    renewSession: "Renouvellez votre session maintenant pour sauvegarder votre travail"
  },
  login: {
    greeting0: "Bienvenue",
    greeting1: "Bienvenue",
    greeting2: "Bienvenue",
    greeting3: "Bienvenue",
    greeting4: "Bienvenue",
    greeting5: "Bienvenue",
    greeting6: "Bienvenue",
    instruction: "Connectez-vous ci-dessous",
    signInWith: "Identifiez-vous avec",
    timeout: "La session a expiré",
    bottomText: '<p style="text-align:right;">&copy; 2001 - %0% <br /><a href="https://umbraco.com" style="text-decoration: none" target="_blank" rel="noopener">Umbraco.com</a></p> ',
    forgottenPassword: "Mot de passe oublié?",
    forgottenPasswordInstruction: "Un email contenant un lien pour ré-initialiser votre mot de passe sera envoyé à l'adresse spécifiée",
    requestPasswordResetConfirmation: "Un email contenant les instructions de ré-initialisation de votre mot de passe sera envoyée à l'adresse spécifiée si elle correspond à nos informations.",
    showPassword: "Montrer le mot de passe",
    hidePassword: "Cacher le mot de passe",
    returnToLogin: "Revenir au formulaire de connexion",
    setPasswordInstruction: "Veuillez fournir un nouveau mot de passe",
    setPasswordConfirmation: "Votre mot de passe a été mis à jour",
    resetCodeExpired: "Le lien sur lequel vous avez cliqué est non valide ou a expiré.",
    resetPasswordEmailCopySubject: "Umbraco: Ré-initialiser le mot de passe",
    resetPasswordEmailCopyFormat: `
        <html>
			<head>
				<meta name='viewport' content='width=device-width'>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
			</head>
			<body class='' style='font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; color: #392F54; line-height: 22px; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background: #1d1333; margin: 0; padding: 0;' bgcolor='#1d1333'>
				<style type='text/css'> @media only screen and (max-width: 620px) {table[class=body] h1 {font-size: 28px !important; margin-bottom: 10px !important; } table[class=body] .wrapper {padding: 32px !important; } table[class=body] .article {padding: 32px !important; } table[class=body] .content {padding: 24px !important; } table[class=body] .container {padding: 0 !important; width: 100% !important; } table[class=body] .main {border-left-width: 0 !important; border-radius: 0 !important; border-right-width: 0 !important; } table[class=body] .btn table {width: 100% !important; } table[class=body] .btn a {width: 100% !important; } table[class=body] .img-responsive {height: auto !important; max-width: 100% !important; width: auto !important; } } .btn-primary table td:hover {background-color: #34495e !important; } .btn-primary a:hover {background-color: #34495e !important; border-color: #34495e !important; } .btn  a:visited {color:#FFFFFF;} </style>
				<table border="0" cellpadding="0" cellspacing="0" class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;" bgcolor="#1d1333">
					<tr>
						<td style="font-family: sans-serif; font-size: 14px; vertical-align: top; padding: 24px;" valign="top">
							<table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;">
								<tr>
									<td background="https://umbraco.com/umbraco/assets/img/application/logo.png" bgcolor="#1d1333" width="28" height="28" valign="top" style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
										<!--[if gte mso 9]> <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:30px;height:30px;"> <v:fill type="tile" src="https://umbraco.com/umbraco/assets/img/application/logo.png" color="#1d1333" /> <v:textbox inset="0,0,0,0"> <![endif]-->
										<div> </div>
										<!--[if gte mso 9]> </v:textbox> </v:rect> <![endif]-->
									</td>
									<td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top"></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;' bgcolor='#1d1333'>
					<tr>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
						<td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 560px; width: 560px; margin: 0 auto; padding: 10px;' valign='top'>
							<div class='content' style='box-sizing: border-box; display: block; max-width: 560px; margin: 0 auto; padding: 10px;'>
								<br>
								<table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; border-radius: 3px; background: #FFFFFF;' bgcolor='#FFFFFF'>
									<tr>
										<td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 50px;' valign='top'>
											<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
												<tr>
													<td style='line-height: 24px; font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'>
														<h1 style='color: #392F54; font-family: sans-serif; font-weight: bold; line-height: 1.4; font-size: 24px; text-align: left; text-transform: capitalize; margin: 0 0 30px;' align='left'>
															Une réinitialisation de votre mot de passe a été demandée
														</h1>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Votre nom d'utilisateur pour vous connecter au backoffice Umbraco est : <strong>%0%</strong>
														</p>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
																<tbody>
																	<tr>
																		<td style='font-family: sans-serif; font-size: 14px; vertical-align: top; border-radius: 5px; text-align: center; background: #35C786;' align='center' bgcolor='#35C786' valign='top'>
																			<a href='%1%' target='_blank' rel='noopener' style='color: #FFFFFF; text-decoration: none; -ms-word-break: break-all; word-break: break-all; border-radius: 5px; box-sizing: border-box; cursor: pointer; display: inline-block; font-size: 14px; font-weight: bold; text-transform: capitalize; background: #35C786; margin: 0; padding: 12px 30px; border: 1px solid #35c786;'>
																				Cliquez sur ce lien pour réinitialiser votre mot de passe
																			</a>
																		</td>
																	</tr>
																</tbody>
															</table>
														</p>
														<p style='max-width: 400px; display: block; color: #392F54; font-family: sans-serif; font-size: 14px; line-height: 20px; font-weight: normal; margin: 15px 0;'>Si vous ne pouvez pas cliquer sur le lien, recopiez cet URL dans votre navigateur :</p>
															<table border='0' cellpadding='0' cellspacing='0'>
																<tr>
																	<td style='-ms-word-break: break-all; word-break: break-all; font-family: sans-serif; font-size: 11px; line-height:14px;'>
																		<font style="-ms-word-break: break-all; word-break: break-all; font-size: 11px; line-height:14px;">
																			<a style='-ms-word-break: break-all; word-break: break-all; color: #392F54; text-decoration: underline; font-size: 11px; line-height:15px;' href='%1%'>%1%</a>
																		</font>
																	</td>
																</tr>
															</table>
														</p>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
								<br><br><br>
							</div>
						</td>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
					</tr>
				</table>
			</body>
		</html>
	`
  },
  main: {
    dashboard: "Tableau de bord",
    sections: "Sections",
    tree: "Contenu"
  },
  moveOrCopy: {
    choose: "Choisissez la page au-dessus...",
    copyDone: "%0% a été copié dans %1%",
    copyTo: "Choisissez ci-dessous l'endroit où le document %0% doit être copié",
    moveDone: "%0% a été déplacé dans %1%",
    moveTo: "Choisissez ci-dessous l'endroit où le document %0% doit être déplacé",
    nodeSelected: "a été choisi comme racine de votre nouveau contenu, cliquez sur 'ok' ci-dessous.",
    noNodeSelected: "Aucun noeud n'a encore été choisi, veuillez choisir un noeud dans la liste ci-dessus avant de cliquer sur 'ok'.",
    notAllowedByContentType: "Le noeud actuel n'est pas autorisé sous le noeud choisi à cause de son type",
    notAllowedByPath: "Le noeud actuel ne peut pas être déplacé dans une de ses propres sous-pages",
    notAllowedAtRoot: "Le noeud actuel ne peut pas exister à la racine",
    notValid: "L'action n'est pas autorisée car vous n'avez pas les droits suffisants sur un ou plusieurs noeuds enfants.",
    relateToOriginal: "Relier les éléments copiés à l'original"
  },
  notifications: {
    editNotifications: "Editez vos notifications pour %0%",
    notificationsSavedFor: "Paramètres de notification enregistrés pour %0%",
    notifications: "Notifications"
  },
  packager: {
    actions: "Actions",
    created: "Créé",
    createPackage: "Créer un package",
    chooseLocalPackageText: `
      Choisissez un package sur votre ordinateur en cliquant sur le bouton Parcourir <br />
	et localisez le package. Les packages Umbraco ont généralement une extension ".umb" ou ".zip".
      `,
    deletewarning: "Ceci va supprimer le package",
    includeAllChildNodes: "Inclure tous les noeuds enfant",
    installed: "Installé",
    installedPackages: "Packages installés",
    noConfigurationView: "Ce package n'a pas de vue de configuration",
    noPackagesCreated: "Aucun package n'a encore été créé",
    noPackages: "Vous n'avez aucun package installé",
    noPackagesDescription: "Vous n'avez pas de package installé. Veuillez soit installer un package local en le sélectionnant sur votre ordinateur, soit naviguer dans la liste des packages disponibles en utilisant l'icone <strong>'Packages'</strong> en haut à droite de votre écran",
    packageContent: "Contenu du package",
    packageLicense: "Licence",
    packageSearch: "Chercher des packages",
    packageSearchResults: "Résultats pour",
    packageNoResults: "Nous n'avons rien pu trouver pour",
    packageNoResultsDescription: "Veuillez essayer de chercher un autre package ou naviguez à travers les catégories",
    packagesPopular: "Populaires",
    packagesNew: "Nouvelles releases",
    packageHas: "a",
    packageKarmaPoints: "points de karma",
    packageInfo: "Information",
    packageOwner: "Propriétaire",
    packageContrib: "Contributeurs",
    packageCreated: "Créé",
    packageCurrentVersion: "Version actuelle",
    packageNetVersion: "version .NET",
    packageDownloads: "Téléchargements",
    packageLikes: "Coups de coeur",
    packageCompatibility: "Compatibilité",
    packageCompatibilityDescription: "Ce package est compatible avec les versions suivantes de Umbraco, selon les rapports des membres de la communauté. Une compatibilité complète ne peut pas être garantie pour les versions rapportées sous 100%",
    packageExternalSources: "Sources externes",
    packageAuthor: "Auteur",
    packageDocumentation: "Documentation",
    packageMetaData: "Meta data du package",
    packageName: "Nom du package",
    packageNoItemsHeader: "Le package ne contient aucun élément",
    packageNoItemsText: `Ce fichier de package ne contient aucun élément à désinstaller.<br/><br/>
      Vous pouvez supprimer tranquillement ce package de votre installation en cliquant sur "Désinstaller le package" ci-dessous.`,
    packageOptions: "Options du package",
    packageReadme: "Package readme",
    packageRepository: "Repository des packages",
    packageUninstallConfirm: "Confirmation de désinstallation",
    packageUninstalledHeader: "Le package a été désinstallé",
    packageUninstalledText: "Le package a été désinstallé avec succès",
    packageUninstallHeader: "Désinstaller le package",
    packageUninstallText: `Vous pouvez désélectionner ci-dessous les éléments que vous ne souhaitez pas supprimer pour le moment. Lorsque vous cliquerez sur "Confirmer la désinstallation", tous les éléments cochés seront supprimés.<br />
      <span style="color: Red; font-weight: bold;">Remarque :</span> tous les documents, media etc. dépendant des éléments que vous supprimez vont cesser de fonctionner, ce qui peut provoquer une instabilité du système,
      désinstallez donc avec prudence. En cas de doute, contactez l'auteur du package.`,
    packageVersion: "Version du package"
  },
  paste: {
    doNothing: "Coller en conservant le formatage (non recommandé)",
    errorMessage: "Le texte que vous tentez de coller contient des caractères spéciaux ou du formatage. Cela peut être dû à une copie d'un texte depuis Microsoft Word. Umbraco peut supprimer automatiquement les caractères spéciaux et le formatage, de manière à ce que le texte collé convienne mieux pour le Web.",
    removeAll: "Coller en tant que texte brut sans aucun formatage",
    removeSpecialFormattering: "Coller, mais supprimer le formatage (recommandé)"
  },
  publicAccess: {
    paGroups: "Protection basée sur les groupes",
    paGroupsHelp: "Si vous souhaitez donner accès à tous les utilisateurs de groupes de membres spécifiques",
    paGroupsNoGroups: "Vous devez créer un groupe de membres avant de pouvoir utiliser la protection basée sur les groupes",
    paErrorPage: "Page d'erreur",
    paErrorPageHelp: "Utilisé pour les personnes connectées, mais qui n'ont pas accès",
    paHowWould: "Choisissez comment restreindre l'accès à la page <strong>%0%</strong>",
    paIsProtected: "<strong>%0%</strong> est maintenant protégée",
    paIsRemoved: "Protection de <strong>%0%</strong> supprimée",
    paLoginPage: "Page de connexion",
    paLoginPageHelp: "Choisissez la page qui contient le formulaire de connexion",
    paRemoveProtection: "Supprimer la protection...",
    paRemoveProtectionConfirm: "Etes-vous certain.e de vouloir supprimer la protection de la page <strong>%0%</strong>?",
    paSelectPages: "Choisissez les pages qui contiennent le formulaire de connexion et les messages d'erreur",
    paSelectGroups: "Sélectionnez les groupes qui ont accès à la page <strong>%0%</strong>",
    paSelectMembers: "Sélectionnez les membres qui ont accès à la page <strong>%0%</strong>",
    paMembers: "Protection pour des membres spécifiques",
    paMembersHelp: "Si vous souhaitez donner accès à des membres spécifiques"
  },
  publish: {
    invalidPublishBranchPermissions: "Permissions utilisateur insuffisantes pour publier tous les documents enfants.",
    contentPublishedFailedIsTrashed: `
      %0% n'a pas pu être publié car cet élément est dans la corbeille.
    `,
    contentPublishedFailedAwaitingRelease: `
      %0% n'a pas pu être publié car cet élément est programmé pour être publié bientôt.
    `,
    contentPublishedFailedExpired: `
      %0% n'a pas pu être publié car cet élément a expiré.
    `,
    contentPublishedFailedInvalid: `
      %0% n'a pas pu être publié à cause des propriétés suivantes qui n'ont pas passé les règles de validation :  %1%.
    `,
    contentPublishedFailedByEvent: `
      %0% n'a pas pu être publié, l'action a été annulée par une extension tierce.
    `,
    contentPublishedFailedByParent: `
      %0% ne peut pas être publié car une page parente n'est pas publiée.
    `,
    contentPublishedFailedByMissingName: "%0% ne peut pas être publié, parce qu'il n'a pas de nom.",
    contentPublishedFailedReqCultureValidationError: "La validation a échoué pour la langue obligatoire '%0%'. Cette langue a été sauvegardée mais pas publiée.",
    inProgress: "Publication en cours - veuillez patienter...",
    inProgressCounter: "%0% pages sur %1% ont été publiées...",
    nodePublish: "%0% a été publié",
    nodePublishAll: "%0% et ses pages enfants ont été publiées",
    publishAll: "Publier %0% et toutes ses pages enfant",
    publishHelp: `Cliquez sur <em>Publier</em> pour publier <strong>%0%</strong> et la rendre ainsi accessible publiquement.<br/><br />
      Vous pouvez publier cette page et toutes ses sous-pages en cochant <em>Inclure les pages enfant non pubiées</em> ci-dessous.
      `
  },
  colorpicker: {
    noColors: "Vous n'avez configuré aucune couleur approuvée"
  },
  contentPicker: {
    allowedItemTypes: "Vous pouvez uniquement sélectionner des éléments du(des) type(s) : %0%",
    pickedTrashedItem: "Vous avez choisi un élément de contenu actuellement supprimé ou dans la corbeille",
    pickedTrashedItems: "Vous avez choisi des éléments de contenu actuellement supprimés ou dans la corbeille"
  },
  mediaPicker: {
    deletedItem: "Elément supprimé",
    pickedTrashedItem: "Vous avez choisi un élément media actuellement supprimé ou dans la corbeille",
    pickedTrashedItems: "Vous avez choisi des éléments media actuellement supprimés ou dans la corbeille",
    trashed: "Mis dans la corbeille"
  },
  relatedlinks: {
    enterExternal: "introduire un lien externe",
    chooseInternal: "choisir une page interne",
    caption: "Légende",
    link: "Lien",
    newWindow: "Ouvrir dans une nouvelle fenêtre",
    captionPlaceholder: "introduisez la légende à afficher",
    externalLinkPlaceholder: "Introduiser le lien"
  },
  imagecropper: {
    reset: "Réinitialiser",
    updateEditCrop: "Terminé",
    undoEditCrop: "Annuler les modifications"
  },
  rollback: {
    headline: "Sélectionnez une version à comparer avec la version actuelle",
    diffHelp: "Ceci affiche les différences entre la version actuelle et la version choisie<br />Le texte en <del>Rouge</del> signifie qu'il a été supprimé de la version choisie, <ins>vert signifie ajouté</ins>",
    documentRolledBack: "Le document a été restauré à une version antérieure",
    htmlHelp: "Ceci affiche la version choisie en tant que HTML, si vous souhaitez voir les différences entre les deux versions en même temps, utilisez la vue différentielle",
    rollbackTo: "Revenir à",
    selectVersion: "Choisissez une version",
    view: "Voir",
    pagination: "Afficher les versions %0% à %1% des %2% versions",
    versions: "Versions",
    currentDraftVersion: "Version de travail",
    currentPublishedVersion: "Version publiée"
  },
  scripts: {
    editscript: "Editer le fichier de script"
  },
  sections: {
    content: "Contenu",
    forms: "Formulaires",
    media: "Medias",
    member: "Membres",
    packages: "Packages",
    settings: "Configuration",
    translation: "Traduction",
    users: "Utilisateurs"
  },
  help: {
    theBestUmbracoVideoTutorials: "Les meilleurs tutoriels vidéo Umbraco"
  },
  settings: {
    defaulttemplate: "Modèle par défaut",
    importDocumentTypeHelp: `Pour importer un type de document, trouvez le fichier ".udt" sur votre ordinateur en cliquant sur le bouton "Parcourir" et cliquez sur "Importer" (une confirmation vous sera demandée à l'écran suivant)`,
    newtabname: "Titre du nouvel onglet",
    nodetype: "Type de noeud",
    objecttype: "Type",
    stylesheet: "Feuille de style",
    script: "Script",
    tab: "Onglet",
    tabname: "Titre de l'onglet",
    tabs: "Onglets",
    contentTypeEnabled: "Type de contenu de base activé",
    contentTypeUses: "Ce type de contenu utilise",
    noPropertiesDefinedOnTab: 'Aucune propriété définie dans cet onglet. Cliquez sur le lien "Ajouter une nouvelle propriété" en-haut pour créer une nouvelle propriété.',
    createMatchingTemplate: "Créer le template correspondant",
    addIcon: "Ajouter une icône"
  },
  sort: {
    sortOrder: "Ordre de tri",
    sortCreationDate: "Date de création",
    sortDone: "Tri achevé.",
    sortHelp: "Faites glisser les différents éléments vers le haut ou vers le bas pour définir la manière dont ils doivent être organisés. Ou cliquez sur les en-têtes de colonnes pour trier la collection complète d'éléments",
    sortPleaseWait: "Veuillez patienter. Les éléments sont en cours de tri, cela peut prendre un moment.",
    sortEmptyState: "Ce noeud n'a aucun noeud enfant à trier"
  },
  speechBubbles: {
    validationFailedHeader: "Validation",
    validationFailedMessage: "Les erreurs de validation doivent être corrigées avant de pouvoir sauvegarder l'élément",
    operationFailedHeader: "Echec",
    operationSavedHeader: "Sauvegardé",
    operationSavedHeaderReloadUser: "Sauvegardé. Veuillez rafraîchir votre navigateur pour voir les changements",
    invalidUserPermissionsText: "Permissions utilisateur insuffisantes, l'opération n'a pas pu être complétée",
    operationCancelledHeader: "Annulation",
    operationCancelledText: "L'opération a été annulée par une extension tierce",
    contentTypeDublicatePropertyType: "Le type de propriété existe déjà",
    contentTypePropertyTypeCreated: "Type de propriété créé",
    contentTypePropertyTypeCreatedText: "Nom : %0% <br /> Type de données : %1%",
    contentTypePropertyTypeDeleted: "Type de propriété supprimé",
    contentTypeSavedHeader: "Type de document sauvegardé",
    contentTypeTabCreated: "Onglet créé",
    contentTypeTabDeleted: "Onglet supprimé",
    contentTypeTabDeletedText: "Onglet avec l'ID : %0% supprimé",
    cssErrorHeader: "Feuille de style non sauvegardée",
    cssSavedHeader: "Feuille de style sauvegardée",
    cssSavedText: "Feuille de style sauvegardée sans erreurs",
    dataTypeSaved: "Type de données sauvegardé",
    dictionaryItemSaved: "Elément de dictionnaire sauvegardé",
    editContentPublishedHeader: "Contenu publié",
    editContentPublishedText: "et visible sur le site",
    editMultiContentPublishedText: "%0% documents publiés et visibles sur le site web",
    editVariantPublishedText: "%0% publié et visible sur le site web",
    editMultiVariantPublishedText: "%0% documents publiés pour la langue %1% et visibles sur le site web",
    editContentSavedHeader: "Contenu sauvegardé",
    editContentSavedText: "N'oubliez pas de publier pour rendre les modifications visibles",
    editContentScheduledSavedText: "Un planning de publication a été mis à jour",
    editVariantSavedText: "%0% sauvegardé",
    editContentSendToPublish: "Envoyer pour approbation",
    editContentSendToPublishText: "Les modifications ont été envoyées pour approbation",
    editVariantSendToPublishText: "%0% modifications ont été envoyées pour approbation",
    editMediaSaved: "Media sauvegardé",
    editMediaSavedText: "Media sauvegardé sans erreurs",
    editMemberSaved: "Membre sauvegardé",
    editStylesheetPropertySaved: "Propriété de feuille de style sauvegardée",
    editStylesheetSaved: "Feuille de style sauvegardée",
    editTemplateSaved: "Modèle sauvegardé",
    editUserError: "Erreur lors de la sauvegarde de l'utilisateur (consultez les logs)",
    editUserSaved: "Utilisateur sauvegardé",
    editUserTypeSaved: "Type d'utilisateur sauvegardé",
    editUserGroupSaved: "Groupe d'utilisateurs sauvegardé",
    fileErrorHeader: "Fichier non sauvegardé",
    fileErrorText: "Le fichier n'a pas pu être sauvegardé. Vérifiez les permissions de fichier.",
    fileSavedHeader: "Fichier sauvegardé",
    fileSavedText: "Fichier sauvegardé sans erreurs",
    languageSaved: "Langue sauvegardée",
    mediaTypeSavedHeader: "Type de média sauvegardé",
    memberTypeSavedHeader: "Type de membre sauvegardé",
    memberGroupSavedHeader: "Groupe de membres sauvegardé",
    memberGroupNameDuplicate: "Un autre groupe de membres existe déjà avec le même nom",
    templateErrorHeader: "Modèle non sauvegardé",
    templateErrorText: "Assurez-vous de ne pas avoir 2 modèles avec le même alias.",
    templateSavedHeader: "Modèle sauvegardé",
    templateSavedText: "Modèle sauvegardé sans aucune erreurs !",
    contentUnpublished: "Contenu publié",
    contentCultureUnpublished: "Variation de contenu %0% dépubliée",
    contentMandatoryCultureUnpublished: "La langue obligatoire '%0%' a été dépubliée. Toutes les langues pour cet éléménent de contenu sont maintenant dépubliées.",
    partialViewSavedHeader: "Vue partielle sauvegardée",
    partialViewSavedText: "Vue partielle sauvegardée sans erreurs !",
    partialViewErrorHeader: "Vue partielle non sauvegardée",
    partialViewErrorText: "Une erreur est survenue lors de la sauvegarde du fichier.",
    permissionsSavedFor: "Permissions sauvegardées pour",
    deleteUserGroupsSuccess: "%0% groupes d'utilisateurs supprimés",
    deleteUserGroupSuccess: "%0% a été supprimé",
    enableUsersSuccess: "%0% utilisateurs activés",
    disableUsersSuccess: "%0% utilisateurs désactivés",
    enableUserSuccess: "%0% est à présent activé",
    disableUserSuccess: "%0% est à présent désactivé",
    setUserGroupOnUsersSuccess: "Les groupes d'utilisateurs ont été définis",
    unlockUsersSuccess: "%0% utilisateurs débloqués",
    unlockUserSuccess: "%0% est à présent débloqué",
    memberExportedSuccess: "Le membre a été exporté vers le fichier",
    memberExportedError: "Une erreur est survenue lors de l'export du membre",
    deleteUserSuccess: "L'utilisateur %0% a été supprimé",
    resendInviteHeader: "Inviter l'utilisateur",
    resendInviteSuccess: "L'invitation a été envoyée à nouveau à %0%",
    contentReqCulturePublishError: "Impossible de publier le document car la langue obligatoire '%0%' n'est pas publiée",
    contentCultureValidationError: "La validation a échoué pour la langue '%0%'",
    documentTypeExportedSuccess: "Le Type de Document a été exporté dans le fichier",
    documentTypeExportedError: "Une erreur est survenue durant l'export du type de document",
    dictionaryItemExportedSuccess: "Les éléments de dictionnaire ont été exportés vers le fichier",
    dictionaryItemExportedError: "Une erreur est survenue lors de l'export des éléments de dictionnaire.",
    dictionaryItemImported: "Les éléments de dictionnaire suivants ont été importés!",
    scheduleErrReleaseDate1: "La date de publication ne peut pas être dans le passé",
    scheduleErrReleaseDate2: "Impossible de planifier la publication du document car la langue obligatoire '%0%' n'est pas publiée",
    scheduleErrReleaseDate3: "Impossible de planifier la publication du document car la langue obligatoire '%0%' a une date de publication postérieure à celle d'une langue non obligatoire",
    scheduleErrExpireDate1: "La date d'expiration ne peut pas être dans le passé",
    scheduleErrExpireDate2: "La date d'expiration ne peut pas être antérieure à la date de publication"
  },
  stylesheet: {
    addRule: "Ajouter un style",
    editRule: "Modifier un style",
    editorRules: "Styles pour l'éditeur de texte",
    editorRulesHelp: "Definir les styles qui doivent êtres disponibles dans l'éditeur de texte pour cette feuille de style",
    editstylesheet: "Editer la feuille de style",
    editstylesheetproperty: "Editer la propriété de feuille de style",
    nameHelp: "Donner un nom pour identifier la propriété dans le Rich Text Editor",
    preview: "Prévisualiser",
    previewHelp: "L'apparence qu'aura le text dans l'éditeur de texte.",
    selector: "Sélecteur",
    selectorHelp: 'Utilise la syntaxe CSS. Ex : "h1" ou ".redHeader"',
    styles: "Styles",
    stylesHelp: `Le CSS qui devrait être appliqué dans l'éditeur de texte, e.g. "color:red;"`,
    tabCode: "Code",
    tabRules: "Editeur de Texte"
  },
  template: {
    deleteByIdFailed: "Echec de la suppression du modèle avec l'ID %0%",
    edittemplate: "Editer le modèle",
    insertSections: "Sections",
    insertContentArea: "Insérer une zone de contenu",
    insertContentAreaPlaceHolder: "Insérer un placeholder de zone de contenu",
    insert: "Insérer",
    insertDesc: "Choisissez l'élément à insérer dans votre modèle",
    insertDictionaryItem: "Elément de dictionnaire",
    insertDictionaryItemDesc: "Un élément de dictionnaire est un espace pour un morceau de texte traduisible, ce qui facilite la création de designs pour des sites web multilangues.",
    insertMacro: "Macro",
    insertMacroDesc: `
      Une Macro est un composant configurable, ce qui est génial pour les parties réutilisables de votre
	  design où vous devez pouvoir fournir des paramètres,
      comme les galeries, les formulaires et les listes.
    `,
    insertPageField: "Valeur",
    insertPageFieldDesc: "Affiche la valeur d'un des champs de la page en cours, avec des options pour modifier la valeur ou spécifier des valeurs alternatives.",
    insertPartialView: "Vue partielle",
    insertPartialViewDesc: `
      Une vue partielle est un fichier modèle séparé qui peut être  à l'intérieur d'un aute modèle,
      c'est génial pour réutiliser du markup ou pour séparer des modèles complexes en plusieurs fichiers.
    `,
    mastertemplate: "Modèle de base",
    noMaster: "Pas de modèle",
    renderBody: "Afficher un modèle enfant",
    renderBodyDesc: `
     Affiche le contenu d'un modèle enfant, en insérant un contenant
     <code>@RenderBody()</code>.
      `,
    defineSection: "Définir une section nommée",
    defineSectionDesc: `
         Définit une partie de votre modèle en tant que section nommée en l'entourant
         de <code>@section { ... }</code>. Celle-ci peut être affichée dans une région
          spécifique du parent de ce modèle, en utilisant <code>@RenderSection</code>.
      `,
    renderSection: "Afficher une section nommée",
    renderSectionDesc: `
      Affiche une région nommée d'un modèle enfant, en insérant un contenant <code>@RenderSection(name)</code>.
      Ceci affiche une région d'un modèle enfant qui est entourée d'une définition <code>@section [name]{ ... }</code> correspondante.
      `,
    sectionName: "Nom de la section",
    sectionMandatory: "La section est obligatoire",
    sectionMandatoryDesc: `
      Si obligatoire, le modèle enfant doit contenir une définition <code>@section</code>, sinon une erreur est affichée.
    `,
    queryBuilder: "Générateur de requêtes",
    itemsReturned: "éléments trouvés, en",
    iWant: "Je veux",
    allContent: "tout le contenu",
    contentOfType: 'le contenu du type "%0%"',
    from: "à partir de",
    websiteRoot: "mon site web",
    where: "où",
    and: "et",
    is: "est",
    isNot: "n'est pas",
    before: "avant",
    beforeIncDate: "avant (incluant la date sélectionnée)",
    after: "après",
    afterIncDate: "après (incluant la date sélectionnée)",
    equals: "égal",
    doesNotEqual: "n'est pas égal",
    contains: "contient",
    doesNotContain: "ne contient pas",
    greaterThan: "supérieur à",
    greaterThanEqual: "supérieur ou égal à",
    lessThan: "inférieur à",
    lessThanEqual: "inférieur ou égal à",
    id: "Id",
    name: "Nom",
    createdDate: "Date de Création",
    lastUpdatedDate: "Date de Dernière Modification",
    orderBy: "trier par",
    ascending: "ascendant",
    descending: "descendant",
    template: "Modèle"
  },
  grid: {
    media: "Image",
    macro: "Macro",
    insertControl: "Choisissez le type de contenu",
    chooseLayout: "Choisissez une mise en page",
    addRows: "Ajouter une ligne",
    addElement: "Ajouter du contenu",
    dropElement: "Supprimer le contenu",
    settingsApplied: "Paramètres appliqués",
    contentNotAllowed: "Ce contenu n'est pas autorisé ici",
    contentAllowed: "Ce contenu est autorisé ici",
    clickToEmbed: "Cliquez pour intégrer",
    clickToInsertImage: "Cliquez pour insérer une image",
    clickToInsertMacro: "Cliquez pour insérer une macro",
    placeholderWriteHere: "Ecrivez ici...",
    gridLayouts: "Mises en pages de la Grid",
    gridLayoutsDetail: "Les mises en pages représentent la surface de travail globale pour l'éditeur de grille, en général, vous n'avez seulement besoin que d'une ou deux mises en pages différentes",
    addGridLayout: "Ajouter une mise en page de grille",
    addGridLayoutDetail: "Ajustez la mise en page en définissant la largeur des colonnes et en ajoutant des sections supplémentaires",
    rowConfigurations: "Configurations des rangées",
    rowConfigurationsDetail: "Les rangées sont des cellules prédéfinies disposées horizontalement",
    addRowConfiguration: "Ajouter une configuration de rangée",
    addRowConfigurationDetail: "Ajustez la rangée en réglant la largeur des cellules et en ajoutant des cellules supplémentaires",
    columns: "Colonnes",
    columnsDetails: "Nombre total combiné de colonnes dans la configuration de la grille",
    settings: "Paramètres",
    settingsDetails: "Configurez les paramètres qui peuvent être modifiés par les éditeurs",
    styles: "Styles",
    stylesDetails: "Configurez les effets de style qui peuvent être modifiés par les éditeurs",
    allowAllEditors: "Autoriser tous les éditeurs",
    allowAllRowConfigurations: "Autoriser toutes les configurations de rangées",
    maxItems: "Eléments maximum",
    maxItemsDescription: "Laisser vide ou mettre à 0 pour un nombre illimté",
    setAsDefault: "Configurer comme défaut",
    chooseExtra: "Choisir en plus",
    chooseDefault: "Choisir le défaut",
    areAdded: "ont été ajoutés"
  },
  contentTypeEditor: {
    compositions: "Compositions",
    group: "Groupe",
    noGroups: "Vous n'avez pas ajouté de groupe",
    addGroup: "Ajouter un groupe",
    inheritedFrom: "Hérité de",
    addProperty: "Ajouter une propriété",
    requiredLabel: "Label requis",
    enableListViewHeading: "Activer la vue en liste",
    enableListViewDescription: "Configure l'élément de contenu de manière à afficher ses éléments enfants sous forme d'une liste que l'on peut trier et filtrer, les enfants ne seront pas affichés dans l'arborescence",
    allowedTemplatesHeading: "Modèles autorisés",
    allowedTemplatesDescription: "Sélectionnez les modèles que les éditeurs sont autorisés à utiliser pour du contenu de ce type.",
    allowAsRootHeading: "Autoriser comme racine",
    allowAsRootDescription: "Autorisez les éditeurs à créer du contenu de ce type à la racine de l'arborescence de contenu.",
    childNodesHeading: "Types de noeuds enfants autorisés",
    childNodesDescription: "Autorisez la création de contenu des types spécifiés sous le contenu de ce type-ci",
    chooseChildNode: "Choisissez les noeuds enfants",
    compositionsDescription: "Hériter des onglets et propriétés d'un type de document existant. De nouveaux onglets seront ajoutés au type de document actuel, ou fusionnés s'il existe un onglet avec un nom sililaire.",
    compositionInUse: "Ce type de contenu est utilisé dans une composition, et ne peut donc pas être lui-même un composé.",
    noAvailableCompositions: "Il n'y a pas de type de contenu disponible à utiliser dans une composition.",
    compositionRemoveWarning: "La suppression d'une composition supprimera les données de toutes les propriétés associées. Une fois que vous sauvegardez le type de document, il n'y a plus moyen de faire marche arrière.",
    availableEditors: "Editeurs disponibles",
    reuse: "Réutiliser",
    editorSettings: "Configuration de l'éditeur",
    configuration: "Configuration",
    yesDelete: "Oui, supprimer",
    movedUnderneath: "a été déplacé en-dessous",
    copiedUnderneath: "a été copié en-dessous",
    folderToMove: "Sélectionnez le répertoire à déplacer",
    folderToCopy: "Sélectionnez le répertoire à copier",
    structureBelow: "dans l'arborescence ci-dessous",
    allDocumentTypes: "Tous les types de document",
    allDocuments: "Tous les documents",
    allMediaItems: "Tous les éléments media",
    usingThisDocument: "utilisant ce type de document seront supprimés définitivement, veuillez confirmer que vous souhaitez les supprimer également.",
    usingThisMedia: "utilisant ce type de media seront supprimés définitivement, veuillez confirmer que vous souhaitez les supprimer également.",
    usingThisMember: "utilisant ce type de membre seront supprimés définitivement, veuillez confirmer que vous souhaitez les supprimer également",
    andAllDocuments: "et tous les documents utilisant ce type",
    andAllMediaItems: "et tous les éléments media utilisant ce type",
    andAllMembers: "et tous les membres utilisant ce type",
    memberCanEdit: "Le membre peut éditer",
    memberCanEditDescription: "Autoriser la modification de la valeur de cette propriété par le membre à partir de sa page de profil",
    isSensitiveData: "Est une donnée sensible",
    isSensitiveDataDescription: "Cacher cette propriété aux éditeurs de contenu qui n'ont pas accès à la visualisation des données sensibles",
    showOnMemberProfile: "Afficher dans le profil du membre",
    showOnMemberProfileDescription: "Permettre d'afficher la valeur de cette propriété sur la page de profil du membre",
    tabHasNoSortOrder: "l'onglet n'a pas d'ordre de tri",
    compositionUsageHeading: "Où cette composition est-elle utilisée?",
    compositionUsageSpecification: "Cette composition est actuellement utilisée dans la composition des types de contenu suivants :",
    variantsHeading: "Permettre une variation par culture",
    variantsDescription: "Permettre aux éditeurs de créer du contenu de ce type dans différentes langues.",
    allowVaryByCulture: "Permettre une variation par culture",
    elementType: "Type de l'Elément",
    elementHeading: "Est un Type d'Elément",
    elementDescription: "Un Type d'Elément est destiné à être utilisé par exemple dans Nested Content, et pas dans l'arborescence.",
    elementDoesNotSupport: "Ceci n'est pas d'application pour un Type d'Elément",
    propertyHasChanges: "Vous avez apporté des modifications à cette propriété. Etes-vous certain.e de vouloir les annuler?",
    historyCleanupHeading: "Nettoyer l'historique",
    historyCleanupDescription: "Autoriser le remplacement des paramètres globaux de nettoyage de l'historique.",
    historyCleanupKeepAllVersionsNewerThanDays: "Garder toutes les versions plus récentes que jours",
    historyCleanupKeepLatestVersionPerDayForDays: "Garder la dernière version quotidienne pendant jours",
    historyCleanupPreventCleanup: "Empêcher le nettoyage",
    historyCleanupEnableCleanup: "Activer le nettoyage",
    historyCleanupGloballyDisabled: "<strong>REMARQUE!</strong> Le nettoyage de l'historique des versions de contenu est désactvé globalement. Ces paramètres ne prendront pas effet avant qu'il ne soit activé."
  },
  webhooks: {
    addWebhook: "Créer un webhook",
    addWebhookHeader: "Ajouter un header au webhook",
    logs: "Logs",
    addDocumentType: "Ajouter un Type de Document",
    addMediaType: "Ajouter un Type de Media"
  },
  languages: {
    addLanguage: "Ajouter une langue",
    mandatoryLanguage: "Langue obligatoire",
    mandatoryLanguageHelp: "Les propriétés doivent être remplies dans cette langue avant que le noeud ne puisse être publié.",
    defaultLanguage: "Langue par défaut",
    defaultLanguageHelp: "Un site Umbraco ne peut avoir qu'une seule langue par défaut définie.",
    changingDefaultLanguageWarning: "Changer la langue par défaut peut amener à ce que du contenu par défaut soit manquant.",
    fallsbackToLabel: "Retombe sur",
    noFallbackLanguageOption: "Pas de langue alternative",
    fallbackLanguageDescription: "Pour permettre à un site multi-langue de retomber sur une autre langue dans le cas où il n'existe pas dans la langue demandée, sélectionnez-là ici.",
    fallbackLanguage: "Langue alternative",
    none: "aucune"
  },
  macro: {
    addParameter: "Ajouter un paramètre",
    editParameter: "Modifier le paramètre",
    enterMacroName: "Introduire le nom de la macro",
    parameters: "Paramètres",
    parametersDescription: "Définir les paramètres qui devraient être disponibles lorsque l'on utilise cette macro.",
    selectViewFile: "Sélectionner le fichier de vue partielle de la macro"
  },
  modelsBuilder: {
    buildingModels: "Fabrication des modèles",
    waitingMessage: "ceci peut prendre un peu de temps, ne vous inquiétez pas",
    modelsGenerated: "Modèles générés",
    modelsGeneratedError: "Les modèles n'ont pas pu être générés",
    modelsExceptionInUlog: "La génération des modèles a échoué, voyez les exceptions dans les U log"
  },
  templateEditor: {
    addDefaultValue: "Ajouter une valeur par défaut",
    defaultValue: "Valeur par défaut",
    alternativeField: "Champ alternatif",
    alternativeText: "Texte alternatif",
    casing: "Casse",
    encoding: "Encodage",
    chooseField: "Choisir un champ",
    convertLineBreaks: "Convertir les sauts de ligne",
    convertLineBreaksHelp: "Remplace les sauts de ligne avec des balises 'br'",
    customFields: "Champs particuliers",
    dateOnly: "Oui, la date seulement",
    formatAsDate: "Formater comme une date",
    htmlEncode: "Encoder en HTML",
    htmlEncodeHelp: "Remplacera les caractères spéciaux par leur équivalent HTML.",
    insertedAfter: "Sera inséré après la valeur du champ",
    insertedBefore: "Sera inséré avant la valeur du champ",
    lowercase: "Minuscules",
    none: "Aucun",
    outputSample: "Example de résultat",
    postContent: "Insérer après le champ",
    preContent: "Insérer avant le champ",
    recursive: "Récursif",
    recursiveDescr: "Oui, rendre récursif",
    standardFields: "Champs standards",
    uppercase: "Majuscules",
    urlEncode: "Encode pour URL",
    urlEncodeHelp: "Formatera les caractères spéciaux dans les URL",
    usedIfAllEmpty: "Sera seulement utilisé si toutes les valeurs des champs ci-dessus sont vides",
    usedIfEmpty: "Ce champ sera utilisé seulement si le champ initial est vide",
    withTime: "Oui, avec l'heure. Séparateur: "
  },
  translation: {
    details: "Détails",
    DownloadXmlDTD: "Télécharger la DTD XML",
    fields: "Champs",
    includeSubpages: "Inclure les pages enfants",
    mailBody: `
      Hello %0%

      Ceci est un mail automatique pour vous informer que le document '%1%'
      a été envoyé pour traduction en '%5%' par %2%.

      Allez sur http://%3%/translation/details.aspx?id=%4% pour l'éditer.

      Ou connectez-vous à Umbraco pour obtenir une vue d'ensemble des tâches de traduction qui vous sont assignées
      http://%3%

      Bonne journée !

      Avec les salutations du Robot Umbraco
    `,
    noTranslators: "Aucun utilisateur traducteur trouvé. Veuillez créer un utilisateur traducteur avant d'envoyer du contenu pour traduction",
    pageHasBeenSendToTranslation: "La page '%0%' a été envoyée pour traduction",
    sendToTranslate: "Envoyer la page '%0%' pour traduction",
    totalWords: "Nombre total de mots",
    translateTo: "Traduire en",
    translationDone: "Traduction complétée.",
    translationDoneHelp: "Vous pouvez prévisualiser les pages que vous avez traduites en cliquant ci-dessous. Si la page originale est trouvée, vous verrez une comparaison entre les deux pages.",
    translationFailed: "Traduction échouée, il se pourrait que fichier XML soit corrompu",
    translationOptions: "Options de traduction",
    translator: "Traducteur",
    uploadTranslationXml: "Uploader le fichier de traduction XML"
  },
  treeHeaders: {
    content: "Contenu",
    contentBlueprints: "Types de contenu",
    media: "Media",
    cacheBrowser: "Navigateur de cache",
    contentRecycleBin: "Corbeille",
    createdPackages: "Packages créés",
    dataTypes: "Types de données",
    dictionary: "Dictionnaire",
    installedPackages: "Packages installés",
    installSkin: "Installer une skin",
    installStarterKit: "Installer un starter kit",
    languages: "Langues",
    localPackage: "Installer un package local",
    macros: "Macros",
    mediaTypes: "Types de média",
    member: "Membres",
    memberGroups: "Groupes de membres",
    memberRoles: "Rôles",
    memberTypes: "Types de membres",
    documentTypes: "Types de documents",
    relationTypes: "Types de relations",
    packager: "Packages",
    packages: "Packages",
    partialViews: "Vues Partielles",
    partialViewMacros: "Vues Partielles pour les Fichiers Macro",
    repositories: "Installer depuis le repository",
    runway: "Installer Runway",
    runwayModules: "Modules Runway",
    scripting: "Fichiers de script",
    scripts: "Scripts",
    stylesheets: "Feuilles de style",
    templates: "Modèles",
    logViewer: "Visualisation des Log",
    users: "Utilisateurs",
    settingsGroup: "Configuration",
    templatingGroup: "Modélisation",
    thirdPartyGroup: "Parties Tierces",
    webhooks: "Webhooks"
  },
  update: {
    updateAvailable: "Nouvelle mise à jour disponible",
    updateDownloadText: "%0% est disponible, cliquez ici pour télécharger",
    updateNoServer: "Aucune connexion au serveur",
    updateNoServerError: "Erreur lors de la recherche de mises à jour. Veuillez vérifier le stack trace pour obtenir plus d'informations."
  },
  user: {
    access: "Accès",
    accessHelp: "Sur base des groupes et des noeuds de départ, l'utilisateur a accès aux noeuds suivants",
    assignAccess: "Donner accès",
    administrators: "Administrateur",
    categoryField: "Champ catégorie",
    createDate: "Utilisateur créé",
    changePassword: "Changer le mot de passe",
    changePhoto: "Changer la photo",
    newPassword: "Nouveau mot de passe",
    newPasswordFormatLengthTip: "Plus que %0% caractère(s) minimum!",
    newPasswordFormatNonAlphaTip: "Il devrait y avoir au moins %0% caractère(s) spéciaux.",
    noLockouts: "n'a pas été bloqué",
    noPasswordChange: "Le mot de passe n'a pas été modifié",
    confirmNewPassword: "Confirmez votre nouveau mot de passe",
    changePasswordDescription: `Vous pouvez changer votre mot de passe d'accès au backoffice Umbraco en remplissant le formulaire ci-dessous puis en cliquant sur le bouton "Changer le mot de passe"`,
    contentChannel: "Canal de contenu",
    createAnotherUser: "Créer un autre utilisateur",
    createUserHelp: "Créer de nouveaux utilisateurs pour leur donner accès à Umbraco. Lors de la création d'un nouvel utilisateur, un mot de passe est généré que vous pouvez partager avec ce dernier.",
    descriptionField: "Champ description",
    disabled: "Désactiver l'utilisateur",
    documentType: "Type de document",
    editors: "Editeur",
    excerptField: "Champ extrait",
    failedPasswordAttempts: "Tentatives de connexion échouées",
    goToProfile: "Voir le profil de l'utilisateur",
    groupsHelp: "Ajouter des groupes pour donner les accès et permissions",
    inviteAnotherUser: "Inviter un autre utilisateur",
    inviteUserHelp: "Inviter de nouveaux utilisateurs pour leur donner accès à Umbraco. Un email d'invitation sera envoyé à chaque utilisateur avec des informations concernant la connexion à Umbraco. Les invitations sont valables pendant 72 heures.",
    language: "Langue",
    languageHelp: "Spécifiez la langue dans laquelle vous souhaitez voir les menus et dialogues",
    lastLockoutDate: "Date du dernier bloquage",
    lastLogin: "Dernière connexion",
    lastPasswordChangeDate: "Dernière modification du mot de passe",
    loginname: "Identifiant",
    mediastartnode: "Noeud de départ dans la librarie de média",
    mediastartnodehelp: "Limiter la librairie média à un noeud de départ spécifique",
    mediastartnodes: "Noeuds de départ dans la librairie de média",
    mediastartnodeshelp: "Limiter la librairie média à des noeuds de départ spécifique",
    modules: "Sections",
    noConsole: "Désactiver l'accès Umbraco",
    noLogin: "ne s'est pas encore connecté",
    oldPassword: "Ancien mot de passe",
    password: "Mot de passe",
    resetPassword: "Réinitialiser le mot de passe",
    passwordChanged: "Votre mot de passe a été modifié!",
    passwordConfirm: "Veuillez confirmer votre nouveau mot de passe",
    passwordEnterNew: "Introduisez votre nouveau mot de passe",
    passwordIsBlank: "Votre nouveau mot de passe ne peut être vide !",
    passwordCurrent: "Mot de passe actuel",
    passwordInvalid: "Mot de passe actuel invalide",
    passwordIsDifferent: "Il y a une différence entre le nouveau mot de passe et le mot de passe confirmé. Veuillez réessayer.",
    passwordMismatch: "Le mot de passe confirmé ne correspond pas au nouveau mot de passe saisi!",
    permissionReplaceChildren: "Remplacer les permissions sur les noeuds enfants",
    permissionSelectedPages: "Vous êtes en train de modifiez les permissions pour les pages :",
    permissionSelectPages: "Choisissez les pages dont les permissions doivent être modifiées",
    removePhoto: "Supprimer la photo",
    permissionsDefault: "Permissions par défaut",
    permissionsGranular: "Permissions granulaires",
    permissionsGranularHelp: "Définir les permissions sur des noeuds spécifiques",
    profile: "Profil",
    searchAllChildren: "Rechercher tous les enfants",
    sectionsHelp: "Ajouter les sections auxquelles les utilisateurs peuvent accéder",
    selectUserGroups: "Sélectionner les groupes d'utilisateurs",
    noStartNode: "Aucun noeud de départ sélectionné",
    noStartNodes: "Aucun noeud de départ sélectionné",
    startnode: "Noeud de départ du contenu",
    startnodehelp: "Limiter l'arborescence de contenu à un noeud de départ spécifique",
    startnodes: "Noeuds de départ du contenu",
    startnodeshelp: "Limiter l'arborescence de contenu à des noeuds de départ spécifiques",
    updateDate: "Dernière mise à jour de l'utilisateur",
    userCreated: "a été créé",
    userCreatedSuccessHelp: "Le nouvel utilisateur a été créé avec succès. Utilisez le mot de passe ci-dessous pour la connexion à Umbraco.",
    userManagement: "Gestion des utilisateurs",
    username: "Nom d'utilisateur",
    userPermissions: "Permissions de l'utilisateur",
    usergroup: "Groupe d'utilisateurs",
    userInvited: "a été invité",
    userInvitedSuccessHelp: "Une invitation a été envoyée au nouvel utilisateur avec les détails concernant la connexion à Umbraco.",
    userinviteWelcomeMessage: "Bien le bonjour et bienvenue dans Umbraco! Vous serez prêt.e dans moins d'1 minute, vous devez encore simplement configurer votre mot de passe.",
    userinviteExpiredMessage: "Bienvenue dans Umbraco! Malheureusement, votre invitation a expiré. Veuillez contacter votre administrateur et demandez-lui de vous l'envoyer à nouveau.",
    writer: "Rédacteur",
    change: "Modifier",
    yourProfile: "Votre profil",
    yourHistory: "Votre historique récent",
    sessionExpires: "La session expire dans",
    inviteUser: "Inviter un utilisateur",
    createUser: "Créer un utilisateur",
    sendInvite: "Envoyer l'invitation",
    backToUsers: "Retour aux utilisateurs",
    inviteEmailCopySubject: "Umbraco: Invitation",
    inviteEmailCopyFormat: `
        <html>
			<head>
				<meta name='viewport' content='width=device-width'>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
			</head>
			<body class='' style='font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; color: #392F54; line-height: 22px; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background: #1d1333; margin: 0; padding: 0;' bgcolor='#1d1333'>
				<style type='text/css'> @media only screen and (max-width: 620px) {table[class=body] h1 {font-size: 28px !important; margin-bottom: 10px !important; } table[class=body] .wrapper {padding: 32px !important; } table[class=body] .article {padding: 32px !important; } table[class=body] .content {padding: 24px !important; } table[class=body] .container {padding: 0 !important; width: 100% !important; } table[class=body] .main {border-left-width: 0 !important; border-radius: 0 !important; border-right-width: 0 !important; } table[class=body] .btn table {width: 100% !important; } table[class=body] .btn a {width: 100% !important; } table[class=body] .img-responsive {height: auto !important; max-width: 100% !important; width: auto !important; } } .btn-primary table td:hover {background-color: #34495e !important; } .btn-primary a:hover {background-color: #34495e !important; border-color: #34495e !important; } .btn  a:visited {color:#FFFFFF;} </style>
				<table border="0" cellpadding="0" cellspacing="0" class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;" bgcolor="#1d1333">
					<tr>
						<td style="font-family: sans-serif; font-size: 14px; vertical-align: top; padding: 24px;" valign="top">
							<table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;">
								<tr>
									<td background="https://umbraco.com/umbraco/assets/img/application/logo.png" bgcolor="#1d1333" width="28" height="28" valign="top" style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
										<!--[if gte mso 9]> <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:30px;height:30px;"> <v:fill type="tile" src="https://umbraco.com/umbraco/assets/img/application/logo.png" color="#1d1333" /> <v:textbox inset="0,0,0,0"> <![endif]-->
										<div> </div>
										<!--[if gte mso 9]> </v:textbox> </v:rect> <![endif]-->
									</td>
									<td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top"></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;' bgcolor='#1d1333'>
					<tr>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
						<td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 560px; width: 560px; margin: 0 auto; padding: 10px;' valign='top'>
							<div class='content' style='box-sizing: border-box; display: block; max-width: 560px; margin: 0 auto; padding: 10px;'>
								<br>
								<table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; border-radius: 3px; background: #FFFFFF;' bgcolor='#FFFFFF'>
									<tr>
										<td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 50px;' valign='top'>
											<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
												<tr>
													<td style='line-height: 24px; font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'>
														<h1 style='color: #392F54; font-family: sans-serif; font-weight: bold; line-height: 1.4; font-size: 24px; text-align: left; text-transform: capitalize; margin: 0 0 30px;' align='left'>
															Salut %0%,
														</h1>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Vous avez été invité.e par <a href="mailto:%4%" style="text-decoration: underline; color: #392F54; -ms-word-break: break-all; word-break: break-all;">%1%</a> à accéder au Umbraco Back Office.
														</p>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Message de <a href="mailto:%1%" style="text-decoration: none; color: #392F54; -ms-word-break: break-all; word-break: break-all;">%1%</a>:
															<br/>
															<em>%2%</em>
														</p>
														<table border='0' cellpadding='0' cellspacing='0' class='btn btn-primary' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; box-sizing: border-box;'>
															<tbody>
																<tr>
																	<td align='left' style='font-family: sans-serif; font-size: 14px; vertical-align: top; padding-bottom: 15px;' valign='top'>
																		<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
																			<tbody>
																				<tr>
																					<td style='font-family: sans-serif; font-size: 14px; vertical-align: top; border-radius: 5px; text-align: center; background: #35C786;' align='center' bgcolor='#35C786' valign='top'>
																						<a href='%3%' target='_blank' rel='noopener' style='color: #FFFFFF; text-decoration: none; -ms-word-break: break-all; word-break: break-all; border-radius: 5px; box-sizing: border-box; cursor: pointer; display: inline-block; font-size: 14px; font-weight: bold; text-transform: capitalize; background: #35C786; margin: 0; padding: 12px 30px; border: 1px solid #35c786;'>
																							Cliquez sur ce lien pour accepter l'invitation
																						</a>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
															</tbody>
														</table>
														<p style='max-width: 400px; display: block; color: #392F54; font-family: sans-serif; font-size: 14px; line-height: 20px; font-weight: normal; margin: 15px 0;'>Si vous ne pouvez pas cliquer sur le lien, copiez cet URL dans votre navigateur :</p>
															<table border='0' cellpadding='0' cellspacing='0'>
																<tr>
																	<td style='-ms-word-break: break-all; word-break: break-all; font-family: sans-serif; font-size: 11px; line-height:14px;'>
																		<font style="-ms-word-break: break-all; word-break: break-all; font-size: 11px; line-height:14px;">
																			<a style='-ms-word-break: break-all; word-break: break-all; color: #392F54; text-decoration: underline; font-size: 11px; line-height:15px;' href='%3%'>%3%</a>
																		</font>
																	</td>
																</tr>
															</table>
														</p>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
								<br><br><br>
							</div>
						</td>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
					</tr>
				</table>
			</body>
    </html>`,
    defaultInvitationMessage: "Nouvel envoi de l'invitation en cours...",
    deleteUser: "Supprimer l'Utilisateur",
    deleteUserConfirmation: "Etes-vous certain(e) de vouloir supprimer le compte de cet utilisateur?",
    stateAll: "Tous",
    stateActive: "Actif",
    stateDisabled: "Désactivé",
    stateLockedOut: "Bloqué",
    stateInvited: "Invité",
    stateInactive: "Inactif",
    sortNameAscending: "Nom (A-Z)",
    sortNameDescending: "Nom (Z-A)",
    sortCreateDateAscending: "Plus ancien",
    sortCreateDateDescending: "Plus récent",
    sortLastLoginDateDescending: "Dernière connexion"
  },
  validation: {
    validation: "Validation",
    validateAsEmail: "Valider comme email",
    validateAsNumber: "Valider comme nombre",
    validateAsUrl: "Valider comme URL",
    enterCustomValidation: "...ou introduisez une validation spécifique",
    fieldIsMandatory: "Champ obligatoire",
    mandatoryMessage: "Introduisez un message d'erreur de validation personnalisé (optionnel)",
    validationRegExp: "Introduisez une expression régulière",
    validationRegExpMessage: "Introduisez un message d'erreur de validation personnalisé (optionnel)",
    minCount: "Vous devez ajouter au moins",
    maxCount: "Vous ne pouvez avoir que",
    items: "éléments",
    itemsSelected: "éléments sélectionnés",
    invalidDate: "Date non valide",
    invalidNumber: "Pas un nombre",
    invalidEmail: "Email non valide",
    invalidNull: "La valeur ne peut pas être null",
    invalidEmpty: "La valeur ne peut pas être vide",
    invalidPattern: "Valeur non valide, elle ne correspond pas au modèle correct",
    customValidation: "Validation personnalisée",
    entriesShort: "Minimum %0% éléments, en nécessite <strong>%1%</strong> supplémentaires.",
    entriesExceed: "Maximum %0% éléments, <strong>%1%</strong> en trop."
  },
  healthcheck: {
    checkSuccessMessage: "La valeur est égale à la valeur recommandée : '%0%'.",
    checkErrorMessageDifferentExpectedValue: "La valeur attendue pour '%2%' dans le fichier de configuration '%3%' est '%1%', mais la valeur trouvée est '%0%'.",
    checkErrorMessageUnexpectedValue: "La valeur inattendue '%0%' a été trouvée pour '%2%' dans le fichier de configuration '%3%'.",
    macroErrorModeCheckSuccessMessage: "MacroErrors est fixé à la valeur '%0%'.",
    macroErrorModeCheckErrorMessage: "MacroErrors est fixé à la valeur '%0%', ce qui empêchera certaines ou même toutes les pages de votre site de se charger complètement en cas d'erreur dans les macros. La rectification de ceci fixera la valeur à '%1%'.",
    httpsCheckValidCertificate: "Le certificat de votre site a été marqué comme valide.",
    httpsCheckInvalidCertificate: "Erreur de validation du certificat : '%0%'",
    httpsCheckExpiredCertificate: "Le certificat SSL de votre site web a expiré.",
    httpsCheckExpiringCertificate: "Le certificat SSL de votre site web va expirer dans %0% jours.",
    healthCheckInvalidUrl: "Erreur en essayant de contacter l'URL %0% - '%1%'",
    httpsCheckIsCurrentSchemeHttps: "Vous êtes actuellement %0% à voir le site via le schéma HTTPS.",
    httpsCheckConfigurationRectifyNotPossible: `
      L'appSetting 'Umbraco:CMS:Global:UseHttps' se trouve à 'false' dans votre fichier appSettings.json.
      Une fois que vous aurez accès à ce site via le schema HTTPS, il faudra la mettre à 'true'.
    `,
    httpsCheckConfigurationCheckResult: `
      L'appSetting 'Umbraco:CMS:Global:UseHttps' se trouve à '%0%' dans votre fichier
      appSettings.json, vos cookies sont %1% marqués comme 'secured'.
    `,
    compilationDebugCheckSuccessMessage: "Le mode de compilation Debug est désactivé.",
    compilationDebugCheckErrorMessage: "Le mode de compilation Debug est actuellement activé. Il est recommandé de désactiver ce paramètre avant la mise en ligne.",
    clickJackingCheckHeaderFound: "Le header ou meta-tag <strong>X-Frame-Options</strong>, utilisé pour contrôler si un site peut être intégré dans un autre via IFRAME, a été trouvé.",
    clickJackingCheckHeaderNotFound: "Le header ou meta-tag <strong>X-Frame-Options</strong> , utilisé pour contrôler si un site peut être intégré dans un autre via IFRAME, n'a pas été trouvé.",
    noSniffCheckHeaderFound: "L'en-tête ou le meta-tag <strong>X-Content-Type-Options</strong> utilisé pour la protection contre les vulnérabilités de MIME sniffing a été trouvé.",
    noSniffCheckHeaderNotFound: "L'en-tête ou le meta-tag <strong>X-Content-Type-Options</strong> utilisé pour la protection contre les vulnérabilités de MIME sniffing n'a pas été trouvé.",
    hSTSCheckHeaderFound: "L'en-tête <strong>Strict-Transport-Security</strong>, aussi connu sous le nom de HSTS-header, a été trouvé.",
    hSTSCheckHeaderNotFound: "L'en-tête <strong>Strict-Transport-Security</strong>, aussi connu sous le nom de HSTS-header, n'a pas été trouvé.",
    xssProtectionCheckHeaderFound: "L'en-tête <strong>X-XSS-Protection</strong> a été trouvé.",
    xssProtectionCheckHeaderNotFound: "L'en-tête <strong>X-XSS-Protection</strong> n'a pas été trouvé.",
    excessiveHeadersFound: "Les headers suivants révélant des informations à propos de la technologie du site web ont été trouvés  : <strong>%0%</strong>.",
    excessiveHeadersNotFound: "Aucun header révélant des informations à propos de la technologie du site web n'a été trouvé.",
    smtpMailSettingsConnectionSuccess: "La configuration SMTP est correcte et le service fonctionne comme prévu.",
    notificationEmailsCheckSuccessMessage: "Un email de notification a été envoyé à <strong>%0%</strong>.",
    notificationEmailsCheckErrorMessage: "L'adresse email de notification est toujours à sa valeur par défaut : <strong>%0%</strong>."
  },
  redirectUrls: {
    disableUrlTracker: "Désactiver URL tracker",
    enableUrlTracker: "Activer URL tracker",
    culture: "Culture",
    originalUrl: "URL original",
    redirectedTo: "Redirigé Vers",
    redirectUrlManagement: "Gestion des redirections d'URL",
    panelInformation: "Les URLs suivants redirigent vers cet élément de contenu :",
    noRedirects: "Aucune redirection n'a été créée",
    noRedirectsDescription: "Lorsqu'une page publiée est renommée ou déplacée, une redirection sera automatiquement créée vers la nouvelle page.",
    redirectRemoved: "Redirection d'URL supprimée.",
    redirectRemoveError: "Erreur lors de la suppression de la redirection d'URL.",
    redirectRemoveWarning: "Ceci supprimera la redirection",
    confirmDisable: "Etes-vous certain(e) de vouloir désactiver le URL tracker?",
    disabledConfirm: "URL tracker est maintenant désactivé.",
    disableError: "Erreur lors de la désactivation de l'URL tracker, plus d'information disponible dans votre fichier log.",
    enabledConfirm: "URL tracker est maintenant activé.",
    enableError: "Erreur lors de l'activation de l'URL tracker, plus d'information disponible dans votre fichier log."
  },
  emptyStates: {
    emptyDictionaryTree: "Pas d'élément de dictionaire à choisir"
  },
  textbox: {
    characters_left: "<strong>%0%</strong> caractères restant.",
    characters_exceed: "Maximum %0% caractères, <strong>%1%</strong> en trop."
  },
  recycleBin: {
    contentTrashed: "Suppression du contenu avec l'Id : {0} lié au contenu parent original avec l'Id : {1}",
    mediaTrashed: "Suppression du media avec l'Id : {0} lié à l'élément media parent original avec l'Id : {1}",
    itemCannotBeRestored: "Cet élément ne peut pas être restauré automatiquement",
    itemCannotBeRestoredHelpText: "Il n'y a aucun endroit où cet élément peut être restauré automatiquement. Vous pouvez déplacer l'élément manuellement en utilisant l'arborescence ci-dessous.",
    wasRestored: "a été restauré sous"
  },
  relationType: {
    direction: "Direction",
    parentToChild: "Parent vers enfant",
    bidirectional: "Bi-directionnel",
    parent: "Parent",
    child: "Enfant",
    count: "Nombre",
    relations: "Relations",
    created: "Création",
    comment: "Remarque",
    name: "Nom",
    noRelations: "Aucune relation pour ce type de relation.",
    tabRelationType: "Type de Relation",
    tabRelations: "Relations"
  },
  dashboardTabs: {
    contentIntro: "Pour Commencer",
    contentRedirectManager: "Gestion des redirections d'URL",
    mediaFolderBrowser: "Contenu",
    settingsWelcome: "Bienvenue",
    settingsExamine: "Gestion d'Examine",
    settingsPublishedStatus: "Statut Publié",
    settingsModelsBuilder: "Models Builder",
    settingsHealthCheck: "Health Check",
    settingsProfiler: "Profilage",
    memberIntro: "Pour Commencer",
    formsInstall: "Installer Umbraco Forms"
  },
  visuallyHiddenTexts: {
    goBack: "Retour",
    activeListLayout: "Layouts actifs :",
    jumpTo: "Aller à",
    group: "groupe",
    passed: "passé",
    warning: "avertissement",
    failed: "échoué",
    suggestion: "suggestion",
    checkPassed: "Vérifier les succès",
    checkFailed: "Vérifier les échecs",
    openBackofficeSearch: "Ouvrir la recherche backoffice",
    openCloseBackofficeHelp: "Ouvrir/Fermer l'aide backoffice",
    openCloseBackofficeProfileOptions: "Ouvrir/Fermer vos options de profil",
    openContextMenu: "Ouvrir le menu de contexte pour",
    currentLanguage: "Langue actuelle",
    switchLanguage: "Changer la langue vers",
    createNewFolder: "Créer un nouveau dossier",
    newPartialView: "Partial View",
    newPartialViewMacro: "Macro de Partial View",
    newMember: "Membre",
    searchContentTree: "Chercher dans l'arborescence de contenu",
    maxAmount: "Quantité maximum",
    expandChildItems: "Afficher les éléments enfant pour",
    openContextNode: "Ouvrir le noeud de contexte pour"
  },
  references: {
    tabName: "Références",
    DataTypeNoReferences: "Ce Type de Données n'a pas de références.",
    labelUsedByDocumentTypes: "Utilisé dans des Types de Document",
    labelUsedByMediaTypes: "Utilisé dans les Types de Media",
    labelUsedByMemberTypes: "Utilisé dans les Types de Membre",
    usedByProperties: "Utilisé par"
  },
  logViewer: {
    logLevels: "Niveaux de Log",
    selectAllLogLevelFilters: "Tout sélectionner",
    deselectAllLogLevelFilters: "Tout déselectionner",
    savedSearches: "Recherches sauvegardées",
    totalItems: "Nombre total d'éléments",
    timestamp: "Date",
    level: "Niveau",
    machine: "Machine",
    message: "Message",
    exception: "Exception",
    properties: "Propriétés",
    searchWithGoogle: "Chercher avec Google",
    searchThisMessageWithGoogle: "Chercher ce message avec Google",
    searchWithBing: "Chercher avec Bing",
    searchThisMessageWithBing: "Chercher ce message avec Bing",
    searchOurUmbraco: "Chercher dans Our Umbraco",
    searchThisMessageOnOurUmbracoForumsAndDocs: "Chercher ce message dans les forums et docs de Our Umbraco",
    searchOurUmbracoWithGoogle: "Chercher dans Our Umbraco avec Google",
    searchOurUmbracoForumsUsingGoogle: "Chercher dans les forums de Our Umbraco en utilisant Google",
    searchUmbracoSource: "Chercher dans les Sources Umbraco",
    searchWithinUmbracoSourceCodeOnGithub: "Chercher dans le code source d'Umbraco sur Github",
    searchUmbracoIssues: "Chercher dans les Umbraco Issues",
    searchUmbracoIssuesOnGithub: "Chercher dans les Umbraco Issues sur Github",
    deleteThisSearch: "Supprimer cette recherche",
    findLogsWithRequestId: "Trouver les Logs avec la Request ID",
    findLogsWithNamespace: "Trouver les Logs avec le Namespace",
    findLogsWithMachineName: "Trouver les logs avec le Nom de Machine",
    open: "Ouvrir"
  },
  clipboard: {
    labelForCopyAllEntries: "Copier %0%",
    labelForArrayOfItemsFrom: "%0% de %1%",
    labelForRemoveAllEntries: "Supprimer tous les éléments"
  },
  propertyActions: {
    tooltipForPropertyActionsMenu: "Ouvrir les Property Actions"
  },
  nuCache: {
    refreshStatus: "Rafraîchir le Statut",
    memoryCache: "Cache Mémoire",
    memoryCacheDescription: `
			Ce bouton vous permet de recharger la cache en mémoire, en la rechargeant entièrement à partir de la cache
	en base de données (mais sans reconstruire cette cache en base de données). C'est une opération relativement rapide.
	Utilisez-le lorsque vous pensez que la cache en mémoire n'a pas été rafraîchie convenablement, après que certains
	événements ont été déclenchés&mdash;ce qui indiquerait un problème mineur dans Umbraco.
	(remarque: ceci déclenche le rechargement sur tous les serveurs dans un environnement LB).
    `,
    reload: "Recharger",
    databaseCache: "Cache en Base de Données",
    databaseCacheDescription: `
	Ce bouton vous permet de reconstruire la cache en base de données, càd le contenu de la table cmsContentNu.
    <strong>La reconstruction peut être une opération lourde.</strong>
	Utilisez-le lorsque le rechargement ne suffit pas, et que vous pensez que la cache en base de données n'a pas été
	générée convenablement&mdash;ce qui indiquerait des problèmes critiques dans Umbraco.
    `,
    rebuild: "Reconstruire",
    internals: "Opérations Internes",
    internalsDescription: `
	Ce bouton vous permet de déclencher une collection de snapshots NuCache (après exécution d'un fullCLR GC).
	A moins que vous sachiez ce que cela signifie, vous n'avez probablement <em>pas</em> besoin de l'utiliser.
    `,
    collect: "Collecter",
    publishedCacheStatus: "Statut de la Cache Publiée",
    caches: "Caches"
  },
  profiling: {
    performanceProfiling: "Profilage de performances",
    performanceProfilingDescription: `
                <p>
				   Umbraco est actuellement exécuté en mode debug. Cela signifie que vous pouvez utiliser le profileur de performances intégré pour évaluer les performance lors du rendu des pages.
                </p>
                <p>
                    Si vous souhaitez activer le profileur pour le rendu d'une page spécifique, ajoutez simplement <strong>umbDebug=true</strong> au querystring lorsque vous demandez la page.
                </p>
                <p>
                    Si vous souhaitez que le profileur soit activé par défaut pour tous les rendus de pages, vous pouvez utiliser le bouton bascule ci-dessous.
					Cela créera un cookie dans votre browser, qui activera alors le profileur automatiquement.
                    En d'autres termes, le profileur ne sera activé par défaut que dans <em>votre</em> browser - pas celui des autres.
                </p>
        `,
    activateByDefault: "Activer le profileur par défaut",
    reminder: "Rappel amical"
  },
  settingsDashboardVideos: {
    trainingHeadline: "Des heures de vidéos de formation Umbraco ne sont qu'à un clic d'ici",
    trainingDescription: `
        <p>Vous voulez maîtriser Umbraco? Passez quelques minutes à apprendre certaines des meilleures pratiques en regardant une de ces vidéos à propos de l'utilisation d'Umbraco. Et visitez <a href="http://umbraco.tv" target="_blank" rel="noopener">umbraco.tv</a> pour encore plus de vidéos Umbraco</p>
    `,
    getStarted: "Pour démarrer"
  },
  settingsDashboard: {
    start: "Commencer ici",
    startDescription: "Cette section contient les blocs fondamentaux pour votre site Umbraco. Suivez les liens ci-dessous pour en apprendre d'avantage sur la façon de travailler avec les éléments de la section Settings",
    more: "En savoir plus",
    bulletPointOne: `
            Lisez-en plus sur la façon de travailler avec les éléments dans la section Settings <a class="btn-link -underline" href="https://docs.umbraco.com/umbraco-cms/fundamentals/backoffice/sections/" target="_blank" rel="noopener">dans la section Documentation</a> de Our Umbraco
        `,
    bulletPointTwo: `
            Posez une question dans le <a class="btn-link -underline" href="https://our.umbraco.com/forum" target="_blank" rel="noopener">Community Forum</a>
        `,
    bulletPointThree: `
            Regardez nos <a class="btn-link -underline" href="https://umbraco.tv" target="_blank" rel="noopener">tutoriels vidéos</a> (certains sont gratuits, certains nécessitent un abonnement)
        `,
    bulletPointFour: `
            Découvrez nos <a class="btn-link -underline" href="https://umbraco.com/products/" target="_blank" rel="noopener">outils d'amélioration de productivité et notre support commercial</a>
        `,
    bulletPointFive: `
            Découvrez nos possibilités de <a class="btn-link -underline" href="https://umbraco.com/training/" target="_blank" rel="noopener">formations et certifications</a>
        `
  },
  treeSearch: {
    searchResult: "élément retrouvé",
    searchResults: "éléments retrouvés"
  }
};
export {
  e as default
};
//# sourceMappingURL=fr-fr-BTNJAZQp.js.map
