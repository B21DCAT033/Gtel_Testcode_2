const e = {
  actions: {
    assigndomain: "Kultura i imena hostova",
    auditTrail: "Audit zapis",
    browse: "Pregledaj čvor",
    changeDocType: "Promijeni Vrstu Dokumenta",
    copy: "Kopiraj",
    create: "Kreiraj",
    export: "Izvezi",
    createPackage: "Kreiraj Paket",
    createGroup: "Kreiraj grupu",
    delete: "Obriši",
    disable: "Onemogući",
    editSettings: "Uredi postavke",
    emptyrecyclebin: "Isprazni koš za smeće",
    enable: "Omogući",
    exportDocumentType: "Izvezi Vrstu Dokumenta",
    importdocumenttype: "Uvezi Vrstu Dokumenta",
    importPackage: "Uvezi Paket",
    liveEdit: "Uređivanje na stranici",
    logout: "Izlaz",
    move: "Premjesti",
    notify: "Obavijesti",
    protect: "Javni pristup",
    publish: "Objavi",
    unpublish: "Poništi objavu",
    refreshNode: "Osvježi",
    republish: "Ponovna objava cijele stranice",
    remove: "Ukloni",
    rename: "Preimenuj",
    restore: "Vrati",
    chooseWhereToCopy: "Odaberite gdje ćete kopirati",
    chooseWhereToMove: "Odaberite gdje ćete premjestiti",
    chooseWhereToImport: "Odaberite gdje ćete uvesti",
    toInTheTreeStructureBelow: "do u strukturi stabla ispod",
    infiniteEditorChooseWhereToCopy: "Odaberite gdje želite kopirati odabrane stavke",
    infiniteEditorChooseWhereToMove: "Odaberite gdje želite premjestiti odabrane stavke",
    wasMovedTo: "je premješteno u",
    wasCopiedTo: "je kopirana u",
    wasDeleted: "je obrisana",
    rights: "Dozvole",
    rollback: "Vraćanje unazad",
    sendtopublish: "Pošalji na objavljivanje",
    sendToTranslate: "Pošalji na prijevod",
    setGroup: "Postavi grupu",
    sort: "Sortiraj",
    translate: "Prevedi",
    update: "Ažuriraj",
    setPermissions: "Postavi dozvole",
    unlock: "Otključaj",
    createblueprint: "Kreirajte Predložak Sadržaja",
    resendInvite: "Ponovo pošaljite pozivnicu"
  },
  actionCategories: {
    content: "Sadržaj",
    administration: "Administracija",
    structure: "Struktura",
    other: "Ostalo"
  },
  actionDescriptions: {
    assignDomain: "Dopustite pristup za dodjelu kulture i imena hostova",
    auditTrail: "Dopustite pristup za pregled dnevnika povijesti čvora",
    browse: "Dopustite pristup za pregled čvora",
    changeDocType: "Dopustite pristup za promjenu Vrste Dokumenta za čvor",
    copy: "Dopustite pristup za kopiranje čvora",
    create: "Dopustite pristup za kreiranje čvora",
    delete: "Dopustite pristup za brisanje čvora",
    move: "Dopustite pristup za premještaj čvora",
    protect: "Dopustite pristup za postavljanje i promjenu javnog pristupa za čvor",
    publish: "Dopustite pristup za objavljivanje čvora",
    unpublish: "Dopustite pristup da poništavanje objave čvora",
    rights: "Dopustite pristup za promjenu dozvola za čvor",
    rollback: "Dopustite pristup za vraćanje čvora na prethodno stanje",
    sendtopublish: "Dopustite pristup za slanje čvora na odobrenje prije objavljivanja",
    sendToTranslate: "Dopustite pristup za slanje čvora na prijevod",
    sort: "Dopustite pristup za promjenu sortiranja čvorova",
    translate: "Dopustite pristup za prevođenje čvora",
    update: "Dopustite pristup za spremanje čvora",
    createblueprint: "Dopustite pristup za kreiranje Predloška Sadržaja",
    notify: "Dopustite pristup za podešavanje obavijesti za čvorove"
  },
  apps: {
    umbContent: "Sadržaj",
    umbInfo: "Info"
  },
  assignDomain: {
    permissionDenied: "Dozvola odbijena.",
    addNew: "Dodaj novu domenu",
    addCurrent: "Dodaj postojeću domenu",
    remove: "Ukloni",
    invalidNode: "Nevažeći čvor.",
    invalidDomain: "Jedna ili više domena imaju nevažeći format.",
    duplicateDomain: "Domena je već dodijeljena.",
    language: "Jezik",
    domain: "Domena",
    domainCreated: "Nova domena '%0%' je kreirana",
    domainDeleted: "Domena '%0%' je obrisana",
    domainExists: "Domena '%0%' je već dodijeljena",
    domainUpdated: "Domena '%0%' je ažurirana",
    orEdit: "Uredi trenutne domene",
    domainHelpWithVariants: `Važeći nazivi domena su: "example.com", "www.example.com", "example.com:8080", ili "https://www.example.com/".
     Nadalje, podržane su i poddomene prvog nivoa, npr. "example.com/en" ili "/en".`,
    inherit: "Naslijedi",
    setLanguage: "Kultura",
    setLanguageHelp: `Postavite kulturu za čvorove ispod trenutnog čvora,<br /> ili naslijedite kulturu od roditeljskih čvorova. Također će se primijeniti<br />
      na trenutni čvor, osim ako se domena u nastavku ne primjenjuje.`,
    setDomains: "Domene"
  },
  buttons: {
    clearSelection: "Obriši odabir",
    select: "Odaberi",
    somethingElse: "Uradi nešto drugo",
    bold: "Podebljano",
    deindent: "Odustani od uvlačenje odlomka",
    formFieldInsert: "Umetni polje obrasca",
    graphicHeadline: "Umetni grafički naslov",
    htmlEdit: "Uredi Html",
    indent: "Uvuci odlomak",
    italic: "Nakošeno",
    justifyCenter: "Centrirano",
    justifyLeft: "Poravnanje lijevo",
    justifyRight: "Poravnanje desno",
    linkInsert: "Umetni link",
    linkLocal: "Umetni lokalni link (sidro)",
    listBullet: "Obična lista",
    listNumeric: "Numerička lista",
    macroInsert: "Umetni makro",
    pictureInsert: "Umetni sliku",
    publishAndClose: "Objavi i zatvori",
    publishDescendants: "Objavi sa potomcima",
    relations: "Uredite odnose",
    returnToList: "Povratak na listu",
    save: "Spremi",
    saveAndClose: "Spremi i zatvori",
    saveAndPublish: "Spremi i objavi",
    saveToPublish: "Spremi i pošalji na odobrenje",
    saveListView: "Spremi prikaz liste",
    schedulePublish: "Zakazivanje objave",
    saveAndPreview: "Spremi i pregledaj",
    showPageDisabled: "Pregled je onemogućen jer nije dodijeljen predložak",
    styleChoose: "Odaberi stil",
    styleShow: "Prikaži stilove",
    tableInsert: "Umetni tablicu",
    saveAndGenerateModels: "Spremi i generiraj modele",
    undo: "Poništi",
    redo: "Vrati",
    deleteTag: "Obriši tag",
    confirmActionCancel: "Odustani",
    confirmActionConfirm: "Potvrdi",
    morePublishingOptions: "Više opcija za objavljivanje",
    submitChanges: "Pošalji"
  },
  auditTrailsMedia: {
    delete: "Mediji je obrisan",
    move: "Mediji premješten",
    copy: "Mediji kopiran",
    save: "Mediji spremljen"
  },
  auditTrails: {
    atViewingFor: "Pregled za",
    delete: "Sadržaj je obrisan",
    unpublish: "Poništena objava Sadržaja",
    unpublishvariant: "Poništena je objava sadržaja za jezike: %0% ",
    publish: "Sadržaj je spremljen i objavljen",
    publishvariant: "Sadržaj spremljen i objavljen za jezike: %0%",
    save: "Sadržaj spremljen",
    savevariant: "Sadržaj spremljen za jezike: %0%",
    move: "Sadržaj premješten",
    copy: "Sadržaj kopiran",
    rollback: "Sadržaj vraćen",
    sendtopublish: "Sadržaj poslan na objavljivanje",
    sendtopublishvariant: "Sadržaj poslan na objavljivanje za jezike: %0%",
    sort: "Sortiranje podređenih stavki je izvršio korisnik",
    custom: "%0%",
    contentversionpreventcleanup: "Čišćenje je onemogućeno za verziju: %0%",
    contentversionenablecleanup: "Čišćenje je omogućeno za verziju: %0%",
    smallCopy: "Kopiraj",
    smallPublish: "Objavljeno",
    smallPublishVariant: "Objavi",
    smallMove: "Premjesti",
    smallSave: "Spremljeno",
    smallSaveVariant: "Spremi",
    smallDelete: "Obriši",
    smallUnpublish: "Poništi objavu",
    smallRollBack: "Vrati na stariju verziju",
    smallSendToPublish: "Pošalji na objavljivanje",
    smallSendToPublishVariant: "Pošalji na objavljivanje",
    smallSort: "Sortiraj",
    smallCustom: "Prilagođeno",
    smallContentVersionPreventCleanup: "Spremi",
    smallContentVersionEnableCleanup: "Spremi",
    historyIncludingVariants: "Povijest (sve varijante)"
  },
  codefile: {
    createFolderIllegalChars: "Naziv mape ne može sadržavati nedozvoljene znakove.",
    deleteItemFailed: "Nije uspjelo brisanje stavke: %0%"
  },
  content: {
    isPublished: "Da li je objavljeno",
    about: "Više o ovoj stranici",
    alias: "Alias",
    alternativeTextHelp: "(kako bi opisali sliku preko telefona)",
    alternativeUrls: "Alternativni linkovi",
    clickToEdit: "Kliknite za uređivanje ove stavke",
    createBy: "Kreirao",
    createByDesc: "Originalni autor",
    updatedBy: "Ažurirao",
    createDate: "Kreirano",
    createDateDesc: "Datum i vrijeme kreiranja ovog dokumenta",
    documentType: "Vrsta dokumenta",
    editing: "Uređivanje",
    expireDate: "Ukloni na",
    itemChanged: "Ova stavka je promijenjena nakon objavljivanja",
    itemNotPublished: "Ova stavka nije objavljena",
    lastPublished: "Posljednje objavljeno",
    noItemsToShow: "Nema stavki za prikaz",
    listViewNoItems: "Nema stavki za prikaz na listi.",
    listViewNoContent: "Nije dodan sadržaj",
    listViewNoMembers: "Nijedan član nije dodan",
    mediatype: "Vrsta medija",
    mediaLinks: "Link do medijske stavke",
    membergroup: "Grupa članova",
    memberrole: "Uloga",
    membertype: "Vrsta člana",
    noChanges: "Nisu napravljene nikakve promjene",
    noDate: "Nije odabran datum",
    nodeName: "Naslov stranice",
    noMediaLink: "Ova medijska stavka nema vezu",
    otherElements: "Svojstva",
    parentNotPublished: "Ovaj dokument je objavljen, ali nije vidljiv jer nadređeni '%0%' nije objavljen",
    parentCultureNotPublished: "Ova kultura je objavljena, ali nije vidljiva jer nije objavljena na nadređenom '%0%'",
    parentNotPublishedAnomaly: "Ovaj dokument je objavljen, ali nije u predmemoriji",
    getUrlException: "Nije moguće dohvatiti URL",
    routeError: "Ovaj dokument je objavljen, ali njegov URL je u sukobu sa sadržajem %0%",
    routeErrorCannotRoute: "Ovaj dokument je objavljen, ali njegov URL se ne može preusmjeriti",
    publish: "Objavi",
    published: "Objavljeno",
    publishedPendingChanges: "Objavljeno (promjene na čekanju)",
    publishStatus: "Status objave",
    publishDescendantsHelp: "Objavi <strong>%0%</strong> i sve stavke sadržaja ispod i time čineći njihov sadržaj javno dostupnim.",
    publishDescendantsWithVariantsHelp: "Objavi varijante i varijante iste vrste ispod i na taj način učinite njihov sadržaj javno dostupnim.",
    releaseDate: "Objavi na",
    unpublishDate: "Poništi objavu na",
    removeDate: "Obriši datum",
    setDate: "Postavi datum",
    sortDone: "Sortiranje je ažurirano",
    sortHelp: `Da biste sortirali čvorove, jednostavno pomaknite čvorove ili kliknite na jedno od zaglavlja kolona. Možete odabrati
       više čvorova držeći tipku "shift" ili "control" dok birate
    `,
    statistics: "Statistika",
    titleOptional: "Naslov (opcionalno)",
    altTextOptional: "Alternativni tekst (opcionalno)",
    captionTextOptional: "Natpis (opcionalno)",
    type: "Vrsta",
    unpublish: "Poništi objavu",
    unpublished: "Neobjavljeno",
    notCreated: "Nije kreirano",
    updateDate: "Zadnje uređivano",
    updateDateDesc: "Datum/vrijeme uređivanja ovog dokumenta",
    uploadClear: "Ukloni datoteke",
    uploadClearImageContext: "Kliknite ovdje kako bi uklonili sliku iz medijske stavke",
    uploadClearFileContext: "Kliknite ovdje kako bi uklonili datoteku iz medijske stavke",
    urls: "Link na dokument",
    memberof: "Član grupe",
    notmemberof: "Nije član grupe",
    childItems: "Dječje stavke",
    target: "Meta",
    scheduledPublishServerTime: "Ovo se označava kao sljedeće vrijeme na serveru:",
    scheduledPublishDocumentation: '<a href="https://docs.umbraco.com/umbraco-cms/fundamentals/data/scheduled-publishing#timezones" target="_blank" rel="noopener">Što ovo znači?</a>',
    nestedContentDeleteItem: "Jeste li sigurni da želite obrisati ovu stavku?",
    nestedContentEditorNotSupported: `Svojstvo %0% koristi uređivač %1% koji nije podržan za Ugniježđeni
      Sadržaj.
    `,
    nestedContentDeleteAllItems: "Jeste li sigurni da želite obrisati sve stavke?",
    nestedContentNoContentTypes: "Za ovo svojstvo nisu konfigurirane vrste sadržaja.",
    nestedContentAddElementType: "Dodajte vrstu elementa",
    nestedContentSelectElementTypeModalTitle: "Odaberite vrstu elementa",
    nestedContentGroupHelpText: `Odaberite grupu čija svojstva trebaju biti prikazana. Ako je ostavljeno prazno,
       koristit će se prva grupa na vrsti elementa.
    `,
    nestedContentTemplateHelpTextPart1: `Unesite angular izraz za procjenu svake stavke za njeno
       ime. Koristi
    `,
    nestedContentTemplateHelpTextPart2: "za prikaz indeksa stavke",
    nestedContentNoGroups: "Odabrana vrsta elementa ne sadrži nijednu podržanu grupu (ovaj uređivač ne podržava kartice, promijenite ih u grupe ili koristite uređivač liste blokova).",
    addTextBox: "Dodajte još jedan okvir za tekst",
    removeTextBox: "Uklonite ovaj okvir za tekst",
    contentRoot: "Korijen Sadržaja",
    includeUnpublished: "Uključite neobjavljeni sadržaj.",
    isSensitiveValue: `Ova vrijednost je skrivena. Ako vam je potreban pristup da vidite ovu vrijednost, obratite se
       administratoru web stranice.
    `,
    isSensitiveValue_short: "Ova vrijednost je skrivena.",
    languagesToPublish: "Koje jezike želite objaviti?",
    languagesToSendForApproval: "Koje jezike želite poslati na odobrenje?",
    languagesToSchedule: "Koje jezike želite zakazano objaviti?",
    languagesToUnpublish: `Odaberite jezike za poništavanje objavljivanja. Poništavanje objavljivanja obaveznog jezika će
       poništiti objavljivanje svih jezika.
    `,
    variantsWillBeSaved: "Sve nove varijante će biti spremljene.",
    variantsToPublish: "Koje varijante želite objaviti?",
    variantsToSave: "Odaberite koje varijante želite spremiti.",
    publishRequiresVariants: "Za objavljivanje su potrebne sljedeće varijante:",
    notReadyToPublish: "Nije spremno za objavljivanje",
    readyToPublish: "Spremno za objavljivanje?",
    readyToSave: "Spremno za spremanje?",
    resetFocalPoint: "Poništi fokusnu točku",
    sendForApproval: "Pošalji na odobrenje",
    schedulePublishHelp: "Odaberite datum i vrijeme za objavljivanje i/ili poništavanje objave stavke sadržaja.",
    createEmpty: "Kreiraj novo",
    createFromClipboard: "Zalijepi iz međuspremnika",
    nodeIsInTrash: "Ova stavka je u košu za smeće",
    saveModalTitle: "Spremi"
  },
  blueprints: {
    createBlueprintFrom: "Kreirajte novi predložak sadržaja iz <em>%0%</em>",
    blankBlueprint: "Prazno",
    selectBlueprint: "Odaberite predložak sadržaja",
    createdBlueprintHeading: "Predložak sadržaja kreiran",
    createdBlueprintMessage: "Predložak sadržaja je kreiran od '%0%'",
    duplicateBlueprintMessage: "Drugi predložak sadržaja sa istim nazivom već postoji",
    blueprintDescription: `Predložak sadržaja je unaprijed definiran sadržaj koji uređivač može odabrati da bi se koristio
       kao osnova za kreiranje novog sadržaja
    `
  },
  media: {
    clickToUpload: "Kliknite za prijenos",
    orClickHereToUpload: "ili kliknite ovdje kako bi odaberali datoteke",
    disallowedFileType: "Nije moguće učitati ovu datoteku, jer nema odobrenu vrstu datoteke",
    disallowedMediaType: "Nije moguće učitati ovu datoteku, format medija sa nastavkom '%0%' nije dozvoljen",
    invalidFileName: "Nije moguće učitati ovu datoteku, jer nema važeći naziv datoteke",
    maxFileSize: "Maksimalna veličina datoteke je",
    mediaRoot: "Korijen medija",
    createFolderFailed: "Kreiranje mape pod ID-om roditelja nije uspjelo %0%",
    renameFolderFailed: "Preimenovanje mape sa ID-om %0% nije uspjelo",
    dragAndDropYourFilesIntoTheArea: "Povucite i ispustite svoje datoteke u područje"
  },
  member: {
    createNewMember: "Kreirajte novog člana",
    allMembers: "Svi članovi",
    memberGroupNoProperties: "Grupe članova nemaju dodatnih svojstva za uređivanje.",
    "2fa": "Dvostruka provjera autentičnosti"
  },
  contentType: {
    copyFailed: "Kopiranje vrste sadržaja nije uspjelo",
    moveFailed: "Premještanje vrste sadržaja nije uspjelo"
  },
  mediaType: {
    copyFailed: "Kopiranje vrste medija nije uspjelo",
    moveFailed: "Premještanje vrste medija nije uspjelo",
    autoPickMediaType: "Automatski odabir"
  },
  memberType: {
    copyFailed: "Kopiranje vrste člana nije uspjelo"
  },
  create: {
    chooseNode: "Gdje želite kreirati novi %0%",
    createUnder: "Kreirajte stavku pod",
    createContentBlueprint: "Odaberite vrstu dokumenta za koju želite napraviti predložak sadržaja",
    enterFolderName: "Unesite naziv mape",
    updateData: "Odaberite vrstu i naslov",
    noDocumentTypes: "Nema dozvoljenih vrsta dokumenata dostupnih za kreiranje sadržaja ovdje. Morate ih omogućiti u <strong>Vrste Dokumenta</strong> unutar sekcije <strong>Postavke</strong>, uređivanjem <strong>Dozvoljene vrste podređenih čvorova</strong> unutar <strong>Dozvole</strong>.",
    noDocumentTypesAtRoot: "Nema dozvoljenih vrsta dokumenata dostupnih za kreiranje sadržaja ovdje. Morate ih kreirati u <strong>Vrste Dokumenata</strong> unutar sekcije <strong>Postavke</strong>.",
    noDocumentTypesWithNoSettingsAccess: `Odabrana stranica u stablu sadržaja ne dozvoljava kreiranje nijedne stranice ispod.
    `,
    noDocumentTypesEditPermissions: "Uredi dozvole za ovu vrstu dokumenta",
    noDocumentTypesCreateNew: "Kreiraj novu vrstu dokumenta",
    noDocumentTypesAllowedAtRoot: "Nema dozvoljenih vrsta dokumenata dostupnih za kreiranje sadržaja ovdje. Morate ih omogućiti u <strong>Vrste Dokumenta</strong> unutar sekcije <strong>Postavke</strong>, izmjenom <strong>Dozvoli kao root</strong> opcije unutar <strong>Dozvole</strong>.",
    noMediaTypes: "Nema dozvoljenih vrsta medija dostupnih za kreiranje medija ovdje. Morate ih omogućiti u <strong>Vrste Medija</strong> unutar sekcije <strong>Postavke</strong>, uređivanjem <strong>Dozvoljene vrste podređenih čvorova</strong> unutar <strong>Dozvole</strong>.",
    noMediaTypesWithNoSettingsAccess: `Odabrani medij u stablu ne dopušta bilo koji drugi medij
       kreiran ispod njega.
    `,
    noMediaTypesEditPermissions: "Uredi dozvole za ovu vrstu medija",
    documentTypeWithoutTemplate: "Vrsta dokumenta bez predloška",
    documentTypeWithTemplate: "Vrsta dokumenta sa predloškom",
    documentTypeWithTemplateDescription: `Definiranje podataka za stranicu sadržaja koja se može kreirati u stablu sadržaja i direktno je dostupana preko URL-a.
    `,
    documentType: "Vrsta dokumenta",
    documentTypeDescription: `Definiranje podataka za komponentu sadržaja koju mogu kreirati urednici u
       stablu sadržaja i može biti izabrana na drugim stranicama, ali nema direktan URL.
    `,
    elementType: "Vrsta elementa",
    elementTypeDescription: `Definiranje sheme za ponavljajući skup svojstava, na primjer, u 'Bloku
       Uređivaču svojstava Lista' ili 'Ugniježđeni sadržaj'.
    `,
    composition: "Kompozicija",
    compositionDescription: `Definiranje višenamjenski skup svojstava koja se mogu uključiti u definiciju
       više drugih vrsta dokumenata. Na primjer, skup 'Common Page Settings'.
    `,
    folder: "Mapa",
    folderDescription: `Koristi se za organiziranje vrste dokumenata, sastava i vrste elemenata kreiranih u ovome
       Stablo vrste dokumenta.
    `,
    newFolder: "Nova mapa",
    newDataType: "Nova vrsta podatka",
    newJavascriptFile: "Nova JavaScript datoteka",
    newEmptyPartialView: "Novi prazan djelomični prikaz",
    newPartialViewMacro: "Novi djelomični prikaz za makro",
    newPartialViewFromSnippet: "Novi djelomični prikaz iz isječka",
    newPartialViewMacroFromSnippet: "Novi djelomični prikaz za makro iz isječka",
    newPartialViewMacroNoMacro: "Novi djelomični prikaz za makro (bez makroa)",
    newStyleSheetFile: "Nova CSS datoteka",
    newRteStyleSheetFile: "Nova Rich Text Editor CSS datoteka"
  },
  dashboard: {
    browser: "Pregledajte svoju web stranicu",
    dontShowAgain: "- Sakrij",
    nothinghappens: "Ako se Umbraco ne otvara, možda ćete morati dozvoliti skočne prozore sa ove stranice",
    openinnew: "je otvoren u novom prozoru",
    restart: "Ponovno pokreni",
    visit: "Posjetite",
    welcome: "Dobrodošli"
  },
  prompt: {
    stay: "Ostani",
    discardChanges: "Poništite promjene",
    unsavedChanges: "Imate ne spremljene promjene",
    unsavedChangesWarning: "Jeste li sigurni da želite izaći s ove stranice? - imate ne spremljene promjene",
    confirmListViewPublish: "Objavljivanjem će odabrane stavke biti vidljive na stranici.",
    confirmListViewUnpublish: `Poništavanje objavljivanja će ukloniti odabrane stavke i sve njihove potomke sa
       stranice.
    `,
    confirmUnpublish: "Poništavanje objavljivanja će ukloniti ovu stranicu i sve njene potomke sa stranice.",
    doctypeChangeWarning: "Imate ne spremljene promjene. Promjenom vrste dokumenta odbacit će se promjene."
  },
  bulk: {
    done: "Završeno",
    deletedItem: "Obrisana %0% stavka",
    deletedItems: "Obrisano %0% stavki",
    deletedItemOfItem: "Obrisana %0% od %1% stavka",
    deletedItemOfItems: "Obrisano %0% od %1% stavki",
    publishedItem: "Objavljeno %0% stavka",
    publishedItems: "Objavljeno %0% stavki",
    publishedItemOfItem: "Objavljeno %0% od %1% stavka",
    publishedItemOfItems: "Objavljeno %0% od %1% stavki",
    unpublishedItem: "Neobjavljeno za %0% stavku",
    unpublishedItems: "Neobjavljeno za %0% stavki",
    unpublishedItemOfItem: "Neobjavljeno za %0% od %1% stavku",
    unpublishedItemOfItems: "Neobjavljeno za %0% od %1% stavki",
    movedItem: "Premještena %0% stavka",
    movedItems: "Premješteno %0% stavki",
    movedItemOfItem: "Premješteno %0% od %1% stavku",
    movedItemOfItems: "Premješteno %0% od %1% stavki",
    copiedItem: "Kopirana %0% stavka",
    copiedItems: "Kopirano %0% stavki",
    copiedItemOfItem: "Kopirano %0% od %1% stavku",
    copiedItemOfItems: "Kopirano %0% od %1% stavki"
  },
  defaultdialogs: {
    nodeNameLinkPicker: "Naslov linka",
    urlLinkPicker: "Link",
    anchorLinkPicker: "Sidro / querystring",
    anchorInsert: "Naziv",
    assignDomain: "Upravljanje nazivima domena",
    closeThisWindow: "Zatvorite ovaj prozor",
    confirmdelete: "Jeste li sigurni da želite obrisati",
    confirmdeleteNumberOfItems: "Jeste li sigurni da želite obrisati <strong>%0%</strong> od <strong>%1%</strong> stavki",
    confirmdisable: "Jeste li sigurni da želite onemogućiti",
    confirmremove: "Jeste li sigurni da želite ukloniti",
    confirmremoveusageof: "Jeste li sigurni da želite ukloniti korištenje <strong>%0%</strong>",
    confirmlogout: "Jeste li sigurni?",
    confirmSure: "Jeste li sigurni?",
    cut: "Izreži",
    editDictionary: "Uredi stavku iz rječnika",
    editLanguage: "Uredi jezik",
    editSelectedMedia: "Uredite odabrane medije",
    editWebhook: "Uredi webhook",
    insertAnchor: "Umetni lokalnu vezu",
    insertCharacter: "Umetni znak",
    insertgraphicheadline: "Umetni grafički naslov",
    insertimage: "Umetni sliku",
    insertlink: "Umetni link",
    insertMacro: "Klikni za dodavanje makro",
    inserttable: "Umetni tablicu",
    languagedeletewarning: "Ovo će izbrisati jezik i sav sadržaj povezan s jezikom",
    languageChangeWarning: `Promjena kulture jezika može biti skupa operacija i rezultirat će promjenama u predmemoriji sadržaja i indeksima koji se rekonstruiraju
    `,
    lastEdited: "Zadnje uređivano",
    link: "Link",
    linkinternal: "Interni link",
    linklocaltip: 'Kada koristite lokalni linkovi, umetnite "#" ispred linka',
    linknewwindow: "Otvoriti u novom prozoru?",
    macroDoesNotHaveProperties: "Ovaj makro ne sadrži svojstva koja možete uređivati",
    paste: "Zalijepi",
    permissionsEdit: "Uredi dozvole za",
    permissionsSet: "Postavi dozvole za",
    permissionsSetForGroup: "Postavi dozvole za %0% za grupu korisnika %1%",
    permissionsHelp: "Odaberi grupe korisnika za koje želite postaviti dozvole",
    recycleBinDeleting: `Stavke u košu za smeće se upravo brišu. Molimo vas da ne zatvarate ovaj prozor
       dok se ova operacija odvija
    `,
    recycleBinIsEmpty: "Koš za smeće je sada prazna",
    recycleBinWarning: "Kada se stavke obrišu iz koša za smeće, nestat će zauvijek",
    regexSearchError: "<a target='_blank' rel='noopener' href='http://regexlib.com'>regexlib.com</a> web servis trenutno ima probleme u komunikaciji na koje ne možemo utjecati. Žao nam je zbog nastalih smetnji.",
    regexSearchHelp: `Traži regular expression kako bi njime validirali polje unosa. Primjer: 'e-pošta,
       'poštanski broj', 'URL'.
    `,
    removeMacro: "Ukloni makro",
    requiredField: "Obavezno polje",
    sitereindexed: "Stranica je ponovo indeksirana",
    siterepublished: `Predmemorija web stranice je osvježena. Sav objavljeni sadržaj je sada ažuriran. Dok će sav
		neobjavljen sadržaj ostati neobjavljen
    `,
    siterepublishHelp: `Predmemorija web stranice će biti osvježena. Svi objavljeni sadržaji bit će ažurirani, dok će sav
       neobjavljeni sadržaj ostati neobjavljen.
    `,
    tableColumns: "Broj kolona",
    tableRows: "Broj redova",
    thumbnailimageclickfororiginal: "Klikni na sliku za prikaz pune veličine",
    treepicker: "Odaberi stavku",
    viewCacheItem: "Prikaži stavku predmemorije",
    relateToOriginalLabel: "Odnosi se na original",
    includeDescendants: "Uključiti potomke",
    theFriendliestCommunity: "Prijateljska zajednica",
    linkToPage: "Link na stranicu",
    openInNewWindow: "Otvara povezani dokument u novom prozoru ili kartici",
    linkToMedia: "Link do medija",
    selectContentStartNode: "Odaberi početni čvor sadržaja",
    selectMedia: "Odaberi medije",
    selectMediaType: "Odaberi vrstu medija",
    selectIcon: "Odaberi ikonu",
    selectItem: "Odaberi stavku",
    selectLink: "Odaberi vezu",
    selectMacro: "Odaberi makro",
    selectContent: "Odaberi sadržaj",
    selectContentType: "Odaberi vrstu sadržaja",
    selectMediaStartNode: "Odaberi početni čvor medija",
    selectMember: "Odaberi člana",
    selectMemberGroup: "Odaberi grupu članova",
    selectMemberType: "Odaberi vrstu članova",
    selectNode: "Odaberi čvor",
    selectLanguages: "Odaberi jezike",
    selectSections: "Odaberi sekcije",
    selectUser: "Odaberi korisnika",
    selectUsers: "Odaberi korisnike",
    noIconsFound: "Nema pronađenih ikona",
    noMacroParams: "Nema parametara za ovaj makro",
    noMacros: "Nema dostupnih makroa za umetanje",
    externalLoginProviders: "Vanjski provajderi prijave",
    exceptionDetail: "Detalji iznimaka",
    stacktrace: "Zapisnik",
    innerException: "Unutarnja iznimka",
    linkYour: "Poveži svoj",
    unLinkYour: "Poništi povezivanje svoje veze",
    account: "račun",
    selectEditor: "Odaberi urednika",
    selectSnippet: "Odaberite predložak",
    variantdeletewarning: "Ovo će obrisati čvor i sve njegove jezike. Ako želite obrisati jedan jezik, poništite radije objavu na tom jeziku.",
    propertyuserpickerremovewarning: "Ovo će ukloniti korisnika <strong>%0%</strong>.",
    userremovewarning: "Ovo će ukloniti korisnika <strong>%0%</strong> iz grupe <strong>%1%</strong>",
    yesRemove: "Da, ukloni",
    deleteLayout: "Brišete izgled",
    deletingALayout: "Promjena izgleda će rezultirati gubitkom podataka za bilo koji postojeći sadržaj koji je zasnovan na ovoj konfiguraciji."
  },
  dictionary: {
    importDictionaryItemHelp: `
      Da bi uvezli stavku iz rječnika, pronađite ".udt" datoteku na svom računalu klikom na
       gumb "Uvezi" (na sljedećem ekranu će se tražiti da potvrdite)
    `,
    itemDoesNotExists: "Stavka iz rječnika ne postoji.",
    parentDoesNotExists: "Nadređena stavka ne postoji.",
    noItems: "Ne postoje stavke iz rječnika.",
    noItemsInFile: "U ovoj datoteci nema stavki iz rječnika.",
    noItemsFound: "Nisu pronađene stavke iz rječnika.",
    createNew: "Kreirajte stavku iz rječnika"
  },
  dictionaryItem: {
    description: "Uredite različite jezičke varijante za stavku rječnika '%0%' ispod",
    displayName: "Kultura",
    changeKeyError: "Stavka '%0%' već postoji.",
    overviewTitle: "Pregled riječnika"
  },
  examineManagement: {
    configuredSearchers: "Konfigurirani pretraživači",
    configuredSearchersDescription: "Prikazuje svojstva i alate za bilo koji konfigurirani pretraživač (npr. kao multi-indeksni pretraživač)",
    fieldValues: "Vrijednosti polja",
    healthStatus: "Status zdravlja",
    healthStatusDescription: "Status zdravlja indeksa i da li se može pročitati",
    indexers: "Indeksi",
    indexInfo: "Indeks info",
    contentInIndex: "Sadržaj u indeksu",
    indexInfoDescription: "Navodi svojstva indeksa",
    manageIndexes: "Upravljanje Examine-ovim indeksima",
    manageIndexesDescription: "Omogućava vam pregled detalja svakog indeksa i pruža neke alate za upravljanje indeksima",
    rebuildIndex: "Obnovi indeks",
    rebuildIndexWarning: `
      Ovo će uzrokovati obnavljanje indexa.<br />
      Ovisno o količini sadržaja vaše web stranice, ovo bi moglo potrajati.<br />
      Nije preporučljivo obnavljati index-e tijekom velike posjećenosti vaše web stranice ili u vrijeme kada urednik uređuje sadržaj stranice.
     `,
    searchers: "Pretraživači",
    searchDescription: "Pretražite indeks i pogledajte rezultate",
    tools: "Alati",
    toolsDescription: "Alati za upravljanje indeksima",
    fields: "polja",
    indexCannotRead: "Indeks se ne može pročitati i morat će se ponovo obnoviti",
    processIsTakingLonger: `Proces traje duže od očekivanog, provjerite Umbraco log zapis da vidite
       da li je bilo grešaka tijekom ove operacije
    `,
    indexCannotRebuild: "Ovaj indeks se ne može ponovo obnoviti jer mu nije dodijeljen",
    iIndexPopulator: "IIndexPopulator"
  },
  placeholders: {
    username: "Upišite svoje korisničko ime",
    password: "Upišite svoju lozinku",
    confirmPassword: "Potvrdite lozinku",
    nameentity: "Imenujte %0%...",
    entername: "Upišite ime...",
    enteremail: "Upišite email...",
    enterusername: "Upišite korisničko ime...",
    label: "Oznaka...",
    enterDescription: "Upišite opis...",
    search: "Upišite za pretragu...",
    filter: "Upišite za filtriranje...",
    enterTags: "Upišite da dodate oznake (pritisnite enter nakon svake oznake)...",
    email: "Upišite vaš email",
    enterMessage: "Upišite poruku...",
    usernameHint: "Vaše korisničko ime je obično vaš email",
    anchor: "#value ili ?key=value",
    enterAlias: "Upišite alias...",
    generatingAlias: "Generiranje aliasa...",
    a11yCreateItem: "Kreiraj stavku",
    a11yEdit: "Uredi",
    a11yName: "Naziv"
  },
  editcontenttype: {
    createListView: "Kreirajte prilagođeni prikaz liste",
    removeListView: "Ukloni prilagođeni prikaz liste",
    aliasAlreadyExists: "Vrsta sadržaja, medija ili člana s ovim aliasom već postoji"
  },
  renamecontainer: {
    renamed: "Preimenovano",
    enterNewFolderName: "Upišite novi naziv mape",
    folderWasRenamed: "%0% je preimenovan u %1%"
  },
  editdatatype: {
    addPrevalue: "Dodajte vrijednost",
    dataBaseDatatype: "Vrsta baze podataka",
    guid: "Uređivač svojstva GUID",
    renderControl: "Uređivač svojstva",
    rteButtons: "Gumbi",
    rteEnableAdvancedSettings: "Omogući napredne postavke za",
    rteEnableContextMenu: "Omogući kontekstni meni",
    rteMaximumDefaultImgSize: "Maksimalna zadana veličina umetnutih slika",
    rteRelatedStylesheets: "Povezani stilovi",
    rteShowLabel: "Prikaži oznaku",
    rteWidthAndHeight: "Širina i visina",
    selectFolder: "Odaberite mapu za premještanje",
    inTheTree: "do u strukturi stabla ispod",
    wasMoved: "je premeštena ispod"
  },
  errorHandling: {
    errorButDataWasSaved: `Vaši podaci su spremljeni, ali prije nego što možete objaviti ovu stranicu postoje neke
       greške koje prvo morate ispraviti:
    `,
    errorChangingProviderPassword: `Trenutni provajder članstva ne podržava promjenu lozinke
       (Omogući preuzimanje lozinke mora biti uključeno)
    `,
    errorExistsWithoutTab: "%0% već postoji",
    errorHeader: "Bilo je grešaka:",
    errorHeaderWithoutTab: "Bilo je grešaka:",
    errorInPasswordFormat: `Lozinka treba imati najmanje %0% znakova i sadržavati najmanje %1%
      znakova koji nisu alfanumerički
    `,
    errorIntegerWithoutTab: "%0% mora biti cijeli broj",
    errorMandatory: "Polje %0% na kartici %1% je obavezno",
    errorMandatoryWithoutTab: "%0% je obavezno polje",
    errorRegExp: "%0% na %1% nije u ispravnom formatu",
    errorRegExpWithoutTab: "%0% nije u ispravnom formatu"
  },
  errors: {
    receivedErrorFromServer: "Primljena greška sa servera",
    dissallowedMediaType: "Administrator je zabranio navedenu vrstu datoteke",
    codemirroriewarning: `NAPOMENA! Iako je CodeMirror omogućen konfiguracijom, on je onemogućen u
       Internet Explorer-u jer nije dovoljno stabilan.
    `,
    contentTypeAliasAndNameNotNull: "Unesite i alias i ime na novu vrstu svojstva!",
    filePermissionsError: "Postoji problem sa pristupom za čitanje/pisanje određenoj datoteci ili mapi",
    macroErrorLoadingPartialView: "Greška pri učitavanju skripte parcijalnog prikaza (datoteka: %0%)",
    missingTitle: "Unesite naslov",
    missingType: "Molimo odaberite vrstu",
    pictureResizeBiggerThanOrg: `Napravit ćete sliku veću od originalne veličine. Jeste li sigurni
       da želite nastaviti?
    `,
    startNodeDoesNotExists: "Početni čvor je obrisan, kontaktirajte svog administratora",
    stylesMustMarkBeforeSelect: "Molimo označite sadržaj prije promjene stila",
    stylesNoStylesOnPage: "Nema dostupnih aktivnih stilova",
    tableColMergeLeft: "Postavite kursor lijevo od dvije ćelije koje želite spojiti",
    tableSplitNotSplittable: "Ne možete podijeliti ćeliju koja nije spojena.",
    propertyHasErrors: "Ovo svojstvo je nevažeće"
  },
  general: {
    about: "O",
    action: "Akcija",
    actions: "Akcije",
    add: "Dodaj",
    alias: "Alias",
    all: "Sve",
    areyousure: "Jeste li sigurni?",
    back: "Nazad",
    backToOverview: "Nazad na pregled",
    border: "Rub",
    by: "od",
    cancel: "Odustani",
    cellMargin: "Margina ćelije",
    choose: "Odaberi",
    clear: "Očisti",
    close: "Zatvori",
    closewindow: "Zatvori prozor",
    closepane: "Zatvori panel",
    comment: "Komentar",
    confirm: "Potvrdi",
    constrain: "Ograniči",
    constrainProportions: "Ograniči proporcije",
    content: "Sadržaj",
    continue: "Nastavi",
    copy: "Kopiraj",
    create: "Kreiraj",
    database: "Baza podataka",
    date: "Datum",
    default: "Zadano",
    delete: "Obriši",
    deleted: "Obrisano",
    deleting: "Brisanje...",
    design: "Dizajn",
    dictionary: "Riječnik",
    dimensions: "Dimenzije",
    discard: "Otkaži",
    down: "Dolje",
    download: "Preuzmi",
    edit: "Uredi",
    edited: "Uređeno",
    elements: "Elementi",
    email: "Email",
    error: "Greška",
    field: "Polje",
    findDocument: "Pronađi",
    first: "Prvi",
    focalPoint: "Fokusna točka",
    general: "Općenito",
    groups: "Grupe",
    group: "Grupa",
    height: "Visina",
    help: "Pomoć",
    hide: "Sakrij",
    history: "Povijest",
    icon: "Ikona",
    id: "Id",
    import: "Uvezi",
    excludeFromSubFolders: "Pretraži samo ovu mapu",
    info: "Info",
    innerMargin: "Unutrašnja margina",
    insert: "Umetni",
    install: "Instaliraj",
    invalid: "Nevažeće",
    justify: "Poravnaj",
    label: "Oznaka",
    language: "Jezik",
    last: "Zadnji",
    layout: "Izgled",
    links: "Linkovi",
    loading: "Učitavanje",
    locked: "Zaključano",
    login: "Prijava",
    logoff: "Odjava",
    logout: "Odjava",
    macro: "Makro",
    mandatory: "Obavezno",
    message: "Poruka",
    move: "Pomakni",
    name: "Ime",
    new: "Novo",
    next: "Sljedeći",
    no: "Ne",
    nodeName: "Ime čvora",
    of: "od",
    off: "Isključeno",
    ok: "OK",
    open: "Otvori",
    options: "Opcije",
    on: "Uključeno",
    or: "ili",
    orderBy: "Poredaj po",
    password: "Lozinka",
    path: "Putanja",
    pleasewait: "Trenutak molim...",
    previous: "Prethodno",
    properties: "Svojstva",
    readMore: "Pročitaj više",
    rebuild: "Ponovo izgradi",
    reciept: "Email za primanje obrasca",
    recycleBin: "Koš za smeće",
    recycleBinEmpty: "Vaš koš za smeće je prazn",
    reload: "Osvježi",
    remaining: "Preostalo",
    remove: "Izbriši",
    rename: "Preimenuj",
    renew: "Obnovi",
    required: "Obavezno",
    retrieve: "Povratiti",
    retry: "Pokušaj ponovo",
    rights: "Dozvole",
    scheduledPublishing: "Planirano objavljivanje",
    umbracoInfo: "Umbraco info",
    search: "Traži",
    searchNoResult: "Žao nam je, ne možemo pronaći ono što tražite.",
    noItemsInList: "Nije dodana nijedna stavka",
    server: "Server",
    settings: "Postavke",
    show: "Prikaži",
    showPageOnSend: "Prikaži stranicu nprilikom Slanja",
    size: "Veličina",
    sort: "Sortiranje",
    status: "Status",
    submit: "Potvrdi",
    success: "Uspjeh",
    type: "Vrsta",
    typeName: "Ime vrste",
    typeToSearch: "Upišite za pretragu...",
    under: "ispod",
    up: "Gore",
    update: "Ažuriraj",
    upgrade: "Nadogradi",
    upload: "Prenesi",
    url: "URL",
    user: "Korisnik",
    username: "Korisničko ime",
    value: "Vrijednost",
    view: "Prikaz",
    welcome: "Dobrodošli...",
    width: "Širina",
    yes: "Da",
    folder: "Mapa",
    searchResults: "Rezultati pretrage",
    reorder: "Promijeni redosljed",
    reorderDone: "Završeno sortiranje",
    preview: "Pregled",
    changePassword: "Promijeni lozinku",
    to: "do",
    listView: "Prikaz liste",
    saving: "Spremanje...",
    current: "trenutni",
    embed: "Ugradi",
    selected: "odabran",
    other: "Ostalo",
    articles: "Članci",
    videos: "Videi",
    avatar: "Avatar za",
    header: "Zaglavlje",
    systemField: "sistemsko polje",
    lastUpdated: "Posljednje ažurirano"
  },
  colors: {
    blue: "Plava"
  },
  shortcuts: {
    addGroup: "Dodaj grupu",
    addProperty: "Dodaj svojstvo",
    addEditor: "Dodaj urednika",
    addTemplate: "Dodaj predložak",
    addChildNode: "Dodajte podređeni čvor",
    addChild: "Dodaj dijete",
    editDataType: "Uredite vrstu podataka",
    navigateSections: "Krećite se po odjeljcima",
    shortcut: "Prečice",
    showShortcuts: "Prikaži prečice",
    toggleListView: "Uključi prikaz liste",
    toggleAllowAsRoot: "Uključi dozvoli kao root",
    commentLine: "Redovi za komentiranje/dekomentiranje",
    removeLine: "Uklonite liniju",
    copyLineUp: "Kopiraj linije gore",
    copyLineDown: "Kopiraj linije dole",
    moveLineUp: "Pomakni linije gore",
    moveLineDown: "Pomakni linije dole",
    generalHeader: "Općenito",
    editorHeader: "Uređivač",
    toggleAllowCultureVariants: "Uključi dozvoli varijante kulture"
  },
  graphicheadline: {
    backgroundcolor: "Boja pozadine",
    bold: "Podebljano",
    color: "Boja teksta",
    font: "Font",
    text: "Tekst"
  },
  headers: {
    page: "Stranica"
  },
  installer: {
    databaseErrorCannotConnect: "Instalacija se ne može povezati s bazom podataka.",
    databaseErrorWebConfig: `Nije moguće spremiti web.config datoteku. Molimo izmijenite konekcijski string
       ručno.
    `,
    databaseFound: "Vaša baza podataka je pronađena i identificirana je kao",
    databaseHeader: "Konfiguracija baze podataka",
    databaseInstall: `
      Pritisnite <strong>Instaliraj</strong> za instalaciju Umbraco %0% baze podataka
    `,
    databaseInstallDone: "Umbraco %0% je sada kopiran u vašu bazu podataka. Pritisnite <strong>Dalje</strong> da nastavite.",
    databaseNotFound: `<p>Baza podataka nije pronađena! Provjerite jesu li informacije u "konekcijskom string" u "web.config" datoteci ispravne.</p>
              <p>Da nastavite, uredite "web.config" datoteku. (koristeći Visual Studio ili vaš omiljeni uređivač teksta), skorlajte do dna, dodajte konekcijski string za vašu bazu podataka u svojstvo nazvan "UmbracoDbDSN" i spremite datoteku. </p>
              <p>
              Kliknite na gumb <strong>pokušaj ponovo</strong> kada završite.<br />
			  <a href="https://our.umbraco.com/documentation/Reference/Config/webconfig/" target="_blank" rel="noopener">
			              Više informacija o uređivanju web.config datoteke možete pronaći ovdje</a>.</p>`,
    databaseText: `Da bi dovršili ovaj korak, morate znati neke informacije o vašem poslužitelju baze podataka ("konekcijski string").<br />
        Molimo kontaktirajte svog ISP-a ako je potrebno.
        Ako instalirate na lokalnoj mašini ili serveru, možda će vam trebati informacije od administratora sistema.`,
    databaseUpgrade: `
      <p>
      Pritisnite <strong>nadogradnja</strong> za nadogradnju vaše baze podataka na Umbraco %0%</p>
      <p>
      Ne brinite - nijedan sadržaj neće biti obrisan i sve će nastaviti raditi nakon toga!
      </p>
      `,
    databaseUpgradeDone: "Vaša baza podataka je nadograđena na novu verziju %0%.<br />Pritisnite <strong>Dalje</strong> da nastavite.",
    databaseUpToDate: "Vaša trenutna baza podataka je ažurirana!. Pritisnite <strong>Dalje</strong> da nastavite sa čarobnjakom za konfiguraciju",
    defaultUserChangePass: "<strong>Zadanu korisničku lozinku treba promijeniti!</strong>",
    defaultUserDisabled: "<strong>Zadani korisnik je onemogućen ili nema pristup Umbraco-u!</strong></p><p>Ne treba preduzimati nikakve daljnje radnje. Pritisnite <strong>Dalje</strong> da nastavite.",
    defaultUserPassChanged: "<strong>Zadana korisnička lozinka je uspješno promijenjena od instalacije!</strong></p><p>Ne treba preduzimati nikakve daljnje radnje. Pritisnite <strong>Dalje</strong> da nastavite.",
    defaultUserPasswordChanged: "Lozinka je promijenjena!",
    greatStart: "Započnite odlično, pogledajte naše uvodne video zapise",
    licenseText: `Klikom na sljedeći gumb (ili modifikacijom umbracoConfigurationStatus u web.config),
       prihvaćate licencu za ovaj softver kao što je navedeno u polju ispod. Primijetite da se ova Umbraco distribucija
       sastoji se od dvije različite licence, open source MIT licence za okvir i licence za besplatni softver Umbraco
       koji pokriva korisničko sučelje.
    `,
    None: "Još nije instalirano.",
    permissionsAffectedFolders: "Zahvaćene datoteke i mape",
    permissionsAffectedFoldersMoreInfo: "Više informacija o postavljanju dozvola za Umbraco ovdje",
    permissionsAffectedFoldersText: `Morate dodijeliti dozvole za izmjenu ASP.NET-a za sljedeće
       datoteke/mape
    `,
    permissionsAlmostPerfect: `<strong>Vaše postavke dozvola su gotovo savršene!</strong><br /><br />
        Možete pokrenuti Umbraco bez problema, ali nećete moći instalirati pakete koji se preporučuju da biste u potpunosti iskoristili Umbraco.`,
    permissionsHowtoResolve: "Kako riješiti",
    permissionsHowtoResolveLink: "Kliknite ovdje da pročitate tekstualnu verziju",
    permissionsHowtoResolveText: "Gledajte naše <strong>video tutorijale</strong> o postavljanju dozvola foldera za Umbraco ili pročitajte tekstualnu verziju.",
    permissionsMaybeAnIssue: `<strong>Vaše postavke dozvola mogu biti problem!</strong>
      <br/><br />
      Možete pokrenuti Umbraco bez problema, ali nećete moći kreirati mape ili instalirati pakete koji se preporučuju da biste u potpunosti iskoristili Umbraco.`,
    permissionsNotReady: `<strong>Vaše postavke dozvola nisu spremne za Umbraco!</strong>
          <br /><br />
          Da biste pokrenuli Umbraco, morat ćete ažurirati postavke dozvola.`,
    permissionsPerfect: `<strong>Vaše postavke dozvola su savršene!</strong><br /><br />
              Spremni ste da pokrenete Umbraco i instalirate pakete!`,
    permissionsResolveFolderIssues: "Rješavanje problema sa mapom",
    permissionsResolveFolderIssuesLink: `Pratite ovu vezu za više informacija o problemima sa ASP.NET i
       kreiranje mapa
    `,
    permissionsSettingUpPermissions: "Postavljanje dozvola za mape",
    permissionsText: `
      Umbraco treba pristup za pisanje/izmjenu određenih mapa kako bi pohranio datoteke poput slika i PDF-ova.
      Također pohranjuje privremene podatke (tj: cache) za poboljšanje performansi vaše web stranice.
    `,
    runwayFromScratch: "Želim početi od nule",
    runwayFromScratchText: `
        Vaša web stranica je trenutno potpuno prazna, tako da je savršeno ako želite početi od nule i kreirati vlastite vrste dokumenata i predloške.
        (<a href="https://umbraco.tv/documentation/videos/for-site-builders/foundation/document-types">naučite kako</a>)
        I dalje možete odabrati da kasnije instalirate Runway. Molimo idite na odjeljak Developer i odaberite Paketi.
      `,
    runwayHeader: "Upravo ste postavili čistu Umbraco platformu. Šta želite sljedeće učiniti?",
    runwayInstalled: "Runway je instaliran",
    runwayInstalledText: `
      Imate postavljene temelje. Odaberite koje module želite instalirati na njega.<br />
      Ovo je naša lista preporučenih modula, označite one koje želite da instalirate ili pogledajte <a href="#" onclick="toggleModules(); return false;" id="toggleModuleList">punu listu modula</a>
      `,
    runwayOnlyProUsers: "Preporučuje se samo iskusnim korisnicima",
    runwaySimpleSite: "Želim početi s jednostavnom web-stranicom",
    runwaySimpleSiteText: `
      <p>
      "Runway" je jednostavna web stranica koja nudi neke osnovne vrste dokumenata i predloške. Instalacijski čarobnjak može postaviti Runway za vas automatski,
        ali ga možete lako urediti, proširiti ili ukloniti. Nije potrebno i možete savršeno koristiti Umbraco i bez njega. Kako god,
        Runway nudi laku osnovu zasnovanu na najboljim praksama za početak brže nego ikad.
        Ako se odlučite za instalaciju Runway, opcionalo možete odabrati osnovne građevne blokove tzv. Runway Modules da poboljšate svoje Runway stranice.
        </p>
        <small>
        <em>Uključeno u Runway:</em> Početna stranica, Stranica za početak, Stranica za instaliranje modula.<br />
        <em>Dodatni moduli:</em> Navigacija, Sitemap, Kontakt, Galerija.
        </small>
      `,
    runwayWhatIsRunway: "Što je Runway",
    step1: "Korak 1/5: Prihvatite licencu",
    step2: "Korak 2/5: Konfiguracija baze podataka",
    step3: "Korak 3/5: Potvrđivanje dozvola za datoteke",
    step4: "Korak 4/5: Provjerite Umbraco sigurnost",
    step5: "Korak 5/5: Umbraco je spreman za početak",
    thankYou: "Hvala vam što ste odabrali Umbraco",
    theEndBrowseSite: `<h3>Pregledajte svoju novu stranicu</h3>
Instalirali ste Runway, pa zašto ne biste vidjeli kako izgleda vaša nova web stranica.`,
    theEndFurtherHelp: `<h3>Dodatna pomoć i informacije</h3>
Potražite pomoć od naše nagrađivane zajednice, pregledajte dokumentaciju ili pogledajte nekoliko besplatnih videozapisa o tome kako napraviti jednostavnu stranicu, kako koristiti pakete i brzi vodič za terminologiju Umbraco`,
    theEndHeader: "Umbraco %0% je instaliran i spreman za upotrebu",
    theEndInstallFailed: `Da biste završili instalaciju, morat ćete
        ručno urediti <strong>/web.config datoteku</strong> i ažurirati svojstvo unutar AppSetting <strong>UmbracoConfigurationStatus</strong> na dnu do vrijednosti od <strong>'%0%'</strong>.`,
    theEndInstallSuccess: `Možete dobiti <strong>započeti odmah</strong> klikom na "Pokreni Umbraco" gumb ispod. <br />Ako ste <strong>novi u Umbraco-u</strong>,
možete pronaći mnogo resursa na našim stranicama za početak.`,
    theEndOpenUmbraco: `<h3>Pokreni Umbraco</h3>
Da bi upravljali svojom web lokacijom, jednostavno otvorite Umbraco backoffice i počnite dodavati sadržaj, ažurirati predloške i stilove ili dodati novu funkcionalnost`,
    Unavailable: "Povezivanje s bazom podataka nije uspjelo.",
    Version3: "Umbraco Verzija 3",
    Version4: "Umbraco Verzija 4",
    watch: "Gledaj",
    welcomeIntro: `Ovaj čarobnjak će vas voditi kroz proces konfiguracije <strong>Umbraco %0%</strong> za novu instalaciju ili nadogradnju sa verzije 3.0.
                                <br /><br />
                                Pritisnite <strong>"Dalje"</strong> da pokrenete čarobnjaka.`
  },
  language: {
    cultureCode: "Kod kulture",
    displayName: "Naziv kulture"
  },
  lockout: {
    lockoutWillOccur: "Bili ste u stanju mirovanja i automatski će doći do odjave",
    renewSession: "Obnovite sada da sačuvate svoj rad"
  },
  login: {
    greeting0: "Dobrodošli",
    greeting1: "Dobrodošli",
    greeting2: "Dobrodošli",
    greeting3: "Dobrodošli",
    greeting4: "Dobrodošli",
    greeting5: "Dobrodošli",
    greeting6: "Dobrodošli",
    instruction: "Prijavite se u nastavku",
    signInWith: "Prijava sa",
    timeout: "Isteklo je vrijeme sesije",
    bottomText: '<p style="text-align:right;">&copy; 2001 - %0% <br /><a href="https://umbraco.com" style="text-decoration: none" target="_blank" rel="noopener">Umbraco.com</a></p> ',
    forgottenPassword: "Zaboravljena lozinka?",
    forgottenPasswordInstruction: "E-mail poruka bit će poslana na navedenu adresu sa linkom za resetiranje lozinke",
    requestPasswordResetConfirmation: "E-mail poruka s uputama za poništavanje lozinke će biti poslana na navedenu adresu ukoliko odgovara našoj evidenciji",
    showPassword: "Prikaži lozinku",
    hidePassword: "Sakrij lozinku",
    returnToLogin: "Povratak na obrazac za prijavu",
    setPasswordInstruction: "Molimo unesite novu lozinku",
    setPasswordConfirmation: "Vaša lozinka je ažurirana",
    resetCodeExpired: "Link na koji ste kliknuli je nevažeći ili je istekao",
    resetPasswordEmailCopySubject: "Umbraco: Reset lozinke",
    resetPasswordEmailCopyFormat: `
        <html>
			<head>
				<meta name='viewport' content='width=device-width'>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
			</head>
			<body class='' style='font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; color: #392F54; line-height: 22px; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background: #1d1333; margin: 0; padding: 0;' bgcolor='#1d1333'>
				<style type='text/css'> @media only screen and (max-width: 620px) {table[class=body] h1 {font-size: 28px !important; margin-bottom: 10px !important; } table[class=body] .wrapper {padding: 32px !important; } table[class=body] .article {padding: 32px !important; } table[class=body] .content {padding: 24px !important; } table[class=body] .container {padding: 0 !important; width: 100% !important; } table[class=body] .main {border-left-width: 0 !important; border-radius: 0 !important; border-right-width: 0 !important; } table[class=body] .btn table {width: 100% !important; } table[class=body] .btn a {width: 100% !important; } table[class=body] .img-responsive {height: auto !important; max-width: 100% !important; width: auto !important; } } .btn-primary table td:hover {background-color: #34495e !important; } .btn-primary a:hover {background-color: #34495e !important; border-color: #34495e !important; } .btn  a:visited {color:#FFFFFF;} </style>
				<table border="0" cellpadding="0" cellspacing="0" class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;" bgcolor="#1d1333">
					<tr>
						<td style="font-family: sans-serif; font-size: 14px; vertical-align: top; padding: 24px;" valign="top">
							<table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;">
								<tr>
									<td background="https://umbraco.com/umbraco/assets/img/application/logo.png" bgcolor="#1d1333" width="28" height="28" valign="top" style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
										<!--[if gte mso 9]> <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:30px;height:30px;"> <v:fill type="tile" src="https://umbraco.com/umbraco/assets/img/application/logo.png" color="#1d1333" /> <v:textbox inset="0,0,0,0"> <![endif]-->
<div></div>
<!--[if gte mso 9]> </v:textbox> </v:rect> <![endif]-->
</td>
<td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top"></td>
</tr>
</table>
</td>
</tr>
</table>
<table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;' bgcolor='#1d1333'>
<tr>
<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'></td>
<td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 560px; width: 560px; margin: 0 auto; padding: 10px;' valign='top'>
<div class='content' style='box-sizing: border-box; display: block; max-width: 560px; margin: 0 auto; padding: 10px;'>
<br>
<table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; border-radius: 3px; background: #FFFFFF;' bgcolor='#FFFFFF'>
<tr>
<td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 50px;' valign='top'>
<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
<tr>
<td style='line-height: 24px; font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'>
<h1 style='color: #392F54; font-family: sans-serif; font-weight: bold; line-height: 1.4; font-size: 24px; text-align: left; text-transform: capitalize; margin: 0 0 30px;' align='left'>
															Zatraženo je ponovno postavljanje lozinke
														</h1>
<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Vaše korisničko ime za prijavu na Umbraco backoffice je: <strong>%0%</strong>
</p>
<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
<tbody>
<tr>
<td style='font-family: sans-serif; font-size: 14px; vertical-align: top; border-radius: 5px; text-align: center; background: #35C786;' align='center' bgcolor='#35C786' valign='top'>
<a href='%1%' target='_blank' rel='noopener' style='color: #FFFFFF; text-decoration: none; -ms-word-break: break-all; word-break: break-all; border-radius: 5px; box-sizing: border-box; cursor: pointer; display: inline-block; font-size: 14px; font-weight: bold; text-transform: capitalize; background: #35C786; margin: 0; padding: 12px 30px; border: 1px solid #35c786;'>
																				Kliknite na ovaj link da poništite lozinku
																			</a>
</td>
</tr>
</tbody>
</table>
</p>
<p style='max-width: 400px; display: block; color: #392F54; font-family: sans-serif; font-size: 14px; line-height: 20px; font-weight: normal; margin: 15px 0;'>Ukoliko ne možete kliknuti na link, kopirajte i zalijepite ovaj URL u prozor vašeg pretraživača:</p>
<table border='0' cellpadding='0' cellspacing='0'>
<tr>
<td style='-ms-word-break: break-all; word-break: break-all; font-family: sans-serif; font-size: 11px; line-height:14px;'>
<font style="-ms-word-break: break-all; word-break: break-all; font-size: 11px; line-height:14px;">
<a style='-ms-word-break: break-all; word-break: break-all; color: #392F54; text-decoration: underline; font-size: 11px; line-height:15px;' href='%1%'>%1%</a>
</font>
</td>
</tr>
</table>
</p>
</td>
</tr>
</table>
</td>
</tr>
</table>
<br><br><br>
</div>
</td>
<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'></td>
</tr>
</table>
</body>
</html>
	`,
    mfaSecurityCodeSubject: "Umbraco: Sigurnosni kod",
    mfaSecurityCodeMessage: "Vaš sigurnosni kod je: %0%",
    "2faTitle": "Posljednji korak",
    "2faText": "Omogućili ste 2-faktorsku autentifikaciju i morate potvrditi svoj identitet.",
    "2faMultipleText": "Molimo odaberite 2-faktor provajdera",
    "2faCodeInput": "Verifikacijski kod",
    "2faCodeInputHelp": "Unesite verifikacijski kod",
    "2faInvalidCode": "Unesen je nevažeći kod"
  },
  main: {
    dashboard: "Kontrolna ploča",
    sections: "Sekcije",
    tree: "Sadržaj"
  },
  moveOrCopy: {
    choose: "Odaberite stranicu iznad...",
    copyDone: "%0% je kopiran u %1%",
    copyTo: "Odaberite gdje dokument %0% treba kopirati ispod",
    moveDone: "%0% je premješten u %1%",
    moveTo: "Odaberite gdje dokument %0% treba premjestiti ispod",
    nodeSelected: "je odabrano kao korijen vašeg novog sadržaja, kliknite na 'Uredu' ispod.",
    noNodeSelected: "Još nije odabran čvor, molimo odaberite čvor na gornjoj listi prije nego kliknete na 'Uredu'",
    notAllowedByContentType: "Trenutni čvor nije dozvoljen pod odabranim čvorom zbog njegove vrste",
    notAllowedByPath: "Trenutni čvor se ne može premjestiti na jednu od njegovih podstranica niti roditelj i odredište mogu biti isti",
    notAllowedAtRoot: "Trenutni čvor ne može postojati u korijenu",
    notValid: `Radnja nije dozvoljena jer nemate dovoljna dopuštenja za 1 ili više djece
       dokumenata.
    `,
    relateToOriginal: "Povežite kopirane stavke s originalom"
  },
  notifications: {
    editNotifications: "Odaberite vaše obavijesti za %0%",
    notificationsSavedFor: "Postavke obavijesti su spremljene za %0%",
    notifications: "Obavijesti"
  },
  packager: {
    actions: "Akcije",
    created: "Kreirano",
    createPackage: "Kreiraj paket",
    chooseLocalPackageText: `
      Odaberite paket sa vašeg računala klikom na Pregledaj<br />
         i odaberite paket. Umbraco paketi uglavnom imaju ".umb" ili ".zip" ekstenziju.
      `,
    deletewarning: "Ovo će obrisati paket",
    includeAllChildNodes: "Uključi sve podređene čvorove",
    installed: "Instalirano",
    installedPackages: "Instalirani paketi",
    installInstructions: "Uputstva za instalaciju",
    noConfigurationView: "Ovaj paket nema prikaz konfiguracije",
    noPackagesCreated: "Još nije kreiran nijedan paket",
    noPackages: "Nijedan paket nije instaliran",
    noPackagesDescription: "Pregledajte dostupne pakete koristeći ikonu <strong>'Paketi'</strong> u gornjem desnom uglu ekrana",
    packageContent: "Sadržaj paketa",
    packageLicense: "Licenca",
    packageSearch: "Pretražite pakete",
    packageSearchResults: "Rezultati za",
    packageNoResults: "Nismo mogli pronaći ništa za",
    packageNoResultsDescription: `Pokušajte potražiti drugi paket ili pregledajte kategorije
    `,
    packagesPopular: "Popularno",
    packagesPromoted: "Promocije",
    packagesNew: "Nova izdanja",
    packageHas: "ima",
    packageKarmaPoints: "karma bodovi",
    packageInfo: "Informacije",
    packageOwner: "Vlasnik",
    packageContrib: "Suradnici",
    packageCreated: "Kreirano",
    packageCurrentVersion: "Trenutna verzija",
    packageNetVersion: ".NET verzija",
    packageDownloads: "Preuzimanja",
    packageLikes: "Lajkovi",
    packageCompatibility: "Kompatibilnost",
    packageCompatibilityDescription: `Ovaj paket je kompatibilan sa sljedećim verzijama Umbraco-a, kako su
      prijavili članovi zajednice. Potpuna kompatibilnost se ne može garantirati za dolje navedene verzije 100%
    `,
    packageExternalSources: "Vanjske poveznice",
    packageAuthor: "Autor",
    packageDocumentation: "Dokumentacija",
    packageMetaData: "Meta podaci paketa",
    packageName: "Naziv paketa",
    packageNoItemsHeader: "Paket ne sadrži nikakve stavke",
    packageNoItemsText: `Ovaj paket ne sadrži nijednu stavku za deinstalaciju.<br/><br/>
      Ovo možete bezbjedno ukloniti iz sistema klikom na "deinstaliraj paket".`,
    packageOptions: "Opcije paketa",
    packageMigrationsRun: "Pokrenite migracije paketa na čekanju",
    packageReadme: "Readme paketa",
    packageRepository: "Repozitorij paketa",
    packageUninstallConfirm: "Potvrdi deinstalaciju paketa",
    packageUninstalledHeader: "Paket je deinstaliran",
    packageUninstalledText: "Paket je uspješno deinstaliran",
    packageUninstallHeader: "Deinstaliraj paket",
    packageUninstallText: `U nastavku možete poništiti odabir stavki koje trenutno ne želite ukloniti. Kada kliknete na "potvrdi deinstalaciju" sve označene stavke će biti uklonjene.<br />
      <span style="color: Red; font-weight: bold;">Bilješka:</span> svi dokumenti, mediji itd. u zavisnosti od stavki koje uklonite, prestat će raditi i mogu dovesti do nestabilnosti sistema,
      pa deinstalirajte sa oprezom. Ako ste u nedoumici, kontaktirajte autora paketa.`,
    packageVersion: "Verzija paketa",
    verifiedToWorkOnUmbracoCloud: "Provjereno za rad na Umbraco Cloud"
  },
  paste: {
    doNothing: "Zalijepi s punim formatiranjem (nije preporučljivo)",
    errorMessage: `Tekst koji pokušavate zalijepiti sadrži posebne znakove ili formatiranje. Ovo bi moglo biti
       uzrokovano kopiranjem teksta iz programa Microsoft Word. Umbraco može automatski ukloniti posebne znakove ili formatiranje, tako da
       zalijepljeni sadržaj će biti prikladniji za web.
    `,
    removeAll: "Zalijepite kao običan tekst bez ikakvog oblikovanja",
    removeSpecialFormattering: "Zalijepi, ali ukloni oblikovanje (preporučeno)"
  },
  publicAccess: {
    paGroups: "Grupna zaštita",
    paGroupsHelp: "Ako želite dodijeliti pristup svim članovima određenih grupa članova",
    paGroupsNoGroups: "Morate kreirati grupu članova prije nego što možete koristiti grupnu autentifikaciju",
    paErrorPage: "Stranica sa greškom",
    paErrorPageHelp: "Koristi se kada su ljudi prijavljeni, ali nemaju pristup",
    paHowWould: "Odaberite kako ograničiti pristup stranici <strong>%0%</strong>",
    paIsProtected: "<strong>%0%</strong> je sada zaštićen",
    paIsRemoved: "Zaštita uklonjena sa <strong>%0%</strong>",
    paLoginPage: "Stranica za prijavu",
    paLoginPageHelp: "Odaberite stranicu koja sadrži obrazac za prijavu",
    paRemoveProtection: "Uklonite zaštitu...",
    paRemoveProtectionConfirm: "Jeste li sigurni da želite ukloniti zaštitu sa stranice <strong>%0%</strong>?",
    paSelectPages: "Odaberite stranice koje sadrže obrazac za prijavu i poruke o greškama",
    paSelectGroups: "Odaberite grupe koje imaju pristup stranici <strong>%0%</strong>",
    paSelectMembers: "Odaberite članove koji imaju pristup stranici <strong>%0%</strong>",
    paMembers: "Posebna zaštita članova",
    paMembersHelp: "Ako želite dati pristup određenim članovima"
  },
  publish: {
    contentPublishedFailedAwaitingRelease: `
      %0% nije mogao biti objavljen jer je stavka zakazana za objavu.
    `,
    contentPublishedFailedExpired: `
      %0% nije mogao biti objavljen jer je stavka istekla.
    `,
    contentPublishedFailedInvalid: `
      %0% nije moglo biti objavljeno jer ova svojstva:  %1%  nisu prošla pravila validacije.
    `,
    contentPublishedFailedByEvent: `
      %0% nije mogao biti objavljen, dodatak treće strane je otkazao radnju.
    `,
    contentPublishedFailedByParent: `
      %0% ne može biti objavljena, jer roditeljska stranica nije objavljena.
    `,
    contentPublishedFailedByMissingName: "%0% ne može se objaviti jer mu nedostaje ime.",
    includeUnpublished: "Uključite neobjavljene podstranice",
    inProgress: "Objavljivanje u toku - molimo pričekajte...",
    inProgressCounter: "%0% od %1% stranica je objavljeno...",
    nodePublish: "%0% je objavljeno",
    nodePublishAll: "%0% i objavljene su podstranice",
    publishAll: "Objavi %0% i sve njegove podstranice",
    publishHelp: `Pritisni <em>Objavi</em> za objavu <strong>%0%</strong> i na taj način svoj sadržaj učiniti javno dostupnim.<br/><br />
      Ovu stranicu i sve njene podstranice možete objaviti odabirom <em>Uključi neobjavljene podstranice</em>.
      `
  },
  colorpicker: {
    noColors: "Niste konfigurirali nijednu odobrenu boju"
  },
  contentPicker: {
    allowedItemTypes: "Možete odabrati samo stavke vrste: %0%",
    pickedTrashedItem: "Odabrali ste stavku sadržaja koja je trenutno obrisana ili je u košu za smeće",
    pickedTrashedItems: "Odabrali ste stavke sadržaja koje su trenutno obrisane ili su u košu za smeće",
    specifyPickerRootTitle: "Odredite korijen",
    defineRootNode: "Odaberite čvor korijena",
    defineXPathOrigin: "Odredite korijen preko XPath",
    defineDynamicRoot: "Odredite Dinamički Korijen",
    configurationStartNodeTitle: "Početni čvor",
    configurationXPathTitle: "XPath Upit"
  },
  dynamicRoot: {
    configurationTitle: "Dinamički korijenski upit",
    pickDynamicRootOriginTitle: "Odabir podrijetla",
    pickDynamicRootOriginDesc: "Definirajte podrijetlo za svoj dinamički korijenski upit",
    originRootTitle: "Korijen",
    originRootDesc: "Korijenski čvor ove sesije uređivanja",
    originParentTitle: "Roditelj",
    originParentDesc: "Čvor izvora u ovoj sesiji uređivanja",
    originCurrentTitle: "Trenutni",
    originCurrentDesc: "Čvor sadržaja koji je izvor za ovu sesiju uređivanja",
    originSiteTitle: "Web stranica",
    originSiteDesc: "Pronađi najbliži čvor s imenom računala (hostname)",
    originByKeyTitle: "Specifični čvor",
    originByKeyDesc: "Odaberite određeni čvor kao podrijetlo za ovaj upit",
    pickDynamicRootQueryStepTitle: "Dodaj korak upitu",
    pickDynamicRootQueryStepDesc: "Definirajte sljedeći korak svog dinamičkog korijenskog upita",
    queryStepNearestAncestorOrSelfTitle: "Najbliži predak ili sam",
    queryStepNearestAncestorOrSelfDesc: "Upitajte najbližeg pretka ili samog sebe koji odgovara jednom od konfiguriranih vrsta",
    queryStepFurthestAncestorOrSelfTitle: "Najudaljeniji predak ili sam",
    queryStepFurthestAncestorOrSelfDesc: "Upitajte najudaljenijeg pretka ili samog sebe koji odgovara jednom od konfiguriranih vrsta",
    queryStepNearestDescendantOrSelfTitle: "Najbliži potomak ili sam",
    queryStepNearestDescendantOrSelfDesc: "Upitajte najbližeg potomka ili samog sebe koji odgovara jednom od konfiguriranih vrsta",
    queryStepFurthestDescendantOrSelfTitle: "Najudaljeniji potomak ili sam",
    queryStepFurthestDescendantOrSelfDesc: "Upitajte najudaljenijeg potomka ili samog sebe koji odgovara jednom od konfiguriranih vrsta",
    queryStepCustomTitle: "Prilagođeno",
    queryStepCustomDesc: "Upitajte pomoću prilagođenog koraka upita",
    addQueryStep: "Dodaj korak upitu",
    queryStepTypes: "Koji odgovara vrstama: ",
    noValidStartNodeTitle: "Nema podudaranja sadržaja",
    noValidStartNodeDesc: "Konfiguracija ove osobine ne odgovara nijednom sadržaju. Stvorite nedostajući sadržaj ili se obratite administratoru kako biste prilagodili postavke dinamičkog korijena za ovu osobinu."
  },
  mediaPicker: {
    deletedItem: "Izbrisana stavka",
    pickedTrashedItem: "Odabrali ste medijsku stavku koja je trenutno obrisana ili je u košu za smeće",
    pickedTrashedItems: "Odabrali ste medijske stavke koje su trenutno obrisane ili su u košu za smeće",
    trashed: "Otpad",
    openMedia: "Otvorite u biblioteci medija",
    changeMedia: "Promjena medijske stavke",
    editMediaEntryLabel: "Uredi %0% od %1%",
    confirmCancelMediaEntryCreationHeadline: "Odbaci kreiranje?",
    confirmCancelMediaEntryCreationMessage: "Jeste li sigurni da želite otkazati kreiranje.",
    confirmCancelMediaEntryHasChanges: `Izmijenili ste ovaj sadržaj. Jeste li sigurni da ga želite
       odbaciti?
    `,
    confirmRemoveAllMediaEntryMessage: "Uklonite sve medije?",
    tabClipboard: "Međuspremnik",
    notAllowed: "Nije dozvoljeno",
    openMediaPicker: "Otvorite odabir medija"
  },
  relatedlinks: {
    enterExternal: "unesite vanjski link",
    chooseInternal: "izaberite internu stranicu",
    caption: "Naslov",
    link: "Link",
    newWindow: "Otvori u novom prozoru",
    captionPlaceholder: "unesite natpis na ekranu",
    externalLinkPlaceholder: "Unesite link"
  },
  imagecropper: {
    reset: "Resetirajte izrezivanje",
    updateEditCrop: "Gotovo",
    undoEditCrop: "Poništi izmjene",
    customCrop: "Korisnički definirano"
  },
  rollback: {
    changes: "Promjene",
    created: "Kreirano",
    currentVersion: "Trenutna verzija",
    diffHelp: "Ovo pokazuje razlike između trenutne verzije i odabrane verzije<br /><del>Crveni tekst</del> bit će uklonjen u odabranoj verziji, <ins>zeleni tekst</ins> će biti dodan",
    noDiff: "Nema razlike između trenutne verzije i odabrane verzije",
    documentRolledBack: "Dokument je vraćen",
    headline: "Odaberite verziju koju želite usporediti sa trenutnom verzijom",
    htmlHelp: `Ovo prikazuje odabranu verziju kao HTML, ako želite vidjeti razliku između dvije
       verzije u isto vrijeme, koristite prikaz diff
    `,
    rollbackTo: "Vratite se na",
    selectVersion: "Odaberite verziju",
    view: "Prikaz"
  },
  scripts: {
    editscript: "Uredite datoteku skripte"
  },
  sections: {
    concierge: "Portirnica",
    content: "Sadržaj",
    courier: "Kurir",
    developer: "Developer",
    forms: "Forme",
    help: "Pomoć",
    installer: "Umbraco Konfiguracijski Čarobnjak",
    media: "Mediji",
    member: "Članovi",
    newsletters: "Newsletteri",
    packages: "Paketi",
    marketplace: "Marketplace",
    settings: "Postavke",
    statistics: "Statistika",
    translation: "Prijevodi",
    users: "Korisnici"
  },
  help: {
    tours: "Ture",
    theBestUmbracoVideoTutorials: "Najbolji Umbraco video tutorijali",
    umbracoForum: "Posjetite our.umbraco.com",
    umbracoTv: "Posjetite umbraco.tv",
    umbracoLearningBase: "Pogledajte naše besplatne video tutorijale",
    umbracoLearningBaseDescription: "na Umbraco Learning Base"
  },
  settings: {
    defaulttemplate: "Zadani predložak",
    importDocumentTypeHelp: `Da biste uvezli vrstu dokumenta, pronađite ".udt" datoteku na svom računalu klikom na
       gumb "Uvezi" (na sljedećem ekranu će se tražiti da potvrdite)
    `,
    newtabname: "Naslov nove kartice",
    nodetype: "Vrsta čvora",
    objecttype: "Vrsta",
    stylesheet: "Stilovi",
    script: "Skripte",
    tab: "Kartica",
    tabname: "Naslov kartice",
    tabs: "Kartice",
    contentTypeEnabled: "Glavna vrsta sadržaja je omogućena",
    contentTypeUses: "Ova vrsta sadržaja koristi",
    noPropertiesDefinedOnTab: `Nema definiranih svojstava na ovoj kartici. Kliknite na vezu "dodaj novu nekretninu" na
       vrh za kreiranje novog svojstva.
    `,
    createMatchingTemplate: "Kreirajte odgovarajući predložak",
    addIcon: "Dodaj ikonu"
  },
  sort: {
    sortOrder: "Redoslijed sortiranja",
    sortCreationDate: "Datum kreiranja",
    sortDone: "Sortiranje završeno.",
    sortHelp: `Povucite različite stavke gore ili dolje ispod da postavite kako bi trebale biti raspoređene. Ili kliknite na
       zaglavlja kolona za sortiranje cijele kolekcije stavki
    `,
    sortPleaseWait: "Pričekajte. Stavke se sortiraju, ovo može potrajati."
  },
  speechBubbles: {
    validationFailedHeader: "Validacija",
    validationFailedMessage: "Greške u validaciji moraju biti ispravljene prije nego što se stavka može spremiti",
    operationFailedHeader: "Nije uspjelo",
    operationSavedHeader: "Spremljeno",
    invalidUserPermissionsText: "Nedovoljne korisničke dozvole, operacija se ne može dovršiti",
    operationCancelledHeader: "Otkazano",
    operationCancelledText: "Operaciju je otkazao dodatak treće strane",
    folderUploadNotAllowed: "Ova datoteka se učitava kao dio fasckile, ali kreiranje nove mape ovdje nije dozvoljeno",
    folderCreationNotAllowed: "Kreiranje nove mape ovdje nije dozvoljeno",
    contentPublishedFailedByEvent: "Objavljivanje je otkazao dodatak treće strane",
    contentTypeDublicatePropertyType: "Vrsta svojstva već postoji",
    contentTypePropertyTypeCreated: "Vrsta svojstva kreirana",
    contentTypePropertyTypeCreatedText: "Naziv: %0% <br /> Vrsta podatka: %1%",
    contentTypePropertyTypeDeleted: "Vrsta svojstva obrisana",
    contentTypeSavedHeader: "Vrsta dokumenta spremljena",
    contentTypeTabCreated: "Kartica kreirana",
    contentTypeTabDeleted: "Kartica je obrisana",
    contentTypeTabDeletedText: "Kartica sa id-em: %0% je obrisana",
    cssErrorHeader: "Stilovi nisu spremljeni",
    cssSavedHeader: "Stilovi spremljeni",
    cssSavedText: "Stilovi spremljeni bez ikakvih grešaka",
    dataTypeSaved: "Vrsta podatka spremljena",
    dictionaryItemSaved: "Stavka riječnika je spremljena",
    editContentPublishedFailedByParent: "Objavljivanje nije uspjelo jer nadređena stranica nije objavljena",
    editContentPublishedHeader: "Sadržaj objavljen",
    editContentPublishedText: "i vidljivo na web stranici",
    editBlueprintSavedHeader: "Predložak sadržaja je spremljen",
    editBlueprintSavedText: "Promjene su uspješno spremljene",
    editContentSavedHeader: "Sadržaj spremljen",
    editContentSavedText: "Ne zaboravite objaviti da promjene budu vidljive",
    editContentSendToPublish: "Poslano na odobrenje",
    editContentSendToPublishText: "Promjene su poslane na odobrenje",
    editMediaSaved: "Medij spremljen",
    editMediaSavedText: "Medij spremljen bez ikakvih grešaka",
    editMemberSaved: "Član spremljen",
    editStylesheetPropertySaved: "Svojstvo stilova spremljeno",
    editStylesheetSaved: "Stilovi spremljeni",
    editTemplateSaved: "Predložak spremljen",
    editUserError: "Greška pri spremanju korisnika (provjerite log zapis)",
    editUserSaved: "Korisnik spremljen",
    editUserTypeSaved: "Vrsta korisnika spremljena",
    editUserGroupSaved: "Grupa korisnika spremljena",
    editCulturesAndHostnamesSaved: "Kulture i imena hostova su spremljeni",
    editCulturesAndHostnamesError: "Greška pri spremanju kultura i imena hostova",
    fileErrorHeader: "Datoteka nije spremljena",
    fileErrorText: "Datoteka nije mogla biti spremljena. Molimo provjerite dozvole za datoteke",
    fileSavedHeader: "Datoteke spremljene",
    fileSavedText: "Datoteka spremljena bez ikakvih grešaka",
    languageSaved: "Jezik spremljen",
    mediaTypeSavedHeader: "Vrsta medija spremljena",
    memberTypeSavedHeader: "Vrsta člana spremljena",
    memberGroupSavedHeader: "Grupa članova spremljena",
    memberGroupNameDuplicate: "Druga grupa članova sa istim imenom već postoji",
    templateErrorHeader: "Predložak nije spremljen",
    templateErrorText: "Uvjerite se da nemate 2 predloška sa istim aliasom",
    templateSavedHeader: "Predložak spremljen",
    templateSavedText: "Predložak spremljen bez ikakvih grešaka!",
    contentUnpublished: "Sadržaj nije objavljen",
    partialViewSavedHeader: "Parcijalni prikaz spremljen",
    partialViewSavedText: "Parcijalni prikaz spremljen bez ikakvih grešaka!",
    partialViewErrorHeader: "Parcijalni prikaz nije spremljen",
    partialViewErrorText: "Došlo je do greške prilikom spremanja datoteke.",
    permissionsSavedFor: "Dozvole su spremljene za",
    deleteUserGroupsSuccess: "Izbrisano je %0% grupa korisnika",
    deleteUserGroupSuccess: "%0% je obrisano",
    enableUsersSuccess: "Omogućeno %0% korisnika",
    disableUsersSuccess: "Onemogućeno %0% korisnika",
    enableUserSuccess: "%0% je sada omogućen",
    disableUserSuccess: "%0% je sada onemogućen",
    setUserGroupOnUsersSuccess: "Grupe korisnika su postavljene",
    unlockUsersSuccess: "Otključano %0% korisnika",
    unlockUserSuccess: "%0% je sada otključan",
    memberExportedSuccess: "Član je izvezen u datoteku",
    memberExportedError: "Došlo je do greške prilikom izvoza člana",
    deleteUserSuccess: "Korisnik %0% je obrisan",
    resendInviteHeader: "Pozovi korisnika",
    resendInviteSuccess: "Pozivnica je ponovo poslana na %0%",
    documentTypeExportedSuccess: "Vrsta dokumenta je izvezena u datoteku",
    documentTypeExportedError: "Došlo je do greške prilikom izvoza vrste dokumenta",
    dictionaryItemExportedSuccess: "Stavke iz riječnika su izvezene u datoteku",
    dictionaryItemExportedError: "Došlo je do greške prilikom izvoza stavki rječnika",
    dictionaryItemImported: "Sljedeće stavke iz rječnika su uvezene!",
    publishWithNoDomains: `Domene nisu konfigurirane za višejezične stranice, molimo kontaktirajte administratora,
       pogledajte log zapise za više informacija
    `,
    publishWithMissingDomain: "Nijedna domena nije konfigurirana za %0%, molimo kontaktirajte administratora",
    copySuccessMessage: "Vaše sistemske informacije su uspješno kopirane u međuspremnik",
    cannotCopyInformation: "Nije moguće kopirati vaše sistemske informacije u međuspremnik",
    webhookSaved: "Webhook spremljen"
  },
  stylesheet: {
    addRule: "Dodaj stil",
    editRule: "Uredi stil",
    editorRules: "Stilovi za uređivanje bogatog teksta",
    editorRulesHelp: `Definirajte stilove koji bi trebali biti dostupni u uređivaču obogaćenog teksta za ove
	   stilove
    `,
    editstylesheet: "Uredi stilove",
    editstylesheetproperty: "Uredi svojstvo stilova",
    nameHelp: "Ime prikazano u uređivaču odabira stilova",
    preview: "Pregled",
    previewHelp: "Kako će tekst izgledati u uređivaču obogaćenog teksta.",
    selector: "Selektor",
    selectorHelp: 'Koristite CSS sintaksu, npr. "h1" ili ".redHeader"',
    styles: "Stilovi",
    stylesHelp: 'CSS koji treba primijeniti u uređivaču obogaćenog teksta, npr. "color:red;"',
    tabCode: "Kod",
    tabRules: "Uređivač"
  },
  template: {
    runtimeModeProduction: "Sadržaj se ne može uređivati kada se koristi način rada <code>Produkcija</code>.",
    deleteByIdFailed: "Brisanje predloška sa ID-om %0% nije uspjelo",
    edittemplate: "Uredi predložak",
    insertSections: "Sekcije",
    insertContentArea: "Umetnite područje sadržaja",
    insertContentAreaPlaceHolder: "Umetnite čuvara mjesta u području sadržaja",
    insert: "Umetni",
    insertDesc: "Odaberite što ćete umetnuti u svoj predložak",
    insertDictionaryItem: "Stavka iz rječnika",
    insertDictionaryItemDesc: `Stavka rječnika je čuvar mjesta za prevodljiv dio teksta, koji
       olakšava kreiranje dizajna za višejezične web stranice.
    `,
    insertMacro: "Makro",
    insertMacroDesc: `
       Makro je komponenta koja se može konfigurirati i odlična je za
       višenamjenske dijelove vašeg dizajna, gdje vam je potrebna opcija za pružanje parametara,
       kao što su galerije, obrasci i liste.
    `,
    insertPageField: "Vrijednost",
    insertPageFieldDesc: "Prikazuje vrijednost polja sa trenutne stranice po aliasu s opcijama za izmjenu vrijednosti ili povratak na alternativne vrijednosti.",
    insertPartialView: "Parcijalni prikaz",
    insertPartialViewDesc: `
       Parcijalni prikaz je zasebna datoteka predloška koja se može prikazati unutar drugog
       predložka, odličan je za ponovnu upotrebu markupa ili za odvajanje složenih predložaka u zasebne datoteke.
    `,
    mastertemplate: "Glavni predložak",
    noMaster: "Nema glavnog predloška",
    renderBody: "Renderirajte podređeni predložak",
    renderBodyDesc: `
     Renderira sadržaj podređenog predloška, umetanjem
     <code>@RenderBody()</code>.
      `,
    defineSection: "Definirajte imenovanu sekciju",
    defineSectionDesc: `
         Definira dio vašeg predloška kao imenovanu sekciju tako što ga umotava
          <code>@section { ... }</code>. Ovo se može prikazati u
           određenom području nadređenog predloška, koristeći <code>@RenderSection</code>.
      `,
    renderSection: "Renderirajte imenovanu sekciju",
    renderSectionDesc: `
      Renderira imenovano područje podređenog predloška, umetanjem <code>@RenderSection(name)</code>.
      Ovo prikazuje područje podređenog predloška koje je umotano u odgovarajuću <code>@section [name]{ ... }</code> definiciju.
      `,
    sectionName: "Naziv sekcije",
    sectionMandatory: "Sekcija je obavezna",
    sectionMandatoryDesc: `
            Ako je obavezno, podređeni predložak mora sadržavati <code>@section</code>, u suprotnom se prikazuje greška.
    `,
    queryBuilder: "Generiranje upita",
    itemsReturned: "stavaka vraćeno, u",
    iWant: "Želim",
    allContent: "sav sadržaj",
    contentOfType: 'sadržaj vrste "%0%"',
    from: "sa",
    websiteRoot: "moje web stranice",
    where: "gdje",
    and: "i",
    is: "je",
    isNot: "nije",
    before: "prije",
    beforeIncDate: "prije (uključujući odabrani datum)",
    after: "poslije",
    afterIncDate: "poslije (uključujući odabrani datum)",
    equals: "jednako",
    doesNotEqual: "nije jednako",
    contains: "sadrži",
    doesNotContain: "ne sadrži",
    greaterThan: "veće od",
    greaterThanEqual: "veće ili jednako",
    lessThan: "manje od",
    lessThanEqual: "manje ili jednako",
    id: "Id",
    name: "Naziv",
    createdDate: "Kreirano",
    lastUpdatedDate: "Ažurirano",
    orderBy: "poredaj po",
    ascending: "uzlazno",
    descending: "silazno",
    template: "Predložak"
  },
  grid: {
    media: "Slika",
    macro: "Makro",
    insertControl: "Odaberite vrstu sadržaja",
    chooseLayout: "Odaberite izgled",
    addRows: "Dodaj redak",
    addElement: "Dodaj sadržaj",
    dropElement: "Ispusti sadržaj",
    settingsApplied: "Postavke su primijenjene",
    contentNotAllowed: "Ovaj sadržaj ovdje nije dozvoljen",
    contentAllowed: "Ovaj sadržaj je ovdje dozvoljen",
    clickToEmbed: "Kliknite za ugradnju",
    clickToInsertImage: "Kliknite da umetnete sliku",
    clickToInsertMacro: "Kliknite da umetnete makro",
    placeholderWriteHere: "Pišite ovdje...",
    gridLayouts: "Raspored mreže",
    gridLayoutsDetail: `Izgledi su cjelokupno radno područje za uređivač mreže, obično vam je potreban samo jedan ili
       dva različita izgleda
    `,
    addGridLayout: "Dodajte raspored mreže",
    editGridLayout: "Uredite raspored mreže",
    addGridLayoutDetail: "Prilagodite izgled postavljanjem širine kolona i dodavanjem dodatnih odjeljaka",
    rowConfigurations: "Konfiguracije redova",
    rowConfigurationsDetail: "Redovi su predefinirani za raspored vodoravno",
    addRowConfiguration: "Dodajte konfiguraciju reda",
    editRowConfiguration: "Uredite konfiguraciju reda",
    addRowConfigurationDetail: "Podesite red postavljanjem širine ćelija i dodavanjem dodatnih ćelija",
    noConfiguration: "Nije dostupna dodatna konfiguracija",
    columns: "Kolone",
    columnsDetails: "Ukupan kombinirani broj kolona u rasporedu mreže",
    settings: "Postavke",
    settingsDetails: "Konfigurirajte koje postavke urednici mogu promijeniti",
    styles: "Stilovi",
    stylesDetails: "Konfigurirajte šta uređivači stilova mogu promijeniti",
    allowAllEditors: "Dozvoli svim urednicima",
    allowAllRowConfigurations: "Dozvoli sve konfiguracije redaka",
    maxItems: "Maksimalan broj stavki",
    maxItemsDescription: "Ostavite prazno ili postavite na 0 za neograničeno",
    setAsDefault: "Postavi kao zadano",
    chooseExtra: "Odaberite extra",
    chooseDefault: "Odaberite zadano",
    areAdded: "su dodani",
    warning: "Upozorenje",
    warningText: "<p>Promjena imena konfiguracije reda će rezultirati gubitkom podataka za bilo koji postojeći sadržaj koji se temelji na ovoj konfiguraciji.</p> <p><strong>Izmjena samo oznake neće rezultirati gubitkom podataka.</strong></p>",
    youAreDeleting: "Brišete konfiguraciju reda",
    deletingARow: `
      Brisanje imena konfiguracije reda će rezultirati gubitkom podataka za bilo koji postojeći sadržaj koji je zasnovan na ovome
      konfiguraciju.
    `,
    deleteLayout: "Brišete izgled",
    deletingALayout: `Izmjena izgleda će rezultirati gubitkom podataka za bilo koji postojeći sadržaj koji je zasnovan
       na ovoj konfiguraciji.
    `
  },
  contentTypeEditor: {
    compositions: "Kompozicije",
    group: "Grupa",
    noGroups: "Niste dodali nijednu grupu",
    addGroup: "Dodaj grupu",
    inheritedFrom: "Naslijeđeno od",
    addProperty: "Dodaj svojstvo",
    requiredLabel: "Obavezna oznaka",
    enableListViewHeading: "Omogući prikaz liste",
    enableListViewDescription: `Konfigurira stavku sadržaja da prikaže njenu listu koja se može sortirati i pretraživati djecu, djeca neće biti prikazana u stablu
    `,
    allowedTemplatesHeading: "Dozvoljeni predlošci",
    allowedTemplatesDescription: `Odaberite koje predloške urednici mogu koristiti na sadržaju ove vrste
    `,
    allowAsRootHeading: "Dozvoli kao korijen",
    allowAsRootDescription: `Dozvolite urednicima da kreiraju sadržaj ove vrste u korijenu stabla sadržaja.
    `,
    childNodesHeading: "Dozvoljene vrste podređenih čvorova",
    childNodesDescription: `Dozvolite da se sadržaj navedenih vrsta kreira ispod sadržaja ove vrste.
    `,
    chooseChildNode: "Odaberite podređeni čvor",
    compositionsDescription: `Naslijediti kartice i svojstva iz postojeće vrste dokumenta. Nove kartice bit će
      dodane trenutnoj vrsti dokumenta ili spojene ako postoji kartica s identičnim imenom.
    `,
    compositionInUse: `Ova vrsta sadržaja se koristi u kompoziciji i stoga se ne može sam sastaviti.
    `,
    noAvailableCompositions: "Nema dostupnih vrsta sadržaja za upotrebu kao kompozicija.",
    compositionRemoveWarning: `Uklanjanje kompozicije će obrisati sve povezane podatke o svojstvu. Jednom kada spremite vrstu dokumenta, nema povratka.
    `,
    availableEditors: "Napravi novi",
    reuse: "Koristite postojeće",
    editorSettings: "Postavke urednika",
    configuration: "Konfiguracija",
    yesDelete: "Da, izbriši",
    movedUnderneath: "je premještena ispod",
    copiedUnderneath: "je kopirano ispod",
    folderToMove: "Odaberite mapu za premještanje",
    folderToCopy: "Odaberite mapu za kopiranje",
    structureBelow: "do u strukturi stabla ispod",
    allDocumentTypes: "Sve vrste dokumenata",
    allDocuments: "Svi dokumenti",
    allMediaItems: "Sve medijske stavke",
    usingThisDocument: "korištenje ove vrste dokumenta bit će trajno izbrisano, potvrdite da želite obrisati ove također.",
    usingThisMedia: `korištenje ove vrste medija će biti trajno izbrisano, potvrdite da želite obrisati ove također.
    `,
    usingThisMember: "korištenje ove vrste člana će biti trajno izbrisano, potvrdite da želite obrisati ove također",
    andAllDocuments: "i svi dokumenti koji koriste ovu vrstu",
    andAllMediaItems: "i sve medijske stavke koje koriste ovu vrstu",
    andAllMembers: "i svi članovi koji koriste ovu vrstu",
    memberCanEdit: "Član može uređivati",
    memberCanEditDescription: "Dozvolite da ovu vrijednost svojstva da uređuje član na svojoj stranici profila",
    isSensitiveData: "Osjetljivi podaci",
    isSensitiveDataDescription: "Sakrij ovu vrijednost svojstva od urednika sadržaja koji nemaju pristup pregledu osjetljive informacije",
    showOnMemberProfile: "Prikaži na profilu člana",
    showOnMemberProfileDescription: "Dozvolite da se ova vrijednost svojstva prikaže na stranici profila člana",
    tabHasNoSortOrder: "kartica nema redoslijed sortiranja",
    compositionUsageHeading: "Gdje se koristi ovaj sastav?",
    compositionUsageSpecification: `Ovaj sastav se trenutno koristi u sastavu sljedećih
      vrsta sadržaja:
    `,
    variantsHeading: "Dozvoli varijacije",
    cultureVariantHeading: "Dozvolite varirati u zavisnosti od kulture",
    segmentVariantHeading: "Dozvoli segmentaciju",
    cultureVariantLabel: "Varijacije po kulturi",
    segmentVariantLabel: "Varijacije po segmentima",
    variantsDescription: "Dozvolite urednicima da kreiraju sadržaj ove vrste na različitim jezicima.",
    cultureVariantDescription: "Dozvolite urednicima da kreiraju sadržaj na različitim jezicima.",
    segmentVariantDescription: "Dozvolite urednicima da kreiraju segmente ovog sadržaja.",
    allowVaryByCulture: "Dozvolite varijaciju po kulturi",
    allowVaryBySegment: "Dozvoli segmentaciju",
    elementType: "Vrsta elementa",
    elementHeading: "Da li je vrste elementa",
    elementDescription: `Vrsta elementa je namijenjena za korištenje na primjer u ugniježenom sadržaju, a ne u stablu.
    `,
    elementCannotToggle: `Vrsta dokumenta se ne može promijeniti u vrstu elementa nakon što je naviknut
      kreirati jednu ili više stavki sadržaja.
    `,
    elementDoesNotSupport: "Ovo nije primjenjivo za vrstu elementa",
    propertyHasChanges: "Napravili ste promjene on ovom svojstvu. Jeste li sigurni da ih želite odbaciti?",
    displaySettingsHeadline: "Izgled",
    displaySettingsLabelOnTop: "Oznaka iznad (puna širina)",
    removeChildNode: "Uklanjate podređeni čvor",
    removeChildNodeWarning: `Uklanjanje podređenog čvora ograničit će opcije urednika da kreiraju drugačiju vrstu sadržaj ispod čvora.
    `,
    usingEditor: "korištenjem ovog uređivača bit će ažurirane nove postavke.",
    historyCleanupHeading: "Brisanje povijesti",
    historyCleanupDescription: "Dozvoli zaobilaženje postavki čišćenja globalne povijesti.",
    historyCleanupKeepAllVersionsNewerThanDays: "Neka sve verzije budu novije od dana",
    historyCleanupKeepLatestVersionPerDayForDays: "Čuvajte najnoviju verziju po danu danima",
    historyCleanupPreventCleanup: "Spriječi čišćenje",
    historyCleanupEnableCleanup: "Omogući čišćenje",
    historyCleanupGloballyDisabled: "<strong>BILJEŠKA!</strong> Čišćenje povijesnih verzija sadržaja onemogućeno je globalno. Ove postavke neće stupiti na snagu prije nego što se omogući.",
    changeDataTypeHelpText: "Promjena vrste podatka sa spremljenim vrijednostima je onemogućena. Da bi omogućili promjenu, možete promijeniti Umbraco:CMS:DataTypes:CanBeChanged postavku u appsettings.json."
  },
  webhooks: {
    addWebhook: "Kreiraj webhook",
    addWebhookHeader: "Dodaj webhook zaglavlje",
    addDocumentType: "Dodaj Vrstu Dokumenta",
    addMediaType: "Dodaj Vrstu Medija",
    createHeader: "Kreiraj zaglavlje",
    deliveries: "Isporuke",
    noHeaders: "Nijedno webhook zaglavlje nije dodano",
    noEventsFound: "Nema pronađenih događaja.",
    enabled: "Omogućeno",
    events: "Događanja",
    event: "Događaj",
    url: "Url",
    types: "Vrste",
    webhookKey: "Webhook key",
    retryCount: "Broj pokušaja"
  },
  languages: {
    addLanguage: "Dodaj jezik",
    culture: "ISO kod",
    mandatoryLanguage: "Obavezan jezik",
    mandatoryLanguageHelp: `Svojstva na ovom jeziku moraju biti popunjena prije nego što se čvor može objaviti.
    `,
    defaultLanguage: "Zadani jezik",
    defaultLanguageHelp: "Umbraco stranica može imati samo jedan zadani jezik.",
    changingDefaultLanguageWarning: "Promjena zadanog jezika može rezultirati nedostatkom zadanog sadržaja.",
    fallsbackToLabel: "Vraća se na",
    noFallbackLanguageOption: "Nema zamjenskog jezika",
    fallbackLanguageDescription: `Da se omogući višejezični sadržaj da se vrati na drugi jezik ako ne
      bude prisutan na traženom jeziku, odaberite ga ovdje.
    `,
    fallbackLanguage: "Zamjenski jezik",
    none: "niti jedan"
  },
  macro: {
    addParameter: "Dodaj parameter",
    editParameter: "Uredi parameter",
    enterMacroName: "Unesite naziv makroa",
    parameters: "Parametri",
    parametersDescription: "Definirajte parametre koji bi trebali biti dostupni kada koristite ovaj makro.",
    selectViewFile: "Odaberite parcijalni prikaz makro datoteke"
  },
  modelsBuilder: {
    buildingModels: "Kreiranje modela",
    waitingMessage: "ovo može potrajati, ne brinite",
    modelsGenerated: "Modeli generirani",
    modelsGeneratedError: "Modeli ne mogu biti generirani",
    modelsExceptionInUlog: "Generiranje modela nije uspjelo, pogledajte iznimku u log zapisima"
  },
  templateEditor: {
    addDefaultValue: "Dodajte zadanu vrijednost",
    defaultValue: "Zadana vrijednost",
    alternativeField: "Rezervno polje",
    alternativeText: "Zadana vrijednost",
    casing: "Veličina slova",
    encoding: "Kodiranje",
    chooseField: "Odaberite polje",
    convertLineBreaks: "Pretvorite prijelome redaka",
    convertLineBreaksHelp: "Zamjenjuje prijelome reda sa 'br' html oznakom",
    customFields: "Prilagođena polja",
    dateOnly: "Samo datum",
    formatAsDate: "Formatiraj kao datum",
    htmlEncode: "Kodirati kao HTML",
    htmlEncodeHelp: "Zamijenit će specijalne znakove njihovim HTML ekvivalentom.",
    insertedAfter: "Bit će umetnuto iza vrednosti polja",
    insertedBefore: "Bit će umetnuto ispred vrednosti polja",
    lowercase: "Mala slova",
    none: "Nema",
    outputSample: "Izlazni uzorak",
    postContent: "Umetnuti nakon polja",
    preContent: "Umetnuti ispred polja",
    recursive: "Rekurzivno",
    recursiveDescr: "Da, neka bude rekurzivno",
    standardFields: "Standardna polja",
    uppercase: "Velika slova",
    urlEncode: "Kodirati kao URL",
    urlEncodeHelp: "Formatirat će posebne znakove u URL-ovima",
    usedIfAllEmpty: "Koristit će se samo kada su vrijednosti polja iznad prazne",
    usedIfEmpty: "Ovo polje će se koristiti samo ako je primarno polje prazno",
    withTime: "Datum i vrijeme"
  },
  translation: {
    details: "Detalji prijevoda",
    DownloadXmlDTD: "Preuzmi XML DTD",
    fields: "Polja",
    includeSubpages: "Uključi podstranice",
    mailBody: `
      Zdravo %0%

      Ovo je automatska pošta koja vas obavještava da je za
	  dokument '%1%' zatražen prijevod na '%5%' od %2%.

      Idi na http://%3%/translation/details.aspx?id=%4% za uređivanje.

      Ili se prijavite na Umbraco da bi dobili pregled vaših zadataka za prijevod
      http://%3%

      Ugodan dan!
      Pozdrav od Umbraco robota
    `,
    noTranslators: `Nije pronađen niti jedan korisnik prevoditelja. Molimo kreirajte korisnika prevoditelja prije nego počnete slati
       sadržaj u prijevod
    `,
    pageHasBeenSendToTranslation: "Stranica '%0%' je poslana na prijevod",
    sendToTranslate: "Pošaljite stranicu '%0%' na prijevod",
    totalWords: "Ukupno riječi",
    translateTo: "Prevedi na",
    translationDone: "Prijevod završen.",
    translationDoneHelp: "Možete pregledati stranice koje ste upravo preveli klikom ispod. ",
    translationFailed: "Prijevod nije uspio, XML datoteka je možda oštećena",
    translationOptions: "Opcije prevođenja",
    translator: "Prevoditelj",
    uploadTranslationXml: "Uvezite XML prijevod"
  },
  treeHeaders: {
    content: "Sadržaj",
    contentBlueprints: "Predlošci sadržaja",
    media: "Mediji",
    cacheBrowser: "Pretraživač predmemorije",
    contentRecycleBin: "Koš za smeće",
    createdPackages: "Kreirani paketi",
    dataTypes: "Vrste podataka",
    dictionary: "Riječnik",
    installedPackages: "Instalirani paketi",
    installSkin: "Instaliraj skin",
    installStarterKit: "Instaliraj starter kit",
    languages: "Jezici",
    localPackage: "Instaliraj lokalni paket",
    macros: "Makroi",
    mediaTypes: "Vrste medija",
    member: "Članovi",
    memberGroups: "Grupe članova",
    memberRoles: "Uloge članova",
    memberTypes: "Vrste članova",
    documentTypes: "Vrste dokumenata",
    relationTypes: "Vrste relacija",
    packager: "Paketi",
    packages: "Paketi",
    partialViews: "Parcijalni prikazi",
    partialViewMacros: "Parcijalni prikazi makro datoteka",
    repositories: "Instaliraj iz repozitorija",
    runway: "Instaliraj Runway",
    runwayModules: "Runway moduli",
    scripting: "Skripte",
    scripts: "Skripte",
    stylesheets: "Stilovi",
    templates: "Predlošci",
    logViewer: "Log preglednik",
    users: "Korisnici",
    settingsGroup: "Postavke",
    templatingGroup: "Predložak",
    thirdPartyGroup: "Treća strana",
    webhooks: "Webhooks"
  },
  update: {
    updateAvailable: "Postoji nova verzija",
    updateDownloadText: "%0% je spremno, kliknite ovdje za preuzimanje",
    updateNoServer: "Veza sa serverom je prekinuta",
    updateNoServerError: "Pogreška prilikom provjeravanja ažuriranja. Za dodtne informacije provjerite trace-stack"
  },
  user: {
    access: "Pristup",
    accessHelp: `Na temelju dodijeljenih grupa i početnih čvorova, korisnik ima pristup sljedećim čvorovima
    `,
    assignAccess: "Dodijeli pristup",
    administrators: "Administrator",
    categoryField: "Polje kategorije",
    createDate: "Korisnik kreiran",
    changePassword: "Promijeni lozinku",
    changePhoto: "Promijeni sliku",
    newPassword: "Nova lozinka",
    newPasswordFormatLengthTip: "Najmanje %0% znakova!",
    newPasswordFormatNonAlphaTip: "Trebalo bi biti najmanje %0% specijalnih znakova.",
    noLockouts: "nije zaključan",
    noPasswordChange: "Lozinka nije promijenjena",
    confirmNewPassword: "Potvrdite novu lozinku",
    changePasswordDescription: 'Možete promijeniti svoju lozinku za pristup Umbraco Back Officeu tako da ispunite donji obrazac i kliknete gumb "Promjeni lozinku"',
    contentChannel: "Kanal sadržaja",
    createAnotherUser: "Kreiraj drugog korisnika",
    createUserHelp: `Kreirajte nove korisnike kako biste im omogućili pristup Umbraco-u. Kada se kreira novi korisnik, stvorit će se lozinka koju možete podijeliti s korisnikom.
    `,
    descriptionField: "Polje kratkog opisa",
    disabled: "Onemogući korisnika",
    documentType: "Vrsta dokumenta",
    editors: "Urednik",
    emailRequired: "Obavezno - unesite email adresu za ovog korisnika",
    excerptField: "Polje izvoda",
    failedPasswordAttempts: "Neuspjeli pokušaji prijave",
    goToProfile: "Idite na korisnički profil",
    groupsHelp: "Dodajte grupe za dodjelu pristupa i dozvola",
    inviteAnotherUser: "Pozovite drugog korisnika",
    inviteUserHelp: `Pozovite nove korisnike da im omogućite pristup Umbraco-u. Korisniku bit će poslan email s pozivnicom i informacijama o tome kako se prijaviti u Umbraco. Pozivnice traju 72 sata.
    `,
    language: "Jezik",
    languageHelp: "Postavite jezik koji ćete vidjeti u izbornicima i dijaloškim okvirima",
    lastLockoutDate: "Zadnji datum zaključavanja",
    lastLogin: "Zadnja prijava",
    lastPasswordChangeDate: "Lozinka zadnje promijenjena",
    loginname: "Korisničko ime",
    mediastartnode: "Medijski početni čvor",
    mediastartnodehelp: "Ograničite biblioteku medija na određeni početni čvor",
    mediastartnodes: "Medijski početni čvorovi",
    mediastartnodeshelp: "Ograničite biblioteku medija na određene početne čvorove",
    modules: "Sekcije",
    nameRequired: "Obavezno - unesite ime za ovog korisnika",
    noConsole: "Onemogućite pristup Umbraco-u",
    noLogin: "se još nije prijavio",
    oldPassword: "Stara lozinka",
    password: "Lozinka",
    resetPassword: "Resetiraj lozinku",
    passwordChanged: "Vaša lozinka je promijenjena!",
    passwordChangedGeneric: "Lozinka je promijenjena",
    passwordConfirm: "Molimo potvrdite novu lozinku",
    passwordEnterNew: "Unesite novu lozinku",
    passwordIsBlank: "Vaša nova lozinka ne može biti prazna!",
    passwordCurrent: "Trenutna lozinka",
    passwordInvalid: "Nevažeća trenutna lozinka",
    passwordIsDifferent: "Postoji razlika između nove lozinke i potvrđene lozinke. Molimo pokušajte ponovo!",
    passwordMismatch: "Potvrđena lozinka ne odgovara novoj lozinki!",
    permissionReplaceChildren: "Zamijenite dozvole podređenog čvora",
    permissionSelectedPages: "Trenutno mijenjate dozvole za stranice:",
    permissionSelectPages: "Odaberite stranice da promijenite njihove dozvole",
    removePhoto: "Ukloni sliku",
    permissionsDefault: "Zadane dozvole",
    permissionsGranular: "Detaljne dozvole",
    permissionsGranularHelp: "Postavite dozvole za određene čvorove",
    profile: "Profil",
    searchAllChildren: "Pretražite svu djecu",
    languagesHelp: "Ograničite jezike kojima korisnici imaju pristup za uređivanje",
    allowAccessToAllLanguages: "Dozvoljen pristup svim jezicima",
    sectionsHelp: "Dodajte odjeljke da korisnicima omogućite pristup",
    selectUserGroups: "Odaberite grupe korisnika",
    noStartNode: "Nije odabran početni čvor",
    noStartNodes: "Nije odabran nijedan početni čvor",
    startnode: "Početni čvor sadržaja",
    startnodehelp: "Ograničite stablo sadržaja na određeni početni čvor",
    startnodes: "Početni čvorovi sadržaja",
    startnodeshelp: "Ograničite stablo sadržaja na određene početne čvorove",
    updateDate: "Korisnik zadnji put ažuriran",
    userCreated: "je kreiran",
    userCreatedSuccessHelp: `Novi korisnik je uspješno kreiran. Za prijavu na Umbraco koristite
      lozinka ispod.
    `,
    userManagement: "Upravljanje korisnicima",
    username: "Korisničko ime",
    userPermissions: "Korisničke dozvole",
    usergroup: "Grupa korisnika",
    userInvited: "je pozvan",
    userInvitedSuccessHelp: "Novom korisniku je poslana pozivnica s detaljima o tome kako se prijaviti u Umbraco.",
    userinviteWelcomeMessage: "Pozdrav i dobrodošli u Umbraco! Jedna minuta bit će vam potrebna da postavite svoju lozinku.",
    userinviteExpiredMessage: "Dobrodošli u Umbraco! Nažalost pozivnica je istekla. Molimo kontaktirajte svog administratora i od njega tražite da ju ponovno pošalje.",
    writer: "Pisac",
    change: "Promjeni",
    yourProfile: "Vaš profil",
    yourHistory: "Vaša nedavna povijest",
    sessionExpires: "Sesija ističe za",
    inviteUser: "Pozovi korisnika",
    createUser: "Kreiraj korisnika",
    sendInvite: "Pošalji pozivnicu",
    backToUsers: "Nazad na korisnike",
    inviteEmailCopySubject: "Umbraco: Pozivnica",
    inviteEmailCopyFormat: `
        <html>
			<head>
				<meta name='viewport' content='width=device-width'>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
			</head>
			<body class='' style='font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; color: #392F54; line-height: 22px; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background: #1d1333; margin: 0; padding: 0;' bgcolor='#1d1333'>
				<style type='text/css'> @media only screen and (max-width: 620px) {table[class=body] h1 {font-size: 28px !important; margin-bottom: 10px !important; } table[class=body] .wrapper {padding: 32px !important; } table[class=body] .article {padding: 32px !important; } table[class=body] .content {padding: 24px !important; } table[class=body] .container {padding: 0 !important; width: 100% !important; } table[class=body] .main {border-left-width: 0 !important; border-radius: 0 !important; border-right-width: 0 !important; } table[class=body] .btn table {width: 100% !important; } table[class=body] .btn a {width: 100% !important; } table[class=body] .img-responsive {height: auto !important; max-width: 100% !important; width: auto !important; } } .btn-primary table td:hover {background-color: #34495e !important; } .btn-primary a:hover {background-color: #34495e !important; border-color: #34495e !important; } .btn  a:visited {color:#FFFFFF;} </style>
				<table border="0" cellpadding="0" cellspacing="0" class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;" bgcolor="#1d1333">
					<tr>
						<td style="font-family: sans-serif; font-size: 14px; vertical-align: top; padding: 24px;" valign="top">
							<table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;">
								<tr>
									<td background="https://umbraco.com/umbraco/assets/img/application/logo.png" bgcolor="#1d1333" width="28" height="28" valign="top" style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
										<!--[if gte mso 9]> <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:30px;height:30px;"> <v:fill type="tile" src="https://umbraco.com/umbraco/assets/img/application/logo.png" color="#1d1333" /> <v:textbox inset="0,0,0,0"> <![endif]-->
<div></div>
<!--[if gte mso 9]> </v:textbox> </v:rect> <![endif]-->
</td>
<td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top"></td>
</tr>
</table>
</td>
</tr>
</table>
<table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;' bgcolor='#1d1333'>
<tr>
<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'></td>
<td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 560px; width: 560px; margin: 0 auto; padding: 10px;' valign='top'>
<div class='content' style='box-sizing: border-box; display: block; max-width: 560px; margin: 0 auto; padding: 10px;'>
<br>
<table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; border-radius: 3px; background: #FFFFFF;' bgcolor='#FFFFFF'>
<tr>
<td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 50px;' valign='top'>
<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
<tr>
<td style='line-height: 24px; font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'>
<h1 style='color: #392F54; font-family: sans-serif; font-weight: bold; line-height: 1.4; font-size: 24px; text-align: left; text-transform: capitalize; margin: 0 0 30px;' align='left'>
															Pozdrav %0%,
														</h1>
<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Pozvani ste od <a href="mailto:%4%" style="text-decoration: underline; color: #392F54; -ms-word-break: break-all; word-break: break-all;">%1%</a> u Umbraco administraciju.
														</p>
<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Poruka od <a href="mailto:%1%" style="text-decoration: none; color: #392F54; -ms-word-break: break-all; word-break: break-all;">%1%</a>:
															<br/>
<em>%2%</em>
</p>
<table border='0' cellpadding='0' cellspacing='0' class='btn btn-primary' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; box-sizing: border-box;'>
<tbody>
<tr>
<td align='left' style='font-family: sans-serif; font-size: 14px; vertical-align: top; padding-bottom: 15px;' valign='top'>
<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
<tbody>
<tr>
<td style='font-family: sans-serif; font-size: 14px; vertical-align: top; border-radius: 5px; text-align: center; background: #35C786;' align='center' bgcolor='#35C786' valign='top'>
<a href='%3%' target='_blank' rel='noopener' style='color: #FFFFFF; text-decoration: none; -ms-word-break: break-all; word-break: break-all; border-radius: 5px; box-sizing: border-box; cursor: pointer; display: inline-block; font-size: 14px; font-weight: bold; text-transform: capitalize; background: #35C786; margin: 0; padding: 12px 30px; border: 1px solid #35c786;'>
																							Kliknite na ovaj link da prihvatite pozivnicu
																						</a>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<p style='max-width: 400px; display: block; color: #392F54; font-family: sans-serif; font-size: 14px; line-height: 20px; font-weight: normal; margin: 15px 0;'>Ukoliko ne možete kliknuti na link, kopirajte i zalijepite ovaj URL u prozor vašeg pretraživača:</p>
<table border='0' cellpadding='0' cellspacing='0'>
<tr>
<td style='-ms-word-break: break-all; word-break: break-all; font-family: sans-serif; font-size: 11px; line-height:14px;'>
<font style="-ms-word-break: break-all; word-break: break-all; font-size: 11px; line-height:14px;">
<a style='-ms-word-break: break-all; word-break: break-all; color: #392F54; text-decoration: underline; font-size: 11px; line-height:15px;' href='%3%'>%3%</a>
</font>
</td>
</tr>
</table>
</p>
</td>
</tr>
</table>
</td>
</tr>
</table>
<br><br><br>
</div>
</td>
<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'></td>
</tr>
</table>
</body>
</html>`,
    defaultInvitationMessage: "Ponovno slanje pozivnice...",
    deleteUser: "Obriši korisnika",
    deleteUserConfirmation: "Jeste li sigurni da želite obrisati ovaj korisnički račun?",
    stateAll: "Sve",
    stateActive: "Aktivan",
    stateDisabled: "Onemogućen",
    stateLockedOut: "Zaključan",
    stateApproved: "Odobren",
    stateInvited: "Pozvan",
    stateInactive: "Neaktivan",
    sortNameAscending: "Naziv (A-Z)",
    sortNameDescending: "Naziv (Z-A)",
    sortCreateDateAscending: "Najstarije",
    sortCreateDateDescending: "Najnovije",
    sortLastLoginDateDescending: "Zadnja prijava",
    noUserGroupsAdded: "Nijedna korisnička grupa nije dodana",
    "2faDisableText": "Ako želite onemogućiti ovaj dvofaktorski provajder, onda morate unjeti kod prikazan na vašem uređaju za autentifikaciju:",
    "2faProviderIsEnabled": "Ovaj dvofaktorski provajder je omogućen",
    "2faProviderIsDisabledMsg": "Ovaj dvofaktorski provajder je sada onemogućen",
    "2faProviderIsNotDisabledMsg": "Nešto je pošlo po zlu s pokušajem da se onemogući ovaj dvofaktorski provajder",
    "2faDisableForUser": "Želite li onemogućiti ovaj dvofaktorski provajder za ovog korisnika?"
  },
  validation: {
    validation: "Validacija",
    noValidation: "Nema validacije",
    validateAsEmail: "Potvrdi kao adresu e-pošte",
    validateAsNumber: "Potvrdite kao broj",
    validateAsUrl: "Potvrdi kao URL",
    enterCustomValidation: "...ili unesite prilagođenu validaciju",
    fieldIsMandatory: "Polje je obavezno",
    mandatoryMessage: "Upišite prilagođenu poruku o grešci validacije (opcionalno)",
    validationRegExp: "Upišite regularni izraz",
    validationRegExpMessage: "Upišite prilagođenu poruku o grešci validacije (opcionalno)",
    minCount: "Morate dodati najmanje",
    maxCount: "možete jedino imati",
    addUpTo: "Dodajte do",
    items: "stavke",
    urls: "URL-ovi",
    urlsSelected: "Odabrani URL-ovi",
    itemsSelected: "odabrane stavke",
    invalidDate: "Nevažeći datum",
    invalidNumber: "Nije broj",
    invalidNumberStepSize: "Nije važeća brojčana veličina koraka",
    invalidEmail: "Nevažeći email",
    invalidNull: "Vrijednost ne može biti null",
    invalidEmpty: "Vrijednost ne može biti prazna",
    invalidPattern: "Vrijednost je nevažeća, ne odgovara ispravnom uzorku",
    customValidation: "Prilagođena validacija",
    entriesShort: "Minimalno %0% unosa, potrebno <strong>%1%</strong> više.",
    entriesExceed: "Maksimalno %0% unosa, <strong>%1%</strong> previše.",
    entriesAreasMismatch: "Zahtjevi za količinu sadržaja nisu ispunjeni za jedno ili više područja."
  },
  healthcheck: {
    checkSuccessMessage: "Vrijednost je postavljena na preporučenu vrijednost: '%0%'.",
    checkErrorMessageDifferentExpectedValue: "Očekivana vrijednost '%1%' za '%2%' u konfiguracijskoj datoteci '%3%', ali je pronađeno '%0%'.",
    checkErrorMessageUnexpectedValue: `Pronađena neočekivana vrijednost '%0%' za '%2%' u konfiguracijskoj datoteci '%3%'.
    `,
    macroErrorModeCheckSuccessMessage: "Makro greške su postavljene na '%0%'.",
    macroErrorModeCheckErrorMessage: `Greške makroa su postavljene na '%0%' što će spriječiti potpuno učitavanje nekih ili svih stranica
	  na vašem sajtu ako postoje greške u makroima. Ako ovo ispravite, vrijednost će biti postavljena na '%1%'.
    `,
    httpsCheckValidCertificate: "Certifikat Vaše web stranice je važeći.",
    httpsCheckInvalidCertificate: "Greška u validaciji certifikata: '%0%'",
    httpsCheckExpiredCertificate: "SSL certifikat vaše web stranice je istekao.",
    httpsCheckExpiringCertificate: "SSL certifikat vaše web stranice istjeće za %0% dana.",
    healthCheckInvalidUrl: "Greška pri pinganju URL-a %0% - '%1%'",
    httpsCheckIsCurrentSchemeHttps: "Trenutno %0% pregledavate stranicu koristeći HTTPS protokol.",
    httpsCheckConfigurationRectifyNotPossible: `AppSetting 'Umbraco:CMS:Global:UseHttps' je postavljen na 'false' u
      vašoj appSettings.json datoteci. Jednom kada pristupite ovoj stranici koristeći HTTPS protokol, to bi trebalo biti postavljeno na 'true'.
    `,
    httpsCheckConfigurationCheckResult: `Postavka aplikacije 'Umbraco:CMS:Global:UseHttps' je postavljena na '%0%' u vašoj
      appSettings.json datoteci, vaši kolačići su %1% označeni kao sigurni.
    `,
    compilationDebugCheckSuccessMessage: "Način kompilacije otklanjanja grešaka je onemogućen.",
    compilationDebugCheckErrorMessage: `Način kompilacije za otklanjanje grešaka je trenutno omogućen. Preporučuje se da se
      onemogućite ovu postavku prije korištenja u produkciji.
    `,
    umbracoApplicationUrlCheckResultTrue: "AppSetting 'Umbraco:CMS:WebRouting:UmbracoApplicationUrl' je postavljen na <strong>%0%</strong>.",
    umbracoApplicationUrlCheckResultFalse: "AppSetting 'Umbraco:CMS:WebRouting:UmbracoApplicationUrl' nije postavljen.",
    clickJackingCheckHeaderFound: "Zaglavlje ili meta-tag <strong>X-Frame-Options</strong> koji se koristi za kontrolu da li neko mjesto može biti IFRAMED od strane drugog je pronađen.",
    clickJackingCheckHeaderNotFound: "Zaglavlje ili meta-tag <strong>X-Frame-Options</strong> koji se koristi za kontrolu da li neko mjesto može biti IFRAMED od strane drugog nije pronađen.",
    noSniffCheckHeaderFound: "Zaglavlje ili meta-tag <strong>X-Content-Type-Options</strong> koji se koristi za zaštitu od ranjivosti MIME sniffinga je pronađen.",
    noSniffCheckHeaderNotFound: "Zaglavlje ili meta-tag <strong>X-Content-Type-Options</strong> koji se koristi za zaštitu od ranjivosti MIME sniffinga nije pronađen.",
    hSTSCheckHeaderFound: "Zaglavlje <strong>Strict-Transport-Security</strong>, također poznat kao HSTS-header, je pronađen.",
    hSTSCheckHeaderNotFound: "Zaglavlje <strong>Strict-Transport-Security</strong> nije pronađeno.",
    hSTSCheckHeaderFoundOnLocalhost: "Zaglavlje <strong>Strict-Transport-Security</strong>, također poznat kao HSTS-header, je pronađen. <strong>Ovo zaglavlje ne bi trebalo biti prisutno na lokalnom hostu.</strong>",
    hSTSCheckHeaderNotFoundOnLocalhost: "Zaglavlje <strong>Strict-Transport-Security</strong> nije pronađeno. Ovo zaglavlje ne bi trebalo biti prisutno na lokalnom hostu.",
    xssProtectionCheckHeaderFound: "Zaglavlje <strong>X-XSS-Protection</strong> je pronađeno.",
    xssProtectionCheckHeaderNotFound: "Zaglavlje <strong>X-XSS-Protection</strong> nije pronađeno.",
    excessiveHeadersFound: "Pronađena su sljedeća zaglavlja koja otkrivaju informacije o tehnologiji web stranice: <strong>%0%</strong>.",
    excessiveHeadersNotFound: `Nisu pronađena zaglavlja koja otkrivaju informacije o tehnologiji web stranice.
    `,
    smtpMailSettingsNotFound: "U datoteci Web.config, system.net/mailsettings nije moguće pronaći.",
    smtpMailSettingsHostNotConfigured: `U datoteci Web.config, system.net/mailsettings, host
      nije konfiguriran.
    `,
    smtpMailSettingsConnectionSuccess: `SMTP postavke su ispravno konfigurirane i usluga radi
      kao što je očekivano.
    `,
    smtpMailSettingsConnectionFail: `SMTP server konfiguriran sa hostom '%0%' i portom '%1%' ne može biti
      dohvaćen. Provjerite jesu li SMTP postavke u datoteci Web.config, system.net/mailsettings ispravne.
    `,
    notificationEmailsCheckSuccessMessage: "E-mail za obavještenje je postavljen na <strong>%0%</strong>.",
    notificationEmailsCheckErrorMessage: "E-pošta za obavještenje je i dalje postavljena na zadanu vrijednost od <strong>%0%</strong>.",
    checkGroup: "Provjerite grupu",
    helpText: `
        <p>Provjera zdravlja procjenjuje različita područja vaše web lokacije u pogledu postavki najboljih praksi, konfiguracija, potencijalnih problema itd. Možete jednostavno riješiti probleme pritiskom na gumb.
        Možete dodati svoje zdravstvene preglede, pogledajte <a href="https://docs.umbraco.com/umbraco-cms/extending/health-check" target="_blank" rel="noopener" class="btn-link -underline">dokumentaciju za više informacija</a> o prilagođenim zdravstvenim pregledima.</p>
        `
  },
  redirectUrls: {
    disableUrlTracker: "Onemogući URL praćenje",
    enableUrlTracker: "Omogući URL praćenje",
    originalUrl: "Originalni URL",
    redirectedTo: "Preusmjerno na",
    redirectUrlManagement: "Preusmjeravanje URL-ova",
    panelInformation: "Sljedeći URL-ovi preusmjeravaju na ovu stavku sadržaja:",
    noRedirects: "Nisu napravljena nikakva preusmjeravanja",
    noRedirectsDescription: `Kada se objavljena stranica preimenuje ili premjesti, preusmjeravanje će automatski biti
       napravljeno na novu stranicu.
    `,
    redirectRemoved: "Preusmjeravanje uklonjeno.",
    redirectRemoveError: "Greška pri uklanjanju preusmjeravanja.",
    redirectRemoveWarning: "Ovo će ukloniti preusmjeravanje",
    confirmDisable: "Jeste li sigurni da želite onemogućiti praćenje URL-ovač?",
    disabledConfirm: "URL praćenje je sada onemogućeno.",
    disableError: "Greška pri onemogućavanju praćenja URL-ova, više informacija možete pronaći u vašem log zapisu.",
    enabledConfirm: "URL praćenje je sada omogućeno.",
    enableError: "Greška pri omogućavanju praćenja URL-ova, više informacija možete pronaći u vašem log zapisu."
  },
  emptyStates: {
    emptyDictionaryTree: "Nema stavki iz rječnika za odabir"
  },
  textbox: {
    characters_left: "<strong>%0%</strong> preostalo znakova.",
    characters_exceed: "Maksimalno %0% znakova, <strong>%1%</strong> previše."
  },
  recycleBin: {
    contentTrashed: "Sadržaj u otpadu s ID-om: {0} povezan je s originalnim nadređenim sadržajem s ID-om: {1}",
    mediaTrashed: "Medij u otpadu s ID-om: {0} povezan je s originalnim nadređenim medijem s ID-om: {1}",
    itemCannotBeRestored: "Nije moguće automatski vratiti ovu stavku",
    itemCannotBeRestoredHelpText: `Ne postoji lokacija na kojoj se ova stavka može automatski vratiti. Možete ručno premjestiti stavku koristeći stablo ispod.
    `,
    wasRestored: "je restauriran pod"
  },
  relationType: {
    direction: "Smjer",
    parentToChild: "Roditelj djetetu",
    bidirectional: "Bidirectional",
    parent: "Roditelj",
    child: "Dijete",
    count: "Broj",
    relation: "Relacija",
    relations: "Relacije",
    created: "Kreirano",
    comment: "Komentar",
    name: "Naziv",
    noRelations: "Nema relacija za ovu vrstu odnosa",
    tabRelationType: "Vrsta relacije",
    tabRelations: "Relacije",
    isDependency: "Je zavisan",
    dependency: "Da",
    noDependency: "Ne"
  },
  dashboardTabs: {
    contentIntro: "Početak rada",
    contentRedirectManager: "Preusmjeravanje URL-ova",
    mediaFolderBrowser: "Sadržaj",
    settingsWelcome: "Dobrodošli",
    settingsExamine: "Examine menadžment",
    settingsPublishedStatus: "Status stranice",
    settingsModelsBuilder: "Generator modela",
    settingsHealthCheck: "Provjera zdravlja",
    settingsAnalytics: "Podaci telemetrije",
    settingsProfiler: "Profiliranje",
    memberIntro: "Početak rada",
    formsInstall: "Instaliraj Umbraco Forms"
  },
  visuallyHiddenTexts: {
    goBack: "Vrati se",
    activeListLayout: "Aktivan raspored:",
    jumpTo: "Skoči na",
    group: "grupa",
    passed: "prošao",
    warning: "upozorenje",
    failed: "neuspješno",
    suggestion: "prijedlog",
    checkPassed: "Provjera prošla",
    checkFailed: "Provjera nije uspjela",
    openBackofficeSearch: "Otvorite backoffice pretragu",
    openCloseBackofficeHelp: "Otvori/Zatvori pomoć za backoffice",
    openCloseBackofficeProfileOptions: "Opcije otvaranja/zatvaranja profila",
    assignDomainDescription: "Postavite kulturu i imena hostova za %0%",
    createDescription: "Kreirajte novi čvor ispod %0%",
    protectDescription: "Postavite ograničenja pristupa uključena %0%",
    rightsDescription: "Dozvole za postavljanje su uključene %0%",
    sortDescription: "Promijenite redoslijed sortiranja za %0%",
    createblueprintDescription: "Kreirajte predložak sadržaja na osnovu %0%",
    openContextMenu: "Otvorite kontekstni meni za",
    currentLanguage: "Trenutni jezik",
    switchLanguage: "Prebaci jezik na",
    createNewFolder: "Kreirajte novi folder",
    newPartialView: "Parcijalni prikaz",
    newPartialViewMacro: "Makro za pracijalni prikaz",
    newMember: "Član",
    newDataType: "Vrsta podatka",
    redirectDashboardSearchLabel: "Pretražite kontrolnu ploču za preusmjeravanje",
    userGroupSearchLabel: "Pretražite odjeljak korisničke grupe",
    userSearchLabel: "Pretražite odjeljak korisnika",
    createItem: "Kreiraj stavku",
    create: "Kreiraj",
    edit: "Uredi",
    name: "Naziv",
    addNewRow: "Dodaj novi red",
    tabExpand: "Pogledajte više opcija",
    searchOverlayTitle: "Pogledajte više opcija",
    searchOverlayDescription: "Potražite čvorove sadržaja, medijske čvorove itd. u backofficeu.",
    searchInputDescription: `Kada su dostupni rezultati autodovršavanja, pritisnite strelice gore i dolje ili koristite
      tipku tab i koristite tipku enter za odabir.
    `,
    path: "Putanja:",
    foundIn: "Pronađeno u",
    hasTranslation: "Ima prijevod",
    noTranslation: "Nedostaje prijevod",
    dictionaryListCaption: "Stavke iz rječnika",
    contextMenuDescription: "Odaberite jednu od opcija za uređivanje čvora.",
    contextDialogDescription: "Izvršite akciju %0% na čvoru %1%.",
    addImageCaption: "Dodajte opis slike",
    searchContentTree: "Pretraži stablo sadržaja",
    maxAmount: "Maksimalni iznos"
  },
  references: {
    tabName: "Reference",
    DataTypeNoReferences: "Ova vrsta podataka nema reference.",
    itemHasNoReferences: "Ova stavka nema reference.",
    labelUsedByDocumentTypes: "Koristi se u vrstama dokumenata",
    labelUsedByMediaTypes: "Koristi se u vrstama medija",
    labelUsedByMemberTypes: "Koristi se u vrstama članova",
    usedByProperties: "Koristi",
    labelUsedItems: "Stavke u upotrebi",
    labelUsedDescendants: "Potomci u upotrebi",
    deleteWarning: "Ova stavka ili njeni potomci se koriste. Brisanje može dovesti do neispravnih veza na vašoj web stranici.",
    unpublishWarning: "Ova stavka ili njeni potomci se koriste. Poništavanje objavljivanja može dovesti do neispravnih veza na vašoj web stranici. Molimo poduzmite odgovarajuće radnje.",
    deleteDisabledWarning: "Ova stavka ili njeni potomci se koriste. Stoga je brisanje onemogućeno.",
    listViewDialogWarning: "Sljedeće stavke koje pokušavate %0% koriste drugi sadržaj."
  },
  logViewer: {
    deleteSavedSearch: "Obriši spremljene pretrage",
    logLevels: "Razine loga",
    selectAllLogLevelFilters: "Označi sve",
    deselectAllLogLevelFilters: "Odznači sve",
    savedSearches: "Spremljene pretrage",
    saveSearch: "Spremi pretragu",
    saveSearchDescription: "Unesite prijateljski naziv za vaš upit za pretragu",
    filterSearch: "Filtriraj pretragu",
    totalItems: "Ukupno",
    timestamp: "Vrijeme",
    level: "Razina",
    machine: "Uređaj",
    message: "Poruka",
    exception: "Izuzetak",
    properties: "Svojstva",
    searchWithGoogle: "Pretraži pomoću Google-a",
    searchThisMessageWithGoogle: "Pretraži ovu poruku pomoću Google-a",
    searchWithBing: "Pretraži pomoću Bing-a",
    searchThisMessageWithBing: "Pretraži ovu poruku pomoću Bing-a",
    searchOurUmbraco: "Pretraži Our Umbraco",
    searchThisMessageOnOurUmbracoForumsAndDocs: "Pretraži ovu poruku na Our Umbraco forumu i dokumentaciji",
    searchOurUmbracoWithGoogle: "Pretraži Our Umbraco pomoću Google-a",
    searchOurUmbracoForumsUsingGoogle: "Pretraži Our Umbraco forume pomoću Google-a",
    searchUmbracoSource: "Pretraži Umbraco Source",
    searchWithinUmbracoSourceCodeOnGithub: "Pretraži Umbraco source code on Github-u",
    searchUmbracoIssues: "Pretraži Umbraco Issues",
    searchUmbracoIssuesOnGithub: "Pretraži Umbraco Issues na Github-u",
    deleteThisSearch: "Obriši ovu pretragu",
    findLogsWithRequestId: "Pronađi logove sa ID-om zatjeva",
    findLogsWithNamespace: "Pronađi logove sa namespace-om",
    findLogsWithMachineName: "Pronađi logove sa nazivom uređaja",
    open: "Otvori",
    polling: "Provjera",
    every2: "Svakih 2 sekunde",
    every5: "Svakih 5 sekundi",
    every10: "Svakih 10 sekundi",
    every20: "Svakih 20 sekundi",
    every30: "Svakih 30 sekundi",
    pollingEvery2: "Provjera svakih 2s",
    pollingEvery5: "Provjera svakih 5s",
    pollingEvery10: "Provjera svakih 10s",
    pollingEvery20: "Provjera svakih 20s",
    pollingEvery30: "Provjera svakih 30s"
  },
  clipboard: {
    labelForCopyAllEntries: "Kopiraj %0%",
    labelForArrayOfItemsFrom: "%0% od %1%",
    labelForArrayOfItems: "Zbirka od %0%",
    labelForRemoveAllEntries: "Uklonite sve stavke",
    labelForClearClipboard: "Očisti međuspremnik"
  },
  propertyActions: {
    tooltipForPropertyActionsMenu: "Otvorite radnje svojstva",
    tooltipForPropertyActionsMenuClose: "Zatvorite Property Actions"
  },
  nuCache: {
    refreshStatus: "Osvježi status",
    memoryCache: "Predmemorija",
    memoryCacheDescription: `
            Ovaj gumb vam omogućuje da obnovite predmemoriju tako što ćete je u potpunosti ponovo učitati iz baze podataka
    (ali ne obnavlja predmemoriju baze podataka). Ovo je relativno brzo.
    Koristite ga kada mislite da predmemorija nije pravilno osvježena, nakon nekih događaja
    pokrenuo&mdash;što bi ukazivalo na manji problem sa Umbracom.
    (Napomena: pokreće ponovno učitavanje na svim serverima u LB okruženju).
    `,
    reload: "Ponovo učitaj",
    databaseCache: "Predmemorija baze podataka",
    databaseCacheDescription: `
    Ovaj gumb vam omogućuje da ponovo obnovite predmemoriju baze podataka, tj. sadržaj tabele cmsContentNu.
    <strong>Obnova može biti skupa.</strong>
    Koristite ga kada ponovno učitavanje nije dovoljno, a mislite da predmemorija baze podataka nije bila
    pravilno generirana; što bi ukazivalo na neko kritično pitanje Umbraco.
    `,
    rebuild: "Ponovo obnovi",
    internals: "Unutrašnjost",
    internalsDescription: `
    Ovaj gumb vam omogućuje da pokrenete kolekciju NuCache snimaka (nakon pokretanja fullCLR GC-a).
    Osim ako ne znate šta to znači, vjerovatno ga <em>ne</em> morate koristiti.
    `,
    collect: "Skupiti",
    publishedCacheStatus: "Objavljeni status predmemorije",
    caches: "Predmemorije"
  },
  profiling: {
    performanceProfiling: "Profiliranje performansi",
    performanceProfilingDescription: `
            <p>
               Umbraco trenutno radi u načinu za otklanjanje grešaka. To znači da možete koristiti ugrađeni profiler performansi za procjenu performansi prilikom renderiranja stranica.
            </p>
            <p>
                Ako želite aktivirati profiler za određeno prikazivanje stranice, jednostavno dodajte <strong>umbDebug=true</strong> na string upita kada tražite stranicu.
            </p>
            <p>
                Ako želite da se profilator aktivira prema zadanim postavkama za sve prikaze stranica, možete koristiti prekidač ispod.
                On će postaviti kolačić u vaš pretraživač, koji zatim automatski aktivira profiler.
                Drugim riječima, profiler će biti aktivan samo po defaultu u <em>vašen</em> pretraživaču.
            </p>
    `,
    activateByDefault: "Zadano aktivirajte profiler",
    reminder: "Prijateljski podsjetnik",
    reminderDescription: `
        <p>
            Nikada ne bi trebali dozvoliti da produkcijska lokacija radi u načinu za otklanjanje grešaka. Režim za otklanjanje grešaka se isključuje podešavanjem <strong>Umbraco:CMS:Hosting:Debug</strong> na <strong>false</strong> u appsettings.json, appsettings.{Environment}.json ili preko varijable okruženja.
        </p>
    `,
    profilerEnabledDescription: `
        <p>
            Umbraco trenutno ne radi u načinu za otklanjanje grešaka, tako da ne možete koristiti ugrađeni profiler. Ovako bi trebalo da bude za proizvodnu lokaciju.
        </p>
        <p>
            Režim za otklanjanje grešaka se uključuje podešavanjem <strong>Umbraco:CMS:Hosting:Debug</strong> na <strong>true</strong> u appsettings.json, appsettings.{Environment}.json ili preko varijable okruženja.
        </p>
    `
  },
  settingsDashboardVideos: {
    trainingHeadline: "Sati Umbraco trening videa udaljeni su samo jedan klik",
    trainingDescription: `
            <p>Želite naučiti Umbraco? Provedite nekoliko minuta učeći najbolje prakse gledajući jedan od ovih videozapisa o korištenju Umbraco-a. I posjetite <a href="https://umbraco.tv" target="_blank" rel="noopener">umbraco.tv</a> za još više Umbraco videa</p>
        `,
    learningBaseDescription: `
        <p>Želite savladati Umbraco? Provedite nekoliko minuta učeći najbolje prakse gledajući jedan od ovih videozapisa o korištenju Umbraco-a <a class="btn-link -underline" href="https://www.youtube.com/c/UmbracoLearningBase" target="_blank" rel="noopener"> Umbraco Learning Base Youtube kanal</a>. Ovdje možete pronaći gomilu video materijala koji pokriva mnoge aspekte Umbraco-a.</p>
      `,
    getStarted: "Za početak"
  },
  settingsDashboard: {
    start: "Krenite ovdje",
    startDescription: `Ovaj odjeljak sadrži blokove za izgradnju vaše Umbraco stranice. Slijedite dolje
      navedene veze linkova kako biste saznali više o radu sa stavkama u odjeljku Postavke
    `,
    more: "Saznajte više",
    bulletPointOne: `
        Pročitajte više o radu sa stavkama u Postavkama <a class="btn-link -underline" href="https://docs.umbraco.com/umbraco-cms/fundamentals/backoffice/sections/" target="_blank" rel="noopener">u odjeljku Dokumentacija</a> na Our Umbraco
    `,
    bulletPointTwo: `
        Postavite pitanje na <a class="btn-link -underline" href="https://our.umbraco.com/forum" target="_blank" rel="noopener">Forumu zajednice</a>
    `,
    bulletPointTutorials: `
        Gledajte besplatno <a class="btn-link -underline" href="https://umbra.co/ulb" target="_blank" rel="noopener">video tutorijale na Umbraco Learning Base</a>
    `,
    bulletPointFour: `
        Saznajte više o našim <a class="btn-link -underline" href="https://umbraco.com/products/" target="_blank" rel="noopener">alatima za povećanje produktivnosti i komercijalna podrška</a>
    `,
    bulletPointFive: `
        Saznajte nešto o mogućnosti stvarne <a class="btn-link -underline" href="https://umbraco.com/training/" target="_blank" rel="noopener">obuke i certifikacije</a>
    `
  },
  startupDashboard: {
    fallbackHeadline: "Dobrodošli u The Friendly CMS",
    fallbackDescription: `Hvala vam što ste odabrali Umbraco - mislimo da bi ovo mogao biti početak nečeg divnog. Iako se u početku može činiti neodoljivim, učinili smo puno da učenje bude što lakše i brže što je moguće više.
    `
  },
  formsDashboard: {
    formsHeadline: "Umbraco Forms",
    formsDescription: `Kreirajte obrasce pomoću intuitivnog 'drag and drop' sučelja. Od jednostavnih kontakt obrazaca
       koji šalje e-mailove do naprednih obrazaca koji se mogu integrirati sa CRM sustavima. Vašim klijentima će se svidjeti!
    `
  },
  blockEditor: {
    headlineCreateBlock: "Odaberite vrstu elementa",
    headlineAddSettingsElementType: "Priložite postavke na vrstu elementa",
    headlineAddCustomView: "Odaberite prikaz",
    headlineAddCustomStylesheet: "Odaberite stil",
    headlineAddThumbnail: "Odaberite sličicu",
    labelcreateNewElementType: "Kreirajte novu vrstu elementa",
    labelCustomStylesheet: "Prilagođeni stil",
    addCustomStylesheet: "Dodaj stil",
    headlineEditorAppearance: "Izgled bloka",
    headlineDataModels: "Modeli podataka",
    headlineCatalogueAppearance: "Izgled kataloga",
    labelBackgroundColor: "Boja pozadine",
    labelIconColor: "Boja ikone",
    labelContentElementType: "Model sadržaja",
    labelLabelTemplate: "Oznaka",
    labelCustomView: "Prilagođeni prikaz",
    labelCustomViewInfoTitle: "Prikaži opis prilagođenog prikaza",
    labelCustomViewDescription: `Zamjenite način na koji se ovaj blok pojavljuje u korisničkom sučelju backofficea. Odaberite .html datoteku
      koja sadrži vaš dizajn.
    `,
    labelSettingsElementType: "Model postavki",
    labelEditorSize: "Veličina uređivača preklapanja",
    addCustomView: "Dodaj prilagođeni prikaz",
    addSettingsElementType: "Dodaj postavke",
    confirmDeleteBlockMessage: "Jeste li sigurni da želite obrisati sadržaj <strong>%0%</strong>?",
    confirmDeleteBlockTypeMessage: "Jeste li sigurni da želite obrisati konfiguraciju bloka <strong>%0%</strong>?",
    confirmDeleteBlockTypeNotice: `Sadržaj ovog bloka bit će i dalje prisutan, uređivanje ovog sadržaja
      više neće biti dostupno i bit će prikazan kao nepodržani sadržaj.
    `,
    confirmDeleteBlockGroupMessage: "Jeste li sigurni da želite obrisati grupu <strong>%0%</strong> i sve konfiguracije ovog bloka?",
    confirmDeleteBlockGroupNotice: `Sadržaj ovih blokova će i dalje biti prisutan, uređivanje ovog sadržaja
      više neće biti dostupan i bit će prikazan kao nepodržani sadržaj.
    `,
    blockConfigurationOverlayTitle: "Konfiguracija od '%0%'",
    elementTypeDoesNotExist: "Ne može se uređivati jer vrsta elementa ne postoji.",
    thumbnail: "Sličica",
    addThumbnail: "Dodaj sličicu",
    tabCreateEmpty: "Kreiraj prazno",
    tabClipboard: "Međuspremnik",
    tabBlockSettings: "Postavke",
    headlineAdvanced: "Napredno",
    forceHideContentEditor: "Sakrij uređivač sadržaja",
    forceHideContentEditorHelp: "Sakrij gumb za uređivanje sadržaja i uređivač sadržaja iz preklapanja Block Editor.",
    gridInlineEditing: "Inline uređivanje",
    gridInlineEditingHelp: "Omogućava inline uređivanje za prvo svojstvo. Dodatna svojstva se mogu uređivati u prekrivaču.",
    blockHasChanges: "Izmijenili ste ovaj sadržaj. Jeste li sigurni da ih želite odbaciti?",
    confirmCancelBlockCreationHeadline: "Odbaciti kreiranje?",
    confirmCancelBlockCreationMessage: "Jeste li sigurni da želite otkazati kreiranje.",
    elementTypeDoesNotExistHeadline: "Greška!",
    elementTypeDoesNotExistDescription: "Vrsta elementa ovog bloka više ne postoji",
    addBlock: "Dodaj sadržaj",
    addThis: "Dodaj %0%",
    propertyEditorNotSupported: "Svojstvo '%0%' koristi uređivač '%1%' koji nije podržan u blokovima.",
    focusParentBlock: "Postavite fokus na blok kontejnera",
    areaIdentification: "Identifikacija",
    areaValidation: "Validacija",
    areaValidationEntriesShort: "<strong>%0%</strong> mora biti prisutan barem <strong>%2%</strong> puta.",
    areaValidationEntriesExceed: "<strong>%0%</strong> mora biti maksimalno prisutan <strong>%3%</strong> puta.",
    areaNumberOfBlocks: "Broj blokova",
    areaDisallowAllBlocks: "Dozvolite samo određene vrste blokova",
    areaAllowedBlocks: "Dozvoljene vrste blokova",
    areaAllowedBlocksHelp: "Definirajte vrste blokova koji su dozvoljeni u ovom području i opcionalo koliko svake vrste treba biti prisutno.",
    confirmDeleteBlockAreaMessage: "Jeste li sigurni da želite obrisati ovo područje?",
    confirmDeleteBlockAreaNotice: "Svi blokovi koji su trenutno kreirani unutar ovog područja bit će obrisani.",
    layoutOptions: "Opcije rasporeda",
    structuralOptions: "Strukturno",
    sizeOptions: "Opcije veličine",
    sizeOptionsHelp: "Definirajte jednu ili više opcija veličine, ovo omogućava promjenu veličine bloka",
    allowedBlockColumns: "Definirajte jednu ili više opcija veličine, ovo omogućava promjenu veličine bloka",
    allowedBlockColumnsHelp: "Definirajte različit broj kolona preko kojih ovaj blok može se protezati. Ovo ne sprječava postavljanje blokova u područja s manjim rasponom kolona.",
    allowedBlockRows: "Dostupni rasponi redova",
    allowedBlockRowsHelp: "Definirajte raspon redova rasporeda preko kojih se ovaj blok može protezati.",
    allowBlockInRoot: "Dozvolite u korijenu",
    allowBlockInRootHelp: "Učinite ovaj blok dostupnim u korijenu izgleda.",
    allowBlockInAreas: "Dozvolite u područjima",
    allowBlockInAreasHelp: "Učinite ovaj blok dostupnim prema zadanim postavkama unutar područja drugih blokova (osim ako za ova područja nisu postavljene eksplicitne dozvole).",
    areaAllowedBlocksEmpty: "Prema zadanim postavkama, sve vrste blokova su dozvoljeni u području. Koristite ovu opciju da dozvolite samo odabrane vrste.",
    areas: "Područja",
    areasLayoutColumns: "Mrežne kolone za područja",
    areasLayoutColumnsHelp: "Definirajte koliko će stupaca biti dostupno za područja. Ako nije definiran, koristit će se broj kolona definiranih za cijeli izgled.",
    areasConfigurations: "Područja",
    areasConfigurationsHelp: "Da biste omogućili ugniježđenje blokova unutar ovog bloka, definirajte jedno ili više područja. Područja slijede raspored definiran njihovom vlastitom konfiguracijom stupca mreže. 'Raspon kolone' i 'raspon reda' za svako područje može se podesiti korištenjem okvira za rukovanje skalom u donjem desnom uglu odabranog područja.",
    invalidDropPosition: "<strong>%0%</strong> nije dozvoljeno na ovom mjestu.",
    defaultLayoutStylesheet: "Zadani raspored stilova",
    confirmPasteDisallowedNestedBlockHeadline: "Nedozvoljeni sadržaj je odbijen",
    confirmPasteDisallowedNestedBlockMessage: "Umetnuti sadržaj sadržavao je nedozvoljeni sadržaj koji nije kreiran. Želite li ipak zadržati ostatak ovog sadržaja??",
    areaAliasHelp: `Kada koristite GetBlockGridHTML() za prikazivanje Block Grid-a, alias će biti prikazan u oznaci kao 'data-area-alias' atribut. Koristite atribut alias za ciljanje elementa za područje. Npr. .umb-block-grid__area[data-area-alias="MyAreaAlias"] { ... }`,
    scaleHandlerButtonTitle: "Povucite za povečanje",
    areaCreateLabelTitle: "Kreiraj oznaku gumba",
    areaCreateLabelHelp: "Nadjačajte tekst oznake za dodavanje novog bloka u ovo područje, primjer: 'Dodaj widget'",
    showSizeOptions: "Prikaži opcije promjene veličine",
    addBlockType: "Dodaj blok",
    addBlockGroup: "Dodaj grupu",
    pickSpecificAllowance: "Odaberi grupu ili blok",
    allowanceMinimum: "Postavite minimalni zahtjev",
    allowanceMaximum: "Postavite maksimalan zahtjev",
    block: "Blok",
    tabBlock: "Blok",
    tabBlockTypeSettings: "Postavke",
    tabAreas: "Područja",
    tabAdvanced: "Napredno",
    headlineAllowance: "Dozvole",
    getSampleHeadline: "Instalirajte uzorak konfiguracije",
    getSampleDescription: "Ovo će dodati osnovne blokove i pomoći vam da započnete s Block Grid Editorom. Dobit ćete blokove za naslov, obogaćeni tekst, sliku, kao i raspored u dvije kolone.",
    getSampleButton: "Instaliraj",
    actionEnterSortMode: "Način sortiranja",
    actionExitSortMode: "Završi način sortiranja",
    areaAliasIsNotUnique: "Ovaj alias područja mora biti jedinstven u usporedbi sa drugim područjima ovog bloka.",
    configureArea: "Konfiguriraj područje",
    deleteArea: "Obriši područje",
    addColumnSpanOption: "Dodajte opciju raspona %0% kolona"
  },
  contentTemplatesDashboard: {
    whatHeadline: "Što su predlošci sadržaja?",
    whatDescription: `Predlošci sadržaja su unaprijed definirani sadržaj koji se može odabrati prilikom kreiranja novog
      čvora sadržaja.
    `,
    createHeadline: "Kako kreirati predložak sadržaja?",
    createDescription: `
            <p>Postoje dva načina za kreiranje predloška sadržaja:</p>
            <ul>
                <li>Desnom tipkom miša kliknite čvor sadržaja i odaberite "Kreiraj predložak sadržaja" da bi kreirali novi predložak sadržaja.</li>
                <li>Kliknite desnom tipkom miša na stablo predložaka sadržaja u odjeljku Postavke i odaberite vrstu dokumenta za koju želite kreirati predložak sadržaja.</li>
            </ul>
            <p>Nakon što upišete ime, urednici mogu početi koristiti predložak sadržaja kao osnovu za svoju novu stranicu.</p>
        `,
    manageHeadline: "Kako upravljati predlošcima sadržaja?",
    manageDescription: `Možete uređivati i brisati predloške sadržaja iz stabla "Predlošci sadržaja" u
      sekciji postavke. Proširite vrstu dokumenta na kojoj se temelji predložak sadržaja i kliknite na nju da biste uredili ili obrisali.
    `
  },
  preview: {
    endLabel: "Kraj",
    endTitle: "Završi način pregleda",
    openWebsiteLabel: "Pregledajte web stranicu",
    openWebsiteTitle: "Otvorite web stranicu u načinu pregleda",
    returnToPreviewHeadline: "Pregledajte web stranicu?",
    returnToPreviewDescription: `Završili ste način pregleda, želite li ga ponovo omogućiti da vidite
      najnovije spremljene verzije vaše web stranice?
    `,
    returnToPreviewAcceptButton: "Pregledajte najnoviju verziju",
    returnToPreviewDeclineButton: "Pogledajte objavljenu verziju",
    viewPublishedContentHeadline: "Pogledajte objavljenu verziju?",
    viewPublishedContentDescription: `Nalazite se u načinu pregleda, želite li izaći da biste vidjeli
      objavljenu verziju Vaše web stranice?
    `,
    viewPublishedContentAcceptButton: "Pogledajte objavljenu verziju",
    viewPublishedContentDeclineButton: "Ostanite u načinu pregleda"
  },
  permissions: {
    FolderCreation: "Kreiranje mape",
    FileWritingForPackages: "Pisanje datoteka za pakete",
    FileWriting: "Pisanje datoteka",
    MediaFolderCreation: "Kreiranje medijskog foldera"
  },
  treeSearch: {
    searchResult: "stavka vraćena",
    searchResults: "stavke vraćene"
  },
  analytics: {
    consentForAnalytics: "Suglasnost za prikupljanje telemetrijskih podataka",
    analyticsLevelSavedSuccess: "Telemetrijska razina spremljena!",
    analyticsDescription: `
      Kako bismo unaprijedili Umbraco i dodali nove funkcionalnosti na temelju relevantnih informacija,
          <br>želimo prikupljati podatke o sustavu i uporabi iz vaše instalacije.
          <br>Zbirni podaci bit će redovito dijeljeni, kao i saznanja dobivena iz tih metrika.
          <br>Nadamo se da ćete nam pomoći prikupiti neke vrijedne podatke.
          <br>
          <br>NEĆEMO prikupljati osobne podatke poput sadržaja, koda, informacija o korisnicima, a svi podaci bit će potpuno anonimni.
       `,
    minimalLevelDescription: "Poslat ćemo samo anonimni ID web-mjesta kako bismo znali da web-mjesto postoji.",
    basicLevelDescription: "Poslat ćemo anonimni ID web-mjesta, verziju Umbraco-a i instalirane pakete.",
    detailedLevelDescription: `
          Poslat ćemo:
          <ul>
            <li>Anonimni ID web-mjesta, verziju Umbraco-a i instalirane pakete.</li>
            <li>Broj: korijenskih čvorova, čvorova sadržaja, makroa, medija, vrsta dokumenata, predložaka, jezika, domena, korisničkih grupa, korisnika, članova, vanjskih pružatelja prijave u Backoffice-u i uređivača svojstava u upotrebi.</li>
            <li>Informacije o sustavu: web poslužitelj, operativni sustav poslužitelja, okvir poslužitelja, jezik operativnog sustava poslužitelja i pružatelj baze podataka.</li>
            <li>Postavke konfiguracije: način Modelsbuilder-a, postoji li prilagođena putanja Umbraco-a, ASP okolina, je li omogućen dostavni API, dopušta li javni pristup i je li u načinu rada za otklanjanje pogrešaka.</li>
          </ul>
          <em>Moguće je da ćemo u budućnosti promijeniti podatke koje šaljemo na Detaljnoj razini. Ako se to dogodi, bit će navedeno iznad.
          <br>Odabirom "Detaljno" pristajete na prikupljanje trenutnih i budućih anonimiziranih informacija.</em>
       `
  }
};
export {
  e as default
};
//# sourceMappingURL=hr-hr-CoB8TWw4.js.map
