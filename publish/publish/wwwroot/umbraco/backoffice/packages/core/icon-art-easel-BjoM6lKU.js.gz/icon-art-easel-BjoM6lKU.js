const h = '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512"><path d="M371.482 115.717H140.518v149.762h230.965zM270.553 49.373h-29.105v54.502h29.105zm128.449 232.268H112.998v37.012h56.242l-38.639 143.975h30.137l38.639-143.975h113.246l38.639 143.975h30.135l-38.639-143.975h56.244zM241.447 431.604h29.105v-96.793h-29.105z"/></svg>';
export {
  h as default
};
//# sourceMappingURL=icon-art-easel-BjoM6lKU.js.map
