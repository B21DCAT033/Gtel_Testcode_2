const h = '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512"><path d="M87.887 74.772v361.521h336.958V74.772zm306.318 330.879H118.544V105.399h275.661zM262.693 137.497H149.04v130.742h113.653zm104.942.521h-79.221v24.951h79.221zm0 107.328h-79.221v24.92h79.221zm0-53.661h-79.221v24.948h79.221zm-1.816 107.327H147.57v24.917h218.249zm0 53.662H147.57v24.887h218.249z"/></svg>';
export {
  h as default
};
//# sourceMappingURL=icon-article-CLvgWmnS.js.map
