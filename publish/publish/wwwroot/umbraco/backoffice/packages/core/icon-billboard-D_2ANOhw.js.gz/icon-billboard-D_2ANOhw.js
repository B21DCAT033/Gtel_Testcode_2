const v = '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512"><path d="M153.537 329.843v62.41h23.68v-62.41h159.498v62.41h23.68v-62.41h89.076V61.513H60.359v268.33zM88.773 89.928h332.283v211.501H88.773zm28.416 28.415H392.64v154.671H117.189zM49.523 421.381h412.953v29.106H49.523z"/></svg>';
export {
  v as default
};
//# sourceMappingURL=icon-billboard-D_2ANOhw.js.map
