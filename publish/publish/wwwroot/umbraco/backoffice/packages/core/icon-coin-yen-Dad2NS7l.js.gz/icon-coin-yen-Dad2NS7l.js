const e = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" class="lucide lucide-japanese-yen" viewBox="0 0 24 24"><path d="M12 9.5V21m0-11.5L6 3m6 6.5L18 3M6 15h12M6 11h12"/></svg>';
export {
  e as default
};
//# sourceMappingURL=icon-coin-yen-Dad2NS7l.js.map
