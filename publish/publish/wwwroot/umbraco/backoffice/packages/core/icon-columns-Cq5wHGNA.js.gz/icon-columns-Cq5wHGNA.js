const o = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" class="lucide lucide-tally-3" viewBox="0 0 24 24"><path d="M4 4v16M9 4v16M14 4v16"/></svg>';
export {
  o as default
};
//# sourceMappingURL=icon-columns-Cq5wHGNA.js.map
