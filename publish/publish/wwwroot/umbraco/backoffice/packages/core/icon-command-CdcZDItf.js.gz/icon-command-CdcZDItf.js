const o = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" class="lucide lucide-terminal" viewBox="0 0 24 24"><path d="m4 17 6-6-6-6M12 19h8"/></svg>';
export {
  o as default
};
//# sourceMappingURL=icon-command-CdcZDItf.js.map
