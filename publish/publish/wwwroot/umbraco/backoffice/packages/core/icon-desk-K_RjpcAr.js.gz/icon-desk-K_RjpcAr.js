const h = '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512"><path d="M459.543 154.424H53.519v52.357h30.82v150.721h24.938V206.781h296.274v150.721h24.955V206.781h29.037z"/></svg>';
export {
  h as default
};
//# sourceMappingURL=icon-desk-K_RjpcAr.js.map
