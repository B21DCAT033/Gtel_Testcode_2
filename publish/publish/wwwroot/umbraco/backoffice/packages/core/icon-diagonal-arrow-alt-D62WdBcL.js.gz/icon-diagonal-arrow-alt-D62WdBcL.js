const o = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" class="lucide lucide-move-diagonal" viewBox="0 0 24 24"><path d="M11 19H5v-6M13 5h6v6M19 5 5 19"/></svg>';
export {
  o as default
};
//# sourceMappingURL=icon-diagonal-arrow-alt-D62WdBcL.js.map
