const o = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" class="lucide lucide-monitor-down" viewBox="0 0 24 24"><path d="M12 13V7M15 10l-3 3-3-3"/><rect width="20" height="14" x="2" y="3" rx="2"/><path d="M12 17v4M8 21h8"/></svg>';
export {
  o as default
};
//# sourceMappingURL=icon-download-D4NdZBMM.js.map
