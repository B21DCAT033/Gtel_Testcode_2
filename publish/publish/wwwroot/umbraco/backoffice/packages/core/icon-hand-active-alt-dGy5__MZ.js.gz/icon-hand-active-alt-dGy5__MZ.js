const a = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" class="lucide lucide-grab" viewBox="0 0 24 24"><path d="M18 11.5V9a2 2 0 0 0-2-2 2 2 0 0 0-2 2v1.4M14 10V8a2 2 0 0 0-2-2 2 2 0 0 0-2 2v2M10 9.9V9a2 2 0 0 0-2-2 2 2 0 0 0-2 2v5M6 14a2 2 0 0 0-2-2 2 2 0 0 0-2 2"/><path d="M18 11a2 2 0 1 1 4 0v3a8 8 0 0 1-8 8h-4a8 8 0 0 1-8-8 2 2 0 1 1 4 0"/></svg>';
export {
  a as default
};
//# sourceMappingURL=icon-hand-active-alt-dGy5__MZ.js.map
