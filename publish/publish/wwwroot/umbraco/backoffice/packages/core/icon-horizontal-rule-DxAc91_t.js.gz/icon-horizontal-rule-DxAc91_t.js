const o = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" class="lucide lucide-separator-horizontal" viewBox="0 0 24 24"><path d="M3 12h18M8 8l4-4 4 4M16 16l-4 4-4-4"/></svg>';
export {
  o as default
};
//# sourceMappingURL=icon-horizontal-rule-DxAc91_t.js.map
