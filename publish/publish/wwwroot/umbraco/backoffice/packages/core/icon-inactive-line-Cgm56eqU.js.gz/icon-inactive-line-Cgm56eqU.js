const t = '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512"><path d="M447.028 468.9 42.031 63.902l21.762-21.763 405 405.002z"/></svg>';
export {
  t as default
};
//# sourceMappingURL=icon-inactive-line-Cgm56eqU.js.map
