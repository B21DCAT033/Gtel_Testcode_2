const o = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" class="lucide lucide-navigation" viewBox="0 0 24 24"><path d="m3 11 19-9-9 19-2-8z"/></svg>';
export {
  o as default
};
//# sourceMappingURL=icon-map-alt-whKpM2YV.js.map
