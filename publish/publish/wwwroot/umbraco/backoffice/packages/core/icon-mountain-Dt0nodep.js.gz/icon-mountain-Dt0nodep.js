const o = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" class="lucide lucide-mountain-snow" viewBox="0 0 24 24"><path d="m8 3 4 8 5-5 5 15H2z"/><path d="M4.14 15.08q3.93-2.355 7.86.42c2.74 1.94 5.49 2 8.23.19"/></svg>';
export {
  o as default
};
//# sourceMappingURL=icon-mountain-Dt0nodep.js.map
