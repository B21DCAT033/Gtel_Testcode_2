const l = '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512"><path d="M83.642 51.955h97.549l79.825 136.791 75.371-136.791h93.118L314.211 261.908l115.294 198.008h-93.118l-75.371-129.289-79.825 129.289H83.642l133.021-198.008z"/></svg>';
export {
  l as default
};
//# sourceMappingURL=icon-os-x-DDxLdUCm.js.map
