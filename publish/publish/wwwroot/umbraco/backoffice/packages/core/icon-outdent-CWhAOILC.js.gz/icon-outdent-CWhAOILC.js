const e = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" class="lucide lucide-indent-decrease" viewBox="0 0 24 24"><path d="M21 12H11M21 18H11M21 6H11M7 8l-4 4 4 4"/></svg>';
export {
  e as default
};
//# sourceMappingURL=icon-outdent-CWhAOILC.js.map
