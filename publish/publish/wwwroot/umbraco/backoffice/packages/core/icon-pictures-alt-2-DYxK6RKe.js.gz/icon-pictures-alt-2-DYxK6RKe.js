const t = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" class="lucide lucide-gallery-thumbnails" viewBox="0 0 24 24"><rect width="18" height="14" x="3" y="3" rx="2"/><path d="M4 21h1M9 21h1M14 21h1M19 21h1"/></svg>';
export {
  t as default
};
//# sourceMappingURL=icon-pictures-alt-2-DYxK6RKe.js.map
