const o = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" class="lucide lucide-play" viewBox="0 0 24 24"><path d="m6 3 14 9-14 9z"/></svg>';
export {
  o as default
};
//# sourceMappingURL=icon-play-DV1Wys0w.js.map
