const o = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" class="lucide lucide-list-music" viewBox="0 0 24 24"><path d="M21 15V6M18.5 18a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5M12 12H3M16 6H3M12 18H3"/></svg>';
export {
  o as default
};
//# sourceMappingURL=icon-playlist-DCpyKqSZ.js.map
