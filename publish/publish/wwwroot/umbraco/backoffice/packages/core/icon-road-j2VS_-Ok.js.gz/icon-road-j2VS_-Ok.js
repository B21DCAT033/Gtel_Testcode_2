const h = '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512"><path d="m261.312 78.641.949 23.021H250.57l.935-23.021h-82.771l-81.18 354.471h153.19v-32.264h31.328v32.264H425.25L344.082 78.641zm-12.015 54.775h14.221l1.097 27.012h-16.431zm-2.387 58.745h18.997l1.421 34.501h-21.826zm-2.683 66.243h24.361l1.508 36.998h-27.391zm-3.483 110.713V344.67l.688-17.528h29.939l.701 17.396v24.58z"/></svg>';
export {
  h as default
};
//# sourceMappingURL=icon-road-j2VS_-Ok.js.map
