const v = '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512"><path d="M395.869 91.516 73.502 245.323l111.799 44.392 248.553-118.588zm6.387 204.508v44.31h-57.147v-39.48l29.102-13.882-10.383-21.761 65.088-31.051-11.861-24.861-197.506 94.235 11.863 24.856 47.42-22.627 10.385 21.76 19.652-9.377v58.427h93.387v43.911h36.24v-124.46z"/></svg>';
export {
  v as default
};
//# sourceMappingURL=icon-security-camera-Bl4kAKa1.js.map
