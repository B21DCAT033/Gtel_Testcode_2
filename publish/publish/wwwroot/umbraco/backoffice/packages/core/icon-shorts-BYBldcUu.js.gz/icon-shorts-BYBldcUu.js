const o = '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512"><path d="m221.72 421.579 34.662-201.949 34.598 201.949h115.094l-21.826-274.453V90.181H129.254v47.286l-22.595 284.112z"/></svg>';
export {
  o as default
};
//# sourceMappingURL=icon-shorts-BYBldcUu.js.map
