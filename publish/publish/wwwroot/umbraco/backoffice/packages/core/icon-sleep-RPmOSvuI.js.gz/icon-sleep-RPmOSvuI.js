const o = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" class="lucide lucide-moon-star" viewBox="0 0 24 24"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9M20 3v4M22 5h-4"/></svg>';
export {
  o as default
};
//# sourceMappingURL=icon-sleep-RPmOSvuI.js.map
