const e = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" class="lucide lucide-square-asterisk" viewBox="0 0 24 24"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M12 8v8M8.5 14l7-4M8.5 10l7 4"/></svg>';
export {
  e as default
};
//# sourceMappingURL=icon-stamp-CVkQWozn.js.map
