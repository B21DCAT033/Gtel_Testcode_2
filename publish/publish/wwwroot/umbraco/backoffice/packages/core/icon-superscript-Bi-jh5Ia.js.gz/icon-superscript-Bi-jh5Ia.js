const e = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" class="lucide lucide-superscript" viewBox="0 0 24 24"><path d="m4 19 8-8M12 19l-8-8M20 12h-4c0-1.5.442-2 1.5-2.5S20 8.334 20 7.002c0-.472-.17-.93-.484-1.29a2.105 2.105 0 0 0-2.617-.436c-.42.239-.738.614-.899 1.06"/></svg>';
export {
  e as default
};
//# sourceMappingURL=icon-superscript-Bi-jh5Ia.js.map
