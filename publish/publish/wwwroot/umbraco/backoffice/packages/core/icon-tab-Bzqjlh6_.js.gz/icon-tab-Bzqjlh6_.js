const o = '<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 512 512"><path d="M422.444 283.7v-95.826c0-13.828-11.21-25.039-25.038-25.039h-282.47c-13.828 0-25.038 11.211-25.038 25.039V283.7h-52.06v65.401h436.664V283.7z"/></svg>';
export {
  o as default
};
//# sourceMappingURL=icon-tab-Bzqjlh6_.js.map
