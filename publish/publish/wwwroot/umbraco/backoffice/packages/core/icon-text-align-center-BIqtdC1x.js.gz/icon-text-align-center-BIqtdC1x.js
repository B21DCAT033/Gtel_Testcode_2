const e = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" class="lucide lucide-align-center" viewBox="0 0 24 24"><path d="M17 12H7M19 18H5M21 6H3"/></svg>';
export {
  e as default
};
//# sourceMappingURL=icon-text-align-center-BIqtdC1x.js.map
