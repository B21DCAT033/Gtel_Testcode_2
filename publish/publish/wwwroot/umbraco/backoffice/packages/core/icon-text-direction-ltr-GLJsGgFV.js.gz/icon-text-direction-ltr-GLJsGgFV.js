const o = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" class="lucide lucide-pilcrow-right" viewBox="0 0 24 24"><path d="M10 3v11M10 9H7a1 1 0 0 1 0-6h8M14 3v11M18 14l4 4H2M22 18l-4 4"/></svg>';
export {
  o as default
};
//# sourceMappingURL=icon-text-direction-ltr-GLJsGgFV.js.map
