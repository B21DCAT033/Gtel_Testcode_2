const o = '<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.75" class="lucide lucide-square-arrow-down-left" viewBox="0 0 24 24"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="m16 8-8 8M16 16H8V8"/></svg>';
export {
  o as default
};
//# sourceMappingURL=icon-window-popin-D0Vcpbek.js.map
