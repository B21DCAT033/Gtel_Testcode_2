import { UmbContextToken as t } from "@umbraco-cms/backoffice/context-api";
const T = new t(
  "UmbEntityIsTrashedContext"
);
export {
  T as U
};
//# sourceMappingURL=is-trashed.entity-context-token-DtToyMNh.js.map
