import t from "./it-it-nEIBQBH6.js";
const o = {
  // NOTE: Imports and re-exports the Italian (Italy) localizations, so that any Italian (Switzerland) localizations can be override them. [LK]
  ...t
};
export {
  o as default
};
//# sourceMappingURL=it-ch-CBMPQF0I.js.map
