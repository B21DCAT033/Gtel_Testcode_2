const e = {
  actions: {
    assigndomain: "Gestisci hostnames",
    auditTrail: "Audit Trail",
    browse: "Sfoglia",
    changeDocType: "Cambia tipo di documento",
    changeDataType: "Cambia tipo di dato",
    copy: "Copia",
    create: "Crea",
    export: "Esporta",
    createPackage: "Crea pacchetto",
    createGroup: "Crea gruppo",
    delete: "Cancella",
    disable: "Disabilita",
    editSettings: "Modifica impostazioni",
    emptyrecyclebin: "Svuota il cestino",
    enable: "Abilita",
    exportDocumentType: "Esporta il tipo di documento",
    importdocumenttype: "Importa il tipo di documento",
    importPackage: "Importa il pacchetto",
    liveEdit: "Modifica in Area di Lavoro",
    logout: "Uscita",
    move: "Sposta",
    notify: "Notifiche",
    protect: "Accesso pubblico",
    publish: "Pubblica",
    unpublish: "Non pubblicare",
    refreshNode: "Aggiorna",
    republish: "Ripubblica intero sito",
    remove: "Rimuovi",
    rename: "Rinomina",
    restore: "Ripristina",
    SetPermissionsForThePage: "Imposta i permessi per la pagina %0%",
    chooseWhereToCopy: "Scegli dove copiare",
    chooseWhereToMove: "Scegli dove muovere",
    toInTheTreeStructureBelow: "nella struttura sottostante",
    infiniteEditorChooseWhereToCopy: "Scegli dove copiare l'oggetto/gli oggetti selezionati",
    infiniteEditorChooseWhereToMove: "Scegli dove spostare l'oggetto/gli oggetti selezionati",
    wasMovedTo: "è stato spostato in",
    wasCopiedTo: "è stato copiato in",
    wasDeleted: "è stato eliminato",
    rights: "Permessi",
    rollback: "Annulla ultima modifica",
    sendtopublish: "Invia per la pubblicazione",
    sendToTranslate: "Invia per la traduzione",
    setGroup: "Crea gruppo",
    sort: "Ordina",
    translate: "Traduci",
    update: "Aggiorna",
    setPermissions: "Imposta permessi",
    unlock: "Sblocca",
    createblueprint: "Crea modello di contenuto",
    resendInvite: "Invia nuovamente l'invito"
  },
  actionCategories: {
    content: "Contenuto",
    administration: "Amministrazione",
    structure: "Struttura",
    other: "Altro"
  },
  actionDescriptions: {
    assignDomain: "Consenti l'accesso per assegnare gli hostnames",
    auditTrail: "Consenti l'accesso per visualizzare la cronologia di un nodo",
    browse: "Consenti l'accesso per visualizzare un nodo",
    changeDocType: "Consenti l'accesso per cambiare tipo di documento a un nodo",
    copy: "Consenti l'accesso per copiare un nodo",
    create: "Consenti l'accesso per creare i nodi",
    delete: "Consenti l'accesso per eliminare i nodi",
    move: "Consenti l'accesso per spostare un nodo",
    protect: "Consenti l'accesso per impostare e cambiare le restrizioni di accesso a un nodo",
    publish: "Consenti l'accesso per pubblicare un nodo",
    unpublish: "Consenti l'accesso per non pubblicare un nodo",
    rights: "Consenti l'accesso per cambiare i permessi di un nodo",
    rollback: "Consenti l'accesso per riportare un nodo a una versione precedente",
    sendtopublish: "Consenti l'accesso per inviare un nodo in approvazione prima di pubblicare",
    sendToTranslate: "Consenti l'accesso per inviare un nodo per la traduzione",
    sort: "Consenti l'accesso per cambiare l'ordinamento dei nodi",
    translate: "Consenti l'accesso per tradurre un nodo",
    update: "Consenti l'accesso per salvare un nodo",
    createblueprint: "Consenti l'accesso per creare un modello di contenuto"
  },
  apps: {
    umbContent: "Contenuto",
    umbInfo: "Info"
  },
  assignDomain: {
    permissionDenied: "Permesso negato.",
    addNew: "Aggiungi nuovo dominio",
    remove: "rimuovi",
    invalidNode: "Nodo non valido.",
    invalidDomain: "Uno o più domini hanno un formato non valido.",
    duplicateDomain: "Il dominio è già stato assegnato.",
    language: "Lingua",
    domain: "Dominio",
    domainCreated: "Il dominio '%0%' è stato creato",
    domainDeleted: "Il dominio '%0%' è stato cancellato",
    domainExists: "Il dominio '%0%' è già stato assegnato",
    domainUpdated: "Il dominio '%0%' è stato aggiornato",
    orEdit: "Modifica il dominio corrente",
    domainHelpWithVariants: `Nomi di dominio validi sono: "example.com", "www.example.com", "example.com:8080", oppure "https://www.example.com/".
     Inoltre sono supportati anche i percorsi a un livello nei domini, ad esempio "example.com/it" oppure "/it".`,
    inherit: "Eredita",
    setLanguage: "Lingua",
    setLanguageHelp: `Imposta la lingua per i nodi sotto il nodo corrente,<br /> oppure eredita la lingua dai nodi padre. Si applicherà anche<br />
      al nodo corrente, a meno che un dominio sotto non venga applicato.`,
    setDomains: "Domini"
  },
  buttons: {
    clearSelection: "Cancella selezione",
    select: "Seleziona",
    somethingElse: "Fai qualcos'altro",
    bold: "Grassetto",
    deindent: "Cancella rientro paragrafo",
    formFieldInsert: "Inserisci campo del form",
    graphicHeadline: "Inserisci intestazione grafica",
    htmlEdit: "Modifica Html",
    indent: "Inserisci rientro paragrafo",
    italic: "Corsivo",
    justifyCenter: "Centra",
    justifyLeft: "Allinea testo a sinistra",
    justifyRight: "Allinea testo a destra",
    linkInsert: "Inserisci Link",
    linkLocal: "Inserisci local link (ancora)",
    listBullet: "Elenco puntato",
    listNumeric: "Elenco numerato",
    macroInsert: "Inserisci macro",
    pictureInsert: "Inserisci immagine",
    publishAndClose: "Pubblica e chiudi",
    publishDescendants: "Pubblica con discendenti",
    relations: "Modifica relazioni",
    returnToList: "Ritorna alla lista",
    save: "Salva",
    saveAndClose: "Salva e chiudi",
    saveAndPublish: "Salva e pubblica",
    saveAndSchedule: "Salva e pianifica",
    saveToPublish: "Salva e invia per approvazione",
    saveListView: "Salva list view",
    schedulePublish: "Pianifica",
    showPage: "Anteprima",
    saveAndPreview: "Salva e visualizza anteprima",
    showPageDisabled: "L'anteprima è disabilitata perché non ci sono template assegnati",
    styleChoose: "Scegli stile",
    styleShow: "Vedi stili",
    tableInsert: "Inserisci tabella",
    generateModelsAndClose: "Genera modelli e chiudi",
    saveAndGenerateModels: "Salva e genera modelli",
    undo: "Indietro",
    redo: "Avanti",
    rollback: "Ripristina",
    deleteTag: "Elimina tag",
    confirmActionCancel: "Cancella",
    confirmActionConfirm: "Conferma",
    morePublishingOptions: "Più opzioni di pubblicazione",
    submitChanges: "Invia",
    submitChangesAndClose: "Invia e chiudi"
  },
  auditTrailsMedia: {
    delete: "Media eliminato",
    move: "Media spostato",
    copy: "Media copiato",
    save: "Media salvato"
  },
  auditTrails: {
    atViewingFor: "Visualizzazione per",
    delete: "Contenuto eliminato",
    unpublish: "Contenuto non pubblicato",
    unpublishvariant: "Contenuto non pubblicato per le lingue: %0%",
    publish: "Contenuto pubblicato",
    publishvariant: "Contenuto pubblicato per le lingue: %0%",
    save: "Contenuto salvato",
    savevariant: "Contenuto salvato per le lingue: %0%",
    move: "Contenuto spostato",
    copy: "Contenuto copiato",
    rollback: "Contenuto ripristinato",
    sendtopublish: "Contenuto inviato per l'approvazione",
    sendtopublishvariant: "Contenuto inviato per l'approvazione per le lingue: %0%",
    sort: "Ordina gli elementi figlio eseguito dall'utente",
    custom: "%0%",
    smallCopy: "Copia",
    smallPublish: "Pubblica",
    smallPublishVariant: "Pubblica",
    smallMove: "Sposta",
    smallSave: "Salva",
    smallSaveVariant: "Salva",
    smallDelete: "Elimina",
    smallUnpublish: "Non pubblicare",
    smallUnpublishVariant: "Non pubblicare",
    smallRollBack: "Ripristina",
    smallSendToPublish: "Invia per l'approvazione",
    smallSendToPublishVariant: "Invia per l'approvazione",
    smallSort: "Ordina",
    smallCustom: "Personalizzato",
    historyIncludingVariants: "Cronologia (tutte le varianti)"
  },
  codefile: {
    createFolderFailedById: "Impossibile creare una cartella sotto genitore con ID %0%",
    createFolderFailedByName: "Impossibile creare una cartella sotto genitore con nome %0%",
    createFolderIllegalChars: "Il nome della cartella non può contenere caratteri non validi.",
    deleteItemFailed: "Impossibile eliminare l'elemento: %0%"
  },
  content: {
    isPublished: "Pubblicato",
    about: "Informazioni su questa pagina",
    alias: "Alias",
    alternativeTextHelp: "(come descriveresti l'immagine via telefono)",
    alternativeUrls: "Links alternativi",
    clickToEdit: "Clicca per modificare questo elemento",
    createBy: "Creato da",
    createByDesc: "Autore originale",
    updatedBy: "Aggiornato da",
    createDate: "Creato il",
    createDateDesc: "Data e ora in cui questo documento è stato creato",
    documentType: "Tipo di documento",
    editing: "Modifica",
    expireDate: "Attivo fino al",
    itemChanged: "Questo elemento è stato modificato dopo la pubblicazione",
    itemNotPublished: "Questo elemento non è stato pubblicato",
    lastPublished: "Ultima pubblicazione",
    noItemsToShow: "Non ci sono elementi da visualizzare",
    listViewNoItems: "Non ci sono elementi da visualizzare nella lista.",
    listViewNoContent: "Nessun elemento figlio è stato aggiunto",
    listViewNoMembers: "Nessun membro è stato aggiunto",
    mediatype: "Tipo di media",
    mediaLinks: "Link ai media",
    membergroup: "Gruppo di membri",
    memberrole: "Ruolo",
    membertype: "Tipo di Membro",
    noChanges: "Non sono state effettuate modifiche",
    noDate: "La data non è stata selezionata",
    nodeName: "Titolo della Pagina",
    noMediaLink: "Questo media non ha link",
    noProperties: "Nessun contenuto può essere aggiunto per questo elemento",
    otherElements: "Proprietà",
    parentNotPublished: "Questo documento è pubblicato, ma non è visibile perché il padre '%0%' non è pubblicato",
    parentCultureNotPublished: "Questa lingua è pubblicata, ma non è visibile perché non è pubblicata al padre '%0%'",
    parentNotPublishedAnomaly: "Questo documento è pubblicato, ma non è nella cache",
    getUrlException: "Impossibile ottenere l'URL",
    routeError: "Questo documento è pubblicato ma il suo URL entrerebbe in conflitto con il contenuto %0%",
    routeErrorCannotRoute: "Questo documento è pubblicato ma il suo URL non può essere instradato",
    publish: "Pubblica",
    published: "Pubblicato",
    publishedPendingChanges: "Pubblicato (modifiche in sospeso)",
    publishStatus: "Stato della pubblicazione",
    publishDescendantsHelp: "Pubblica <strong>%0%</strong> e tutti gli elementi sottostanti, rendendo così il loro contenuto pubblicamente disponibile.",
    publishDescendantsWithVariantsHelp: "Pubblica le varianti e le varianti dello stesso tipo sottostanti, rendendo così il loro contenuto pubblicamente disponibile.",
    releaseDate: "Pubblicato il",
    unpublishDate: "Non pubblicato il",
    removeDate: "Rimuovi data",
    setDate: "Imposta data",
    sortDone: "Ordinamento dei nodi aggiornato",
    sortHelp: 'Per ordinare i nodi, è sufficiente trascinare i nodi o fare clic su una delle intestazioni di colonna. È possibile selezionare più nodi tenendo premuto il tasto "shift" o "control" durante la selezione',
    statistics: "Statistiche",
    titleOptional: "Titolo (opzionale)",
    altTextOptional: "Testo alternativo (opzionale)",
    captionTextOptional: "Didascalia (opzionale)",
    type: "Tipo",
    unpublish: "Non pubblicare",
    unpublished: "Bozza",
    notCreated: "Non creato",
    updateDate: "Ultima modifica",
    updateDateDesc: "Data e ora in cui questo documento è stato modificato",
    uploadClear: "Rimuovi file(s)",
    uploadClearImageContext: "Clicca qui per rimuovere l'immagine dal media",
    uploadClearFileContext: "Clicca qui per rimuovere il file dal media",
    urls: "Link al documento",
    memberof: "Membro del gruppo/i",
    notmemberof: "Non un membro del gruppo/i",
    childItems: "Elementi figli",
    target: "Target",
    scheduledPublishServerTime: "Questo si traduce nella seguente ora sul server:",
    scheduledPublishDocumentation: '<a href="https://docs.umbraco.com/umbraco-cms/fundamentals/data/scheduled-publishing#timezones" target="_blank" rel="noopener">Cosa significa questo?</a>',
    nestedContentDeleteItem: "Sei sicuro di voler eliminare questo oggetto?",
    nestedContentDeleteAllItems: "Sei sicuro di voler eliminare tutti gli oggetti?",
    nestedContentEditorNotSupported: "La proprietà %0% usa l'editor %1% che non è supportato dal Nested Content.",
    nestedContentNoContentTypes: "Nessun tipo di contenuto configurato per questa proprietà.",
    nestedContentAddElementType: "Aggiungi Element Type",
    nestedContentSelectElementTypeModalTitle: "Seleziona Element Type",
    nestedContentGroupHelpText: "Seleziona il gruppo di cui devono essere visualizzate le proprietà. Se lasciato vuoto, verrà utilizzato il primo gruppo sull'Element Type.",
    nestedContentTemplateHelpTextPart1: `Immettere un'espressione di angular da valutare rispetto a ciascun
      elemento per il relativo nome. Utilizza
    `,
    nestedContentTemplateHelpTextPart2: "per visualizzare l'index dell'oggetto",
    addTextBox: "Aggiungi un altro box di testo",
    removeTextBox: "Rimuovi questa text box",
    contentRoot: "Root del contenuto",
    includeUnpublished: "Includi elementi di contenuto non pubblicati.",
    isSensitiveValue: "Questo valore è nascosto. Se hai bisogno dell'accesso per visualizzare questo valore contatta l'amministratore del sito.",
    isSensitiveValue_short: "Questo valore è nascosto.",
    languagesToPublishForFirstTime: `Quali lingue vorresti pubblicare? Tutte le lingue con contenuto vengono
      salvate!
    `,
    languagesToPublish: "Quali lingue vorresti pubblicare?",
    languagesToSave: "Quali lingue vorresti salvare?",
    languagesToSaveForFirstTime: "Tutte le lingue con contenuto vengono salvate alla creazione!",
    languagesToSendForApproval: "Quali lingue vorresti inviare per l'approvazione?",
    languagesToSchedule: "Quali lingue vorresti pianificare?",
    languagesToUnpublish: `Seleziona le lingue da non pubblicare. Non pubblicando una lingua obbligatoria
      annullerai la pubblicazione di tutte le lingue.
    `,
    publishedLanguages: "Lingue pubblicate",
    unpublishedLanguages: "Lingue non pubblicate",
    unmodifiedLanguages: "Lingue non modificate",
    untouchedLanguagesForFirstTime: "Queste lingue non sono state create.",
    variantsWillBeSaved: "Tutte le nuove varianti verranno salvate.",
    variantsToPublish: "Quali varianti vorresti pubblicare?",
    variantsToSave: "Scegli quali varianti verranno salvate.",
    variantsToSendForApproval: "Scegli le varianti da inviare per l'approvazione.",
    variantsToSchedule: "Imposta pubblicazione pianificata...",
    variantsToUnpublish: `Seleziona le varianti da non pubblicare. Non pubblicando una lingua obbligatoria
      annullerai la pubblicazione di tutte le varianti.
    `,
    publishRequiresVariants: "Per la pubblicazione sono necessarie le seguenti varianti:",
    notReadyToPublish: "Non siamo pronti per la pubblicazione",
    readyToPublish: "Pronto per la pubblicazione?",
    readyToSave: "Pronto per il salvataggio?",
    sendForApproval: "Invia per l'approvazione",
    schedulePublishHelp: "Seleziona da data e l'ora in cui pubblicare/non pubblicare il contenuto.",
    createEmpty: "Crea nuovo/a",
    createFromClipboard: "Incolla dagli appunti",
    nodeIsInTrash: "Questo articolo è nel cestino",
    saveModalTitle: "Salva"
  },
  blueprints: {
    createBlueprintFrom: "Crea un nuovo modello di contenuto da '%0%'",
    blankBlueprint: "Vuoto",
    selectBlueprint: "Seleziona un modello di contenuto",
    createdBlueprintHeading: "Modello di contenuto creato",
    createdBlueprintMessage: "Un modello di contenuto è stato creato da '%0%'",
    duplicateBlueprintMessage: "Un altro modello di contenuto con lo stesso nome esiste già",
    blueprintDescription: "Un modello di contenuto è del contenuto predefinito che un editor può utilizzare come base per creare un nuovo contenuto."
  },
  media: {
    clickToUpload: "Clicca per caricare",
    orClickHereToUpload: "o clicca qui per scegliere i files",
    dragFilesHereToUpload: "Puoi trascinare i file qui per caricarli.",
    disallowedFileType: "Impossibile caricare questo file, non ha un tipo di file approvato",
    maxFileSize: "La dimensione massima del file è",
    mediaRoot: "Media root",
    moveFailed: "Impossibile spostare il media",
    moveToSameFolderFailed: "La cartella padre e di destinazione non possono essere le stesse",
    copyFailed: "Impossibile copiare il media",
    createFolderFailed: "Impossibile creare una cartella sotto l'id padre %0%",
    renameFolderFailed: "Impossibile rinominare la cartella con id %0%",
    dragAndDropYourFilesIntoTheArea: "Trascina e rilascia i tuoi file nell'area",
    uploadNotAllowed: "Il caricamento non è consentito in questa posizione."
  },
  member: {
    createNewMember: "Crea un nuovo membro",
    allMembers: "Tutti i membri",
    memberGroupNoProperties: "I gruppi di membri non hanno proprietà aggiuntive per la modifica."
  },
  contentType: {
    copyFailed: "Impossibile copiare il content type",
    moveFailed: "Impossibile spostare il content type"
  },
  mediaType: {
    copyFailed: "Impossibile copiare il media type",
    moveFailed: "Impossibile spostare il media type",
    autoPickMediaType: "Selezione automatica"
  },
  memberType: {
    copyFailed: "Impossibile copiare il member type"
  },
  create: {
    chooseNode: "Dove vuoi creare il nuovo %0%",
    createUnder: "Crea un elemento sotto",
    createContentBlueprint: "Seleziona il Document Type per cui vuoi creare un modello di contenuto",
    enterFolderName: "Inserisci il nome della cartella",
    updateData: "Scegli il tipo ed il titolo",
    noDocumentTypes: "Non ci sono tipi di documento abilitati disponibili per creare un contenuto qui. Devi abilitarli in <strong>Tipi di documento</strong> dentro la sezione <strong>Impostazioni</strong>, modificando <strong>Tipi di nodi figlio consentiti</strong> sotto <strong>Permessi</strong>.",
    noDocumentTypesAtRoot: "Non ci sono tipi di documento abilitati disponibili per creare un contenuto qui. Devi crearli in <strong>Tipi di documento</strong> dentro la sezione <strong>Impostazioni</strong>.",
    noDocumentTypesWithNoSettingsAccess: `La pagina selezionata nel content tree non permette a nessuna
      pagina di essere creata sotto di essa.
    `,
    noDocumentTypesEditPermissions: "Modifica permessi per questo tipo di documento",
    noDocumentTypesCreateNew: "Crea un nuovo tipo di documento",
    noDocumentTypesAllowedAtRoot: "Non ci sono tipi di documento abilitati disponibili per creare un contenuto qui. Devi abilitarli in <strong>Tipi di documento</strong> dentro la sezione <strong>Impostazioni</strong>, cambiando l'opzione <strong>Consenti come root</strong> sotto <strong>Permessi</strong>.",
    noMediaTypes: "Non ci sono tipi di documento abilitati disponibili per creare un media qui. Devi abilitarli in <strong>Tipi di documento</strong> dentro la sezione <strong>Impostazioni</strong>, modificando <strong>Tipi di nodi figlio consentiti</strong> sotto <strong>Permessi</strong>.",
    noMediaTypesWithNoSettingsAccess: `Il media selezionato non consente la creazione di altri media al di
      sotto di esso.
    `,
    noMediaTypesEditPermissions: "Modifica permessi per questo tipo di media",
    documentTypeWithoutTemplate: "Tipo di documento senza template",
    documentTypeWithTemplate: "Tipo di documento con template",
    documentTypeWithTemplateDescription: "La definizione dei dati per una pagina di contenuto che può essere creata dagli editor nella struttura dei contenuti ed è direttamente accessibile tramite un URL.",
    documentType: "Tipo di documento",
    documentTypeDescription: "La definizione dei dati per un componente del contenuto che può essere creato dagli editor nella struttura del contenuto e prelevato su altre pagine ma non ha un URL diretto.",
    elementType: "Tipo di elemento",
    elementTypeDescription: "Definisce lo schema per un insieme ripetuto di proprietà, ad esempio, in un editor di proprietà 'Block List' o 'Nested Content'.",
    composition: "Composizione",
    compositionDescription: 'Definisce un insieme riutilizzabile di proprietà che possono essere incluse nella definizione di più altri tipi di documento. Ad esempio, un insieme di "Impostazioni pagina comuni".',
    folder: "Cartella",
    folderDescription: `Utilizzato per organizzare i tipi di documento, le composizioni e i tipi di elementi
      creati in questo albero dei tipi di documento.
    `,
    newFolder: "Nuova cartella",
    newDataType: "Nuovo tipo di dato",
    newJavascriptFile: "Nuovo file JavaScript",
    newEmptyPartialView: "Nuova partial view vuota",
    newPartialViewMacro: "Nuova partial view macro",
    newPartialViewFromSnippet: "Nuova partial view da snippet",
    newPartialViewMacroFromSnippet: "Nuova partial view macro da snippet",
    newPartialViewMacroNoMacro: "Nuova partial view macro (senza macro)",
    newStyleSheetFile: "Nuovo foglio di stile",
    newRteStyleSheetFile: "Nuovo foglio di stile per Rich Text Editor"
  },
  dashboard: {
    browser: "Naviga il tuo sito web",
    dontShowAgain: "Non mostrare più",
    nothinghappens: "se Umbraco non si sta aprendo, potresti aver bisogno di rimuovere il blocco popup",
    openinnew: "hai aperto una nuova finestra",
    restart: "Riavvia",
    visit: "Visita",
    welcome: "Benvenuto"
  },
  prompt: {
    stay: "Rimani",
    discardChanges: "Scarta le modifiche",
    unsavedChanges: "Hai delle modifiche non salvate",
    unsavedChangesWarning: `Sei sicuro di voler lasciare questa pagina? Hai delle modifiche non salvate!
    `,
    confirmListViewPublish: "Pubblicando renderai visibli gli oggetti selezionati sul sito.",
    confirmListViewUnpublish: `Non pubblicando rimuoverai gli oggetti selezionati e i loro discendenti dal
      sito.
    `,
    confirmUnpublish: "Non pubblicando rimuoverai questa pagina e tutti i suoi discendenti dal sito.",
    doctypeChangeWarning: "Hai modifiche non salvate. Apportare modifiche al tipo di documento annullerà le modifiche."
  },
  bulk: {
    done: "Fatto",
    deletedItem: "Eliminato %0% elemento",
    deletedItems: "Eliminati %0% elementi",
    deletedItemOfItem: "Eliminato %0% su %1% elemento",
    deletedItemOfItems: "Eliminati %0% su %1% elementi",
    publishedItem: "Pubblicato %0% elemento",
    publishedItems: "Pubblicati %0% elementi",
    publishedItemOfItem: "Pubblicato %0% su %1% elemento",
    publishedItemOfItems: "Pubblicati %0% su %1% elementi",
    unpublishedItem: "%0% elemento non pubblicato",
    unpublishedItems: "%0% elementi non pubblicati",
    unpublishedItemOfItem: "Elementi non pubblicati: %0% su %1%",
    unpublishedItemOfItems: "Elementi non pubblicati: %0% su %1%",
    movedItem: "Spostato %0% elemento",
    movedItems: "Spostati %0% elementi",
    movedItemOfItem: "Spostato %0% su %1% elemento",
    movedItemOfItems: "Spostati %0% su %1% elementi",
    copiedItem: "Copiato %0% elemento",
    copiedItems: "Copiati %0% elementi",
    copiedItemOfItem: "Copiato %0% su %1% elemento",
    copiedItemOfItems: "Copiati %0% su %1% elementi"
  },
  defaultdialogs: {
    nodeNameLinkPicker: "Titolo del Link",
    urlLinkPicker: "Link",
    anchorLinkPicker: "Ancora / querystring",
    anchorInsert: "Nome",
    closeThisWindow: "Chiudi questa finestra",
    confirmdelete: "Sei sicuro di voler eliminare",
    confirmdisable: "Sei sicuro di voler disabilitare",
    confirmremove: "Sei sicuro di voler rimuovere",
    confirmremoveusageof: "Sei sicuro di voler rimuovere l'utilizzo di <strong>%0%</strong>",
    confirmremovereferenceto: "Sei sicuro di voler rimuovere la referenza a <strong>%0%</strong>",
    confirmlogout: "Sei sicuro?",
    confirmSure: "Sei sicuro?",
    cut: "Taglia",
    editDictionary: "Modifica elemento del Dizionario",
    editLanguage: "Modifica la lingua",
    editSelectedMedia: "Modifica il media selezionato",
    insertAnchor: "Inserisci il link locale",
    insertCharacter: "Inserisci carattere",
    insertgraphicheadline: "Inserisci intestazione grafica",
    insertimage: "Inserisci immagine",
    insertlink: "Inserisci link",
    insertMacro: "Inserisci macro",
    inserttable: "Inserisci tabella",
    languagedeletewarning: "Questo eliminerà la lingua",
    languageChangeWarning: "La modifica della cultura di una lingua può essere un'operazione costosa e comporterà la ricostruzione della cache dei contenuti e degli indici",
    lastEdited: "Ultima modifica",
    link: "Link",
    linkinternal: "Link interno",
    linklocaltip: "Quando usi il link locale, inserisci # prima del link",
    linknewwindow: "Apri in nuova finestra?",
    macroContainerSettings: "Impostazioni della macro",
    macroDoesNotHaveProperties: "Questa macro non contiene proprietà editabili",
    paste: "Incolla",
    permissionsEdit: "Modifica i permessi per",
    permissionsSet: "Imposta i permessi per",
    permissionsSetForGroup: "Imposta i permessi per %0% per il gruppo di utenti %1%",
    permissionsHelp: "Seleziona i gruppi di utenti per il quale vuoi impostare i permessi",
    recycleBinDeleting: "Gli elementi presenti nel cestino verranno cancellati. Non chiudere questa finestra finchè l'operazione non è terminata.",
    recycleBinIsEmpty: "Il cestino è vuoto",
    recycleBinWarning: "Gli elementi cancellati dal cestino non potranno essere recuperati.",
    regexSearchError: "Il webservice <a target='_blank' rel='noopener' href='http://regexlib.com'>regexlib.com</a> ha attualmente qualche problema, di cui non abbiamo il controllo. Siamo spiacevoli dell'inconveniente.",
    regexSearchHelp: "Ricerca un'espressione regolare da aggiungere al campo della form per poter validare il contenuto. Esempio: 'email, 'zip-code', 'URL'.",
    removeMacro: "Elimina Macro",
    requiredField: "Campo obbligatorio",
    sitereindexed: "Il sito è stato reindicizzato",
    siterepublished: "Il sito è stato ripubblicato",
    siterepublishHelp: "La cache del sito sarà ricreata. Tutti gli elementi pubblicati saranno aggiornati, tutti quelli non pubblicati rimarranno tali.",
    tableColumns: "Numero di colonne",
    tableRows: "Numero di righe",
    thumbnailimageclickfororiginal: "Clicca sull'immmagine per ingrandirla",
    treepicker: "Seleziona elemento",
    viewCacheItem: "Visualizza gli elementi in cache",
    relateToOriginalLabel: "Relaziona con l'originale",
    includeDescendants: "Includi discendenti",
    theFriendliestCommunity: "La comunità più amichevole",
    linkToPage: "Link alla pagina",
    openInNewWindow: "Apre il documento linkato in una nuova finestra o tab",
    linkToMedia: "Link al media",
    selectContentStartNode: "Seleziona il nodo di inizio per il contenuto",
    selectMedia: "Seleziona media",
    selectMediaType: "Seleziona tipo di media",
    selectIcon: "Seleziona icona",
    selectItem: "Seleziona oggetto",
    selectLink: "Seleziona link",
    selectMacro: "Seleziona macro",
    selectContent: "Seleziona contenuto",
    selectContentType: "Seleziona tipo di contenuto",
    selectMediaStartNode: "Seleziona il nodo di inizio per i media",
    selectMember: "Seleziona membro",
    selectMemberGroup: "Seleziona gruppo di membri",
    selectMemberType: "Seleziona tipo di membri",
    selectNode: "Seleziona nodo",
    selectSections: "Seleziona sezioni",
    selectUser: "Seleziona utente",
    selectUsers: "Seleziona utenti",
    noIconsFound: "Non sono state trovate icone",
    noMacroParams: "Non ci sono parametri per questa macro",
    noMacros: "Non ci sono macro disponibili da inserire",
    externalLoginProviders: "Provider di accesso esterni",
    exceptionDetail: "Exception Details",
    stacktrace: "Stacktrace",
    innerException: "Inner Exception",
    linkYour: "Linka il tuo",
    unLinkYour: "Togli il link al tuo",
    account: "account",
    selectEditor: "Seleziona editor",
    selectEditorConfiguration: "Seleziona configurazione",
    selectSnippet: "Seleziona snippet",
    variantdeletewarning: "Questo cancellerà il nodo e tutte le sue lingue. Se desideri eliminare solo una lingua, dovresti invece non pubblicare il nodo in quella lingua.",
    propertyuserpickerremovewarning: "Questo rimuoverà l'utente <strong>%0%</strong>.",
    userremovewarning: "Questo rimuoverà l'utente <strong>%0%</strong> dal gruppo <strong>%1%</strong>",
    yesRemove: "Si, rimuovi"
  },
  dictionary: {
    noItems: "Non ci sono oggetti nel Dizionario."
  },
  dictionaryItem: {
    description: "Modifica le lingue per l'elemento '%0%' qui sotto.",
    displayName: "Nome della cultura",
    changeKeyError: "La chiave '%0%' esiste già.",
    overviewTitle: "Panoramica del Dizionario"
  },
  examineManagement: {
    configuredSearchers: "Searchers configurati",
    configuredSearchersDescription: "Visualizza le proprietà e gli strumenti per ogni Searcher configurato (per esempio un multi-index searcher)",
    fieldValues: "Valori del campo",
    healthStatus: "Stato di salute",
    healthStatusDescription: "Lo stato di salute dell'index e se può essere letto",
    indexers: "Indexers",
    indexInfo: "Index info",
    indexInfoDescription: "Elenca le proprietà dell'index",
    manageIndexes: "Gestisci gli indexes di Examine",
    manageIndexesDescription: `Permette di visualizzare i dettagli di ogni index e fornisce alcuni strumenti
      per gestire gli index
    `,
    rebuildIndex: "Ricostruisci index",
    rebuildIndexWarning: `
      Questo causerà la ricostruzione dell'index.<br />
      A seconda della quantità di contenuti presenti nel tuo sito, potrebbe volerci un po' di tempo.<br />
      Non è consigliabile ricostruire un indice durante i periodi di elevato traffico del sito Web o quando gli editor modificano i contenuti.
     `,
    searchers: "Searchers",
    searchDescription: "Cerca nell'index e visualizza i risultati",
    tools: "Strumenti",
    toolsDescription: "Strumenti per gestire l'index",
    fields: "Campi",
    indexCannotRead: "L'indice non può essere letto e dovrà essere ricostruito",
    processIsTakingLonger: "Il processo sta impiegando più tempo del previsto, controlla il log di Umbraco per vedere se ci sono stati errori durante questa operazione",
    indexCannotRebuild: "Questo indice non può essere ricostruito perché non ha assegnato",
    iIndexPopulator: "IIndexPopulator"
  },
  placeholders: {
    username: "Inserisci il tuo username",
    password: "Inserisci la tua password",
    confirmPassword: "Conferma la tua password",
    nameentity: "Dai un nome a %0%...",
    entername: "Inserisci un nome...",
    enteremail: "Inserisci un email...",
    enterusername: "Inserisci un username...",
    label: "Etichetta...",
    enterDescription: "Inserisci una descrizione...",
    search: "Cerca...",
    filter: "Filtra...",
    enterTags: "Scrivi per aggiungere tags (premi invio dopo ogni tag)...",
    email: "Inserisci la tua email",
    enterMessage: "Inserisci un messaggio...",
    usernameHint: "Il tuo username di solito è la tua email",
    anchor: "#value oppure ?key=value",
    enterAlias: "Inserisci un alias...",
    generatingAlias: "Sto generando l'alias...",
    a11yCreateItem: "Crea oggetto",
    a11yEdit: "Modifica",
    a11yName: "Nome"
  },
  editcontenttype: {
    createListView: "Crea una list view custom",
    removeListView: "Rimuovi la list view custom",
    aliasAlreadyExists: "Un tipo di contenuto, tipo di media o tipo di membro con questo alias esiste già"
  },
  renamecontainer: {
    renamed: "Rinominato",
    enterNewFolderName: "Inserisci qui il nuovo nome della cartella",
    folderWasRenamed: "'%0%' è stato rinominato in '%1%'"
  },
  editdatatype: {
    addPrevalue: "Aggiungi valore predefinito",
    dataBaseDatatype: "Tipo di Dato del database",
    guid: "Tipo di dati GUID",
    renderControl: "Rendering controllo",
    rteButtons: "Bottoni",
    rteEnableAdvancedSettings: "Abilita impostazioni avanzate per",
    rteEnableContextMenu: "Abilita menu contestuale",
    rteMaximumDefaultImgSize: "Dimensione massima delle immagini inserite",
    rteRelatedStylesheets: "Fogli di stile collegati",
    rteShowLabel: "Visualizza etichetta",
    rteWidthAndHeight: "Larghezza e altezza",
    allPropTypes: "Tutti i tipi di proprietà & dati delle proprietà",
    willBeDeleted: "usando questo tipo di dato verrà eliminato permanentemente, per favore conferma che vuoi eliminare anche questo.",
    yesDelete: "Si, elimina",
    andAllRelated: "e tutti i tipi di proprietà &amp; dati delle proprietà che usano questo tipo di dato",
    selectFolder: "Seleziona la cartella da spostare",
    inTheTree: "nella struttura sottostante",
    wasMoved: "è stato spostato sotto",
    hasReferencesDeleteConsequence: "Eliminando <strong>%0%</strong> eliminerà le proprietà e i dati dagli oggetti seguenti",
    acceptDeleteConsequence: "Capisco che questa azione eliminerà le proprietà e i dati basati su questo tipo di dato"
  },
  errorHandling: {
    errorButDataWasSaved: "I tuoi dati sono stati salvati, ma prima che tu possa pubblicare la tua pagina ci sono degli errori che devono essere corretti:",
    errorChangingProviderPassword: "Il MemberShip provider corrente non supporta il cambio password (EnablePasswordRetrieval deve essere true)",
    errorExistsWithoutTab: "%0% esiste già",
    errorHeader: "Si sono verificati degli errori:",
    errorHeaderWithoutTab: "Si sono verificati degli errori:",
    errorInPasswordFormat: "La password deve essere lunga almeno %0% caratteri e deve contenere almeno %1% carattere(i) non alfanumerico(i)",
    errorIntegerWithoutTab: "%0% deve essere un intero",
    errorMandatory: "%0% nella tab %1% è un campo obbligatorio",
    errorMandatoryWithoutTab: "%0% è un campo obbligatorio",
    errorRegExp: "%0% in %1% non è un formato corretto",
    errorRegExpWithoutTab: "%0% non è un formato corretto"
  },
  errors: {
    receivedErrorFromServer: "È stato ricevuto un errore dal server",
    dissallowedMediaType: "Il tipo di file specificato è stato disabilitato dall'amministratore",
    codemirroriewarning: "NOTA! Anche se CodeMirror è attivata per la configurazione, è disattivato in Internet Explorer perché non è abbastanza stabile.",
    contentTypeAliasAndNameNotNull: "Per favore compila entrambi i campi alias e nome sul nuovo propertytype!",
    filePermissionsError: "Si è verificato un problema nella lettura/scrittura di un file o di una cartella",
    macroErrorLoadingPartialView: "Errore durante il caricamento di una Partial View script (file: %0%)",
    missingTitle: "Per favore inserisci un titolo",
    missingType: "Per favore scegli un tipo",
    pictureResizeBiggerThanOrg: "Stai allargano l'immagine più dell'originale. Sei sicuro che vuoi procedere?",
    startNodeDoesNotExists: "Nodo iniziale cancellato, per favore contatta il tuo amministratore",
    stylesMustMarkBeforeSelect: "Per favore evidenzia il contenuto prima di cambiare lo stile",
    stylesNoStylesOnPage: "Nessuno stile attivo disponibile",
    tableColMergeLeft: "Per favore posiziona il cursore a sinistra delle due celle che desideri unire ",
    tableSplitNotSplittable: "Non puoi dividere una cella che non è stata unita.",
    propertyHasErrors: "Questa proprietà non è valida"
  },
  general: {
    options: "Opzioni",
    about: "Info",
    action: "Azione",
    actions: "Azioni",
    add: "Aggiungi",
    alias: "Alias",
    all: "Tutti",
    areyousure: "Sei sicuro?",
    back: "Indietro",
    backToOverview: "Torna alla panoramica",
    border: "Bordo",
    by: "o",
    cancel: "Annulla",
    cellMargin: "Margine Cella (cell margin)",
    choose: "Scegli",
    clear: "Pulisci",
    close: "Chiudi",
    closewindow: "Chiudi la finestra",
    closepane: "Chiudi il pannello",
    comment: "Commento",
    confirm: "Conferma",
    constrain: "Vincola",
    constrainProportions: "Vincola le proporzioni",
    content: "Contenuto",
    continue: "Continua",
    copy: "Copia",
    create: "Crea",
    cropSection: "Selezione di ritaglio",
    database: "Database",
    date: "Data",
    default: "Default",
    delete: "Elimina",
    deleted: "Eliminato",
    deleting: "Eliminazione...",
    design: "Design",
    dictionary: "Dizionario",
    dimensions: "Dimensioni",
    discard: "Scarta",
    down: "Giù",
    download: "Scarica",
    edit: "Modifica",
    edited: "Modificato",
    elements: "Elementi",
    email: "Email",
    error: "Errore",
    field: "Campo",
    findDocument: "Trova",
    first: "Primo",
    focalPoint: "Punto focale",
    general: "Generale",
    groups: "Gruppi",
    group: "Gruppo",
    height: "Altezza",
    help: "Guida",
    hide: "Nascondi",
    history: "Cronologia",
    icon: "Icona",
    id: "Id",
    import: "Importa",
    includeFromsubFolders: "Includi le sottocartelle nella ricerca",
    excludeFromSubFolders: "Cerca solo in questa cartella",
    info: "Info",
    innerMargin: "Margine interno (inner margin)",
    insert: "Inserisci",
    install: "Installa",
    invalid: "Non valido",
    justify: "Giustificato",
    label: "Etichetta",
    language: "Lingua",
    last: "Ultimo",
    layout: "Layout",
    links: "Links",
    loading: "Caricamento",
    locked: "Bloccato",
    login: "Login",
    logoff: "Log off",
    logout: "Logout",
    macro: "Macro",
    mandatory: "Obbligatorio",
    message: "Messaggio",
    move: "Sposta",
    name: "Nome",
    new: "Nuovo",
    next: "Successivo",
    no: "No",
    of: "di",
    off: "Off",
    ok: "Ok",
    open: "Apri",
    on: "On",
    or: "o",
    orderBy: "Ordina per",
    password: "Password",
    path: "Percorso",
    pleasewait: "Attendere prego...",
    previous: "Precedente",
    properties: "Proprietà",
    rebuild: "Ricompila",
    reciept: "Email per ricevere i dati del modulo",
    recycleBin: "Cestino",
    recycleBinEmpty: "Il cestino è vuoto",
    reload: "Ricarica",
    remaining: "Rimangono",
    remove: "Rimuovi",
    rename: "Rinomina",
    renew: "Rinnova",
    required: "Obbligatorio",
    retrieve: "Recupera",
    retry: "Riprova",
    rights: "Permessi",
    scheduledPublishing: "Pubblicazione programmata",
    search: "Cerca",
    searchNoResult: "Spiacenti, non riusciamo a trovare quello che stai cercando.",
    noItemsInList: "Non è stato aggiunto nessun elemento",
    server: "Server",
    settings: "Impostazioni",
    show: "Mostra",
    showPageOnSend: "Mostra la pagina inviata",
    size: "Dimensione",
    sort: "Ordina",
    status: "Stato",
    submit: "Conferma",
    success: "Riuscito",
    type: "Tipo",
    typeToSearch: "Digita per cercare...",
    under: "sotto",
    up: "Su",
    update: "Aggiorna",
    upgrade: "Aggiornamento",
    upload: "Carica",
    url: "URL",
    user: "Utente",
    username: "Username",
    value: "Valore",
    view: "Vedi",
    welcome: "Benvenuto...",
    width: "Larghezza",
    yes: "Si",
    folder: "Cartella",
    searchResults: "Risultati di ricerca",
    reorder: "Riordina",
    reorderDone: "Ho finito di riordinare",
    preview: "Anteprima",
    changePassword: "Cambia password",
    to: "a",
    listView: "Vista lista",
    saving: "Salvataggio...",
    current: "corrente",
    embed: "Incorpora",
    selected: "selezionato",
    other: "Altro",
    articles: "Articoli",
    videos: "Video",
    installing: "Installazione",
    avatar: "Avatar per"
  },
  colors: {
    blue: "Blu"
  },
  shortcuts: {
    addGroup: "Aggiungi gruppo",
    addProperty: "Aggiungi proprietà",
    addEditor: "Aggiungi editor",
    addTemplate: "Aggiungi template",
    addChildNode: "Aggiungi nodo figlio",
    addChild: "Aggiungi figlio",
    editDataType: "Modifica tipo di dato",
    navigateSections: "Naviga tra le sezioni",
    shortcut: "Scorciatoie",
    showShortcuts: "vedi scorciatoie",
    toggleListView: "Attiva/disattiva vista lista",
    toggleAllowAsRoot: "Attiva/disattiva consenti come root",
    commentLine: "Commenta/Non commentare righe",
    removeLine: "Rimuovi riga",
    copyLineUp: "Copia linee sopra",
    copyLineDown: "Copia linee sotto",
    moveLineUp: "Sposta linee in su",
    moveLineDown: "Sposta linee in giù",
    generalHeader: "Generale",
    editorHeader: "Editor",
    toggleAllowCultureVariants: "Attiva/disattiva consenti varianti lingua",
    toggleAllowSegmentVariants: "Attiva/disattiva la segmentazione"
  },
  graphicheadline: {
    backgroundcolor: "Colore di sfondo",
    bold: "Grassetto",
    color: "Colore del testo",
    font: "Carattere",
    text: "Testo"
  },
  headers: {
    page: "Pagina"
  },
  installer: {
    databaseErrorCannotConnect: "L'installer non può connettersi al database.",
    databaseFound: "Database trovato ed identificato come",
    databaseHeader: "Configurazione database",
    databaseInstall: `
      Premi il tasto <strong>installa</strong> per installare il database Umbraco %0%
    `,
    databaseInstallDone: "Umbraco %0% è stato copiato nel tuo database. Premi <strong>Avanti</strong> per proseguire.",
    databaseText: `Per completare questo passaggio, devi conoscere alcune informazioni riguardanti il tuo database server ("connection string").<br />
        Se è necessario contatta il tuo ISP per reperire le informazioni necessarie.
        Se stai effettuando l'installazione in locale o su un server, puoi richiederle al tuo amministratore di sistema.`,
    databaseUpgrade: `
        		<p>
        		Premi il tasto <strong>aggiorna</strong> per aggiornare il database ad Umbraco %0%</p>
        		<p>
        		Non preoccuparti, il contenuto non verrà perso e tutto continuerà a funzionare dopo l'aggiornamento!
        		</p>
        	`,
    databaseUpgradeDone: `Il tuo database è stato aggiornato all'ultima versione %0%.<br />Premi il tasto <strong>Avanti</strong> per
        continuare. `,
    databaseUpToDate: "Il tuo database è aggiornato!. Clicca il tasto <strong>Avanti</strong> per continuare la configurazione.",
    defaultUserChangePass: "<strong>La password predefinita per l'utente di default deve essere cambiata!</strong>",
    defaultUserDisabled: "<strong>L'utente di default è stato disabilitato o non ha accesso ad Umbraco!</strong></p><p>Non è necessario eseguire altre operazioni. Clicca il tasto <strong>Avanti</strong> per continuare.",
    defaultUserPassChanged: "<strong>La password dell'utente di default è stata modificata con successo</strong></p><p>Non è necessario eseguire altre operazioni. Clicca il tasto <strong>Avanti</strong> per continuare.",
    defaultUserPasswordChanged: "La password è stata modificata!",
    greatStart: "Parti alla grande, guarda i nostri video introduttivi",
    None: "Ancora non installato.",
    permissionsAffectedFolders: "File e directory interessati",
    permissionsAffectedFoldersMoreInfo: "Ulteriori informazioni sull'impostazione dei permessi per Umbraco qui",
    permissionsAffectedFoldersText: "Devi autorizzare l'utente ASP.NET a modificare i seguenti files/cartelle",
    permissionsAlmostPerfect: `<strong>La configurazione dei permessi è quasi perfetta!</strong><br /><br />
        	Puoi eseguire Umbraco senza problemi, ma non sarai in grado di installare i pacchetti che sono consigliati per sfruttare a pieno le potenzialità di Umbraco.`,
    permissionsHowtoResolve: "Risoluzione del problema",
    permissionsHowtoResolveLink: "Clicca qui per leggere la versione testuale",
    permissionsHowtoResolveText: "Guarda il nostro <strong>video tutorial</strong> su come impostare i permessi delle cartelle per Umbraco o leggi la versione testuale.",
    permissionsMaybeAnIssue: `<strong>Le impostazioni dei permessi potrebbero avere dei problemi!</strong>
        	<br/><br />
        	Puoi eseguire Umbraco senza problemi, ma non sarai in grado di creare cartelle o installare pacchetti che sono consigliati per sfruttare a pieno le potenzialità di Umbraco.`,
    permissionsNotReady: `<strong>Le impostazioni dei permessi non sono corrette per Umbraco!</strong>
        	<br /><br />
        	Per eseguire Umbraco, devi aggiornare le impostazioni dei permessi.`,
    permissionsPerfect: `<strong>La configurazione dei permessi è perfetta!</strong><br /><br />
        	Sei pronto per avviare Umbraco e installare i pacchetti!`,
    permissionsResolveFolderIssues: "Risolvere il problema sulle cartelle",
    permissionsResolveFolderIssuesLink: "Clicca questo link per ulteriori informazioni sui problemi con ASP.NET e la creazione di cartelle.",
    permissionsSettingUpPermissions: "Impostazione dei permessi delle cartelle",
    permissionsText: `
        		Per poter archiviare file come immagini e PDF, Umbraco deve avere accesso in scrittura/modifica ad alcune directory.
        		Inoltre per incrementare le prestazioni del tuo sito, deve essere possibile memorizzare informazioni temporanee (es: cache).
        	`,
    runwayFromScratch: "Voglio partire da zero",
    runwayFromScratchText: `
        		Il tuo sito al momento è completamente vuoto, e questo è il punto di partenza ideale per creare da zero i tuoi tipi documento e i tuoi templates.
        		(<a href="https://umbraco.tv/documentation/videos/for-site-builders/foundation/document-types">Guarda come</a>)
        		Puoi anche installare eventuali Runway in un secondo momento. Vai nella sezione Developer e scegli Pacchetti.
        	`,
    runwayHeader: "Hai configurato una versione pulita della piattaforma Umbraco. Cosa vuoi fare adesso?",
    runwayInstalled: "Runway è installato",
    runwayInstalledText: `
      			Hai le basi. Seleziona quali moduli vorresti installare.<br />
      			Questa è la lista dei nostri moduli raccomandati, seleziona quali vorresti installare, o vedi <a href="#" onclick="toggleModules(); return false;" id="toggleModuleList">l'intera lista di moduli</a>
      		`,
    runwayOnlyProUsers: "Raccommandato solo per utenti esperti",
    runwaySimpleSite: "Vorrei iniziare da un sito semplice",
    runwaySimpleSiteText: `
      <p>
      "Runway" è un semplice sito web contenente alcuni tipi di documento e alcuni templates di base. L'installer configurerà Runway per te automaticamente,
        ma tu potrai facilmente modificarlo, estenderlo o eliminarlo. Non è necessario installarlo e potrai usare Umbraco anche senza di esso, ma
        Runway ti offre le basi e le best practices per cominciare velocemente.
        Se sceglierai di installare Runway, volendo potrai anche selezionare i moduli di Runway per migliorare le pagine.
        </p>
        <small>
        <em>Inclusi in Runway:</em> Home page, pagina Guida introduttiva, pagina Installazione moduli<br />
        <em>Moduli opzionali:</em> Top Navigation, Sitemap, Contatti, Gallery.
        </small>
      `,
    runwayWhatIsRunway: "Cos'è Runway",
    step1: "Passo 1/5 Accettazione licenza",
    step2: "Passo 2/5: Configurazione database",
    step3: "Passo 3/5: Controllo permessi dei file",
    step4: "Passo 4/5: Controllo impostazioni sicurezza",
    step5: "Passo 5/5: Umbraco è pronto per iniziare",
    thankYou: "Grazie per aver scelto Umbraco",
    theEndBrowseSite: `<h3>Naviga per il tuo nuovo sito</h3>
Hai installato Runway, quindi perché non dare uno sguardo al vostro nuovo sito web.`,
    theEndFurtherHelp: `<h3>Ulteriori informazioni e assistenza</h3>
Fatti aiutare dalla nostra community, consulta la documentazione o guarda alcuni video gratuiti su come costruire un semplice sito web, come usare i pacchetti e una guida rapida alla terminologia Umbraco`,
    theEndHeader: "Umbraco %0% è installato e pronto per l'uso",
    theEndInstallSuccess: `Puoi <strong>iniziare immediatamente</strong> cliccando sul bottone "Avvia Umbraco". <br />Se sei <strong>nuovo su Umbraco</strong>,
        	si possono trovare un sacco di risorse sulle nostre pagine Getting Started.`,
    theEndOpenUmbraco: `<h3>Avvia Umbraco</h3>
Per gestire il tuo sito web, è sufficiente aprire il backoffice di Umbraco e iniziare ad aggiungere i contenuti, aggiornando i modelli e i fogli di stile o aggiungere nuove funzionalità`,
    Unavailable: "Connessione al database non riuscita.",
    Version3: "Umbraco Versione 3",
    Version4: "Umbraco Versione 4",
    watch: "Guarda",
    welcomeIntro: `Questa procedura guidata ti guiderà attraverso il processo di configurazione di <strong>Umbraco %0%</strong> per una nuova installazione o per l'aggiornamento dalla versione 3.0.
                                <br /><br />
                                Clicca <strong>"avanti"</strong> per avviare la procedura.`
  },
  language: {
    cultureCode: "Codice cultura",
    displayName: "Nome cultura"
  },
  lockout: {
    lockoutWillOccur: "Sei stato inattivo, si verificherà quindi un logout automatico tra",
    renewSession: "Riconnetti adesso per salvare il tuo lavoro"
  },
  login: {
    greeting0: "Benvenuto",
    greeting1: "Benvenuto",
    greeting2: "Benvenuto",
    greeting3: "Benvenuto",
    greeting4: "Benvenuto",
    greeting5: "Benvenuto",
    greeting6: "Benvenuto",
    instruction: "Fai il login qui sotto",
    signInWith: "Fai il login con",
    timeout: "Sessione scaduta",
    bottomText: '<p style="text-align:right;">&copy; 2001 - %0% <br /><a href="https://umbraco.com" style="text-decoration: none" target="_blank" rel="noopener">umbraco.com</a></p> ',
    forgottenPassword: "Password dimenticata?",
    forgottenPasswordInstruction: "Una email verrà inviata all'indirizzo specificato con un link per il reset della password",
    requestPasswordResetConfirmation: "Un'e-mail con le istruzioni per il reset della password verrà inviata all'indirizzo specificato se registrato.",
    showPassword: "Mostra password",
    hidePassword: "Nascondi password",
    returnToLogin: "Ritorna alla finestra di login",
    setPasswordInstruction: "Inserisci una nuova password",
    setPasswordConfirmation: "La tua password è stata modificata",
    resetCodeExpired: "Il link su cui hai cliccato non è valido o è scaduto",
    resetPasswordEmailCopySubject: "Umbraco: Reset Password",
    resetPasswordEmailCopyFormat: `
        <html>
			<head>
				<meta name='viewport' content='width=device-width'>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
			</head>
			<body class='' style='font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; color: #392F54; line-height: 22px; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background: #1d1333; margin: 0; padding: 0;' bgcolor='#1d1333'>
				<style type='text/css'> @media only screen and (max-width: 620px) {table[class=body] h1 {font-size: 28px !important; margin-bottom: 10px !important; } table[class=body] .wrapper {padding: 32px !important; } table[class=body] .article {padding: 32px !important; } table[class=body] .content {padding: 24px !important; } table[class=body] .container {padding: 0 !important; width: 100% !important; } table[class=body] .main {border-left-width: 0 !important; border-radius: 0 !important; border-right-width: 0 !important; } table[class=body] .btn table {width: 100% !important; } table[class=body] .btn a {width: 100% !important; } table[class=body] .img-responsive {height: auto !important; max-width: 100% !important; width: auto !important; } } .btn-primary table td:hover {background-color: #34495e !important; } .btn-primary a:hover {background-color: #34495e !important; border-color: #34495e !important; } .btn  a:visited {color:#FFFFFF;} </style>
				<table border="0" cellpadding="0" cellspacing="0" class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;" bgcolor="#1d1333">
					<tr>
						<td style="font-family: sans-serif; font-size: 14px; vertical-align: top; padding: 24px;" valign="top">
							<table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;">
								<tr>
									<td background="https://umbraco.com/umbraco/assets/img/application/logo.png" bgcolor="#1d1333" width="28" height="28" valign="top" style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
										<!--[if gte mso 9]> <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:30px;height:30px;"> <v:fill type="tile" src="https://umbraco.com/umbraco/assets/img/application/logo.png" color="#1d1333" /> <v:textbox inset="0,0,0,0"> <![endif]-->
										<div> </div>
										<!--[if gte mso 9]> </v:textbox> </v:rect> <![endif]-->
									</td>
									<td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top"></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;' bgcolor='#1d1333'>
					<tr>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
						<td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 560px; width: 560px; margin: 0 auto; padding: 10px;' valign='top'>
							<div class='content' style='box-sizing: border-box; display: block; max-width: 560px; margin: 0 auto; padding: 10px;'>
								<br>
								<table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; border-radius: 3px; background: #FFFFFF;' bgcolor='#FFFFFF'>
									<tr>
										<td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 50px;' valign='top'>
											<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
												<tr>
													<td style='line-height: 24px; font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'>
														<h1 style='color: #392F54; font-family: sans-serif; font-weight: bold; line-height: 1.4; font-size: 24px; text-align: left; text-transform: capitalize; margin: 0 0 30px;' align='left'>
															Reset della password richiesto
														</h1>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Il tuo username per effettuare l'accesso al backoffice di Umbraco è: <strong>%0%</strong>
														</p>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
																<tbody>
																	<tr>
																		<td style='font-family: sans-serif; font-size: 14px; vertical-align: top; border-radius: 5px; text-align: center; background: #35C786;' align='center' bgcolor='#35C786' valign='top'>
																			<a href='%1%' target='_blank' rel='noopener' style='color: #FFFFFF; text-decoration: none; -ms-word-break: break-all; word-break: break-all; border-radius: 5px; box-sizing: border-box; cursor: pointer; display: inline-block; font-size: 14px; font-weight: bold; text-transform: capitalize; background: #35C786; margin: 0; padding: 12px 30px; border: 1px solid #35c786;'>
																				Clicca questo link per resettare la password
																			</a>
																		</td>
																	</tr>
																</tbody>
															</table>
														</p>
														<p style='max-width: 400px; display: block; color: #392F54; font-family: sans-serif; font-size: 14px; line-height: 20px; font-weight: normal; margin: 15px 0;'>Se non riesci a cliccare sul link, copia e incolla questo URL nella finestra del browser:</p>
															<table border='0' cellpadding='0' cellspacing='0'>
																<tr>
																	<td style='-ms-word-break: break-all; word-break: break-all; font-family: sans-serif; font-size: 11px; line-height:14px;'>
																		<font style="-ms-word-break: break-all; word-break: break-all; font-size: 11px; line-height:14px;">
																			<a style='-ms-word-break: break-all; word-break: break-all; color: #392F54; text-decoration: underline; font-size: 11px; line-height:15px;' href='%1%'>%1%</a>
																		</font>
																	</td>
																</tr>
															</table>
														</p>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
								<br><br><br>
							</div>
						</td>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
					</tr>
				</table>
			</body>
		</html>
	`
  },
  main: {
    dashboard: "Dashboard",
    sections: "Sezioni",
    tree: "Contenuto"
  },
  moveOrCopy: {
    choose: "Scegli la pagina sopra...",
    copyDone: "%0% è stato copiato in %1%",
    copyTo: "Seleziona dove il documento %0% deve essere copiato",
    moveDone: "%0% è stato spostato in %1%",
    moveTo: "Seleziona dove il documento %0% deve essere spostato",
    nodeSelected: "è stato selezionato come radice del nuovo contenuto, clicca 'ok' per proseguire.",
    noNodeSelected: "Nessun nodo selezionato, si prega di selezionare un nodo nella lista di cui sopra prima di fare click su 'ok'",
    notAllowedByContentType: "Non è possibile associare questo tipo di nodo sotto il nodo selezionato.",
    notAllowedByPath: "Il nodo corrente non può essere spostato in un'altra sua sottopagina",
    notAllowedAtRoot: "Il nodo corrente non può esistere nella root",
    notValid: "Quest'azione non è consentita dato che non hai i permessi su uno o più documenti figlio.",
    relateToOriginal: "Collega gli elementi copiati all'originale"
  },
  notifications: {
    editNotifications: "Modifica le tue notifiche per %0%",
    notificationsSavedFor: "Impostazioni di notifica salvate per %0%",
    notifications: "Notifiche"
  },
  packager: {
    actions: "Azioni",
    created: "Creati",
    createPackage: "Crea pacchetto",
    chooseLocalPackageText: `
      Scegli un pacchetto dal tuo computer cliccando il pulsante Sfoglia<br />
         e selezionando il pacchetto. I pacchetti Umbraco generalmente hanno l'estensione ".umb" o ".zip".
      `,
    deletewarning: "Questo eliminerà il pacchetto",
    dropHere: "Trascina qui caricare",
    includeAllChildNodes: "Includi tutti i figli",
    orClickHereToUpload: "o clicca qui per scegliere il file del pacchetto",
    uploadPackage: "Carica pacchetto",
    localPackageDescription: `Installa un pacchetto locale dalla tua macchina. Installa solamente pacchetti
      di cui ti fidi e ne conosci la provenienza
    `,
    uploadAnother: "Carica un altro pacchetto",
    cancelAndUploadAnother: "Cancella e carica un altro pacchetto",
    accept: "Accetto",
    termsOfUse: "termini di servizio",
    pathToFile: "Percorso del file",
    pathToFileDescription: "Percorso assoluto del file (es: /bin/umbraco.bin)",
    installed: "Installati",
    installedPackages: "Pacchetti installati",
    installLocal: "Installa localmente",
    installFinish: "Termina",
    noConfigurationView: "Questo pacchetto non ha una vista di configurazione",
    noPackagesCreated: "Non sono ancora stati creati pacchetti",
    noPackages: "Non hai installato nessun pacchetto",
    noPackagesDescription: "Non hai installato nessun pacchetto. Installa un pacchetto selezionandolo dalla tua macchina, oppure cerca tra i pacchetti disponibili usando l'icona <strong>'Pacchetti'</strong> in alto a destra del tuo schermo",
    packageActions: "Azioni del pacchetto",
    packageAuthorUrl: "URL dell'autore",
    packageContent: "Contenuto del pacchetto",
    packageFiles: "Files del pacchetto",
    packageIconUrl: "URL dell'icona",
    packageInstall: "Installa pacchetto",
    packageLicense: "Licenza",
    packageLicenseUrl: "URL della licenza",
    packageProperties: "Proprietà del pacchetto",
    packageSearch: "Cerca un pacchetto...",
    packageSearchResults: "Risultati per",
    packageNoResults: "Non abbiamo trovato niente per",
    packageNoResultsDescription: `Per favore prova a cercare un altro pacchetto oppure cerca tra le
      categorie
    `,
    packagesPopular: "Popolari",
    packagesNew: "Nuove uscite",
    packageHas: "ha",
    packageKarmaPoints: "punti karma",
    packageInfo: "Informazioni",
    packageOwner: "Proprietario",
    packageContrib: "Contributori",
    packageCreated: "Creato",
    packageCurrentVersion: "Versione corrente",
    packageNetVersion: "Versione .NET",
    packageDownloads: "Downloads",
    packageLikes: "Likes",
    packageCompatibility: "Compatibilità",
    packageCompatibilityDescription: "Questo pacchetto è compatibile con le seguenti versioni di Umbraco, come riportato dai membri della community. La piena compatibilità non può essere garantita per le versioni con un giudizio inferiore al 100%",
    packageExternalSources: "Sorgenti esterne",
    packageAuthor: "Autore",
    packageDocumentation: "Documentazione",
    packageMetaData: "Meta dati del pacchetto",
    packageName: "Nome del pacchetto",
    packageNoItemsHeader: "Il pacchetto non contiene nessun elemento",
    packageNoItemsText: `Questo pacchetto non contiene elementi da disinstallare.<br/><br/>
      È possibile rimuovere questo pacchetto dal sistema cliccando "rimuovi pacchetto" in basso.`,
    packageOptions: "Opzioni del pacchetto",
    packageReadme: "Pacchetto leggimi",
    packageRepository: "Repository del pacchetto",
    packageUninstallConfirm: "Conferma eliminazione",
    packageUninstalledHeader: "Il pacchetto è stato disinstallato",
    packageUninstalledText: "Il pacchetto è stato disinstallato con successo",
    packageUninstallHeader: "Disinstalla pacchetto",
    packageUninstallText: `È possibile deselezionare gli elementi che non si desidera rimuovere, in questo momento, in basso. Quando si fa click su "Conferma eliminazione" verranno rimossi tutti gli elementi selezionati.<br />
      <span style="color: Red; font-weight: bold;">Avviso:</span> tutti i documenti, i media, etc a seconda degli elementi che rimuoverai, smetteranno di funzionare, e potrebbero portare a un'instabilità del sistema,
      perciò disinstalla con cautela. In caso di dubbio contattare l'autore del pacchetto.`,
    packageVersion: "Versione del pacchetto",
    packageVersionUpgrade: "Aggiornamento dalla versione",
    packageAlreadyInstalled: "Pacchetto già installato",
    targetVersionMismatch: "Questo pacchetto non può essere installato poichè richiede almeno Umbraco",
    installStateUninstalling: "Sto disinstallando...",
    installStateDownloading: "Sto scaricando...",
    installStateImporting: "Sto importando...",
    installStateInstalling: "Sto installando...",
    installStateRestarting: "Sto riavviando, per favore aspetta...",
    installStateComplete: "Completato, la tua pagina verrà ora ricaricata, aspetta...",
    installStateCompleted: `Per favore clicca 'Completa' per completare l'installazione e ricaricare la
      pagina.
    `,
    installStateUploading: "Sto effettuando l'upload del pacchetto...",
    verifiedToWorkOnUmbracoCloud: "Verificato il funzionamento su Umbraco Cloud"
  },
  paste: {
    doNothing: "Incolla con tutte le formattazioni (Non consigliato)",
    errorMessage: "Il testo che stai cercando di incollare contiene caratteri speciali o una formattazione. Questo potrebbe essere causato da Microsoft Word. Umbraco può rimuovere carattere speciali o formattazioni automaticamente, per rendere il contenuto da incollare più adatto per il web.",
    removeAll: "Incolla come testo semplice senza alcuna formattazione",
    removeSpecialFormattering: "Incolla, ma rimuove  la formattazione (Consigliato)"
  },
  publicAccess: {
    paGroups: "Protezione basata su gruppi",
    paGroupsHelp: "Se vuoi controllare gli accessi usando i gruppi di membri",
    paGroupsNoGroups: `Devi creare un gruppo di membri prima di utilizzare l'autenticazione basata sui
      gruppi
    `,
    paErrorPage: "Pagina di Errore",
    paErrorPageHelp: "Usato quando qualcuno è connesso, ma non ha accesso",
    paHowWould: "Seleziona come restringere l'accesso alla pagina <strong>%0%</strong>",
    paIsProtected: "<strong>%0%</strong> è ora protetta",
    paIsRemoved: "Protezione rimossa da <strong>%0%</strong>",
    paLoginPage: "Pagina di Login",
    paLoginPageHelp: "Scegliere la pagina che contiene il form di login",
    paRemoveProtection: "Rimuovi la protezione...",
    paRemoveProtectionConfirm: "Sei sicuro di voler rimuovere la protezione dalla pagina <strong>%0%</strong>?",
    paSelectPages: "Seleziona le pagine che contengono il form di login e i messaggi di errore",
    paSelectGroups: "Seleziona i gruppi che hanno accesso alla pagina <strong>%0%</strong>",
    paSelectMembers: "Seleziona i membri che hanno accesso alla pagina <strong>%0%</strong>",
    paMembers: "Protezione specifica per membri",
    paMembersHelp: "Se vuoi controllare gli accessi per membri specifici"
  },
  publish: {
    invalidPublishBranchPermissions: "Permessi insufficienti per pubblicare tutti i discendenti",
    contentPublishedFailedIsTrashed: `
      %0% non può essere pubblicato perché l'elemento è nel cestino.
    `,
    contentPublishedFailedAwaitingRelease: `
      %0% non può essere pubblicato perché l'elemento ha in corso una pubblicazione programmata.
    `,
    contentPublishedFailedExpired: `
      %0% non può essere pubblicato perché l'elemento è scaduto.
    `,
    contentPublishedFailedInvalid: `
      %0% non può essere pubblicato perché alcune proprietà non hanno passato la validazione.
    `,
    contentPublishedFailedByEvent: `
      %0% non può essere pubblicato, un add-on di terze parti ha cancellato l'azione.
    `,
    contentPublishedFailedByParent: `
      %0% non può essere pubblicato perché la pagina padre non è pubblicata.
    `,
    contentPublishedFailedByMissingName: "%0% non può essere pubblicato perché manca un nome.",
    contentPublishedFailedReqCultureValidationError: "Validazione fallita per la lingua obbligatoria '%0%'. Questa lingua è stata salvata ma non pubblicata.",
    inProgress: "Pubblicazione in corso, aspetta...",
    inProgressCounter: "%0% di %1% pagine sono state pubblicate...",
    nodePublish: "%0% è stato pubblicato",
    nodePublishAll: "%0% e le relative sottopagine sono state pubblicate",
    publishAll: "Pubblica %0% e tutte le sue sottopagine",
    publishHelp: `Click <em>Pubblica</em> per pubblicare <strong>%0%</strong> e quindi rendere visibile pubblicamente il suo contenuto.<br/><br />
      Puoi pubblicare questa pagina e tutte le sue sottopagine spuntando <em>Includi le sottopagine non pubblicate</em> sotto.
      `
  },
  colorpicker: {
    noColors: "Non hai configurato nessun colore"
  },
  contentPicker: {
    allowedItemTypes: "Puoi selezionare solo oggetti di tipo: %0%",
    pickedTrashedItem: "Hai selezionato un elemento eliminato o nel cestino",
    pickedTrashedItems: "Hai selezionato più elementi eliminati o nel cestino"
  },
  mediaPicker: {
    deletedItem: "Elemento eliminato",
    pickedTrashedItem: "Hai selezionato un media eliminato o nel cestino",
    pickedTrashedItems: "Hai selezionato più elementi eliminati o nel cestino",
    trashed: "Eliminato",
    openMedia: "Apri nella libreria dei media",
    changeMedia: "Cambia media",
    resetMediaCrop: "Resetta i tagli del media",
    editMediaEntryLabel: "Modifica %0% su %1%",
    confirmCancelMediaEntryCreationHeadline: "Scartare la creazione?",
    confirmCancelMediaEntryCreationMessage: "Sei sicuro di voler cancellare la creazione?",
    confirmCancelMediaEntryHasChanges: `Hai fatto delle modifiche a questo contenuto. Sei sicuro di volerle
      scartare?
    `,
    confirmRemoveMediaEntryMessage: "Rimuovere?",
    confirmRemoveAllMediaEntryMessage: "Rimuovere tutti i media?",
    tabClipboard: "Appunti",
    notAllowed: "Non permesso"
  },
  relatedlinks: {
    enterExternal: "Aggiungi link esterno",
    chooseInternal: "Aggiungi link interno",
    caption: "Didascalia",
    link: "Link",
    newWindow: "Apri in una nuova finestra",
    captionPlaceholder: "inserisci la didascalia da visualizzare",
    externalLinkPlaceholder: "Inserisci il link"
  },
  imagecropper: {
    reset: "Resetta tagio",
    saveCrop: "Salva taglio",
    addCrop: "Aggiungi nuovo taglio",
    updateEditCrop: "Fatto",
    undoEditCrop: "Annulla modifiche",
    customCrop: "Definite dall'utente"
  },
  rollback: {
    changes: "Modifiche",
    headline: "Seleziona una versione da confrontare con la versione corrente",
    diffHelp: "Qui vengono mostrate le differenze tra la versione corrente e la versione selezionata<br />Il testo <del>in rosso</del> non verrà mostrato nella versione selezionata, <ins>quello in verde verrà aggiunto</ins>",
    documentRolledBack: "Il documento è stato riportato alla versione scelta.",
    htmlHelp: "Qui viene mostrata la versione selezionata in formato html, se vuoi vedere contemporaneamente le differenze tra le due versioni, usa la modalità diff view",
    rollbackTo: "Ritorna alla versione",
    selectVersion: "Seleziona la versione",
    view: "Vedi"
  },
  scripts: {
    editscript: "Modifica il file di script"
  },
  sections: {
    content: "Contenuto",
    forms: "Forms",
    media: "Media",
    member: "Membri",
    packages: "Pacchetti",
    settings: "Impostazioni",
    translation: "Traduzione",
    users: "Utenti"
  },
  help: {
    tours: "Tours",
    theBestUmbracoVideoTutorials: "I migliori video tutorial su Umbraco",
    umbracoForum: "Visita our.umbraco.com",
    umbracoTv: "Visita umbraco.tv"
  },
  settings: {
    defaulttemplate: "Template di base",
    importDocumentTypeHelp: 'Importa  un tipo di documento, trova il file con estensione ".udt" sul tuo computer dopo aver cliccato il pulsante "Sfoglia" e poi clicca  "Importa" (ti chiederà una conferma nella prossima schermata)',
    newtabname: "Titolo nuova tab",
    nodetype: "Tipo di nodo",
    objecttype: "Tipo",
    stylesheet: "Foglio di stile",
    script: "Script",
    tab: "Tab",
    tabname: "Titolo tab",
    tabs: "Tabs",
    contentTypeEnabled: "Tipo di contenuto Master abilitato",
    contentTypeUses: "Questo tipo di contenuto usa",
    noPropertiesDefinedOnTab: 'Non ci sono proprietà definite per questa tab. Clicca sul link "aggiungi una nuova proprietà" in cima per creare una nuova proprietà.',
    createMatchingTemplate: "Crea un template corrispondente",
    addIcon: "Aggiungi icona"
  },
  sort: {
    sortOrder: "Ordinamento",
    sortCreationDate: "Data creazione",
    sortDone: "Ordinamento completato.",
    sortHelp: "Sposta su o giù le pagine trascinandole per determinarne l'ordinamento. Oppure clicca la testata della colonna per ordinare l'intero gruppo di pagine",
    sortPleaseWait: "Si prega di attendere. Gli elementi sono in fase di ordinamento, questo può richiedere del tempo.",
    sortEmptyState: "Questo elemento non ha elementi figlio da ordinare"
  },
  speechBubbles: {
    validationFailedHeader: "Validazione",
    validationFailedMessage: `Gli errori di validazione devono essere sistemati prima che l'elemento possa
      essere salvato
    `,
    operationFailedHeader: "Fallita",
    operationSavedHeader: "Salvato",
    operationSavedHeaderReloadUser: "Salvato. Per vedere le modifiche appena salvate ricarica la pagina",
    invalidUserPermissionsText: "Permessi utente non sufficienti, non è stato possibile completare l'operazione",
    operationCancelledHeader: "Cancellato",
    operationCancelledText: "L'operazione è stata cancellata da un add-on di terze parti",
    contentTypeDublicatePropertyType: "Tipo di proprietà già esistente",
    contentTypePropertyTypeCreated: "Tipo di proprietà creato",
    contentTypePropertyTypeCreatedText: "Nome: %0% <br /> Tipo di dato: %1%",
    contentTypePropertyTypeDeleted: "Tipo di proprietà eliminato",
    contentTypeSavedHeader: "Tipo di documento salvato",
    contentTypeTabCreated: "Tab creata",
    contentTypeTabDeleted: "Tab eliminata",
    contentTypeTabDeletedText: "Tab con id: %0% eliminata",
    cssErrorHeader: "Foglio di stile non salvato",
    cssSavedHeader: "Foglio di stile salvato",
    cssSavedText: "Foglio di stile salvato correttamente",
    dataTypeSaved: "Tipo di dato salvato",
    dictionaryItemSaved: "Elemento del dizionario salvato",
    editContentPublishedHeader: "Contenuto pubblicato",
    editContentPublishedText: "e visibile sul sito web",
    editMultiContentPublishedText: "%0% documenti pubblicati e visibili sul sito web",
    editVariantPublishedText: "%0% pubblicati e visibili sul sito web",
    editMultiVariantPublishedText: "%0% documenti pubblicati per le lingue %1% e visibili sul sito web",
    editContentSavedHeader: "Contenuto salvato",
    editContentSavedText: "Ricorda di pubblicare per rendere i cambiamenti visibili",
    editContentScheduledSavedText: "È stata aggiornata una pianificazione per la pubblicazione",
    editVariantSavedText: "%0% salvata",
    editContentSendToPublish: "Invia per l'approvazione",
    editContentSendToPublishText: "Le modifiche sono state inviate per l'approvazione",
    editVariantSendToPublishText: "%0% modifiche sono state inviate per l'approvazione",
    editMediaSaved: "Media salvato",
    editMediaSavedText: "Media salvato senza nessun errore",
    editMemberSaved: "Membro salvato",
    editMemberGroupSaved: "Gruppo di Membri salvato",
    editStylesheetPropertySaved: "Proprietà del foglio di stile salvata",
    editStylesheetSaved: "Foglio di stile salvato",
    editTemplateSaved: "Template salvato",
    editUserError: "Errore durante il salvataggio dell'utente (verifica il log)",
    editUserSaved: "Utente salvato",
    editUserTypeSaved: "Tipo di utente salvato",
    editUserGroupSaved: "Gruppo di utenti salvato",
    editCulturesAndHostnamesSaved: "Hostnames salvati",
    editCulturesAndHostnamesError: "Errore durante il salvataggio degli hostnames",
    fileErrorHeader: "File non salvato",
    fileErrorText: "Il file non può essere salvato. Controlla le impostazioni dei permessi sui file",
    fileSavedHeader: "File salvato",
    fileSavedText: "File salvato con successo!",
    languageSaved: "Lingua salvata",
    mediaTypeSavedHeader: "Tipo di Media salvato",
    memberTypeSavedHeader: "Tipo di Membro salvato",
    memberGroupSavedHeader: "Gruppo di Membri salvato",
    templateErrorHeader: "Template non salvato",
    templateErrorText: "Per favore controlla di non avere due templates con lo stesso alias",
    templateSavedHeader: "Template salvato",
    templateSavedText: "Template salvato con successo!",
    contentUnpublished: "Contenuto non pubblicato",
    contentCultureUnpublished: "Variazione di contenuto %0% non pubblicata",
    contentMandatoryCultureUnpublished: "La lingua obbligatoria '%0%' è stata non pubblicata. Tutte le lingue per questo elemento di contenuto verranno ora non pubblicate.",
    partialViewSavedHeader: "Partial view salvata",
    partialViewSavedText: "Partial view salvata senza errori!",
    partialViewErrorHeader: "Partial view non salvata",
    partialViewErrorText: "Errore durante il salvataggio del file.",
    permissionsSavedFor: "Permessi salvati per",
    deleteUserGroupsSuccess: "Eliminati %0% gruppi di utenti",
    deleteUserGroupSuccess: "%0% è stato eliminato",
    enableUsersSuccess: "Abilitati %0% utenti",
    disableUsersSuccess: "Disabilitati %0% utenti",
    enableUserSuccess: "%0% è ora abilitato",
    disableUserSuccess: "%0% è ora disabilitato",
    setUserGroupOnUsersSuccess: "I gruppi di utenti sono stati assegnati",
    unlockUsersSuccess: "Sono stati sbloccati %0% utenti",
    unlockUserSuccess: "%0% è ora sbloccato",
    memberExportedSuccess: "Il Membro è stato esportato in un file",
    memberExportedError: "Si è verificato un errore durante l'esportazione del membro",
    deleteUserSuccess: "L'utente %0% è stato eliminato",
    resendInviteHeader: "Invita utenti",
    resendInviteSuccess: "L'invito è stato reinviato a %0%",
    contentReqCulturePublishError: "Impossibile pubblicare il documento, in quanto è richiesto '%0%', ma non è pubblicato",
    contentCultureValidationError: "Validazione fallita per la lingua '%0%'",
    documentTypeExportedSuccess: "Il Tipo di Documento è stato esportato in un file",
    documentTypeExportedError: "C'è stato un errore durante l'esportazione del Tipo di Documento",
    scheduleErrReleaseDate1: "La data di rilascio non può essere passata",
    scheduleErrReleaseDate2: "Non è possibile pianificare il documento per la pubblicazione poiché è richiesto '%0%', che non è pubblicato",
    scheduleErrReleaseDate3: "Non è possibile pianificare il documento per la pubblicazione poiche '%0%' ha una data di pubblicazione posteriore di una lingua non obbligatoria",
    scheduleErrExpireDate1: "La data di scadenza non può essere passata",
    scheduleErrExpireDate2: "La data di scadenza non può essere prima della data di rilascio"
  },
  stylesheet: {
    addRule: "Aggiungi stile",
    editRule: "Modifica stile",
    editorRules: "Stili del Rich text editor",
    editorRulesHelp: `Definisci gli stili che dovranno essere disponibili nel Rich text editor per questo
      foglio di stile
    `,
    editstylesheet: "Modifica foglio di stile",
    editstylesheetproperty: "Modifica proprietà del foglio di stile",
    nameHelp: "Nome che identifica lo stile nel rich text editor",
    preview: "Anteprima",
    previewHelp: "Come il testo verrà visualizzato nel Rich text editor.",
    selector: "Selettore",
    selectorHelp: "Usa la sintassi CSS standard es: h1, .redHeader, .blueText",
    styles: "Stili",
    stylesHelp: 'Il CSS che verrà applicato nel Rich text editor, e.s. "color:red;"',
    tabCode: "Codice",
    tabRules: "Rich Text Editor"
  },
  template: {
    deleteByIdFailed: "Impossibile eliminare il template con ID %0%",
    edittemplate: "Modifica template",
    insertSections: "Sezioni",
    insertContentArea: "Inserisci area di contenuto",
    insertContentAreaPlaceHolder: "Inserisci segnaposto per l'area di contenuto",
    insert: "Inserisci",
    insertDesc: "Scegli cosa inserire nel tuo template",
    insertDictionaryItem: "Elementi del dizionario",
    insertDictionaryItemDesc: "Un elemento del dizionario è un segnaposto per un pezzo di testo traducibile, che facilita il design di siti web multi lingua.",
    insertMacro: "Macro",
    insertMacroDesc: `
            Una macro è un componente configurabile, ottimo per
            parti riusabili del tuo design, dove hai bisogno di impostare parametri diversi,
            come galleries, forms e liste.`,
    insertPageField: "Valore",
    insertPageFieldDesc: `Visualizza il valore di un campo nominato dalla pagina corrente, con delle opzioni
      per modificare il valore o impostare il valore di fallback.
    `,
    insertPartialView: "Partial view",
    insertPartialViewDesc: `
            Una partial view è un file di template separato che può essere renderizzato dentro ad un altro
            template; ottimo per il riutilizzo del markup o per separare template complessi in più files.`,
    mastertemplate: "Master template",
    noMaster: "No master",
    renderBody: "Renderizza template figli",
    renderBodyDesc: `
			     Renderizza i contenuti di un template figlio, inserendo un
			     segnaposto <code>@RenderBody()</code>.
      		`,
    defineSection: "Definisci una sezione nominata",
    defineSectionDesc: `
         Definisci una parte del tuo template come sezione nominata, avvolgendola in
          <code>@section { ... }</code>. Questa potrà poi essere renderizzata in una
          specifica area del padre di questo template, usando <code>@RenderSection</code>.
      `,
    renderSection: "Renderizza una sezione nominata",
    renderSectionDesc: `
      Renderizza una sezione nominata di un template figlio, inserendo un segnaposto <code>@RenderSection(name)</code>.
      Questo renderizzerà un'area di un template figlio avvolta nel corrispondente <code>@section [name]{ ... }</code> definition.
      `,
    sectionName: "Nome della sezione",
    sectionMandatory: "La sezione è obbligatoria",
    sectionMandatoryDesc: `
            	Se obbligatorio, il template figlio dovrà contenere una definizione <code>@section</code>, altrimenti verrà visualizzato un errore.
		    `,
    queryBuilder: "Generatore di query",
    itemsReturned: "oggetti trovati, in",
    copyToClipboard: "copia negli appunti",
    iWant: "Voglio",
    allContent: "tutti i contenuti",
    contentOfType: 'contenuti di tipo "%0%"',
    from: "da",
    websiteRoot: "il mio sito web",
    where: "dove",
    and: "e",
    is: "è",
    isNot: "non è",
    before: "prima",
    beforeIncDate: "prima (comprese le date selezionate)",
    after: "dopo",
    afterIncDate: "dopo (comprese le date selezionate)",
    equals: "è uguale a",
    doesNotEqual: "non è uguale a",
    contains: "contiene",
    doesNotContain: "non contiene",
    greaterThan: "maggiore di",
    greaterThanEqual: "maggiore di o uguale a",
    lessThan: "minore di",
    lessThanEqual: "minore di o uguale a",
    id: "Id",
    name: "Nome",
    createdDate: "Data di creazione",
    lastUpdatedDate: "Ultima data di aggiornamento",
    orderBy: "ordina per",
    ascending: "ascendente",
    descending: "discendente",
    template: "Template"
  },
  grid: {
    media: "Immagine",
    macro: "Macro",
    insertControl: "Seleziona il tipo di contenuto",
    chooseLayout: "Seleziona un layout",
    addRows: "Aggiungi una riga",
    addElement: "Aggiungi contenuto",
    dropElement: "Elimina contenuto",
    settingsApplied: "Impostazioni applicate",
    contentNotAllowed: "Questo contenuto non è consentito qui",
    contentAllowed: "Questo contenuto è consentito qui",
    clickToEmbed: "Clicca per incorporare",
    clickToInsertImage: "Clicca per inserire un immagine",
    clickToInsertMacro: "Clicca per inserire una macro",
    placeholderImageCaption: "Didascalia dell'immagine...",
    placeholderWriteHere: "Scrivi qui...",
    gridLayouts: "I Grid Layout",
    gridLayoutsDetail: `I layout sono l'area globale di lavoro per il grid editor, di solito ti servono
      solamente uno o due layout differenti
    `,
    addGridLayout: "Aggiungi un Grid Layout",
    editGridLayout: "Modifica il Grid Layout",
    addGridLayoutDetail: `Sistema il layout impostando la larghezza della colonna ed aggiungendo ulteriori
      sezioni
    `,
    rowConfigurations: "Configurazioni della riga",
    rowConfigurationsDetail: "Le righe sono le colonne predefinite disposte orizzontalmente",
    addRowConfiguration: "Aggiungi configurazione della riga",
    editRowConfiguration: "Modifica configurazione della riga",
    addRowConfigurationDetail: `Sistema la riga impostando la larghezza della colonna ed aggiungendo
      ulteriori colonne
    `,
    noConfiguration: "Nessuna ulteriore configurazione disponibile",
    columns: "Colonne",
    columnsDetails: "Totale combinazioni delle colonne nel grid layout",
    settings: "Impostazioni",
    settingsDetails: "Configura le impostazioni che possono essere cambiate dai editori",
    styles: "Stili",
    stylesDetails: "Configura i stili che possono essere cambiati dai editori",
    allowAllEditors: "Permetti tutti i editor",
    allowAllRowConfigurations: "Permetti tutte le configurazioni della riga",
    maxItems: "Oggetti massimi",
    maxItemsDescription: "Lascia vuoto o imposta a 0 per illimitati",
    setAsDefault: "Imposta come predefinito",
    chooseExtra: "Scegli aggiuntivi",
    chooseDefault: "Scegli predefinito",
    areAdded: "sono stati aggiunti",
    warning: "Attenzione",
    youAreDeleting: "Stai eliminando le configurazioni della riga",
    deletingARow: `
      Eliminando un nome della configurazione della riga perderai i dati associati a qualsiasi contenuto basato su
      questa configurazione.
    `
  },
  contentTypeEditor: {
    compositions: "Composizioni",
    group: "Gruppi",
    noGroups: "Non hai aggiunto nessun gruppo",
    addGroup: "Aggiungi gruppo",
    inheritedFrom: "Ereditato da",
    addProperty: "Aggiungi proprietà",
    requiredLabel: "Etichetta richiesta",
    enableListViewHeading: "Abilita la vista lista",
    enableListViewDescription: `Configura l'oggetto per visualizzare una lista dei suoi figli, ordinabili e
      ricercabili. I figli non saranno visualizzati nell'albero dei contenuti
    `,
    allowedTemplatesHeading: "Templates abilitati",
    allowedTemplatesDescription: `Scegli che templates sono abilitati all'utilizzo per i contenuti di questo
      tipo.
    `,
    allowAsRootHeading: "Consenti come nodo root",
    allowAsRootDescription: `Consenti agli editori la creazione di questo tipo di contenuto a livello root.
    `,
    childNodesHeading: "Tipi di nodi figlio consentiti",
    childNodesDescription: `Consenti la creazione di contenuti con i tipi specificati sotto il contenuto di
      questo tipo.
    `,
    chooseChildNode: "Scegli nodo figlio",
    compositionsDescription: "Eredita schede e proprietà da un tipo di documento esistente. Le nuove schede verranno aggiunte al tipo di documento corrente o unite se esiste una scheda con un nome identico.",
    compositionInUse: "Questo tipo di contenuto è utlizzato in una composizione, e quindi non può essere composto da se stesso.",
    noAvailableCompositions: "Non ci sono tipi di contenuto utilizzabili come composizione.",
    compositionRemoveWarning: "Rimuovendo una composizione si elimineranno tutti i dati associati ad essa. Una volta salvato il tipo di documento non ci sarà nessun modo di recuperare i dati.",
    availableEditors: "Crea nuovo",
    reuse: "Usa esistente",
    editorSettings: "Impostazioni dell'editor",
    searchResultSettings: "Configurazioni disponibili",
    searchResultEditors: "Crea una nuova configurazione",
    configuration: "Configurazione",
    yesDelete: "Si, elimina",
    movedUnderneath: "è stato spostato sotto",
    copiedUnderneath: "è stato copiato sotto",
    folderToMove: "Seleziona la cartella da spostare",
    folderToCopy: "Seleziona la cartella da copiare",
    structureBelow: "nella struttura sottostante",
    allDocumentTypes: "Tutti i tipo di documento",
    allDocuments: "Tutti i documenti",
    allMediaItems: "Tutti i media",
    usingThisDocument: `che usano questo tipo di documento verranno eliminati permanentemente, sei sicuro di
      voler eliminare anche questi?
    `,
    usingThisMedia: `che usano questo tipo di media verranno eliminati permanentemente, sei sicuro di voler
      eliminare anche questi?
    `,
    usingThisMember: `che usano questo tipo di membro verranno eliminati permanentemente, sei sicuro di voler
      eliminare anche questi?
    `,
    andAllDocuments: "e tutti i documenti che usano questo tipo",
    andAllMediaItems: "e tutti i media che usano questo tipo",
    andAllMembers: "e tutti i membri che usano questo tipo",
    memberCanEdit: "Il membro può modificare",
    memberCanEditDescription: "Abilita il membro alla modifica di questo valore dalla pagina del suo profilo.",
    isSensitiveData: "Dati sensibili",
    isSensitiveDataDescription: "Nascondi il valore di questa proprietà dagli editors che non hanno l'accesso per visualizzare i dati sensibili",
    showOnMemberProfile: "Visualizza sul profilo del membro",
    showOnMemberProfileDescription: "Permette a questo valore di essere visualizzato sulla pagina del profilo del membro",
    tabHasNoSortOrder: "la scheda non ha un ordine",
    compositionUsageHeading: "Dove è usata questa composizione?",
    compositionUsageSpecification: "Questa composizione è usata nella composizione dei seguenti tipi di contenuto:",
    variantsHeading: "Consenti variazioni",
    cultureVariantHeading: "Consenti variazioni in base alla lingua",
    segmentVariantHeading: "Consenti segmentazione",
    cultureVariantLabel: "Varia in base alla cultura",
    segmentVariantLabel: "Varia per segmenti",
    variantsDescription: `Consenti agli editors la creazione di contenuto di questo tipo in lingue
      differenti.
    `,
    cultureVariantDescription: "Consenti agli editors la creazione di contenuto in diverse lingue.",
    segmentVariantDescription: "Consenti agli editors la creazione di segmenti per questo contenuto.",
    allowVaryByCulture: "Consenti variazioni in base alla lingua",
    allowVaryBySegment: "Consenti segmentazione",
    elementType: "Tipo di elemento",
    elementHeading: "È un tipo di elemento",
    elementDescription: "Un tipo di elemento è pensato per essere usato ad esempio nel Nested Content, e non nell'albero dei nodi.",
    elementCannotToggle: "Un tipo di documento non può essere cambiato in un tipo di elemento una volta che è stato usato per creare uno o più contenuti.",
    elementDoesNotSupport: "Questo non è applicabile per un tipo di elemento",
    propertyHasChanges: "Hai fatto modifiche a questa proprietà. Sei sicuro di volerle scartare?",
    displaySettingsHeadline: "Aspetto",
    displaySettingsLabelOnTop: "Etichetta sopra (larghezza intera)"
  },
  languages: {
    addLanguage: "Aggiungi lingua",
    mandatoryLanguage: "Lingua obbligatoria",
    mandatoryLanguageHelp: "Le proprietà in questa lingua devono essere compliate prima che il nodo possa essere pubblicato.",
    defaultLanguage: "Lingua di default",
    defaultLanguageHelp: "Un sito web Umbraco può avere solo una lingua di default.",
    changingDefaultLanguageWarning: `Il cambio della lingua predefinita potrebbe comportare la mancanza di
      contenuti predefiniti.
    `,
    fallsbackToLabel: "Ripiega a",
    noFallbackLanguageOption: "Nessuna lingua alternativa",
    fallbackLanguageDescription: "Per consentire ad un contenuto multi-lingua di ripiegare su un altra lingua se il contenuto non è presente nella lingua richiesta, selezionalo qui.",
    fallbackLanguage: "Lingua alternativa",
    none: "nessuna"
  },
  macro: {
    addParameter: "Aggiungi parametro",
    editParameter: "Modifica parametro",
    enterMacroName: "Inserisci il nome della macro",
    parameters: "Parametri",
    parametersDescription: `Definisci i parametri che dovranno essere disponibili utilizzando questa macro.
    `,
    selectViewFile: "Seleziona il file partial view per la macro"
  },
  modelsBuilder: {
    buildingModels: "Compilazione modelli in corso...",
    waitingMessage: "questo potrà impiegare un po' di tempo, non preoccuparti",
    modelsGenerated: "Modelli generati",
    modelsGeneratedError: "Impossibile generare i modelli",
    modelsExceptionInUlog: `La generazione dei modelli non è andata a buon fine, consulta i log di Umbraco
    `
  },
  templateEditor: {
    addFallbackField: "Aggiungi campo alternativo",
    fallbackField: "Campo alternativo",
    addDefaultValue: "Aggiungi valore predefinito",
    defaultValue: "Valore predefinito",
    alternativeField: "Campo alternativo",
    alternativeText: "Valore predefinito",
    casing: "Maiuscole/Minuscole",
    encoding: "Codifica",
    chooseField: "Scegli il campo",
    convertLineBreaks: "Converte le interruzioni di linea",
    convertLineBreaksDescription: "Si, converti le interruzioni di linea",
    convertLineBreaksHelp: "Copia le interruzioni di linea con html-tag &lt;br&gt;",
    customFields: "Campi Personalizzati",
    dateOnly: "Solo data",
    formatAndEncoding: "Formato e codifica",
    formatAsDate: "In formato data",
    formatAsDateDescr: "Formatta il valore in data, o in data e ora, secondo la cultura corrente",
    htmlEncode: "Codifica HTML",
    htmlEncodeHelp: "Andrà a sostituire i caratteri speciali con il loro equivalente HTML.",
    insertedAfter: "Sarà inserito dopo il valore del campo",
    insertedBefore: "Sarà inserito prima del valore del campo",
    lowercase: "Minuscolo",
    modifyOutput: "Modifica output",
    none: "Nessuno",
    outputSample: "Esempio di output",
    postContent: "Inserisci dopo il campo",
    preContent: "Inserisci prima del campo",
    recursive: "Ricorsivo",
    recursiveDescr: "Si, rendilo ricorsivo",
    separator: "Separatore",
    standardFields: "Campi Standard",
    uppercase: "Maiuscolo",
    urlEncode: "Codifica URL",
    urlEncodeHelp: "Andrà a sostituire i caratteri speciali con il loro equivalente negli URL.",
    usedIfAllEmpty: "Sarà usato solo se i valori dei campi sopra sono vuoti",
    usedIfEmpty: "Questo campo sarà usato soltanto se il campo primario è vuoto",
    withTime: "Data e ora"
  },
  translation: {
    details: "Dettagli di traduzione",
    DownloadXmlDTD: "Scarica XML DTD",
    fields: "Campi",
    includeSubpages: "Includi le sottopagine",
    mailBody: `
      Ciao %0%

      Questa è un'email automatica per informarti che è stata richiesta una traduzione in '%5%' da %2%
      per il documento il documento '%1%'.

      Vai al http://%3%/translation/details.aspx?id=%4% per effettuare la modifica.

      Oppure effettua il login in Umbraco per avere una panoramica delle attività di traduzione
      http://%3%

      Buona giornata!

      Saluti dal robot di Umbraco
    `,
    noTranslators: "Non è stato trovato nessun utente con ruolo di traduttore. Crealo prima di inviare il contenuto per la traduzione",
    pageHasBeenSendToTranslation: "La pagina '%0%' è stata inviata per la traduzione",
    sendToTranslate: "Invia la pagina '%0%' per la traduzione",
    totalWords: "Totale parole",
    translateTo: "Si traduce in",
    translationDone: "Traduzione completata.",
    translationDoneHelp: "È possibile visualizzare in anteprima le pagine che hai appena tradotto, cliccando qui sotto. Se esiste la pagina originale, si otterrà un confronto tra le due pagine.",
    translationFailed: "Traduzione non riuscita, il file XML potrebbe essere danneggiato",
    translationOptions: "Opzioni di traduzione",
    translator: "Traduttore",
    uploadTranslationXml: "Carica il file xml di traduzione"
  },
  treeHeaders: {
    content: "Contenuti",
    contentBlueprints: "Modelli di contenuto",
    media: "Media",
    cacheBrowser: "Cache Browser",
    contentRecycleBin: "Cestino",
    createdPackages: "Pacchetti creati",
    dataTypes: "Tipi di dato",
    dictionary: "Dizionario",
    installedPackages: "Pacchetti installati",
    installSkin: "Installare skin",
    installStarterKit: "Installare starter kit",
    languages: "Lingue",
    localPackage: "Installa un pacchetto locale",
    macros: "Macros",
    mediaTypes: "Tipi di media",
    member: "Membri",
    memberGroups: "Gruppi di Membri",
    memberRoles: "Ruoli",
    memberTypes: "Tipi di membro",
    documentTypes: "Tipi di documento",
    relationTypes: "Tipi di relazione",
    packager: "Pacchetti",
    packages: "Pacchetti",
    partialViews: "Partial Views",
    partialViewMacros: "Macro Partial Views",
    repositories: "Installa dal repository",
    runway: "Installa Runway",
    runwayModules: "Moduli Runway",
    scripting: "Files di scripting",
    scripts: "Scripts",
    stylesheets: "Fogli di stile",
    templates: "Templates",
    logViewer: "Logs",
    users: "Utenti",
    settingsGroup: "Impostazioni",
    templatingGroup: "Templating",
    thirdPartyGroup: "Terze parti"
  },
  update: {
    updateAvailable: "Nuovo aggiornamento disponibile",
    updateDownloadText: "%0% è pronto, clicca qui per il download",
    updateNoServer: "Non connesso al server",
    updateNoServerError: "Errore di controllo per l'aggiornamento. Si prega di rivedere lo stack-trace per ulteriori informazioni"
  },
  user: {
    access: "Accesso",
    accessHelp: `Basandosi sui gruppi assegnati e sui nodi di partenza, l'utente ha accesso ai seguenti
      nodi
    `,
    assignAccess: "Assegna accessi",
    administrators: "Amministratore",
    categoryField: "Campo Categoria",
    createDate: "Utente creato il",
    changePassword: "Cambia la tua password",
    changePhoto: "Cambia foto",
    newPassword: "Nuova password",
    newPasswordFormatLengthTip: "Minimo %0% caratteri!",
    newPasswordFormatNonAlphaTip: "Dovrebbero esserci almeno %0% caratteri speciali qui.",
    noLockouts: "non è stato bloccato",
    noPasswordChange: "La password non è stata modificata",
    confirmNewPassword: "Conferma la nuova password",
    changePasswordDescription: "È possibile modificare la password di accesso al backoffice Umbraco compilando il form sottostante e clicca sul pulsante 'Modifica password'",
    contentChannel: "Contenuto del canale",
    createAnotherUser: "Crea un altro utente",
    createUserHelp: `Crea nuovi utenti per dar loro accesso a Umbraco. Quando un nuovo utente viene creato,
      una nuova password da condividere con l'utente viene generata.
    `,
    descriptionField: "Campo Descrizione",
    disabled: "Disabilita l'utente",
    documentType: "Tipo di Documento",
    editors: "Editor",
    excerptField: "Campo Eccezione",
    failedPasswordAttempts: "Tentativi di accesso falliti",
    goToProfile: "Vai al profilo dell'utente",
    groupsHelp: "Crea gruppi per assegnare gli accessi e i permessi",
    inviteAnotherUser: "Invita un altro utente",
    inviteUserHelp: "Invita nuovi utenti per dar loro l'accesso a Umbraco. Un'email contenente le informazioni su come effettuare l'accesso in Umbraco verrà inviata all'utente. Un invito dura per 72 ore.",
    language: "Lingua",
    languageHelp: "Imposta la lingua che vedrai nei menu e nei dialoghi",
    lastLockoutDate: "Data dell'ultimo blocco",
    lastLogin: "Ultimo login",
    lastPasswordChangeDate: "Ultima modifica della password",
    loginname: "Login",
    mediastartnode: "Nodo di inizio nella sezione Media",
    mediastartnodehelp: "Limita la libreria multimediale a un nodo iniziale specifico",
    mediastartnodes: "Nodi di inizio nella sezione Media",
    mediastartnodeshelp: "Limita la libreria multimediale a uno o più nodi iniziali specifici",
    modules: "Sezioni",
    noConsole: "Disabilita l'accesso ad Umbraco",
    noLogin: "non ha ancora effettuato l'accesso",
    oldPassword: "Vecchia password",
    password: "Password",
    resetPassword: "Resetta password",
    passwordChanged: "La tua password è stata cambiata!",
    passwordChangedGeneric: "Password cambiata",
    passwordConfirm: "Si prega di confermare la nuova password",
    passwordEnterNew: "Inserisci la tua nuova password",
    passwordIsBlank: "La nuova password non può essere vuota!",
    passwordCurrent: "Password attuale",
    passwordInvalid: "La password corrente non è valida",
    passwordIsDifferent: "C'è una differenza tra la nuova password e la conferma della password. Riprova!",
    passwordMismatch: "La password di conferma non corrisponde alla nuova password!",
    permissionReplaceChildren: "Sostituisci permessi sui nodi figlio",
    permissionSelectedPages: "Stai modificando i permessi per le seguenti pagine:",
    permissionSelectPages: "Seleziona le pagine alle quali vuoi modificare i permessi",
    removePhoto: "Rimuovi foto",
    permissionsDefault: "Permessi predefiniti",
    permissionsGranular: "Permessi granulari",
    permissionsGranularHelp: "Imposta i permessi per nodi specifici",
    profile: "Profilo",
    searchAllChildren: "Cerca in tutti i figli",
    sectionsHelp: "Aggiungi sezioni per cui l'utente deve avere accesso",
    selectUserGroups: "Seleziona gruppi di utenti",
    noStartNode: "Nodo di partenza non selezionato",
    noStartNodes: "Nodi di partenza non selezionati",
    startnode: "Nodo di inizio della sezione Contenuto",
    startnodehelp: "Limita l'albero dei contenuti a un nodo iniziale specifico",
    startnodes: "Nodi di inizio del contenuto",
    startnodeshelp: "Limita l'albero dei contenuti a uno o più nodi iniziali specifici",
    updateDate: "Ultimo aggiornamento utente",
    userCreated: "è stato creato",
    userCreatedSuccessHelp: "Il nuovo utente è stato creato correttamente. Per effettuare il login in Umbraco utilizza la password sottostante.",
    userManagement: "Gestione utenti",
    username: "Username",
    userPermissions: "Permessi Utente",
    usergroup: "Gruppo di utenti",
    userInvited: "è stato invitato",
    userInvitedSuccessHelp: "Un invito è stato invitato al nuovo utente con le istruzioni su come effettuare il login in Umbraco.",
    userinviteWelcomeMessage: `Ciao e benvenuto su Umbraco! In solo 1 minuto sarai pronto a partire, dovrai
      solamente impostare una password.
    `,
    userinviteExpiredMessage: "Benvenuto su Umbraco! Purtroppo il tuo invito è scaduto. Per favore contatta l'amministratore e chiedigli di rispedirlo.",
    writer: "Autore",
    change: "Modifica",
    yourProfile: "Il tuo profilo",
    yourHistory: "La tua attività recente",
    sessionExpires: "La sessione scade in",
    inviteUser: "Invita utente",
    createUser: "Crea utente",
    sendInvite: "Invia invito",
    backToUsers: "Torna agli utenti",
    inviteEmailCopySubject: "Invito per Umbraco",
    inviteEmailCopyFormat: `
        <html>
			<head>
				<meta name='viewport' content='width=device-width'>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
			</head>
			<body class='' style='font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; color: #392F54; line-height: 22px; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background: #1d1333; margin: 0; padding: 0;' bgcolor='#1d1333'>
				<style type='text/css'> @media only screen and (max-width: 620px) {table[class=body] h1 {font-size: 28px !important; margin-bottom: 10px !important; } table[class=body] .wrapper {padding: 32px !important; } table[class=body] .article {padding: 32px !important; } table[class=body] .content {padding: 24px !important; } table[class=body] .container {padding: 0 !important; width: 100% !important; } table[class=body] .main {border-left-width: 0 !important; border-radius: 0 !important; border-right-width: 0 !important; } table[class=body] .btn table {width: 100% !important; } table[class=body] .btn a {width: 100% !important; } table[class=body] .img-responsive {height: auto !important; max-width: 100% !important; width: auto !important; } } .btn-primary table td:hover {background-color: #34495e !important; } .btn-primary a:hover {background-color: #34495e !important; border-color: #34495e !important; } .btn  a:visited {color:#FFFFFF;} </style>
				<table border="0" cellpadding="0" cellspacing="0" class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;" bgcolor="#1d1333">
					<tr>
						<td style="font-family: sans-serif; font-size: 14px; vertical-align: top; padding: 24px;" valign="top">
							<table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;">
								<tr>
									<td background="https://umbraco.com/umbraco/assets/img/application/logo.png" bgcolor="#1d1333" width="28" height="28" valign="top" style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
										<!--[if gte mso 9]> <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:30px;height:30px;"> <v:fill type="tile" src="https://umbraco.com/umbraco/assets/img/application/logo.png" color="#1d1333" /> <v:textbox inset="0,0,0,0"> <![endif]-->
										<div> </div>
										<!--[if gte mso 9]> </v:textbox> </v:rect> <![endif]-->
									</td>
									<td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top"></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;' bgcolor='#1d1333'>
					<tr>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
						<td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 560px; width: 560px; margin: 0 auto; padding: 10px;' valign='top'>
							<div class='content' style='box-sizing: border-box; display: block; max-width: 560px; margin: 0 auto; padding: 10px;'>
								<br>
								<table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; border-radius: 3px; background: #FFFFFF;' bgcolor='#FFFFFF'>
									<tr>
										<td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 50px;' valign='top'>
											<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
												<tr>
													<td style='line-height: 24px; font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'>
														<h1 style='color: #392F54; font-family: sans-serif; font-weight: bold; line-height: 1.4; font-size: 24px; text-align: left; text-transform: capitalize; margin: 0 0 30px;' align='left'>
															Ciao %0%,
														</h1>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Sei stato invitato nel Back Office di Umbraco da <a href="mailto:%4%" style="text-decoration: underline; color: #392F54; -ms-word-break: break-all; word-break: break-all;">%1%</a>.
														</p>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Messaggio da <a href="mailto:%1%" style="text-decoration: none; color: #392F54; -ms-word-break: break-all; word-break: break-all;">%1%</a>:
															<br/>
															<em>%2%</em>
														</p>
														<table border='0' cellpadding='0' cellspacing='0' class='btn btn-primary' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; box-sizing: border-box;'>
															<tbody>
																<tr>
																	<td align='left' style='font-family: sans-serif; font-size: 14px; vertical-align: top; padding-bottom: 15px;' valign='top'>
																		<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
																			<tbody>
																				<tr>
																					<td style='font-family: sans-serif; font-size: 14px; vertical-align: top; border-radius: 5px; text-align: center; background: #35C786;' align='center' bgcolor='#35C786' valign='top'>
																						<a href='%3%' target='_blank' rel='noopener' style='color: #FFFFFF; text-decoration: none; -ms-word-break: break-all; word-break: break-all; border-radius: 5px; box-sizing: border-box; cursor: pointer; display: inline-block; font-size: 14px; font-weight: bold; text-transform: capitalize; background: #35C786; margin: 0; padding: 12px 30px; border: 1px solid #35c786;'>
																							Clicca questo link per accettare l'invito
																						</a>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
															</tbody>
														</table>
														<p style='max-width: 400px; display: block; color: #392F54; font-family: sans-serif; font-size: 14px; line-height: 20px; font-weight: normal; margin: 15px 0;'>Se non puoi cliccare sul link, copia e incolla questo URL in una nuova finestra del tuo browser:</p>
															<table border='0' cellpadding='0' cellspacing='0'>
																<tr>
																	<td style='-ms-word-break: break-all; word-break: break-all; font-family: sans-serif; font-size: 11px; line-height:14px;'>
																		<font style="-ms-word-break: break-all; word-break: break-all; font-size: 11px; line-height:14px;">
																			<a style='-ms-word-break: break-all; word-break: break-all; color: #392F54; text-decoration: underline; font-size: 11px; line-height:15px;' href='%3%'>%3%</a>
																		</font>
																	</td>
																</tr>
															</table>
														</p>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
								<br><br><br>
							</div>
						</td>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
					</tr>
				</table>
			</body>
    </html>`,
    invite: "Invita",
    defaultInvitationMessage: "Sto rinviando l'invito...",
    deleteUser: "Cancella utente",
    deleteUserConfirmation: "Sei sicuro di voler cancellare questo account utente?",
    stateAll: "Tutti",
    stateActive: "Attivi",
    stateDisabled: "Disabilitati",
    stateLockedOut: "Bloccati",
    stateInvited: "Invitati",
    stateInactive: "Inattivi",
    sortNameAscending: "Nome (A-Z)",
    sortNameDescending: "Nome (Z-A)",
    sortCreateDateAscending: "Più vecchi",
    sortCreateDateDescending: "Più nuovi",
    sortLastLoginDateDescending: "Ultimo login",
    noUserGroupsAdded: "Non sono stati aggiunti gruppi di utenti"
  },
  validation: {
    validation: "Validazione",
    validateAsEmail: "Valida come indirizzo email",
    validateAsNumber: "Valida come numero",
    validateAsUrl: "Valida come URL",
    enterCustomValidation: "...oppure inserisci una validazione personalizzata",
    fieldIsMandatory: "Il campo è obbligatorio",
    mandatoryMessage: "Inserisci un errore di validazione personalizzato (opzionale)",
    validationRegExp: "Inserisci una regular expression",
    validationRegExpMessage: "Inserisci un errore di validazione personalizzato (opzionale)",
    minCount: "Devi aggiungere almeno",
    maxCount: "Puoi avere solamente",
    addUpTo: "Aggiungi fino a",
    items: "elementi",
    urls: "URL",
    urlsSelected: "URL selezionati",
    itemsSelected: "elementi selezionati",
    invalidDate: "Data non valida",
    invalidNumber: "Non è un numero",
    invalidNumberStepSize: "Non è un numero di step valido",
    invalidEmail: "Email non valida",
    invalidNull: "Il valore non può essere nullo",
    invalidEmpty: "Il valore non può essere vuoto",
    invalidPattern: "Il valore non è valido, non corrisponde al pattern corretto",
    customValidation: "Validazione personalizzata",
    entriesShort: "Minimo %0% voci, ne richiede <strong>%1%</strong> in più.",
    entriesExceed: "Massimo %0% voci, <strong>%1%</strong> di troppo."
  },
  healthcheck: {
    checkSuccessMessage: "Il valore è impostato al valore raccomandato: '%0%'.",
    rectifySuccessMessage: "Il valore è impostato a '%1%' per l'XPath '%2%' nel file di configurazione '%3%'.",
    checkErrorMessageDifferentExpectedValue: "Mi aspettavo il valore '%1%' per '%2%' nel file di configurazione '%3%', ma ho trovato '%0%'.",
    checkErrorMessageUnexpectedValue: "Non mi aspettavo il valore '%0%' per '%2%' nel file di configurazione '%3%'.",
    customErrorsCheckSuccessMessage: "Gli errori personalizzati sono impostati a '%0%'.",
    customErrorsCheckErrorMessage: "Gli errori personalizzati al momento sono impostati a '%0%'. È raccomandato impostarli a '%1%' prima di andare live.",
    customErrorsCheckRectifySuccessMessage: "Errori personalizzati impostati correttamente a '%0%'.",
    macroErrorModeCheckSuccessMessage: "I MacroErrors sono impostati a '%0%'.",
    macroErrorModeCheckErrorMessage: "I MacroErrors sono impostati a '%0%' che impediranno il caricamento di qualche pagina nel sito se c'è anche solo un errore nella macro. Rettificando questa impostazione verrà impostato il valore '%1%'.",
    macroErrorModeCheckRectifySuccessMessage: "I MacroErrors sono ora impostati a '%0%'.",
    trySkipIisCustomErrorsCheckSuccessMessage: "Prova a saltare gli errori personalizzati di IIS è impostato a '%0%' e stai usando la versione '%1%' di IIS.",
    trySkipIisCustomErrorsCheckErrorMessage: "Prova a saltare gli errori personalizzati di IIS è al momento '%0%'. È raccomandato impostarlo a '%1%' per la tua versione di IIS (%2%).",
    trySkipIisCustomErrorsCheckRectifySuccessMessage: "Prova a saltare gli errori personalizzati di IIS è stato correttamente impostato a '%0%'.",
    configurationServiceFileNotFound: "Il file seguente non esiste: '%0%'.",
    configurationServiceNodeNotFound: "Non riesco a trovare <strong>'%0%'</strong> nel file di configurazione <strong>'%1%'</strong>.",
    configurationServiceError: "C'è stato un errore, controlla i log per l'errore dettagliato: %0%.",
    databaseSchemaValidationCheckDatabaseOk: "Database - Lo schema del database è corretto per questa versione di Umbraco",
    databaseSchemaValidationCheckDatabaseErrors: `Sono stati trovati %0% problemi con lo schema del database
      (Controlla i log per dettagli aggiuntivi)
    `,
    databaseSchemaValidationCheckDatabaseLogMessage: `Sono stati trovati alcuni errori durante la validazione
      dello schema del database per la versione corrente di Umbraco.
    `,
    httpsCheckValidCertificate: "Il certificato SSL del tuo sito web è valido.",
    httpsCheckInvalidCertificate: "Errore di validazione del certificato SSL: '%0%'",
    httpsCheckExpiredCertificate: "Il certificato SSL del tuo sito web è scaduto.",
    httpsCheckExpiringCertificate: "Il certificato SSL del tuo sito web scadrà tra %0% giorni.",
    healthCheckInvalidUrl: "Errore durante il ping dell'URL %0% - '%1%'",
    httpsCheckIsCurrentSchemeHttps: `Attualmente %0% stai visualizzando il sito web utilizzando lo schema
      HTTPS.
    `,
    httpsCheckConfigurationRectifyNotPossible: "L'appSetting 'Umbraco.Core.UseHttps' è impostata a 'false' nel file web.config. Quando accederai al sito web usando lo schema HTTPS, il valore dovrà essere impostato a 'true'.",
    httpsCheckConfigurationCheckResult: "L'appSetting 'Umbraco.Core.UseHttps' è impostata a '%0%' nel file web.config, i tuoi cookie %1% sono contrassegnati come sicuri.",
    httpsCheckEnableHttpsError: `Non posso aggiornare l'impostazione 'Umbraco.Core.UseHttps' nel file
      web.config. Errore: %0%
    `,
    httpsCheckEnableHttpsButton: "Abilita HTTPS",
    httpsCheckEnableHttpsDescription: `Imposta il valore di umbracoSSL a true nelle appSetting del file
      web.config.
    `,
    httpsCheckEnableHttpsSuccess: "L'appSetting 'Umbraco.Core.UseHttps' è ora impostato a 'true' nel file web.config, i tuoi cookies sono contrassegnati come sicuri.",
    rectifyButton: "Correggi",
    cannotRectifyShouldNotEqual: `Non posso correggere un controllo con un valore di confronto pari a
      'ShouldNotEqual'.
    `,
    cannotRectifyShouldEqualWithValue: `Non posso correggere un controllo con un valore di confronto pari a
      'ShouldEqual' con un valore fornito.
    `,
    valueToRectifyNotProvided: "Il valore per correggere il controllo non è presente.",
    compilationDebugCheckSuccessMessage: "La modalità di compilazione debug è disabilitata.",
    compilationDebugCheckErrorMessage: "La modalità di compilazione debug è attualmente abilitata. Si consiglia di disabilitare questa impostazione prima di andare live.",
    compilationDebugCheckRectifySuccessMessage: "La modalità di compilazione debug è stata disabilitata con successo.",
    traceModeCheckSuccessMessage: "La modalità traccia è disabilitata.",
    traceModeCheckErrorMessage: "La modalità traccia è abilitata. Si consiglia di disabilitare questa impostazione prima di andare live.",
    traceModeCheckRectifySuccessMessage: "La modalità traccia è stata disabilitata con successo.",
    folderPermissionsCheckMessage: "Tutte le cartelle hanno i permessi corretti impostati.",
    requiredFolderPermissionFailed: "Le cartelle seguenti devono essere impostate con i permessi di modifica: <strong>%0%</strong>.",
    optionalFolderPermissionFailed: "Le cartelle seguenti devono essere impostate con i permessi di modifica per alcune funzionalità di Umbraco: <strong>%0%</strong>. Se non vengono scritte non è necessario intraprendere alcuna azione.",
    filePermissionsCheckMessage: "Tutti i file hanno i permessi corretti impostati.",
    requiredFilePermissionFailed: "I files seguenti devono essere impostati con i permessi di modifica: <strong>%0%</strong>.",
    optionalFilePermissionFailed: "I files seguenti devono essere impostati con i permessi di modifica per alcune funzionalità di Umbraco: <strong>%0%</strong>. Se non vengono scritti non è necessario intraprendere alcuna azione.",
    clickJackingCheckHeaderFound: "L'header o meta-tag <strong>X-Frame-Options</strong> usato per controllare se un sito può essere inserito in un IFRAME da un altro è stato trovato.",
    clickJackingCheckHeaderNotFound: "L'header o meta-tag <strong>X-Frame-Options</strong> usato per controllare se un sito può essere inserito in un IFRAME da un altro non è stato trovato.",
    setHeaderInConfig: "Imposta l'header nella configurazione",
    clickJackingSetHeaderInConfigDescription: `Aggiunge un valore alla sezione httpProtocol/customHeaders del
      file web.config per prevenire che un sito possa essere inserito in un IFRAME da altri siti web.
    `,
    clickJackingSetHeaderInConfigSuccess: "L'impostazione per creare un header per prevenire l'inserimento del sito in altri siti tramite IFRAME è stata aggiunta al file web.config.",
    setHeaderInConfigError: "Non posso aggiornare il file web.config. Errore: %0%",
    noSniffCheckHeaderFound: "L'header o meta-tag <strong>X-Content-Type-Options</strong> usato per proteggere dalle vulnerabilità per MIME sniffing è stato trovato.",
    noSniffCheckHeaderNotFound: "L'header o meta-tag <strong>X-Content-Type-Options</strong> usato per proteggere dalle vulnerabilità per MIME sniffing è stato trovato.",
    noSniffSetHeaderInConfigDescription: "Aggiunge un valore alla sezione httpProtocol/customHeaders del file web.config per proteggere dalle vulnerabilità per MIME sniffing.",
    noSniffSetHeaderInConfigSuccess: "L'impostazione per creare un header per proteggere dalle vulnerabilità per MIME sniffing è stata aggiunta al file web.config.",
    hSTSCheckHeaderFound: "L'header <strong>Strict-Transport-Security</strong>, conosciuto anche come l'header HSTS, è stato trovato.",
    hSTSCheckHeaderNotFound: "L'header <strong>Strict-Transport-Security</strong> non è stato trovato.",
    hSTSSetHeaderInConfigDescription: `Aggiunge l'header 'Strict-Transport-Security' con il valore
      'max-age=10886400' alla sezione httpProtocol/customHeaders del file web.config. Usa questa correzione solo se
      avrai i tuoi domini in esecuzione con https per le prossime 18 settimane (minimo).
    `,
    hSTSSetHeaderInConfigSuccess: "L'header HSTS è stato aggiunto al file web.config.",
    xssProtectionCheckHeaderFound: "L'header <strong>X-XSS-Protection</strong> è stato trovato.",
    xssProtectionCheckHeaderNotFound: "L'header <strong>X-XSS-Protection</strong> non è stato trovato.",
    xssProtectionSetHeaderInConfigDescription: `Aggiunge l'header 'X-XSS-Protection' con il valore '1;
      mode=block' alla sezione httpProtocol/customHeaders del file web.config.
    `,
    xssProtectionSetHeaderInConfigSuccess: "L'header X-XSS-Protection è stato aggiunto al file web.config.",
    excessiveHeadersFound: "Gli header seguenti, contenenti informazioni riguardo la tecnologia utilizzata per il sito sono stati trovati: <strong>%0%</strong>.",
    excessiveHeadersNotFound: `Non sono stati trovati header che rivelano informazioni riguardo alla
      tecnologia utilizzata per il sito.
    `,
    smtpMailSettingsNotFound: "Nel file web.config, system.net/mailsettings non è stato trovato.",
    smtpMailSettingsHostNotConfigured: "Nel file web.config, nella sezione system.net/mailsettings, l'host non è stato configurato.",
    smtpMailSettingsConnectionSuccess: `Le impostazioni SMTP sono state inserite correttamente e il servizio
      funziona come previsto.
    `,
    smtpMailSettingsConnectionFail: "Il server SMTP configurato con l'host '%0%' e la porta '%1%' non può essere raggunto. Per favore controlla che le impostazioni SMTP nel file web.config (sezione system.net/mailsettings) siano corrette.",
    notificationEmailsCheckSuccessMessage: "L'email di notifica è stata impostata a <strong>%0%</strong>.",
    notificationEmailsCheckErrorMessage: "L'email di notifica è ancora impostata al valore predefinito di <strong>%0%</strong>.",
    checkAllGroups: "Controlla tutti i gruppi",
    checkGroup: "Controlla gruppo",
    helpText: `
        <p>L'health checker valuta varie aree del tuo sito per le impostazioni delle migliori pratiche, la configurazione, i potenziali problemi, ecc. Puoi facilmente risolvere i problemi premendo un pulsante.
        Puoi aggiungere i tuoi health check personalizzati, guarda sulla <a href="https://docs.umbraco.com/umbraco-cms/extending/health-check" target="_blank" rel="noopener" class="btn-link -underline">documentazione per più informazioni</a> riguardo i custom health checks.</p>
        `
  },
  redirectUrls: {
    disableUrlTracker: "Disabilita tracciamento degli URL",
    enableUrlTracker: "Abilita tracciamento degli URL",
    culture: "Cultura",
    originalUrl: "URL originale",
    redirectedTo: "Reindirizzato a",
    redirectUrlManagement: "Gestione Redirect URL",
    panelInformation: "I seguenti URL reindirizzano a questo contenuto:",
    noRedirects: "Nessun reindirizzamento è stato effettuato",
    noRedirectsDescription: "Quando una pagina pubblicata viene rinominata o spostata, verrà automaticamente effettuato un reindirizzamento alla nuova pagina.",
    confirmRemove: "Sei sicuro di voler eliminare il reindirizzamento da '%0%' a '%1%'?",
    redirectRemoved: "Reindirizzamento URL rimosso.",
    redirectRemoveError: "Errore durante la rimozione del reindirizzamento URL.",
    redirectRemoveWarning: "Questo rimuoverà il reindirizzamento",
    confirmDisable: "Sei sicuro di voler disabilitare il tracciamento degli URL?",
    disabledConfirm: "Il tracciamento degli URL è stato disabilitato.",
    disableError: "Si è verificato un errore disabilitando il tracciamento degli URL. Più informazioni sono disponibili nei file di log.",
    enabledConfirm: "Il tracciamento degli URL è stato abilitato.",
    enableError: "Si è verificato un errore abilitando il tracciamento degli URL. Più informazioni sono disponibili nei file di log."
  },
  emptyStates: {
    emptyDictionaryTree: "Nessun elemento del dizionario tra cui scegliere"
  },
  textbox: {
    characters_left: "<strong>%0%</strong> caratteri rimasti.",
    characters_exceed: "Massimo %0% caratteri, <strong>%1%</strong> di troppo."
  },
  recycleBin: {
    contentTrashed: `Contenuto cestinato con Id: {0} relativo al contenuto principale originale con Id: {1}
    `,
    mediaTrashed: "Media cestinato con Id: {0} relativo al media principale originale con Id: {1}",
    itemCannotBeRestored: "Impossibile ripristinare automaticamente questo elemento",
    itemCannotBeRestoredHelpText: `Non esiste una posizione in cui questo elemento possa essere ripristinato
      automaticamente. Puoi spostare l'elemento manualmente utilizzando l'albero sottostante.
    `,
    wasRestored: "è stato ripristinato sotto"
  },
  relationType: {
    direction: "Direzione",
    parentToChild: "Da genitore a figlio",
    bidirectional: "Bidirezionale",
    parent: "Genitore",
    child: "Figlio",
    count: "Numero",
    relations: "Relazioni",
    created: "Creato",
    comment: "Commento",
    name: "Nome",
    noRelations: "Nessuna relazione per questo tipo di relazione",
    tabRelationType: "Tipo di relazione",
    tabRelations: "Relazioni"
  },
  dashboardTabs: {
    contentIntro: "Guida introduttiva",
    contentRedirectManager: "Gestione Redirect URL",
    mediaFolderBrowser: "Contenuto",
    settingsWelcome: "Benvenuto",
    settingsExamine: "Gestione Examine",
    settingsPublishedStatus: "Stato di pubblicazione",
    settingsModelsBuilder: "Models Builder",
    settingsHealthCheck: "Health Check",
    settingsProfiler: "Profilazione",
    memberIntro: "Guida introduttiva",
    formsInstall: "Installa Umbraco Forms"
  },
  visuallyHiddenTexts: {
    goBack: "Indietro",
    activeListLayout: "Layout attivo:",
    jumpTo: "Vai a",
    group: "gruppo",
    passed: "passato",
    warning: "attenzone",
    failed: "fallito",
    suggestion: "suggerimento",
    checkPassed: "Check passato",
    checkFailed: "Check fallito",
    openBackofficeSearch: "Apri la ricerca nel backoffice",
    openCloseBackofficeHelp: "Apri/chiudi l'aiuto del backoffice",
    openCloseBackofficeProfileOptions: "Apri/chiudi le opzioni del tuo profilo",
    assignDomainDescription: "Imposta le Culture e gli Hostnames per %0%",
    createDescription: "Crea nuovo nodo sotto %0%",
    protectDescription: "Imposta le restrizioni di accesso per %0%",
    rightsDescription: "Imposta i permessi per %0%",
    sortDescription: "Modifica l'ordinamento per %0%",
    createblueprintDescription: "Crea un modello di contenuto basato su %0%",
    openContextMenu: "Apri il menu contestuale per",
    currentLanguage: "Lingua corrente",
    switchLanguage: "Cambia lingua in",
    createNewFolder: "Crea nuova cartella",
    newPartialView: "Partial View",
    newPartialViewMacro: "Partial View Macro",
    newMember: "Membro",
    newDataType: "Tipo di dato",
    redirectDashboardSearchLabel: "Cerca nella dashboard di reindirizzamento",
    userGroupSearchLabel: "Cerca nella sezione dei gruppi di utenti",
    userSearchLabel: "Cerca tra gli utenti",
    createItem: "Crea oggetto",
    create: "Crea",
    edit: "Modifica",
    name: "Nome",
    addNewRow: "Aggiungi nuova riga",
    tabExpand: "Vedi più opzioni",
    searchOverlayTitle: "Cerca nel backoffice di Umbraco",
    searchOverlayDescription: "Cerca contenuti, media, ecc. nel backoffice.",
    searchInputDescription: "Quando sono disponibili dei risultati dal completamento automatico, premere le frecce su e giù oppure utilizzare il tasto TAB e utilizzare il tasto Invio per selezionare.",
    path: "Percorso:",
    foundIn: "Trovato in",
    hasTranslation: "Ha una traduzione",
    noTranslation: "Traduzione mancante",
    dictionaryListCaption: "Voci del dizionario",
    contextMenuDescription: "Seleziona una delle opzioni per modificare il nodo.",
    contextDialogDescription: "Esegui l'azione %0% sul nodo %1%",
    addImageCaption: "Aggiungi una descrizione per l'immagine",
    searchContentTree: "Cerca nell'albero dei contenuti",
    maxAmount: "Numero massimo"
  },
  references: {
    tabName: "Riferimenti",
    DataTypeNoReferences: "Questo tipo di dato non ha riferimenti.",
    labelUsedByDocumentTypes: "Usato nei tipi di documento",
    noDocumentTypes: "Non ci sono riferimenti a tipi di documento.",
    labelUsedByMediaTypes: "Usato nei tipi di media",
    noMediaTypes: "Non ci sono riferimenti a tipi di media.",
    labelUsedByMemberTypes: "Usato nei tipi di membro",
    noMemberTypes: "Non ci sono riferimenti a tipi di membro.",
    usedByProperties: "Usato da",
    labelUsedByItems: "Correlato ai seguenti elementi",
    labelUsedByDocuments: "Usato nei documenti",
    labelUsedByMembers: "Usato nei membri",
    labelUsedByMedia: "Usato nei media"
  },
  logViewer: {
    deleteSavedSearch: "Elimina ricerca salvata",
    logLevels: "Livelli di log",
    selectAllLogLevelFilters: "Seleziona tutto",
    deselectAllLogLevelFilters: "Deselezionare tutto",
    savedSearches: "Ricerche salvate",
    saveSearch: "Salva ricerca",
    saveSearchDescription: "Inserisci un nome descrittivo per la tua query di ricerca",
    filterSearch: "Filtra la ricerca",
    totalItems: "Risultati totali",
    timestamp: "Timestamp",
    level: "Livello",
    machine: "Macchina",
    message: "Messaggio",
    exception: "Exception",
    properties: "Proprietà",
    searchWithGoogle: "Ricerca con Google",
    searchThisMessageWithGoogle: "Ricerca questo messaggio con Google",
    searchWithBing: "Ricerca con Bing",
    searchThisMessageWithBing: "Ricerca questo messaggio con Bing",
    searchOurUmbraco: "Ricerca su Our Umbraco",
    searchThisMessageOnOurUmbracoForumsAndDocs: `Ricerca questo messaggio sui forum e le documentazioni di
      Our Umbraco
    `,
    searchOurUmbracoWithGoogle: "Ricerca su Our Umbraco con Google",
    searchOurUmbracoForumsUsingGoogle: "Ricerca sui forum di Our Umbraco con Google",
    searchUmbracoSource: "Ricerca nel codice sorgente di Umbraco",
    searchWithinUmbracoSourceCodeOnGithub: "Ricerca nel codice sorgente di Umbraco su GitHub",
    searchUmbracoIssues: "Ricerca tra i problemi di Umbraco",
    searchUmbracoIssuesOnGithub: "Ricerca tra i problemi di Umbraco su GitHub",
    deleteThisSearch: "Elimina questa ricerca",
    findLogsWithRequestId: "Trova log con Request ID",
    findLogsWithNamespace: "Trova log con Namespace",
    findLogsWithMachineName: "Trova log con Machine Name",
    open: "Apri",
    polling: "Polling",
    every2: "Ogni 2 secondi",
    every5: "Ogni 5 secondi",
    every10: "Ogni 10 secondi",
    every20: "Ogni 20 secondi",
    every30: "Ogni 30 secondi",
    pollingEvery2: "Polling ogni 2s",
    pollingEvery5: "Polling ogni 5s",
    pollingEvery10: "Polling ogni 10s",
    pollingEvery20: "Polling ogni 20s",
    pollingEvery30: "Polling ogni 30s"
  },
  clipboard: {
    labelForCopyAllEntries: "Copia %0%",
    labelForArrayOfItemsFrom: "%0% da %1%",
    labelForArrayOfItems: "Lista di %0%",
    labelForRemoveAllEntries: "Rimuovi tutti gli oggetti",
    labelForClearClipboard: "Svuota appunti"
  },
  propertyActions: {
    tooltipForPropertyActionsMenu: "Apri le azioni per le proprietà",
    tooltipForPropertyActionsMenuClose: "Chiudi le azioni per le proprietà"
  },
  nuCache: {
    wait: "Attendi",
    refreshStatus: "Aggiorna stato",
    memoryCache: "Memory Cache",
    memoryCacheDescription: `
            Questo pulsante di consente di ricaricare la Memory Cache, ricaricandola completamente dalla cache
    del database (ma non ricostruisce la cache del database). Questo è relativamente veloce.
    Usalo quando pensi che la Memory Cache non sia stata aggiornata correttamente, dopo che si sono verificati
    alcuni eventi che indicherebbero un problema minore di Umbraco.
    (nota: ricarica la Memory Cache su tutti i server in un Load Balanced environment).
    `,
    reload: "Ricarica",
    databaseCache: "Cache del Database",
    databaseCacheDescription: `
    Questo pulsante ti consente di ricostruire la cache del database, ad esempio le tabelle cmsContentNu.
    <strong>La ricostruzione può metterci del tempo.</strong>
    Usalo quando la ricarica della Memory Cache non è sufficiente e pensi che la cache del database non sia
    stata generata correttamente, che indicherebbe un problema critico di Umbraco.
    `,
    rebuild: "Ricostruisci",
    internals: "Interni",
    internalsDescription: `
    Questo pulsante consente di attivare una raccolta di snapshot NuCache (dopo aver eseguito un GC fullCLR).
    A meno che tu non sappia cosa significa, probabilmente <em>non</em> hai bisogno di usarlo.
    `,
    collect: "Raccogli",
    publishedCacheStatus: "Stato della Published Cache",
    caches: "Caches"
  },
  profiling: {
    performanceProfiling: "Profilazione delle performance",
    performanceProfilingDescription: `
                <p>
                    Umbraco attualmente funziona in modalità debug. Ciò significa che puoi utilizzare il profiler delle prestazioni integrato per valutare le prestazioni durante il rendering delle pagine.
                </p>
                <p>
                    Se vuoi attivare il profiler per il rendering di una pagina specifica, aggiungi semplicemente <strong>umbDebug=true</strong> alla querystring quando richiedi la pagina.
                </p>
                <p>
                    Se vuoi che il profiler sia attivato per impostazione predefinita per tutti i rendering di pagina, puoi utilizzare l'interruttore qui sotto.
                    Verrà impostato un cookie nel tuo browser, che quindi attiverà automaticamente il profiler.
                    In altre parole, il profiler sarà attivo per impostazione predefinita solo nel <em>tuo</em> browser, non in quello di tutti gli altri.
                </p>
        `,
    activateByDefault: "Attiva la profilazione per impostazione predefinita",
    reminder: "Promemoria",
    reminderDescription: `
            <p>
                Non dovresti mai lasciare che un sito di produzione venga eseguito in modalità debug. La modalità di debug viene disattivata impostando <strong>debug="false"</strong> nell'elemento <strong>&lt;compilation /&gt;</strong> nel file web.config.
            </p>
        `,
    profilerEnabledDescription: `
            <p>
                Umbraco attualmente non viene eseguito in modalità debug, quindi non è possibile utilizzare il profiler integrato. Questo è come dovrebbe essere per un sito produttivo.
            </p>
            <p>
                La modalità di debug viene attivata impostando <strong>debug="true"</strong> nell'elemento <strong>&lt;compilation /&gt;</strong> in web.config.
            </p>
        `
  },
  settingsDashboardVideos: {
    trainingHeadline: "Ore di videoallenamenti su Umbraco sono a solo un click da te",
    trainingDescription: `
        <p>Vuoi padroneggiare Umbraco? Dedica un paio di minuti all'apprendimento di alcune best practice guardando uno di questi video sull'utilizzo di Umbraco. Visita <a href="https://umbraco.tv" target="_blank" rel="noopener">umbraco.tv</a> per altri video su Umbraco</p>
    `,
    getStarted: "Per iniziare"
  },
  settingsDashboard: {
    start: "Inizia da qui!",
    startDescription: "Questa sezione contiene gli elementi costitutivi del tuo sito Umbraco. Segui i collegamenti sottostanti per saperne di più su come lavorare con gli elementi nella sezione Impostazioni",
    more: "Scopri di più",
    bulletPointOne: `
            Maggiori informazioni su come lavorare con gli elementi in Impostazioni <a class="btn-link -underline" href="https://docs.umbraco.com/umbraco-cms/fundamentals/backoffice/sections/" target="_blank" rel="noopener">nella documentazione</a> di Our Umbraco
        `,
    bulletPointTwo: `
            Fai una domanda nel <a class="btn-link -underline" href="https://our.umbraco.com/forum" target="_blank" rel="noopener">Community Forum</a>
        `,
    bulletPointThree: `
            Guarda i nostri <a class="btn-link -underline" href="https://umbraco.tv" target="_blank" rel="noopener">video tutorial</a> (alcuni sono gratuiti, altri richiedono un abbonamento)
        `,
    bulletPointFour: `
            Scopri di più sui nostri <a class="btn-link -underline" href="https://umbraco.com/products/" target="_blank" rel="noopener">strumenti per aumentare la produttività e il supporto commerciale</a>
        `,
    bulletPointFive: `
            Scopri di più sulle opportunità di <a class="btn-link -underline" href="https://umbraco.com/training/" target="_blank" rel="noopener">certificazione</a>
        `
  },
  startupDashboard: {
    fallbackHeadline: "Benvenuto nell'amichevole CMS",
    fallbackDescription: "Grazie per aver scelto Umbraco! Pensiamo che questo possa essere l'inizio di qualcosa di fantastico. Sebbene all'inizio possa sembrare travolgente, abbiamo fatto molto per rendere la curva di apprendimento il più fluida e veloce possibile."
  },
  formsDashboard: {
    formsHeadline: "Umbraco Forms",
    formsDescription: `Crea moduli utilizzando un'interfaccia drag and drop intuitiva. Da semplici moduli di
      contatto che inviano e-mail a questionari avanzati che si integrano con i sistemi CRM. I tuoi clienti lo
      adoreranno!
    `
  },
  blockEditor: {
    headlineCreateBlock: "Scegli tipo di elemento",
    headlineAddSettingsElementType: "Allega un tipo di elemento delle impostazioni",
    headlineAddCustomView: "Seleziona vista",
    headlineAddCustomStylesheet: "Seleziona foglio di stile",
    headlineAddThumbnail: "Scegli miniatura",
    labelcreateNewElementType: "Crea nuovo tipo di elemento",
    labelCustomStylesheet: "Foglio di stile personalizzato",
    addCustomStylesheet: "Aggiungi foglio di stile",
    headlineEditorAppearance: "Aspetto dell'editor",
    headlineDataModels: "Modelli di dati",
    headlineCatalogueAppearance: "Aspetto del catalogo",
    labelBackgroundColor: "Colore di sfondo",
    labelIconColor: "Colore dell'icona",
    labelContentElementType: "Modello del contenuto",
    labelLabelTemplate: "Etichetta",
    labelCustomView: "Vista personalizzata",
    labelCustomViewInfoTitle: "Mostra la descrizione della vista personalizzata",
    labelCustomViewDescription: "Sovrascrivi come questo blocco apparirà nell'UI del backoffice. Seleziona un file .html contenente la tua versione.",
    labelSettingsElementType: "Modello di impostazioni",
    labelEditorSize: "Dimensione dell'editor di sovrapposizione",
    addCustomView: "Aggiungi vista personalizzata",
    addSettingsElementType: "Aggiungi impostazioni",
    labelTemplatePlaceholder: "Sovrascrivi modello di etichetta",
    confirmDeleteBlockMessage: "Sei sicuro di voler eliminare il contenuto <strong>%0%</strong>?",
    confirmDeleteBlockTypeMessage: "Sei sicuro di voler eliminare la configurazione del blocco <strong>%0%</strong>?",
    confirmDeleteBlockTypeNotice: "Il contenuto di questo blocco sarà comunque presente, ma la modifica non sarà più possibile e sarà visualizzato come contenuto non supportato.",
    blockConfigurationOverlayTitle: "Configurazione di '%0%'",
    thumbnail: "Miniatura",
    addThumbnail: "Aggiungi miniatura",
    tabCreateEmpty: "Crea vuota",
    tabClipboard: "Appunti",
    tabBlockSettings: "Impostazioni",
    headlineAdvanced: "Avanzate",
    forceHideContentEditor: "Forza nascondi editor di contenuti",
    blockHasChanges: "Hai fatto delle modifiche a questo contenuto. Sei sicuro di volerle scartare?",
    confirmCancelBlockCreationHeadline: "Scartare la creazione?",
    confirmCancelBlockCreationMessage: "Sei sicuro di voler cancellare la creazione.",
    elementTypeDoesNotExistHeadline: "Errore!",
    elementTypeDoesNotExistDescription: "Il tipo di elemento di questo blocco non esiste più",
    addBlock: "Aggiungi contenuto",
    addThis: "Aggiungi %0%",
    propertyEditorNotSupported: "La proprietà '%0%' usa l'editor '%1%' che non è supportato nei blocchi."
  },
  contentTemplatesDashboard: {
    whatHeadline: "Cosa sono i modelli di contenuto?",
    whatDescription: `I modelli di contenuto sono contenuti predefiniti che possono essere selezionati
      durante la creazione di un nuovo nodo di contenuto.
    `,
    createHeadline: "Come creo un modello di contenuto?",
    createDescription: `
            <p>Ci sono due modi per creare un modello di contenuto:</p>
            <ul>
                <li>Fare clic con il pulsante destro del mouse su un nodo di contenuto e selezionare "Crea modello di contenuto" per creare un nuovo modello di contenuto.</li>
                <li>Fare clic con il pulsante destro del mouse sull'albero dei modelli di contenuto nella sezione Impostazioni e selezionare il tipo di documento per il quale si desidera creare un modello di contenuto.</li>
            </ul>
            <p>Una volta specificato un nome, gli editors potranno cominciare a usare il tipo di contenuto come base per la nuova pagina.</p>
        `,
    manageHeadline: "Come gestisco i modelli di contenuto?",
    manageDescription: `Puoi modificare ed eliminare i modelli di contenuto dall'albero "Modelli di
      contenuto" nella sezione Impostazioni. Espandere il tipo di documento su cui si basa il modello di contenuto e
      fare clic su di esso per modificarlo o eliminarlo.
    `
  },
  preview: {
    endLabel: "Chiudi",
    endTitle: "Chiudi anteprima",
    openWebsiteLabel: "Anteprima sito web",
    openWebsiteTitle: "Apri il sito in modalità anteprima",
    returnToPreviewHeadline: "Aprire l'anteprima del sito web?",
    returnToPreviewDescription: "Hai chiuso la modalità anteprima. Vuoi abilitarla nuovamente per visualizzare l'ultima versione salvata nel sito web?",
    returnToPreviewAcceptButton: "Anteprima dell'ultima versione",
    returnToPreviewDeclineButton: "Visualizza versione pubblicata",
    viewPublishedContentHeadline: "Vuoi vedere la versione pubblicata?",
    viewPublishedContentDescription: "Sei in modalità anteprima, vuoi uscire e vedere la versione pubblicata nel tuo sito web?",
    viewPublishedContentAcceptButton: "Visualizza versione pubblicata",
    viewPublishedContentDeclineButton: "Rimani in modalità anteprima"
  },
  treeSearch: {
    searchResult: "oggetto trovato",
    searchResults: "oggetti trovati"
  }
};
export {
  e as default
};
//# sourceMappingURL=it-it-nEIBQBH6.js.map
