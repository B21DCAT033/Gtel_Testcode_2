const e = [
  {
    type: "modal",
    alias: "Umb.Modal.ErrorViewer",
    name: "Error Viewer Modal",
    element: () => import("./error-viewer-modal.element-CVADHe3y.js")
  }
];
export {
  e as m
};
//# sourceMappingURL=manifest-D87W_b9a.js.map
