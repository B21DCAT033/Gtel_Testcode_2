const t = "Umb.Condition.SectionUserPermission", o = "Umb.Repository.Section.Item", s = [
  {
    type: "repository",
    alias: o,
    name: "Section Item Repository",
    api: () => import("./section-item.repository-B9ft9W21.js")
  }
];
export {
  o as U,
  t as a,
  s as m
};
//# sourceMappingURL=manifests-BmDqVuWE.js.map
