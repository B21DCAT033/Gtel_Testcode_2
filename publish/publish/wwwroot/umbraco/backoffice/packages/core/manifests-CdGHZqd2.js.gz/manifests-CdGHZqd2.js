const e = [
  {
    type: "modal",
    alias: "Umb.Modal.ContextDebugger",
    name: "Context Debugger Modal",
    element: () => import("./debug-modal.element-CYXuS7Bs.js")
  }
], t = [...e];
export {
  t as m
};
//# sourceMappingURL=manifests-CdGHZqd2.js.map
