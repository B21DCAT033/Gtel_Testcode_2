const e = "Umb.Modal.ServerFile.Rename", a = [
  {
    type: "modal",
    alias: e,
    name: "Rename Server File Modal",
    element: () => import("./rename-server-file-modal.element-Bm5IsErL.js")
  }
];
export {
  e as U,
  a as m
};
//# sourceMappingURL=manifests-FzOUH899.js.map
