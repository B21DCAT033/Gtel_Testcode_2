const t = {
  type: "kind",
  alias: "Umb.Kind.PropertyAction.Default",
  matchKind: "default",
  matchType: "propertyAction",
  manifest: {
    type: "propertyAction",
    kind: "default",
    weight: 1e3,
    element: () => import("./property-action.element-BD-2odIw.js"),
    meta: {
      icon: "icon-bug",
      label: "(Missing label in manifest)"
    }
  }
}, e = [
  t
];
export {
  t as U,
  e as m
};
//# sourceMappingURL=manifests-fsCMI7-p.js.map
