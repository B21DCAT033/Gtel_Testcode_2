const e = {
  actions: {
    assigndomain: "Beheer domeinnamen",
    auditTrail: "Documentgeschiedenis",
    browse: "Node bekijken",
    changeDocType: "Documenttype wijzigen",
    changeDataType: "Datatype aanpassen",
    copy: "Kopiëren",
    create: "Nieuw",
    export: "Export",
    createPackage: "Nieuwe package",
    createGroup: "Groep maken",
    delete: "Verwijderen",
    disable: "Uitschakelen",
    editSettings: "Instellingen wijzigen",
    emptyrecyclebin: "Prullenbak leegmaken",
    enable: "Inschakelen",
    exportDocumentType: "Documenttype exporteren",
    importdocumenttype: "Documenttype importeren",
    importPackage: "Package importeren",
    liveEdit: "Aanpassen in Canvas",
    logout: "Afsluiten",
    move: "Verplaatsen",
    notify: "Meldingen",
    protect: "Publieke toegang",
    publish: "Publiceren",
    unpublish: "Depubliceren",
    refreshNode: "Nodes opnieuw inladen",
    republish: "Herpubliceer de site",
    remove: "Verwijder",
    rename: "Hernoem",
    restore: "Herstellen",
    chooseWhereToCopy: "Kies waar u wilt kopiëren",
    chooseWhereToMove: "Kies waar u wilt verplaatsen",
    toInTheTreeStructureBelow: "naar de boomstructuur hieronder",
    infiniteEditorChooseWhereToCopy: "Kies waar u de geselecteerde item(s) naartoe wilt kopiëren",
    infiniteEditorChooseWhereToMove: "Kies waar u de geselecteerde item(s) naartoe wilt verplaatsen",
    wasMovedTo: "was verplaatst naar",
    wasCopiedTo: "was gekopieerd naar",
    wasDeleted: "was verwijderd",
    rights: "Rechten",
    rollback: "Vorige versies",
    sendtopublish: "Klaar voor publicatie",
    sendToTranslate: "Klaar voor vertalen",
    setGroup: "Groep instellen",
    sort: "Sorteren",
    translate: "Vertalen",
    update: "Bijwerken",
    setPermissions: "Rechten instellen",
    unlock: "Deblokkeer",
    createblueprint: "Inhoudssjabloon aanmaken",
    resendInvite: "Uitnodiging opnieuw versturen"
  },
  actionCategories: {
    content: "Inhoud",
    administration: "Administratie",
    structure: "Structuur",
    other: "Andere"
  },
  actionDescriptions: {
    assignDomain: "Toegang toestaan om cultuur- en hostnamen toe te wijzen",
    auditTrail: "Toegang toestaan om het geschiedenislogboek van een node te bekijken",
    browse: "Toegang toestaan om een node te bekijken",
    changeDocType: "Toegang toestaan om het documenttype van een node te wijzigen",
    copy: "Toegang toestaan om een node te kopiëren",
    create: "Toegang toestaan om nodes aan te maken",
    delete: "Toegang toestaan om nodes te verwijderen",
    move: "Toegang toestaan om een node te verplaatsen.",
    protect: "Toegang toestaan om openbare toegang voor een node in te stellen en te wijzigen",
    publish: "Toegang toestaan om een node te publiceren",
    unpublish: "Toegang toestaan om een node te depubliceren",
    rights: "Toegang toestaan om de machtigingen van een node te wijzigen",
    rollback: "Toegang toestaan om een node terug te draaien naar een vorige status",
    sendtopublish: "Toegang toestaan om een node te verzenden voor goedkeuring voor publicatie",
    sendToTranslate: "Toegang toestaan om een node te verzenden voor vertaling",
    sort: "Toegang toestaan om de volgorde van nodes te wijzigen",
    translate: "Toegang toestaan om een node te vertalen",
    update: "Toegang toestaan om een node op te slaan",
    createblueprint: "Toegang toestaan om Inhoudssjabloon aan te maken",
    notify: "Toegang toestaan om meldingen voor content nodes aan te maken"
  },
  apps: {
    umbContent: "Inhoud",
    umbInfo: "Info"
  },
  assignDomain: {
    permissionDenied: "Toegang geweigerd.",
    addNew: "Nieuw domein toevoegen",
    remove: "verwijderen",
    invalidNode: "Ongeldige node.",
    invalidDomain: "Ongeldig domeinformaat.",
    duplicateDomain: "Domein is reeds aanwezig.",
    domain: "Domein",
    language: "Taal",
    domainCreated: "Nieuw domein '%0%' is aangemaakt",
    domainDeleted: "Domein '%0%' is verwijderd",
    domainExists: "Domein '%0' is al aanwezig",
    domainUpdated: "Domein '%0%' is bijgewerkt",
    orEdit: "Bewerk huidige domeinen",
    inherit: "Overerven",
    domainHelpWithVariants: `Geldige domeinnamen zijn: "example.com", "www.example.com", "example.com:8080" of "https://www.example.com/".
    Verder worden ook paden op één niveau in domeinen ondersteund, bv. "example.com/en" of "/en".`,
    setLanguage: "Cultuur",
    setLanguageHelp: `Zet de cultuur voor de nodes onder de huidige node,<br /> of erf de cultuur over van de oudernodes. Zal ook van toepassing <br />
      zijn op de huidige node, tenzij een domein hieronder ook van toepassing is.`,
    setDomains: "Domeinen"
  },
  auditTrailsMedia: {
    delete: "Media verwijderd",
    move: "Media verplaatst",
    copy: "Media gekopieerd",
    save: "Media bewaard"
  },
  auditTrails: {
    atViewingFor: "Tonen voor",
    delete: "Inhoud verwijderd",
    unpublish: "Inhoud gedepubliceerd",
    unpublishvariant: "Inhoud gedepubliceerd voor talen: %0%",
    publish: "Inhoud gepubliceerd",
    publishvariant: "Inhoud gepubliceerd voor talen: %0%",
    save: "Inhoud bewaard",
    savevariant: "Inhoud bewaard voor talen: %0%",
    move: "Inhoud verplaatst",
    copy: "Inhoud gekopieerd",
    rollback: "Inhoud teruggezet",
    sendtopublish: "Inhoud verzonden voor publicatie",
    sendtopublishvariant: "Inhoud verzonden voor publicatie voor talen: %0%",
    sort: "Sorteer onderliggende items door de gebruiker uitgevoerd",
    custom: "%0%",
    smallCopy: "Kopieer",
    smallPublish: "Publiceer",
    smallPublishVariant: "Publiceer",
    smallMove: "Verplaats",
    smallSave: "Bewaar",
    smallSaveVariant: "Bewaar",
    smallDelete: "Verwijder",
    smallUnpublish: "Depubliceer",
    smallUnpublishVariant: "Depubliceer",
    smallRollBack: "Terugzetten",
    smallSendToPublish: "Verzenden voor publicatie",
    smallSendToPublishVariant: "Verzenden voor publicatie",
    smallSort: "Sorteer",
    smallCustom: "Aangepast",
    historyIncludingVariants: "Geschiedenis (alle varianten)"
  },
  buttons: {
    clearSelection: "Selectie ongedaan maken",
    select: "Selecteren",
    somethingElse: "Doe iets anders",
    bold: "Vet",
    deindent: "Paragraaf uitspringen",
    formFieldInsert: "Voeg formulierveld in",
    graphicHeadline: "Voeg grafische titel in",
    htmlEdit: "Wijzig Html",
    indent: "Paragraaf inspringen",
    italic: "Cursief",
    justifyCenter: "Centreren",
    justifyLeft: "Links Uitlijnen",
    justifyRight: "Rechts Uitlijnen",
    linkInsert: "Link Invoegen",
    linkLocal: "Lokale link invoegen (anker)",
    listBullet: "Opsomming",
    listNumeric: "Nummering",
    macroInsert: "Macro invoegen",
    pictureInsert: "Afbeelding invoegen",
    publishAndClose: "Publiceren en sluiten",
    publishDescendants: "Publiceren met onderliggende nodes",
    relations: "Relaties wijzigen",
    returnToList: "Terug naar overzicht",
    save: "Opslaan",
    saveAndClose: "Opslaan en sluiten",
    saveAndPublish: "Opslaan en publiceren",
    saveToPublish: "Opslaan en verzenden voor goedkeuring",
    saveListView: "Lijstweergave opslaan",
    schedulePublish: "Planning",
    saveAndPreview: "Opslaan en voorbeeld bekijken",
    showPageDisabled: "Voorbeeld bekijken is uitgeschakeld omdat er geen sjabloon is geselecteerd",
    styleChoose: "Stijl kiezen",
    styleShow: "Stijlen tonen",
    tableInsert: "Tabel invoegen",
    generateModelsAndClose: "Models genereren en sluiten",
    saveAndGenerateModels: "Opslaan en models genereren",
    undo: "Ongedaan maken",
    redo: "Herhalen",
    deleteTag: "Tag verwijderen",
    confirmActionCancel: "Annuleren",
    confirmActionConfirm: "Bevestigen",
    morePublishingOptions: "Meer publicatie opties",
    submitChanges: "Indienen"
  },
  codefile: {
    createFolderIllegalChars: "De mapnaam mag geen ongeldige tekens bevatten.",
    deleteItemFailed: "Verwijderen van item is mislukt: %0%"
  },
  content: {
    isPublished: "Is gepubliceerd",
    about: "Over deze pagina",
    alias: "Alternatieve link",
    alternativeTextHelp: "(hoe zou jij de foto beschrijven via de telefoon)",
    alternativeUrls: "Alternatieve links",
    clickToEdit: "Klik om dit item te wijzigen",
    createBy: "Aangemaakt door",
    createByDesc: "Oorspronkelijke auteur",
    updatedBy: "Bijgewerkt door",
    createDate: "Aangemaakt op",
    createDateDesc: "Datum/tijd waarop dit document is aangemaakt",
    documentType: "Documenttype",
    editing: "Aanpassen",
    expireDate: "Verloopt op",
    itemChanged: "Dit item is gewijzigd na publicatie",
    itemNotPublished: "Dit item is niet gepubliceerd",
    lastPublished: "Laatst gepubliceerd op",
    noItemsToShow: "Er zijn geen items om weer te geven",
    listViewNoItems: "Er zijn geen items om weer te geven.",
    listViewNoContent: "Er zijn geen subitems toegevoegd",
    listViewNoMembers: "Er zijn geen leden toegevoegd",
    mediatype: "Mediatype",
    mediaLinks: "Link naar media item(s)",
    membergroup: "Ledengroep",
    memberrole: "Rol",
    membertype: "Ledentype",
    noChanges: "Er zijn geen wijzigingen aangebracht",
    noDate: "Geen datum gekozen",
    nodeName: "Pagina Titel",
    noMediaLink: "Dit media item heeft geen link",
    noProperties: "Inhoud kan niet worden toegevoegd aan dit item",
    otherElements: "Eigenschappen",
    parentNotPublished: `Dit document is gepubliceerd maar niet zichtbaar omdat de bovenliggende pagina '%0%'
      niet gepubliceerd is
    `,
    parentCultureNotPublished: `Deze cultuur is gepubliceerd maar is niet zichtbaar omdat het niet
      gepubliceerd is op de bovenliggende pagina '%0%'
    `,
    parentNotPublishedAnomaly: `Dit document is gepubliceerd, maar het staat niet in de cache (interne
      serverfout)
    `,
    getUrlException: "Kan de URL niet ophalen",
    routeError: "Dit document is gepubliceerd maar de URL conflicteert met %0%",
    routeErrorCannotRoute: "Dit document is gepubliceerd maar de URL kan niet worden gerouteerd",
    publish: "Publiceren",
    published: "Gepubliceerd",
    publishedPendingChanges: "Gepubliceerd (hangende wijzigingen)",
    publishStatus: "Publicatiestatus",
    publishDescendantsHelp: "Publiceer <strong>%0%</strong> en alle onderliggende content items en maak daarmee de inhoud openbaar.",
    publishDescendantsWithVariantsHelp: "Publiceer varianten en varianten van hetzelfde onderliggende type en maak daarmee de inhoud openbaar.",
    releaseDate: "Publiceren op",
    unpublishDate: "Depubliceren op",
    removeDate: "Verwijderdatum",
    setDate: "Datum instellen",
    sortDone: "De sorteervolgorde is gewijzigd",
    sortHelp: `Om nodes te sorteren, sleep de nodes of klik op één van de kolomtitels. Je kan meerdere nodes
      tegelijk selecteren door de "shift"- of "control"knop in te drukken tijdens het selecteren.
    `,
    statistics: "Statistieken",
    titleOptional: "Titel (optioneel)",
    altTextOptional: "Alternatieve tekst (optioneel)",
    captionTextOptional: "Bijschrift (optioneel)",
    type: "Type",
    unpublish: "Depubliceren",
    unpublished: "Concept",
    notCreated: "Niet gemaakt",
    updateDate: "Laatst gewijzigd",
    updateDateDesc: "Date/time this document was edited",
    uploadClear: "Bestand(en) verwijderen",
    uploadClearImageContext: "Klik hier om de afbeelding van het media item te verwijderen",
    uploadClearFileContext: "Klik hier om het bestand van het media item te verwijderen",
    urls: "Link naar het document",
    memberof: "Lid van groep(en)",
    notmemberof: "Geen lid van groep(en)",
    childItems: "Subitems",
    target: "Doel",
    scheduledPublishServerTime: "Dit betekend de volgende tijd op de server:",
    scheduledPublishDocumentation: '<a href="https://docs.umbraco.com/umbraco-cms/fundamentals/data/scheduled-publishing#timezones" target="_blank" rel="noopener">Wat houd dit in?</a>',
    nestedContentDeleteItem: "Ben je er zeker van dat je dit item wilt verwijderen?",
    nestedContentDeleteAllItems: "Ben je zeker dat je alle items wilt verwijderen?",
    nestedContentEditorNotSupported: `Eigenschap %0% gebruikt editor %1% welke niet wordt ondersteund door
      Nested Content.
    `,
    nestedContentNoContentTypes: "Er zijn geen content types geconfigureerd voor deze eigenschap.",
    nestedContentAddElementType: "Element type toevoegen",
    nestedContentSelectElementTypeModalTitle: "Selecteer een element type",
    nestedContentGroupHelpText: `Selecteer de groep waarvan je de eigenschappen wil tonen. Indien je niets
      selecteert, wordt de eerste groep van het elementtype gebruikt.
    `,
    nestedContentTemplateHelpTextPart1: `Voer een angular expressie in om te evalueren tegen de naam van elk
      item. Gebruik
    `,
    nestedContentTemplateHelpTextPart2: "om de itemindex weer te geven",
    addTextBox: "Voeg nog een tekstvak toe",
    removeTextBox: "Verwijder dit tekstvak",
    contentRoot: "Content root",
    includeUnpublished: "Inclusief niet-gepubliceerde inhoudsitems.",
    isSensitiveValue: `Deze waarde is verborgen. Indien u toegang nodig heeft om deze waarde te bekijken,
      neem dan contact op met uw websitebeheerder.
    `,
    isSensitiveValue_short: "Deze waarde is verborgen",
    languagesToPublish: "Welke talen wil je publiceren?",
    languagesToSendForApproval: "Welke talen wil je ter goedkeuring verzenden?",
    languagesToSchedule: "Welke talen wil je plannen?",
    languagesToUnpublish: `Selecteer de talen om te depubliceren. Een verplichte taal depubliceren zal alle
      talen depubliceren.
    `,
    variantsWillBeSaved: "Alle nieuwe varianten worden opgeslagen.",
    variantsToPublish: "Welke varianten wil je publiceren?",
    variantsToSave: "Kies welke varianten u wilt opslaan.",
    publishRequiresVariants: "De volgende varianten zijn vereist om te kunnen publiceren:",
    notReadyToPublish: "We zijn niet klaar om te publiceren",
    readyToPublish: "Klaar om te publiceren?",
    readyToSave: "Klaar om op te slaan?",
    sendForApproval: "Ter goedkeuring verzenden",
    schedulePublishHelp: `Selecteer de datum en tijd om het content item te publiceren en/of depubliceren.
    `,
    createEmpty: "Maak nieuw",
    createFromClipboard: "Plakken vanaf het klembord",
    nodeIsInTrash: "Dit item is in de prullenbak",
    saveModalTitle: "Opslaan"
  },
  blueprints: {
    createBlueprintFrom: "Nieuw Inhoudssjabloon aanmaken voor <em>%0%</em>",
    blankBlueprint: "Leeg",
    selectBlueprint: "Selecteer een Inhoudssjabloon",
    createdBlueprintHeading: "Inhoudssjabloon aangemaakt",
    createdBlueprintMessage: "Inhoudssjabloon is aangemaakt voor '%0%'",
    duplicateBlueprintMessage: "Er bestaat al een Inhoudssjabloon met dezelfde naam",
    blueprintDescription: `Een inhoudssjabloon is voorgedefinieerde inhoud die een editor kan selecteren om
      te gebruiken als basis voor het maken van nieuwe inhoud
    `
  },
  media: {
    clickToUpload: "Klik om te uploaden",
    orClickHereToUpload: "Of klik hier om bestanden te kiezen",
    disallowedFileType: "Kan dit bestand niet uploaden, het heeft niet het juiste bestandstype.",
    maxFileSize: "Maximale bestandsgrootte is",
    mediaRoot: "Media root",
    moveToSameFolderFailed: "De bovenliggende map en de doelmap kunnen niet hetzelfde zijn",
    createFolderFailed: "Kan de map onder de bovenliggende map met id %0% niet aanmaken",
    renameFolderFailed: "Kan de map met id %0% niet hernoemen",
    dragAndDropYourFilesIntoTheArea: "Sleep en zet je bestand(en) neer in dit gebied",
    uploadNotAllowed: "Upload is niet toegelaten in deze locatie.",
    fileSecurityValidationFailure: "Een of meerdere veiligheid validaties zijn gefaald voor het bestand"
  },
  member: {
    createNewMember: "Maak nieuw lid aan",
    allMembers: "Alle leden",
    memberGroupNoProperties: "Ledengroepen hebben geen extra eigenschappen om te bewerken."
  },
  create: {
    chooseNode: "Waar wil je de nieuwe %0% aanmaken?",
    createUnder: "Aanmaken onder",
    createContentBlueprint: "Selecteer een documenttype waarvoor je een Inhoudssjabloon wil maken",
    enterFolderName: "Voer een mapnaam in",
    updateData: "Kies een type en een titel",
    noDocumentTypes: 'Er zijn geen toegestane ​​documenttypes beschikbaar. Schakel deze in in de sectie Instellingen onder <strong>"Documenttypes"</ strong>.',
    noDocumentTypesAtRoot: "Er zijn geen documenttypes beschikbaar om hier aan te maken. Je moet deze aanmaken bij <strong>Documenttypes</strong> in de sectie <strong>Instellingen</strong>.",
    noDocumentTypesWithNoSettingsAccess: `De geselecteerde pagina in de boomstructuur laat geen nieuwe
      onderliggende paginas toe.
    `,
    noDocumentTypesEditPermissions: "Rechten aanpassen voor dit documenttype",
    noDocumentTypesCreateNew: "Nieuw documenttype aanmaken",
    noDocumentTypesAllowedAtRoot: "Er zijn geen toegestane ​​documenttypes beschikbaar om hier aan te maken. Je moet deze inschakelen bij <strong>Documenttypes</strong> in de sectie <strong>Instellingen</strong>, de optie <strong>Toestaan op root-niveau</strong> onder <strong>Rechten</strong>.",
    noMediaTypes: 'Er zijn geen toegestande mediatypes beschikbaar. Schakel deze in in de sectie Instellingen onder <strong>"Mediatypes"</strong>.',
    noMediaTypesWithNoSettingsAccess: `De geselecteerde media in de boomstructuur laat niet toe dat er
      onderliggende media aangemaakt wordt.
    `,
    noMediaTypesEditPermissions: "Rechten aanpassen voor dit mediatype",
    documentTypeWithoutTemplate: "Documenttype zonder sjabloon",
    newFolder: "Nieuwe map",
    newDataType: "Nieuw datatype",
    newJavascriptFile: "Nieuw JavaScript bestand",
    newEmptyPartialView: "Nieuwe lege partial view",
    newPartialViewMacro: "Nieuwe partial view macro",
    newPartialViewFromSnippet: "Nieuwe partial view van fragment",
    newPartialViewMacroFromSnippet: "Nieuwe partial view macro van fragment",
    newPartialViewMacroNoMacro: "Nieuwe partial view macro (zonder macro)",
    newStyleSheetFile: "Nieuw style sheet bestand",
    newRteStyleSheetFile: "Nieuw Rich Text Editor style sheet bestand"
  },
  dashboard: {
    browser: "Open je website",
    dontShowAgain: "- Verbergen",
    nothinghappens: `Als Umbraco niet geopend wordt dan moet je mogelijk popups toestaan voor deze site.
    `,
    openinnew: "is geopend in een nieuw venster",
    restart: "Herstarten",
    visit: "Bezoek",
    welcome: "Welkom"
  },
  prompt: {
    stay: "Blijf op deze pagina",
    discardChanges: "Negeer wijzigingen",
    unsavedChanges: "Wijzigingen niet opgeslagen",
    unsavedChangesWarning: `Weet je zeker dat deze pagina wilt verlaten? Er zijn onopgeslagen wijzigingen
    `,
    confirmListViewPublish: "Publiceren maakt de geselecteerde items zichtbaar op de site.",
    confirmListViewUnpublish: `Depubliceren zal de geselecteerde items en alle onderliggende items
      verwijderen van de site.
    `,
    confirmUnpublish: `Depubliceren zal deze pagina en alle onderliggende pagina's verwijderen van de site.
    `,
    doctypeChangeWarning: `Wijzigingen niet opgeslagen. Aanpassingen aan het Documenttype zullen de
      wijzigingen ongedaan maken.
    `
  },
  bulk: {
    done: "Done",
    deletedItem: "%0% item verwijderd",
    deletedItems: "%0% items verwijderd",
    deletedItemOfItem: "Item %0% van de %1% verwijderd",
    deletedItemOfItems: "Items %0% van de %1% verwijderd",
    publishedItem: "%0% item gepubliceerd",
    publishedItems: "%0% items gepubliceerd",
    publishedItemOfItem: "Item %0% van de %1% gepubliceerd",
    publishedItemOfItems: "Items %0% van de %1% gepubliceerd",
    unpublishedItem: "%0% item gedepubliceerd",
    unpublishedItems: "%0% items gedepubliceerd",
    unpublishedItemOfItem: "Item %0% van de %1% gedepubliceerd",
    unpublishedItemOfItems: "Items %0% van de %1% gedepubliceerd",
    movedItem: "%0% item verplaatst",
    movedItems: "%0% items verplaatst",
    movedItemOfItem: "item %0% van de %1% verplaatst",
    movedItemOfItems: "items %0% van de %1% verplaatst",
    copiedItem: "%0% item gekopieerd",
    copiedItems: "%0% items gekopieerd",
    copiedItemOfItem: "item %0% van de %1% gekopieerd",
    copiedItemOfItems: "item %0% van de %1% gekopieerd"
  },
  defaultdialogs: {
    nodeNameLinkPicker: "Link Titel",
    urlLinkPicker: "Link",
    anchorLinkPicker: "Anker / querystring",
    anchorInsert: "Naam",
    closeThisWindow: "Sluit dit venster",
    confirmdelete: "Weet je zeker dat je dit wilt verwijderen",
    confirmdisable: "Weet je zeker dat je dit wilt uitschakelen",
    confirmremove: "Weet u zeker dat u wilt verwijderen",
    confirmremoveusageof: "Ben je zeker dat je het gebruik van <strong>%0%</strong> wil verwijderen",
    confirmlogout: "Weet je het zeker?",
    confirmSure: "Weet je het zeker?",
    cut: "Knippen",
    editDictionary: "Pas woordenboekitem aan",
    editLanguage: "Taal aanpassen",
    editSelectedMedia: "Geselecteerde media bewerken",
    insertAnchor: "Lokale link invoegen",
    insertCharacter: "Karakter invoegen",
    insertgraphicheadline: "Voeg grafische titel in",
    insertimage: "Afbeelding invoegen",
    insertlink: "Link invoegen",
    insertMacro: "Klik om een Macro toe te voegen",
    inserttable: "Tabel invoegen",
    languagedeletewarning: "Dit zal de taal verwijderen",
    languageChangeWarning: `De cultuur veranderen voor een taal kan een langdurige operatie zijn en zal ertoe
      leiden dat de inhoudscache en indexen opnieuw worden opgebouwd
    `,
    lastEdited: "Laatst aangepast op",
    link: "Link",
    linkinternal: "Interne link",
    linklocaltip: "Plaats een hekje (“#”) voor voor interne links.",
    linknewwindow: "In nieuw venster openen?",
    macroDoesNotHaveProperties: "Deze macro heeft geen eigenschappen die u kunt bewerken",
    paste: "Plakken",
    permissionsEdit: "Bewerk rechten voor",
    permissionsSet: "Rechten instellen voor",
    permissionsSetForGroup: "Rechten instellen voor %0% voor gebruikersgroepf %1%",
    permissionsHelp: "Selecteer de gebruikersgroepen waarvoor u de rechten wilt instellen",
    recycleBinDeleting: `De items worden nu uit de prullenbak verwijderd. Sluit dit venster niet terwijl de
      actie nog niet voltooid is.
    `,
    recycleBinIsEmpty: "De prullenbak is nu leeg.",
    recycleBinWarning: "Als items worden verwijderd uit de prullenbak, zijn ze voorgoed verwijderd.",
    regexSearchError: "De webservice van <a target='_blank' rel='noopener' href='https://regexlib.com'>regexlib.com</a> ondervindt momenteel problemen waarover we geen controle hebben. Onze excuses voor het ongemak.",
    regexSearchHelp: `Zoek naar een reguliere expressie om validatie aan een formulierveld toe te voegen.
      Voorbeeld: 'email', 'postcode', 'URL'.
    `,
    removeMacro: "Verwijder Macro",
    requiredField: "Verplicht veld",
    sitereindexed: "Site is opnieuw geïndexeerd",
    siterepublished: "De site is opnieuw gepubliceerd",
    siterepublishHelp: `De cache zal worden vernieuwd. Alle gepubliceerde inhoud zal worden bijgewerkt,
      terwijl ongepubliceerde inhoud ongepubliceerd zal blijven.
    `,
    tableColumns: "Aantal kolommen",
    tableRows: "Aantal regels",
    thumbnailimageclickfororiginal: "Klik op de afbeelding voor volledige grootte",
    treepicker: "Kies een item",
    viewCacheItem: "Toon cache item",
    relateToOriginalLabel: "Relateer aan origineel",
    includeDescendants: "Onderliggende nodes meenemen",
    theFriendliestCommunity: "De vriendelijkste gemeenschap",
    linkToPage: "Link naar pagina",
    openInNewWindow: "Opent het gelinkte document in een nieuw venster of tab",
    linkToMedia: "Link naar media",
    selectContentStartNode: "Selecteer content start node",
    selectMedia: "Selecteer media",
    selectMediaType: "Selecteer media type",
    selectIcon: "Selecteer icoon",
    selectItem: "Selecteer item",
    selectLink: "Selecteer link",
    selectMacro: "Selecteer macro",
    selectContent: "Selecteer content",
    selectContentType: "Selecteer content type",
    selectMediaStartNode: "Selecteer media start node",
    selectMember: "Selecteer member",
    selectMemberGroup: "Selecteer lid groep",
    selectMemberType: "Selecteer lid type",
    selectNode: "Selecteer node",
    selectLanguages: "Selecteer talen",
    selectSections: "Selecteer secties",
    selectUser: "Selecteer gebruiker",
    selectUsers: "Selecteer gebruikers",
    noIconsFound: "Geen iconen gevonden",
    noMacroParams: "Er zijn geen parameters voor deze macro",
    noMacros: "Er zijn geen macro's beschikbaar om in te voegen",
    externalLoginProviders: "Externe login providers",
    exceptionDetail: "Error details",
    stacktrace: "Stacktrace",
    innerException: "Inner Exception",
    linkYour: "Link je",
    unLinkYour: "De-Link je",
    account: "account",
    selectEditor: "Selecteer editor",
    selectEditorConfiguration: "Selecteer configuratie",
    selectSnippet: "Selecteer fragment",
    variantdeletewarning: `Dit zal de node en al zijn talen verwijderen. Als je slechts één taal wil
      verwijderen, moet je de node in die taal depubliceren.
    `,
    propertyuserpickerremovewarning: "Dit zal de gebruiker <strong>%0%</strong> verwijderen.",
    userremovewarning: "Dit zal de gebruiker <strong>%0%</strong> verwijderen van de <strong>%1%</strong> groep",
    yesRemove: "Ja, verwijderen"
  },
  dictionary: {
    noItems: "Er zijn geen woordenboekitems.",
    noItemsFound: "Er zijn geen woordenboekitems gevonden.",
    createNew: "Woordenboekitem aanmaken"
  },
  dictionaryItem: {
    description: "Wijzig de verschillende taalversies voor het woordenboek item '%0%'. Je kunt extra talen toevoegen bij 'talen' in het menu links",
    displayName: "Cultuurnaam",
    changeKeyError: "De key '%0%' bestaat al.",
    overviewTitle: "Woordenboek overzicht"
  },
  examineManagement: {
    configuredSearchers: "Ingestelde Zoekers",
    configuredSearchersDescription: `Toont eigenschappen en hulpmiddelen voor elke geconfigureerde Zoeker
      (bijv. zoals een multi-indexzoeker)
    `,
    fieldValues: "Veldwaarden",
    healthStatus: "Gezondheidsstatus",
    healthStatusDescription: "De gezondheidsstatus van de index en of het kan gelezen worden",
    indexers: "Indexeerders",
    indexInfo: "Index info",
    indexInfoDescription: "De eigenschappen oplijsten van de index",
    manageIndexes: "Beheer de indexen van Examine",
    manageIndexesDescription: `Bekijk de details van elke index en gebruik hulpmiddelen voor het beheer er
      van
    `,
    rebuildIndex: "Index opnieuw bouwen",
    rebuildIndexWarning: `
      Hierdoor wordt de index opnieuw opgebouwd.<br />
      Afhankelijk van hoeveel inhoud er op je site staat, kan dit even duren.<br />
      Het wordt niet aanbevolen om een index opnieuw op te bouwen terwijl er veel verkeer op de website is of wanneer editors inhoud bewerken.
     `,
    searchers: "Zoekers",
    searchDescription: "Zoek in de index en bekijk de resultaten",
    tools: "Hulpmiddelen",
    toolsDescription: "Hulpmiddelen om de index te beheren",
    fields: "velden",
    indexCannotRead: "De index kan niet gelezen worden en moet opnieuw worden gebouwd",
    processIsTakingLonger: `Het proces duurt langer dan verwacht, controleer het Umbraco logboek om te kijken
      of er geen fouten waren tijdens deze operatie
    `,
    indexCannotRebuild: "Deze index kan niet opnieuw worden opgebouwd want het heeft geen toegewezen",
    iIndexPopulator: "IIndexPopulator"
  },
  placeholders: {
    username: "Typ jouw gebruikersnaam",
    password: "Typ jouw wachtwoord",
    confirmPassword: "Bevestig jouw wachtwoord",
    nameentity: "Benoem de %0%...",
    entername: "Typ een naam...",
    enteremail: "Voer een e-mailadres in",
    enterusername: "Voer een gebruikersnaam in...",
    label: "Label...",
    enterDescription: "Voer een omschrijving in...",
    search: "Typ om te zoeken...",
    filter: "Typ om te filteren...",
    enterTags: "Typ om tags toe te voegen (druk op Enter na elke tag)...",
    email: "Voer jouw e-mailadres in",
    enterMessage: "Voer een bericht in ...",
    usernameHint: "Jouw gebruikersnaam is meestal jouw e-mailadres",
    anchor: "#value of ?key=value",
    enterAlias: "Voer een alias in...",
    generatingAlias: "Alias genereren...",
    a11yCreateItem: "Item aanmaken",
    a11yEdit: "Bewerken",
    a11yName: "Naam"
  },
  editcontenttype: {
    createListView: "Maak een aangepaste lijstweergave",
    removeListView: "Verwijder aangepaste lijstweergave",
    aliasAlreadyExists: "Een content type, media type of member type met deze alias bestaat al"
  },
  renamecontainer: {
    renamed: "Hernoemd",
    enterNewFolderName: "Voer een nieuwe mapnaam in",
    folderWasRenamed: "%0% is hernoemd naar %1%"
  },
  editdatatype: {
    addPrevalue: "Prevalue toevoegen",
    dataBaseDatatype: "Database datatype",
    guid: "Data Editor GUID",
    renderControl: "Render control",
    rteButtons: "Knoppen",
    rteEnableAdvancedSettings: "Geavanceerde instellingen inschakelen voor",
    rteEnableContextMenu: "Context menu inschakelen",
    rteMaximumDefaultImgSize: "Maximum standaard grootte van afbeeldingen",
    rteRelatedStylesheets: "Gerelateerde stylesheets",
    rteShowLabel: "Toon label",
    rteWidthAndHeight: "Breedte en hoogte",
    selectFolder: "Selecteer een map om te verplaatsen",
    inTheTree: "naar in de boomstructuur hieronder",
    wasMoved: "werd eronder verplaatst",
    hasReferencesDeleteConsequence: "Door <strong>%0%</strong> te verwijderen zullen alle eigenschappen en de data verwijderd worden van de volgende items:",
    acceptDeleteConsequence: `Ik begrijp dat deze actie alle eigenschappen en data zal verwijderen die
      gebaseerd is op dit datatype.
    `
  },
  errorHandling: {
    errorButDataWasSaved: `Je data is opgeslagen, maar voordat je deze pagina kunt publiceren moet je eerst
      aan paar problemen oplossen:
    `,
    errorChangingProviderPassword: `Veranderen van het wachtwoord wordt door de huidige Membership Provider
      niet ondersteund (EnablePasswordRetrieval moet op true staan)
    `,
    errorExistsWithoutTab: "%0% bestaat al",
    errorHeader: "Er zijn fouten geconstateerd:",
    errorHeaderWithoutTab: "Er zijn fouten geconstateerd:",
    errorInPasswordFormat: `Het wachtwoord moet minstens %0% tekens lang zijn en moet minstens %1% cijfers
      bevatten
    `,
    errorIntegerWithoutTab: "%0% moet een geheel getal zijn",
    errorMandatory: "%0% op tab %1% is een verplicht veld",
    errorMandatoryWithoutTab: "%0% is een verplicht veld",
    errorRegExp: "%0% op tab %1% is niet in het correcte formaat",
    errorRegExpWithoutTab: "%0% is niet in het correcte formaat"
  },
  errors: {
    receivedErrorFromServer: "Een error ontvangen van de server",
    dissallowedMediaType: "Het opgegeven bestandstype is niet toegestaan ​​door de beheerder",
    codemirroriewarning: `OPMERKING! Ondanks dat CodeMiror is ingeschakeld, is het uitgeschakeld in Internet
      Explorer omdat het niet stabiel genoeg is.
    `,
    contentTypeAliasAndNameNotNull: `Zowel de alias als de naam van het nieuwe eigenschappentype moeten
      worden ingevuld!
    `,
    filePermissionsError: "Er is een probleem met de lees/schrijfrechten op een bestand of map",
    macroErrorLoadingPartialView: "Error bij het laden van Partial View script (file: %0%)",
    missingTitle: "Vul een titel in",
    missingType: "Selecteer een type",
    pictureResizeBiggerThanOrg: `U wilt een afbeelding groter maken dan de originele afmetingen. Weet je
      zeker dat je wilt doorgaan?
    `,
    startNodeDoesNotExists: "Start node is verwijderd, neem contact op met uw systeembeheerder",
    stylesMustMarkBeforeSelect: "Markeer de inhoud voordat u de stijl aanpast",
    stylesNoStylesOnPage: "Geen actieve stijlen beschikbaar",
    tableColMergeLeft: "Plaats de cursor links van de twee cellen die je wilt samenvoegen",
    tableSplitNotSplittable: "Je kunt een cel die is samengevoegd niet delen",
    propertyHasErrors: "Deze eigenschap is ongeldig"
  },
  general: {
    options: "Opties",
    about: "Over",
    action: "Actie",
    actions: "Acties",
    add: "Toevoegen",
    alias: "Alias",
    all: "Alles",
    areyousure: "Weet je het zeker?",
    back: "Terug",
    backToOverview: "Terug naar overzicht",
    border: "Rand",
    by: "bij",
    cancel: "Annuleren",
    cellMargin: "Cel marge",
    choose: "Kies",
    clear: "Wissen",
    close: "Sluiten",
    closewindow: "Sluit venster",
    closepane: "Sluit paneel",
    comment: "Commentaar",
    confirm: "Bevestig",
    constrain: "Beperken",
    constrainProportions: "Verhoudingen behouden",
    content: "Inhoud",
    continue: "Doorgaan",
    copy: "Kopiëren",
    create: "Aanmaken",
    cropSection: "Sectie bijsnijden",
    database: "Database",
    date: "Datum",
    default: "Standaard",
    delete: "Verwijder",
    deleted: "Verwijderd",
    deleting: "Aan het verwijderen...",
    design: "Ontwerp",
    dictionary: "Woordenboek",
    dimensions: "Afmetingen",
    discard: "Gooi weg",
    down: "Omlaag",
    download: "Download",
    edit: "Bewerken",
    edited: "Bewerkt",
    elements: "Elementen",
    email: "E-mail",
    error: "Fout",
    field: "Veld",
    findDocument: "Zoeken",
    first: "Eerste",
    focalPoint: "Focus punt",
    general: "Algemeen",
    groups: "Groepen",
    group: "Groep",
    height: "Hoogte",
    help: "Help",
    hide: "Verbergen",
    history: "Geschiedenis",
    icon: "Icoon",
    id: "Id",
    import: "Importeren",
    excludeFromSubFolders: "Alleen in deze map zoeken",
    info: "Info",
    innerMargin: "Binnenste marge",
    insert: "Invoegen",
    install: "Installeren",
    invalid: "Ongeldig",
    justify: "Uitvullen",
    label: "Label",
    language: "Taal",
    last: "Laatste",
    layout: "Layout",
    links: "Links",
    loading: "Aan het laden",
    locked: "Gesloten",
    login: "Inloggen",
    logoff: "Uitloggen",
    logout: "Uitloggen",
    macro: "Macro",
    mandatory: "Verplicht",
    message: "Bericht",
    move: "Verplaats",
    name: "Naam",
    new: "Nieuw",
    next: "Volgende",
    no: "Nee",
    of: "of",
    off: "Uit",
    ok: "OK",
    open: "Open",
    on: "Aan",
    or: "of",
    orderBy: "Sorteren op",
    password: "Wachtwoord",
    path: "Pad",
    pleasewait: "Een ogenblik geduld aub...",
    previous: "Vorige",
    properties: "Eigenschappen",
    readMore: "Lees meer",
    rebuild: "Opnieuw opbouwen",
    reciept: "E-mail om formulier resultaten te ontvangen",
    recycleBin: "Prullenbak",
    recycleBinEmpty: "De prullenbak is leeg",
    reload: "Vernieuwen",
    remaining: "Overblijvend",
    remove: "Verwijderen",
    rename: "Hernoem",
    renew: "Vernieuw",
    required: "Verplicht",
    retrieve: "Ophalen",
    retry: "Opnieuw proberen",
    rights: "Rechten",
    scheduledPublishing: "Geplande publicatie",
    search: "Zoeken",
    searchNoResult: "We konden helaas niet vinden wat je zocht",
    noItemsInList: "Er zijn geen items toegevoegd",
    server: "Server",
    settings: "Instellingen",
    shared: "Gedeeld",
    show: "Toon",
    showPageOnSend: "Toon pagina na verzenden",
    size: "Grootte",
    sort: "Sorteer",
    status: "Status",
    submit: "Verstuur",
    success: "Succes",
    type: "Typen",
    typeToSearch: "Typ om te zoeken...",
    under: "onder",
    up: "Omhoog",
    update: "Update",
    upgrade: "Upgrade",
    upload: "Upload",
    url: "URL",
    user: "Gebruiker",
    username: "Gebruikersnaam",
    value: "Waarde",
    view: "Bekijk",
    welcome: "Welkom...",
    width: "Breedte",
    yes: "Ja",
    folder: "Map",
    searchResults: "Zoekresultaten",
    reorder: "Herschik",
    reorderDone: "Ik ben klaar met herschikken",
    preview: "Voorvertoning",
    changePassword: "Wachtwoord veranderen",
    to: "naar",
    listView: "Lijstweergave",
    saving: "Aan het opslaan...",
    current: "huidig",
    embed: "Embed",
    selected: "geselecteerd",
    other: "Andere",
    articles: "Artikels",
    videos: "Videos",
    avatar: "Avatar van"
  },
  colors: {
    blue: "Blauw"
  },
  shortcuts: {
    addTab: "Tabblad toevoegen",
    addGroup: "Groep toevoegen",
    addProperty: "Eigenschap toevoegen",
    addEditor: "Editor toevoegen",
    addTemplate: "Sjabloon toevoegen",
    addChildNode: "Child node toevoegen",
    addChild: "Child toevoegen",
    editDataType: "Datatype bewerken",
    navigateSections: "Secties navigeren",
    shortcut: "Snelkoppeling",
    showShortcuts: "Toon snelkoppelingen",
    toggleListView: "Lijstweergave in/uitschakelen",
    toggleAllowAsRoot: "Toestaan op root-niveau in/uitschakelen",
    commentLine: "Regel in/uit commentaar zetten",
    removeLine: "Regel verwijderen",
    copyLineUp: "Kopieer Regels Omhoog",
    copyLineDown: "Kopieer Regels Omlaag",
    moveLineUp: "Verplaats Regels Omhoog",
    moveLineDown: "Verplaats Regels Omlaag",
    generalHeader: "Algemeen",
    editorHeader: "Editor",
    toggleAllowCultureVariants: "Cultuur varianten toestaan in/uitschakelen"
  },
  graphicheadline: {
    backgroundcolor: "Achtergrondkleur",
    bold: "Vet",
    color: "Tekstkleur",
    font: "Lettertype",
    text: "Tekst"
  },
  headers: {
    page: "Pagina"
  },
  installer: {
    databaseErrorCannotConnect: "De installer kan geen connectie met de database maken.",
    databaseFound: "Je database is gevonden en is geïdentificeerd als",
    databaseHeader: "Database configuratie",
    databaseInstall: "Druk op de knop <strong>installeren</strong> om de Umbraco %0% database te installeren",
    databaseInstallDone: "Umbraco %0% is nu gekopieerd naar je database. Druk op <strong>Volgende</strong> om door te gaan.",
    databaseText: 'Om deze stap te voltooien moet je enkele gegevens weten over je database server ("connection string").<br/> Gelieve contact op te nemen met je ISP indien nodig. Wanneer je installeert op een lokale computer of server, dan heb je waarschijnlijk informatie nodig van je systeembeheerder.',
    databaseUpgrade: "<p> Klik de <strong>upgrade</strong> knop om je database te upgraden naar Umbraco %0%</p> <p> Maak je geen zorgen - er zal geen inhoud worden gewist en alles blijft gewoon werken! </p>",
    databaseUpgradeDone: "Je database is geupgrade naar de definitieve versie %0%.<br />Klik <strong>Volgende</strong> om verder te gaan.",
    databaseUpToDate: "De huidige database is up-to-date!. Klik <strong>volgende</strong> om door te gaan",
    defaultUserChangePass: "<strong>Het wachtwoord van de default gebruiker dient veranderd te worden!</strong>",
    defaultUserDisabled: "<strong>De default gebruiker is geblokkeerd of heeft geen toegang tot Umbraco!</strong></p><p>Geen verdere actie noodzakelijk. Klik <strong>Volgende</strong> om verder te gaan.",
    defaultUserPassChanged: "<strong>Het wachtwoord van de default gebruiker is sinds installatie met succes veranderd.</strong></p><p>Geen verdere actie noodzakelijk. Klik <strong>Volgende</strong> om verder te gaan.",
    defaultUserPasswordChanged: "Het wachtwoord is veranderd!",
    greatStart: "Neem een jumpstart en bekijk onze introductie videos",
    None: "Nog niet geïnstalleerd.",
    permissionsAffectedFolders: "Betreffende bestanden en mappen",
    permissionsAffectedFoldersMoreInfo: `Meer informatie over het instellen van machtigingen voor Umbraco
      vind je hier
    `,
    permissionsAffectedFoldersText: `Je dient ASP.NET 'modify' machtiging te geven voor de volgende
      bestanden/mappen
    `,
    permissionsAlmostPerfect: "<strong>Je machtigingen zijn bijna perfect!</strong><br /><br /> Je kunt Umbraco zonder problemen starten, maar je kunt nog geen packages installeren om volledig van Umbraco te profiteren.",
    permissionsHowtoResolve: "Hoe op te lossen",
    permissionsHowtoResolveLink: "Klik hier om de tekst versie te lezen",
    permissionsHowtoResolveText: "Bekijk onze <strong>video tutorial</strong> over het instellen van machtigingen voor Umbraco, of lees de tekst versie.",
    permissionsMaybeAnIssue: "<strong>Je machtigingen zijn misschien incorrect!</strong> <br/><br /> Je kunt Umbraco probleemloos starten, maar je kunt nog geen mappen aanmaken of packages installeren om zo volledig van Umbraco te profiteren.",
    permissionsNotReady: "<strong>Je machtigingen zijn nog niet gereed gemaakt voor Umbraco!</strong> <br /><br /> Om Umbraco te starten zul je je machtigingen moeten aanpassen.",
    permissionsPerfect: "<strong>Je machtigingen zijn perfect!</strong><br /><br /> Je bent nu klaar om Umbraco te starten en om packages te installeren!",
    permissionsResolveFolderIssues: "Map probleem wordt opgelost",
    permissionsResolveFolderIssuesLink: `Volg deze link voor meer informatie over problemen met ASP.NET en
      het aanmaken van mappen
    `,
    permissionsSettingUpPermissions: "Machtigingen worden aangepast",
    permissionsText: `Umbraco heeft write/modify toegang nodig op bepaalde mappen om bestanden zoals plaatjes
      en PDF's op te slaan. Het slaat ook tijdelijke data (ook bekend als 'de cache') op om de snelheid van je website
      te verbeteren.
    `,
    runwayFromScratch: "Ik wil met een lege website beginnen",
    runwayFromScratchText: 'Je website is momenteel helemaal leeg. Dat is prima als je vanaf nul wilt beginnen en je eigen documenttypes en templates wilt maken (<a href="https://umbraco.tv/documentation/videos/for-site-builders/foundation/document-types">leer hoe</a>). Je kunt er later alsnog voor kiezen om Runway te installeren. Ga dan naar de Ontwikkelaar sectie en kies Packages.',
    runwayHeader: "Je hebt zojuist een blanco Umbraco platform geinstalleerd. Wat wil je nu doen?",
    runwayInstalled: "Runway is geinstalleerd",
    runwayInstalledText: 'Je hebt de basis geinstalleerd. Kies welke modules je er op wilt installeren.<br /> Dit is onze lijst van aanbevolen modules. Vink de modules die je wilt installeren, of bekijk de <a href="#" onclick="toggleModules(); return false;" id="toggleModuleList">volledige lijst modules</a>',
    runwayOnlyProUsers: "Alleen aanbevolen voor gevorderde gebruikers",
    runwaySimpleSite: "Ik wil met een eenvoudige website beginnen",
    runwaySimpleSiteText: `<p> "Runway" is een eenvoudige website die je van enkele elementaire documenttypes en templates voorziet. De installer kan Runway automatisch voor je opzetten, maar je kunt het gemakkelijk aanpassen, uitbreiden of verwijderen. Het is niet vereist en je kunt Umbraco prima zonder Runway gebruiken.

Echter, Runway biedt een gemakkelijke basis om je snel op weg te helpen. Als je er voor kiest om Runway te installeren, dan kun je optioneel de bouwstenen (genaamd Runway Modules) kiezen om je Runway pagina's te verbeteren.</p> <small> <em>Runway omvat:</em> Home pagina, Getting Started pagina, Module installatie pagina.<br /> <em>Optionele Modules:</em> Top Navigatie, Sitemap, Contact, Gallery. </small>
    `,
    runwayWhatIsRunway: "Wat is Runway",
    step1: "Stap 1/5: Licentie aanvaarden",
    step2: "Stap 2/5: Database configureren",
    step3: "Stap 3/5: Controleren van rechten op bestanden",
    step4: "Stap 4/5: Umbraco beveiliging controleren",
    step5: "Stap 5/5: Umbraco is klaar",
    thankYou: "Bedankt dat je voor Umbraco hebt gekozen",
    theEndBrowseSite: "<h3>Browse je nieuwe site</h3> Je hebt Runway geinstalleerd, dus kijk eens hoe je nieuwe site eruit ziet.",
    theEndFurtherHelp: "<h3>Meer hulp en informatie</h3> Vind hulp in onze bekroonde community, blader door de documentatie of bekijk enkele gratis videos over het bouwen van een eenvoudige site, het gebruiken van packages en een overzicht van Umbraco terminologie",
    theEndHeader: "Umbraco %0% is geïnstalleerd en klaar voor gebruik.",
    theEndInstallSuccess: `Je kunt <strong>meteen beginnen</strong> door de "Launch Umbraco" knop hieronder te klikken. <br />Als je een <strong>beginnende Umbraco gebruiker</strong> bent, dan kun je you can find veel informatie op onze "getting started" pagina's vinden.`,
    theEndOpenUmbraco: "<h3>Launch Umbraco</h3> Om je website te beheren open je simpelweg de Umbraco backoffice en begin je inhoud toe te voegen, templates en stylesheets aan te passen of nieuwe functionaliteit toe te voegen",
    Unavailable: "Verbinding met de database mislukt.",
    Version3: "Umbraco versie 3",
    Version4: "Umbraco versie 4",
    watch: "Bekijken",
    welcomeIntro: 'Deze wizard helpt u met het configureren van <strong>Umbraco %0%</strong> voor een nieuwe installatie of een upgrade van versie 3.0. <br /><br /> Druk op <strong>"volgende"</strong> om de wizard te starten.'
  },
  language: {
    cultureCode: "Cultuurcode",
    displayName: "Cultuurnaam"
  },
  lockout: {
    lockoutWillOccur: "Je bent inactief en zult automatisch worden uitgelogd over",
    renewSession: "Vernieuw je sessie om je wijzigingen te behouden"
  },
  login: {
    greeting0: "Welkom",
    greeting1: "Welkom",
    greeting2: "Welkom",
    greeting3: "Welkom",
    greeting4: "Welkom",
    greeting5: "Welkom",
    greeting6: "Welkom",
    instruction: "log hieronder in",
    signInWith: "Inloggen met",
    timeout: "Sessie is verlopen",
    bottomText: '<p style="text-align:right;">&copy; 2001 - %0% <br /><a href="https://umbraco.com" style="text-decoration: none" target="_blank" rel="noopener">umbraco.com</a></p>',
    forgottenPassword: "Wachtwoord vergeten?",
    forgottenPasswordInstruction: `Er zal een e-mail worden gestuurd naar het e-mailadres van jouw account.
      Hierin staat een link om je wachtwoord te resetten
    `,
    requestPasswordResetConfirmation: `Een e-mail met daarin de wachtwoord reset uitleg zal worden gestuurd
      als het e-mailadres in onze database voorkomt.
    `,
    showPassword: "Wachtwoord tonen",
    hidePassword: "Wacthwoord verbergen",
    returnToLogin: "Terug naar loginformulier",
    setPasswordInstruction: "Geef alsjeblieft een nieuw wachtwoord op",
    setPasswordConfirmation: "Je wachtwoord is aangepast",
    resetCodeExpired: "De link die je hebt aangeklikt is niet (meer) geldig.",
    resetPasswordEmailCopySubject: "Umbraco: Wachtwoord Reset",
    resetPasswordEmailCopyFormat: '<p>De gebruikersnaam om in te loggen bij jouw Umbraco omgeving is: <strong>%0%</strong></p><p>Klik <a href="%1%"><strong>hier</strong></a> om je wachtwoord te resetten of knip/plak deze URL in je browser:</p><p><em>%1%</em></p>',
    mfaSecurityCodeSubject: "Umbraco: Beveiligingscode",
    mfaSecurityCodeMessage: "Jouw beveiligingscode is: %0%",
    "2faTitle": "Laatste stap",
    "2faText": "Je hebt tweestapsverificatie ingeschakeld en moet je identiteit verifiëren.",
    "2faMultipleText": "Kies een tweestapsverificatie aanbieder",
    "2faCodeInput": "Verificatiecode",
    "2faCodeInputHelp": "Vul de verificatiecode in",
    "2faInvalidCode": "Ongeldige code ingevoerd"
  },
  main: {
    dashboard: "Dashboard",
    sections: "Secties",
    tree: "Inhoud"
  },
  moveOrCopy: {
    choose: "Selecteer pagina boven...",
    copyDone: "%0% is gekopieerd naar %1%",
    copyTo: "Kopieer naar",
    moveDone: "%0% is verplaatst naar %1%",
    moveTo: "Verplaats naar",
    nodeSelected: "is geselecteerd als root van je nieuwe pagina, klik hieronder op 'ok'.",
    noNodeSelected: `Nog geen node geselecteerd, selecteer eerst een node in bovenstaade lijst voordat je op
      'volgende' klikt
    `,
    notAllowedByContentType: `De huidige node is niet toegestaan onder de geselecteerde node vanwege het node
      type
    `,
    notAllowedByPath: "De huidige node kan niet naar een van zijn subpagina’s worden verplaatst.",
    notAllowedAtRoot: "De huidige node kan niet worden gebruikt op root-niveau",
    notValid: "Deze actie is niet toegestaan omdat je onvoldoende rechten hebt op één of meer subitems.",
    relateToOriginal: "Relateer gekopieerde items aan het origineel"
  },
  notifications: {
    editNotifications: "Bewerk de notificatie voor %0%",
    notificationsSavedFor: "Notificatie instellingen opgeslagen voor %0%",
    notifications: "Notificaties"
  },
  packager: {
    actions: "Acties",
    created: "Aangemaakt",
    createPackage: "Package aanmaken",
    chooseLocalPackageText: `Kies een package op je computer door op "Bladeren" te klikken en de package te
      selecteren. Umbraco packages hebben meestal ".umb" of ".zip" als extensie.
    `,
    deletewarning: "Dit zal de package verwijderen",
    includeAllChildNodes: "Inclusief alle onderliggende nodes",
    installed: "Geïnstalleerd",
    installedPackages: "Geïnstalleerde packages",
    noConfigurationView: "Deze package heeft geen instellingen",
    noPackagesCreated: "Er zijn nog geen packages aangemaakt",
    noPackages: "Er zijn geen packages geïnstalleerd",
    noPackagesDescription: "Je hebt geen packages geïnstalleerd. Installeer een lokale package door het op je computer te selecteren of blader door beschikbare packages met het pictogram <strong>'Packages'</strong> rechtsboven in je scherm.",
    packageContent: "Package Inhoud",
    packageLicense: "Licentie",
    packageSearch: "Zoeken naar packages",
    packageSearchResults: "Resultaten voor",
    packageNoResults: "We konden niets vinden voor",
    packageNoResultsDescription: "Probeer een ander pakket te zoeken of blader door de categorieën",
    packagesPopular: "Populair",
    packagesNew: "Nieuwe releases",
    packageHas: "heeft",
    packageKarmaPoints: "karma punten",
    packageInfo: "Informatie",
    packageOwner: "Eigenaar",
    packageContrib: "Bijdragers",
    packageCreated: "Aangemaakt",
    packageCurrentVersion: "Huidige versie",
    packageNetVersion: ".NET versie",
    packageDownloads: "Downloads",
    packageLikes: "Likes",
    packageCompatibility: "Compatibiliteit",
    packageCompatibilityDescription: `Deze package is compatibel met de volgende versies van Umbraco, zoals
      gerapporteerd door de communityleden. Volledige compatibiliteit kan niet worden gegarandeerd voor versies die voor
      minder dan 100% worden gerapporteerd
    `,
    packageExternalSources: "Externe bronnen",
    packageAuthor: "Auteur",
    packageDocumentation: "Documentatie",
    packageMetaData: "Package meta data",
    packageName: "Package naam",
    packageNoItemsHeader: "Package bevat geen inhoud",
    packageNoItemsText: `Deze package bevat geen inhoud om te verwijderen.<br/><br/>
      Je kunt deze package veilig verwijderen door op 'verwijder package' te klikken.
    `,
    packageOptions: "Package opties",
    packageReadme: "Package lees mij",
    packageRepository: "Package repository",
    packageUninstallConfirm: "Bevestig verwijderen",
    packageUninstalledHeader: "Package is verwijderd",
    packageUninstalledText: "De package is succesvol verwijderd",
    packageUninstallHeader: "Verwijder package",
    packageUninstallText: `Je kunt de items die je niet wilt verwijderen deselecteren. Als je 'Bevestig verwijderen' klikt worden alle geselecteerde items verwijderd.<br />
      <span style="color: Red; font-weight: bold;">Waarschuwing:</span> alle documenten, media etc, die afhankelijk zijn van de items die je verwijderd, zullen niet meer werken en kan leiden tot een instabiele installatie,
      wees dus voorzichtig met verwijderen. Als je het niet zeker weet, neem dan contact op met de auteur van de package.
    `,
    packageVersion: "Package versie"
  },
  paste: {
    doNothing: "Plakken met alle opmaak (Niet aanbevolen)",
    errorMessage: `De tekst die je probeert te plakken bevat speciale tekens en/of opmaak. Dit kan
      veroorzaakt worden doordat de tekst vanuit Microsoft Word is gekopieerd. Umbraco kan deze speciale tekens en
      formattering automatisch verwijderen zodat de geplakte tekst geschikt is voor het web.
    `,
    removeAll: "Plakken als ruwe tekst en alle opmaak verwijderen",
    removeSpecialFormattering: "Plakken, en verwijder de opmaak (aanbevolen)"
  },
  publicAccess: {
    paGroups: "Groepsgebaseerde beveiliging",
    paGroupsHelp: "Als je toegang wilt verlenen aan alle leden van specifieke ledengroepen",
    paGroupsNoGroups: `Je moet een ledengroep maken voordat je op groep gebaseerde authenticatie kunt
      gebruiken
    `,
    paErrorPage: "Foutpagina",
    paErrorPageHelp: `Gebruikt om te tonen als een gebruiker is ingelogd, maar geen rechten heeft om de
      pagina te bekijken
    `,
    paHowWould: "Hoe wil je de pagina <strong>%0%</strong> beveiligen?",
    paIsProtected: "<strong>%0%</strong> is nu beveiligd",
    paIsRemoved: "Beveiliging verwijderd van <strong>%0%</strong>",
    paLoginPage: "Login Pagina",
    paLoginPageHelp: "Kies de pagina met het login-formulier",
    paRemoveProtection: "Beveiliging verwijderen",
    paRemoveProtectionConfirm: "Weet je zeker dat je de bescherming van de pagina <strong>%0%</strong> wilt verwijderen?",
    paSelectPages: "Kies de pagina's die het login-formulier en de error-berichten bevatten",
    paSelectGroups: "Selecteer de groepen die toegang hebben tot de pagina <strong>%0%</strong>",
    paSelectMembers: "Selecteer de leden die toegang hebben tot de pagina <strong>%0%</strong>",
    paMembers: "Specifieke bescherming voor leden",
    paMembersHelp: "Als je toegang wilt verlenen aan bepaalde leden"
  },
  publish: {
    invalidPublishBranchPermissions: `Onvoldoende gebruikersmachtigingen om alle onderliggende documenten te
      publiceren
    `,
    contentPublishedFailedIsTrashed: `
      %0% kon niet gepubliceerd worden omdat het item zich in de prullenbak bevindt.
    `,
    contentPublishedFailedAwaitingRelease: `
      %0% kan niet worden gepubliceerd omdat het item is gepland voor release.
    `,
    contentPublishedFailedExpired: `
      %0% kon niet gepubliceerd worden omdat het item niet meer geldig is.
    `,
    contentPublishedFailedInvalid: `
      %0% kan niet worden gepubliceerd omdat de eigenschappen: %1% de validatieregels niet hebben doorstaan.
    `,
    contentPublishedFailedByEvent: `
      %0% kon niet worden gepubliceerd omdat een invoegtoepassing van een derde partij de actie heeft geannuleerd.
    `,
    contentPublishedFailedByParent: `
      %0% kon niet gepubliceerd worden omdat de bovenliggende pagina niet gepubliceerd is.
    `,
    contentPublishedFailedByMissingName: "%0% kan niet worden gepubliceerd omdat de naam ontbreekt.",
    contentPublishedFailedReqCultureValidationError: `Validatie mislukt voor de vereiste taal '%0%'. Deze
      taal werd opgeslagen maar is niet gepubliceerd.
    `,
    inProgress: "Publicatie in uitvoering - even geduld...",
    inProgressCounter: "%0% van %1% pagina’s zijn gepubliceerd...",
    nodePublish: "%0% is gepubliceerd",
    nodePublishAll: "%0% en onderliggende pagina’s zijn gepubliceerd",
    publishAll: "Publiceer %0% en alle subitems",
    publishHelp: `Klik <em>ok</em> om <strong>%0%</strong> te publiceren en de wijzigingen zichtbaar te maken voor bezoekers.<br/><br />
      Je kunt deze pagina publiceren en alle onderliggende sub-pagina's door <em>publiceer alle subitems</em> aan te vinken hieronder.
    `
  },
  colorpicker: {
    noColors: "Je hebt geen goedgekeurde kleuren geconfigureerd"
  },
  contentPicker: {
    allowedItemTypes: "Je kan alleen items van de volgende type(s) selecteren: %0%",
    pickedTrashedItem: `Je hebt een content-item geselecteerd dat op dit ogenblik verwijderd of in the
      prullenbak is
    `,
    pickedTrashedItems: `Je hebt content-items geselecteerd die op dit ogenblik verwijderd of in the
      prullenbak zijn
    `
  },
  dynamicRoot: {
    noValidStartNodeTitle: "Geen overeenkomende inhoud",
    noValidStartNodeDesc: "De configuratie van deze eigenschap komt met geen enkele inhoud overeen. Maak de ontbrekende inhoud aan of neem contact op met uw beheerder om de dynamische root-instellingen voor deze eigenschap aan te passen."
  },
  mediaPicker: {
    deletedItem: "Verwijderd item",
    pickedTrashedItem: `Je hebt een media-item geselecteerd dat op dit ogenblik verwijderd of in the
      prullenbak is
    `,
    pickedTrashedItems: `Je hebt media-items geselecteerd die op dit ogenblik verwijderd of in the prullenbak
      zijn
    `,
    trashed: "Weggegooid"
  },
  relatedlinks: {
    enterExternal: "Externe link toevoegen",
    chooseInternal: "Interne link toevoegen",
    caption: "Bijschrift",
    link: "Link",
    newWindow: "In een nieuw venster openen",
    captionPlaceholder: "Voer het bijschrift in",
    externalLinkPlaceholder: "Voer de link in"
  },
  imagecropper: {
    reset: "Uitsnede resetten",
    updateEditCrop: "Klaar",
    undoEditCrop: "Aanpassingen ongedaan maken",
    customCrop: "Gebruiker gedefinieerd"
  },
  rollback: {
    changes: "Wijzigingen",
    created: "Aangemaakt",
    headline: "Selecteer een versie om te vergelijken met de huidige versie",
    currentVersion: "Huidige versie",
    diffHelp: "Hier worden de verschillen getoond tussen de huidige en de geselecteerde versie<br /><del>Rode</del> tekst wordt niet getoond in de geselecteerde versie, <ins>groen betekent toegevoegd</ins>",
    documentRolledBack: "Document is teruggezet",
    htmlHelp: `Hiermee wordt de geselecteerde versie als html getoond, als u de verschillen tussen de twee
      versies tegelijk wilt zien, gebruik dan de diff view
    `,
    rollbackTo: "Terugzetten naar",
    selectVersion: "Selecteer versie",
    view: "Bekijk",
    pagination: "Toont versie %0% tot %1% van %2% versies",
    versions: "Versies",
    currentDraftVersion: "Conceptversie",
    currentPublishedVersion: "Gepubliceerde versie"
  },
  scripts: {
    editscript: "Bewerk script-bestand"
  },
  sections: {
    content: "Inhoud",
    forms: "Formulieren",
    media: "Media",
    member: "Leden",
    packages: "Packages",
    settings: "Instellingen",
    translation: "Vertaling",
    users: "Gebruikers"
  },
  help: {
    tours: "Rondleidingen",
    theBestUmbracoVideoTutorials: "De beste Umbraco video tutorials",
    umbracoForum: "Bezoek our.umbraco.com",
    umbracoTv: "Bezoek umbraco.tv"
  },
  settings: {
    defaulttemplate: "Standaard template",
    importDocumentTypeHelp: `Om een bestaand documenttype te importeren, zoek het betreffende “.udt” bestand
      door op browse en import te klikken. (Je ziet een bevestigingspagina voordat de import start. Als het documenttype
      al bestaat dan wordt het bijgewerkt.)
    `,
    newtabname: "Nieuwe tabtitel",
    nodetype: "Node type",
    objecttype: "Type",
    stylesheet: "Stylesheet",
    script: "Script",
    tab: "Tab",
    tabname: "Tab titel",
    tabs: "Tabs",
    contentTypeEnabled: "Basis inhoudstype ingeschakeld",
    contentTypeUses: "Dit inhoudstype gebruikt",
    noPropertiesDefinedOnTab: `Geen eigenschappen gedefinieerd op dit tabblad. Klik op de link "voeg een
      nieuwe eigenschap" aan de bovenkant om een ​​nieuwe eigenschap te creëren.
    `,
    createMatchingTemplate: "Maak een bijpassende sjabloon",
    addIcon: "Icoon toevoegen"
  },
  sort: {
    sortOrder: "Sorteer volgorde",
    sortCreationDate: "Aanmaakdatum",
    sortDone: "Sorteren gereed.",
    sortHelp: `Sleep de pagina's omhoog of omlaag om de volgorde te veranderen. Of klik op de kolomkop om
      alle pagina's daarop te sorteren.
    `,
    sortPleaseWait: "Een ogenblik geduld. Paginas worden gesorteerd, dit kan even duren.",
    sortEmptyState: "Dit item heeft geen subitems om te sorteren"
  },
  speechBubbles: {
    validationFailedHeader: "Validatie",
    validationFailedMessage: `Validatiefouten moeten worden opgelost voor dit item kan worden opgeslagen
    `,
    operationFailedHeader: "Mislukt",
    operationSavedHeader: "Opgeslagen",
    operationSavedHeaderReloadUser: `Opgeslagen. Gelieve uw browser te herladen om de aanpassingen te zien
    `,
    invalidUserPermissionsText: `Wegens onvoldoende rechten kon deze handeling kon niet worden uitgevoerd
    `,
    operationCancelledHeader: "Geannuleerd",
    operationCancelledText: "Uitvoering is geannuleerd door de plugin van een 3e partij",
    contentTypeDublicatePropertyType: "Eigenschappentype bestaat al",
    contentTypePropertyTypeCreated: "Eigenschappentype aangemaakt",
    contentTypePropertyTypeCreatedText: "Naam: %0% <br /> Datatype: %1%",
    contentTypePropertyTypeDeleted: "Eigenschappentype verwijderd",
    contentTypeSavedHeader: "Inhoudstype opgeslagen",
    contentTypeTabCreated: "Tab aangemaakt",
    contentTypeTabDeleted: "Tab verwijderd",
    contentTypeTabDeletedText: "Tab met id: %0% verwijderd",
    cssErrorHeader: "Stylesheet niet opgeslagen",
    cssSavedHeader: "Stylesheet opgeslagen",
    cssSavedText: "Stylesheet opgeslagen zonder fouten",
    dataTypeSaved: "Datatype opgeslagen",
    dictionaryItemSaved: "Woordenboek item opgeslagen",
    editContentPublishedHeader: "Inhoud gepubliceerd",
    editContentPublishedText: "en zichtbaar op de website",
    editMultiContentPublishedText: "%0% documenten gepubliceerd en zichtbaar op de website",
    editVariantPublishedText: "%0% gepubliceerd en zichtbaar op de website",
    editMultiVariantPublishedText: `%0% documenten gepubliceerd voor de talen languages %1% en zichtbaar op
      de website
    `,
    editContentSavedHeader: "Inhoud opgeslagen",
    editContentSavedText: "Vergeet niet te publiceren om de wijzigingen zichtbaar te maken",
    editContentScheduledSavedText: "Een planning voor publicatie is bijgewerkt",
    editVariantSavedText: "%0% bewaard",
    editContentSendToPublish: "Verzend voor goedkeuring",
    editContentSendToPublishText: "Aanpassingen zijn verstuurd voor goedkeuring",
    editVariantSendToPublishText: "%0% aanpassingen zijn verstuurd voor goedkeuring",
    editMediaSaved: "Media opgeslagen",
    editMediaSavedText: "Media opgeslagen zonder fouten",
    editMemberSaved: "Lid opgeslagen",
    editStylesheetPropertySaved: "Stijlsheet eigenschap opgeslagen",
    editStylesheetSaved: "Stijlsheet opgeslagen",
    editTemplateSaved: "Template opgeslagen",
    editUserError: "Fout bij opslaan gebruiker (zie logboek)",
    editUserSaved: "Gebruiker opgeslagen",
    editUserTypeSaved: "Gebruikerstype opgeslagen",
    editUserGroupSaved: "Gebruikersgroep opgeslagen",
    editCulturesAndHostnamesSaved: "Cultuur en hostnaam opgeslagen",
    editCulturesAndHostnamesError: "Fout bij opslaan culturen en hostnamen",
    fileErrorHeader: "Bestand niet opgeslagen",
    fileErrorText: "bestand kon niet worden opgeslagen. Controleer de bestandsbeveiliging",
    fileSavedHeader: "Bestand opgeslagen",
    fileSavedText: "Bestand opgeslagen zonder fouten",
    languageSaved: "Taal opgeslagen",
    mediaTypeSavedHeader: "Mediatype opgeslagen",
    memberTypeSavedHeader: "Ledentype opgeslagen",
    memberGroupSavedHeader: "Ledengroep opgeslagen",
    memberGroupNameDuplicate: "Er bestaat al een andere ledengroep met dezelfde naam",
    templateErrorHeader: "Sjabloon niet opgeslagen",
    templateErrorText: "Controleer dat je geen 2 sjablonen met dezelfde naam hebt",
    templateSavedHeader: "Sjabloon opgeslagen",
    templateSavedText: "Sjabloon opgeslagen zonder fouten!",
    contentUnpublished: "Inhoud gedepubliceerd",
    contentCultureUnpublished: "Inhoud variatie %0% gedepubliceerd",
    contentMandatoryCultureUnpublished: `De verplichte taal '%0%' is gedepubliceerd. Alle talen voor deze
      inhoud zijn nu gedepubliceerd.
    `,
    partialViewSavedHeader: "Partial view opgeslagen",
    partialViewSavedText: "Partial view opgeslagen zonder fouten!",
    partialViewErrorHeader: "Partial view niet opgeslagen",
    partialViewErrorText: "Er is een fout opgetreden bij het opslaan van het bestand.",
    permissionsSavedFor: "Rechten opgeslagen voor",
    deleteUserGroupsSuccess: "%0% gebruikersgroepen verwijderd",
    deleteUserGroupSuccess: "%0% is verwijderd",
    enableUsersSuccess: "%0% gebruikers geactiveerd",
    disableUsersSuccess: "%0% gebruikers gedeactiveerd",
    enableUserSuccess: "%0% is nu geactiveerd",
    disableUserSuccess: "%0% is nu gedeactiveerd",
    setUserGroupOnUsersSuccess: "Gebruikersgroepen zijn ingesteld",
    unlockUsersSuccess: "%0% gebruikers gedeblokkeerd",
    unlockUserSuccess: "%0% is nu gedeblokkeerd",
    memberExportedSuccess: "Lid is geexporteerd naar een bestand",
    memberExportedError: "Er heeft zich een fout voorgedaan tijdens het exporteren van het lid",
    deleteUserSuccess: "Gebruiker %0% is verwijderd",
    resendInviteHeader: "Gebruiker uitnodigen",
    resendInviteSuccess: "Uitnodiging is opnieuw gestuurd naar gebruiker %0%",
    contentReqCulturePublishError: `Kan het document niet publiceren omdat de vereiste '%0%' niet is
      gepubliceerd
    `,
    contentCultureValidationError: "Validatie is mislukt voor de taal '%0%'",
    documentTypeExportedSuccess: "Documenttype is geëxporteerd naar een bestand",
    documentTypeExportedError: "Er is een fout gebeurd tijdens het exporteren van het documenttype",
    scheduleErrReleaseDate1: "De publicatiedatum kan niet in het verleden liggen",
    scheduleErrReleaseDate2: `Kan het document niet plannen voor publicatie omdat de vereiste '%0%' niet is
      gepubliceerd
    `,
    scheduleErrReleaseDate3: `Kan het document niet plannen voor publicatie omdat de vereiste '%0%' een
      publicatiedatum heeft die later is dan een niet-verplichte taal
    `,
    scheduleErrExpireDate1: "De vervaldatum kan niet in het verleden liggen",
    scheduleErrExpireDate2: "De vervaldatum kan niet voor de publicatiedatum liggen"
  },
  stylesheet: {
    addRule: "Stijl toevoegen",
    editRule: "Stijl bewerken",
    editorRules: "Rich text editor stijlen",
    editorRulesHelp: `Definieer de stijlen die beschikbaar moeten zijn in de rich text editor voor deze
      stylesheet
    `,
    editstylesheet: "Stylesheet bewerken",
    editstylesheetproperty: "Stylesheet eigenschap bewerken",
    nameHelp: "Naam waarmee de stijl in de editor te kiezen is",
    preview: "Voorbeeld",
    previewHelp: "Hoe de tekst er zal uitzien in de rich text editor.",
    selector: "Selector",
    selectorHelp: 'Gebruik CSS syntax, bv. "h1" or ".redHeader"',
    styles: "Stijlen",
    stylesHelp: 'De CSS die moet toegepast worden in de rich text editor, bv. "color:red;"',
    tabCode: "Code",
    tabRules: "Rich Text Editor"
  },
  template: {
    runtimeModeProduction: "Inhoud kan niet worden bewerkt in de runtime-modus <code>Production</code>.",
    deleteByIdFailed: "Kan sjabloon met ID %0% niet verwijderen",
    edittemplate: "Sjabloon aanpassen",
    insertSections: "Secties",
    insertContentArea: "Inhoudsgebied invoegen",
    insertContentAreaPlaceHolder: "Een tijdelijke aanduiding voor het inhoudsgebied invoegen",
    insert: "Invoegen",
    insertDesc: "Kies wat je wil invoegen in het sjabloon",
    insertDictionaryItem: "Woordenboek item invoegen",
    insertDictionaryItemDesc: `Een woordenboekitem is een tijdelijke aanduiding voor een vertaalbaar stuk
      tekst, waardoor het gemakkelijk is om ontwerpen voor meertalige websites te maken.
    `,
    insertMacro: "Macro invoegen",
    insertMacroDesc: `
      Een Macro is een configureerbaar component die gebruikt kan worden voor
      herbruikbare delen van je ontwerp, waar je de optie nodig hebt om parameters op te geven,
      zoals bij gallerijen, formulieren en lijsten.
    `,
    insertPageField: "Umbraco pagina veld invoegen",
    insertPageFieldDesc: `Toont de waarde van een benoemd veld van de huidige pagina, met opties om de waarde
      te wijzigen of terug te vallen op alternatieve waarden.
    `,
    insertPartialView: "Partial view",
    insertPartialViewDesc: `
      Een partial view is een apart sjabloon dat kan gerendered worden in een ander sjabloon,
      het is geschikt voor het hergebruiken van HTML of voor het scheiden van complexe sjablonen in afzonderlijke
      bestanden.
    `,
    mastertemplate: "Hoofdsjabloon",
    noMaster: "Geen hoofdsjabloon",
    renderBody: "Render onderliggend sjabloon",
    renderBodyDesc: `
        Rendert de inhoud van een onderliggend sjabloon, door
        <code>@RenderBody()</code> in te voegen.
    `,
    defineSection: "Definieer een benoemde sectie",
    defineSectionDesc: `
        Definieert een deel van uw sjabloon als een benoemde sectie door deze in
        <code>@section { ... }</code> te omwikkelen. Dit kan worden weergegeven
        in een specifiek gebied van de bovenliggende sjabloon door <code>@RenderSection</code> te gebruiken.
    `,
    renderSection: "Render een benoemde sectie",
    renderSectionDesc: `
      Rendert een benoemd gebied van een onderliggend sjabloon, door een tijdelijke aanduiding <code>@RenderSection(name)</code> in te voegen.
      This renders an area of a child template which is wrapped in a corresponding <code>@section [name]{ ... }</code> definition.
      `,
    sectionName: "Sectienaam",
    sectionMandatory: "Sectie is verplicht",
    sectionMandatoryDesc: `
        Indien verplicht, moet het onderliggend sjabloon <code>@section</code> definiëren, anders wordt een fout getoond.
    `,
    queryBuilder: "Querybouwer",
    itemsReturned: "items gevonden, in",
    iWant: "Ik wil",
    allContent: "alle inhoud",
    contentOfType: 'inhoud van het type "%0%"',
    from: "van",
    websiteRoot: "mijn website",
    where: "waar",
    and: "en",
    is: "is",
    isNot: "is niet",
    before: "voor",
    beforeIncDate: "voor (inclusief geselecteerde datum)",
    after: "na",
    afterIncDate: "na (inclusief geselecteerde datum)",
    equals: "is gelijk aan",
    doesNotEqual: "is niet gelijk aan",
    contains: "bevat",
    doesNotContain: "bevat niet",
    greaterThan: "groter dan",
    greaterThanEqual: "groter dan of gelijk aan",
    lessThan: "kleiner dan",
    lessThanEqual: "kleiner of gelijk aan",
    id: "Id",
    name: "Naam",
    createdDate: "Datum aangemaakt",
    lastUpdatedDate: "Datum gewijzigd",
    orderBy: "sorteren op",
    ascending: "oplopend",
    descending: "aflopend",
    template: "Sjabloon"
  },
  grid: {
    media: "Afbeelding",
    macro: "Macro",
    insertControl: "Item toevoegen",
    chooseLayout: "Kies de indeling",
    addRows: "Kies een indeling voor deze pagina om content toe te kunnen voegen",
    addElement: "Plaats een (extra) content blok",
    dropElement: "Drop content",
    settingsApplied: "Instellingen toegepast",
    contentNotAllowed: "Deze content is hier niet toegestaan",
    contentAllowed: "Deze content is hier toegestaan",
    clickToEmbed: "Klik om een item te embedden",
    clickToInsertImage: "Klik om een afbeelding in te voegen",
    placeholderWriteHere: "Typ hier...",
    gridLayouts: "Grid lay-outs",
    gridLayoutsDetail: `Lay-outs zijn het globale werkgebied voor de grid editor. Je hebt meestal maar één of
      twee verschillende lay-outs nodig
    `,
    addGridLayout: "Een grid lay-out toevoegen",
    editGridLayout: "Grid lay-out aanpassen",
    addGridLayoutDetail: `De lay-out aanpassen door de kolombreedte aan te passen en extra kolommen toe te
      voegen
    `,
    rowConfigurations: "Rijconfiguratie",
    rowConfigurationsDetail: "Rijen zijn voorgedefinieerde cellen die horizontaal zijn gerangschikt",
    addRowConfiguration: "Een rijconfiguratie toevoegen",
    editRowConfiguration: "Rijconfiguratie aanpassen",
    addRowConfigurationDetail: `De rijconfiguratie aanpassen door de breedte van de cel in te stellen en
      extra cellen toe te voegen
    `,
    noConfiguration: "Geen verdere instellingen beschikbaar",
    columns: "Kolommen",
    columnsDetails: "Het totaal aantal gecombineerde kolommen in de grid layout",
    settings: "Instellingen",
    settingsDetails: "Configureren welke instellingen de editors kunnen aanpassen",
    styles: "Styles",
    stylesDetails: "Configureren welke stijlen de editors kunnen aanpassen",
    allowAllEditors: "Alle editors toelaten",
    allowAllRowConfigurations: "Alle rijconfiguraties toelaten",
    maxItems: "Maximale artikelen",
    maxItemsDescription: "Laat dit leeg of is ingesteld op -1 voor onbeperkt",
    setAsDefault: "Instellen als standaard",
    chooseExtra: "Kies extra",
    chooseDefault: "Kies standaard",
    areAdded: "zijn toegevoegd",
    youAreDeleting: "Je gaat de rijconfiguratie verwijderen",
    deletingARow: `
      Een rijconfiguratienaam verwijderen zal er voor zorgen dat bestaande inhoud verloren gaat die gebaseerd is op deze
      configuratie.
    `
  },
  contentTypeEditor: {
    compositions: "Composities",
    group: "Groep",
    noGroups: "Er zijn nog geen groepen toegevoegd",
    addGroup: "Groep toevoegen",
    inheritedFrom: "Inherited van",
    addProperty: "Eigenschap toevoegen",
    requiredLabel: "Verplicht label",
    enableListViewHeading: "Lijstweergave inschakelen",
    enableListViewDescription: `Laat de onderliggende nodes van het content item zien als een sorteer- en
      doorzoekbare lijstweergave. Deze onderliggende nodes worden dan niet in de boomstructuur getoond.
    `,
    allowedTemplatesHeading: "Toegestane Sjablonen",
    allowedTemplatesDescription: `Kies welke sjablonen toegestaan zijn om door de editors op dit contenttype
      gebruikt te worden
    `,
    allowAsRootHeading: "Sta toe op hoofdniveau",
    allowAsRootDescription: "Sta editors toe om inhoud van dit type aan te maken op hoofdniveau",
    childNodesHeading: "Toegestane onderliggende node types",
    childNodesDescription: `Sta inhoud van een bepaald type toe om onder dit type aangemaakt te kunnen
      worden
    `,
    chooseChildNode: "Kies onderliggende node",
    compositionsDescription: `Overgeërfde tabs en properties van een bestaand documenttype. Nieuwe tabs
      worden toegevoegd aan het huidige documenttype of samengevoegd als een tab met dezelfde naam al bestaat.
    `,
    compositionInUse: `Dit contenttype wordt gebruikt in een compositie en kan daarom niet zelf een
      compositie worden.
    `,
    noAvailableCompositions: "Er zijn geen contenttypen beschikbaar om als compositie te gebruiken.",
    compositionRemoveWarning: `Een compositie verwijderen zal alle bijbehorende eigenschapsdata ook
      verwijderen. Zodra je het documenttype hebt opgeslagen is er geen weg meer terug.
    `,
    availableEditors: "Beschikbare editors",
    reuse: "Herbruik",
    editorSettings: "Editor instellingen",
    searchResultSettings: "Beschikbare configuraties",
    searchResultEditors: "Nieuwe configuration aanmaken",
    configuration: "Configuratie",
    yesDelete: "Ja, verwijder",
    movedUnderneath: "is naar onder geplaatst",
    copiedUnderneath: "is naar onder gecopierd",
    folderToMove: "Selecteer de map om te verplaatsen",
    folderToCopy: "Selecteer de map om te kopieren",
    structureBelow: "naar de boomstructuur onder",
    allDocumentTypes: "Alle Documenttypes",
    allDocuments: "Alle documenten",
    allMediaItems: "Alle media items",
    usingThisDocument: `die gebruik maken van dit documenttype zullen permanent verwijderd worden. Bevestig
      aub dat je deze ook wilt verwijderen.
    `,
    usingThisMedia: `die gebruik maken van dit mediatype zullen permanent verwijderd worden. Bevestig aub dat
      je deze ook wilt verwijderen.
    `,
    usingThisMember: `die gebruik maken van dit lidtype zullen permanent verwijderd worden. Bevestig aub dat
      je deze ook wilt verwijderen.
    `,
    andAllDocuments: "en alle documenten van dit type",
    andAllMediaItems: "en alle media items van dit type",
    andAllMembers: "en alle leden van dit type",
    memberCanEdit: "Lid kan bewerken",
    memberCanEditDescription: "Toestaan dat deze eigenschap kan worden gewijzigd door het lid op zijn profiel pagina.",
    isSensitiveData: "Omvat gevoelige gegevens",
    isSensitiveDataDescription: "Verberg deze eigenschap voor de content editor die geen toegang heeft tot het bekijken van gevoelige informatie.",
    showOnMemberProfile: "Toon in het profiel van leden",
    showOnMemberProfileDescription: "Toelaten dat deze eigenschap wordt getoond op de profiel pagina van het lid.",
    tabHasNoSortOrder: "tab heeft geen sorteervolgorde",
    compositionUsageHeading: "Waar wordt deze compositie gebruikt?",
    compositionUsageSpecification: `Deze samenstelling wordt momenteel gebruikt bij de samenstelling van de
      volgende inhoudstypen:
    `,
    variantsHeading: "Variaties toestaan",
    cultureVariantHeading: "Variëren per cultuur toestaan",
    segmentVariantHeading: "Segmentatie toestaan",
    cultureVariantLabel: "Varieer per cultuur",
    segmentVariantLabel: "Varieer per segment",
    variantsDescription: `Editors toestaan om nieuwe inhoud aan te maken van dit type in verschillende
      talen.
    `,
    cultureVariantDescription: "Editors toestaan om nieuwe inhoud in verschillende talen te creëren",
    segmentVariantDescription: "Editors toestaan om nieuwe segmenten van deze inhoud te creëren.",
    allowVaryByCulture: "Variaties per cultuur toestaan",
    allowVaryBySegment: "Segmentatie toestaan",
    elementType: "Elementtype",
    elementHeading: "Is een elementtype",
    elementDescription: `Een elementtype is bedoeld om bijvoorbeeld in geneste inhoud gebruikt te worden en
      niet in de boomstructuur.
    `,
    elementCannotToggle: `Een documenttype kan niet worden gewijzigd in een elementtype nadat het is gebruikt
      om een of meer contentitems te maken.
    `,
    elementDoesNotSupport: "Dit is niet van toepassing op een elementtype",
    propertyHasChanges: `Je hebt wijzigingen aangebracht aan deze eigenschap. Ben je zeker dat je ze wil
      weggooien?
    `,
    addTab: "Tabblad toevoegen",
    historyCleanupHeading: "Geschiedenis opschonen",
    historyCleanupDescription: "Overschrijf de standaard geschiedenis opschonen instellingen.",
    historyCleanupKeepAllVersionsNewerThanDays: "Bewaar alle versies nieuwer dan dagen",
    historyCleanupKeepLatestVersionPerDayForDays: "Bewaar de laatste versie per dag voor dagen",
    historyCleanupPreventCleanup: "Voorkom opschonen",
    historyCleanupEnableCleanup: "Opschonen aanzetten",
    historyCleanupGloballyDisabled: "Geschiedenis opschonen is globaal uitgeschakeld. Deze instellingen worden pas van kracht nadat ze zijn ingeschakeld."
  },
  webhooks: {
    addWebhook: "Webhook aanmaken",
    addWebhookHeader: "Webhook header toevoegen",
    logs: "Logboek",
    addDocumentType: "Documenttype toevoegen",
    addMediaType: "Mediatype toevoegen"
  },
  languages: {
    addLanguage: "Taal toevoegen",
    mandatoryLanguage: "Verplichte taal",
    mandatoryLanguageHelp: `Eigenschappen van deze taal moeten worden ingevuld voordat de node kan worden
      gepubliceerd.
    `,
    defaultLanguage: "Standaard taal",
    defaultLanguageHelp: "Een Umbraco site kan maar één standaardtaal hebben.",
    changingDefaultLanguageWarning: "Als u de standaardtaal wijzigt, kan er standaardinhoud ontbreken.",
    fallsbackToLabel: "Valt terug naar",
    noFallbackLanguageOption: "Geen terugvaltaal",
    fallbackLanguageDescription: `Om meertalige inhoud terug te laten vallen naar een andere taal als deze
      niet aanwezig is in de gevraagde taal, selecteert u deze hier.
    `,
    fallbackLanguage: "Terugvaltaal",
    none: "Geen"
  },
  macro: {
    addParameter: "Parameter toevoegen",
    editParameter: "Parameter bewerken",
    enterMacroName: "Macro naam invoeren",
    parameters: "Parameters",
    parametersDescription: `Definieer de parameters die beschikbaar moeten zijn bij het gebruik van deze
      macro.
    `,
    selectViewFile: "Selecteer een partial view macro bestand"
  },
  modelsBuilder: {
    buildingModels: "Models aan het gereneren",
    waitingMessage: "dit kan enige tijd duren, geduld aub",
    modelsGenerated: "Models gegenereerd",
    modelsGeneratedError: "Models konden niet gegenereerd worden",
    modelsExceptionInUlog: "Models generatie is mislukt, kijk in de Umbraco log voor details"
  },
  templateEditor: {
    addDefaultValue: "Standaardwaarde toevoegen",
    defaultValue: "Standaardwaarde",
    alternativeField: "Alternatief veld",
    alternativeText: "Alternatieve tekst",
    casing: "Kapitalisatie",
    encoding: "Codering",
    chooseField: "Selecteer veld",
    convertLineBreaks: "Converteer regelafbreking",
    convertLineBreaksHelp: "Vervang regelafbrekingen met HTML-tag<br>",
    customFields: "Aangepaste velden",
    dateOnly: "Ja, alleen datum",
    formatAsDate: "Opmaken als datum",
    htmlEncode: "HTML-encoderen",
    htmlEncodeHelp: "Speciale karakters worden geëncodeerd naar HTML.",
    insertedAfter: "Zal worden ingevoegd na de veld waarde",
    insertedBefore: "Zal worden ingevoegd voor de veld waarde",
    lowercase: "Kleine letters",
    none: "Geen",
    outputSample: "Uitvoervoorbeeld",
    postContent: "Invoegen na veld",
    preContent: "Invoegen voor veld",
    recursive: "Recursief",
    recursiveDescr: "Ja, recursief maken",
    standardFields: "Standaard velden",
    uppercase: "Hoofdletters",
    urlEncode: "URL-encoderen",
    urlEncodeHelp: "Speciale karakters in URL's worden geëncodeerd",
    usedIfAllEmpty: "Zal alleen worden gebruikt waneer de bovenstaande veldwaardes leeg zijn",
    usedIfEmpty: "Dit veld zal alleen worden gebruikt als het primaire veld leeg is",
    withTime: "Ja, met tijd. Scheidingsteken:"
  },
  translation: {
    details: "Details van vertaling",
    DownloadXmlDTD: "Download xml DTD",
    fields: "Velden",
    includeSubpages: "Inclusief onderliggende pagina's",
    mailBody: `
      Hallo %0%

      Dit is een geautomatiseerde mail om u op de hoogte te brengen dat document '%1%'
      is aangevraagd voor vertaling naar '%5%' door %2%.

      Ga naar http://%3%/translation/details.aspx?id=%4% om te bewerken.
	  Of log in bij Umbraco om een overzicht te krijgen van al jouw vertalingen.


      Met vriendelijke groet!


      De Umbraco Robot
        `,
    noTranslators: `Geen vertaal-gebruikers gevonden. Maak eerst een vertaal-gebruiker aan voordat je
      pagina's voor vertaling verstuurt
    `,
    pageHasBeenSendToTranslation: "De pagina '%0%' is verstuurd voor vertaling",
    sendToTranslate: "Stuur voor vertaling",
    totalWords: "Totaal aantal woorden",
    translateTo: "Vertaal naar",
    translationDone: "Vertaling voltooid.",
    translationDoneHelp: `Je kan een voorbeeld van vertaalde pagina's bekijken door hieronder te klikken. Als
      de originele pagina gevonden werd, wordt een vergelijking van beide pagina's getoond.
    `,
    translationFailed: "Vertalen niet gelukt, het XML-bestand is mogelijk beschadigd.",
    translationOptions: "Vertalingsopties",
    translator: "Vertaler",
    uploadTranslationXml: "Vertaald XML-document uploaden"
  },
  treeHeaders: {
    content: "Inhoud",
    contentBlueprints: "Inhoudssjablonen",
    media: "Media",
    cacheBrowser: "Cachebrowser",
    contentRecycleBin: "Prullenbak",
    createdPackages: "Gemaakte packages",
    dataTypes: "Datatypes",
    dictionary: "Woordenboek",
    installedPackages: "Geïnstalleerde packages",
    installSkin: "Installeer skin",
    installStarterKit: "Installeer starter kit",
    languages: "Talen",
    localPackage: "Installeer een lokale package",
    macros: "Macro's",
    mediaTypes: "Mediatypes",
    member: "Leden",
    memberGroups: "Ledengroepen",
    memberRoles: "Rollen",
    memberTypes: "Ledentypes",
    documentTypes: "Documenttypes",
    relationTypes: "Relatietypes",
    packager: "Packages",
    packages: "Packages",
    partialViews: "Partial Views",
    partialViewMacros: "Partial View Macro Bestanden",
    repositories: "Installeer vanuit repository",
    runway: "Installeer Runway",
    runwayModules: "Runway modules",
    scripting: "Script bestanden",
    scripts: "Scripts",
    stylesheets: "Stylesheets",
    templates: "Sjablonen",
    logViewer: "Logboeken",
    users: "Gebruikers",
    settingsGroup: "Instellingen",
    templatingGroup: "Sjabloon",
    thirdPartyGroup: "Derde partij",
    webhooks: "Webhooks"
  },
  update: {
    updateAvailable: "Nieuwe update beschikbaar",
    updateDownloadText: "%0% is gereed, klik hier om te downloaden",
    updateNoServer: "Er is geen verbinding met de server",
    updateNoServerError: `Er is een fout opgetreden bij het zoeken naar een update. Bekijk de trace-stack
      voor verdere informatie.
    `
  },
  user: {
    access: "Toegang",
    accessHelp: `Gebaseerd op de gebruikersgroepen en startpagina's heeft de gebruiker toegang tot de
      volgende pagina's
    `,
    assignAccess: "Toegang geven",
    administrators: "Beheerders",
    categoryField: "Categorieveld",
    createDate: "Gebruiker aangemaakt",
    changePassword: "Verander je wachtwoord",
    changePhoto: "Wijzig je foto",
    newPassword: "Wijzig je wachtwoord",
    newPasswordFormatLengthTip: "Nog minimaal %0% teken(s) te gaan!",
    noLockouts: "is niet gedeblokkeerd",
    noPasswordChange: "Het wachtwoord is niet gewijzigd",
    confirmNewPassword: "Bevestig nieuw wachtwoord",
    changePasswordDescription: `Je kunt je wachtwoord veranderen door onderstaand formulier in te vullen en
      op de knop 'Verander wachtwoord' te klikken
    `,
    contentChannel: "Inhoudskanaal",
    createAnotherUser: "Nog een gebruiker aanmaken",
    createUserHelp: `Maak nieuwe gebruikers aan om hun toegang te geven tot Umbraco. Wanneer een nieuwe
      gebruiker wordt aangemaakt wordt er een wachtwoord gegenereerd dat je met hun kan delen.
    `,
    descriptionField: "Omschrijving",
    disabled: "Geblokkeerde gebruiker",
    documentType: "Documenttype",
    editors: "Editor",
    excerptField: "Samenvattingsveld",
    failedPasswordAttempts: "Foute wachtwoord pogingen",
    goToProfile: "Ga naar gebruikersprofiel",
    groupsHelp: "Voeg gebruikersgroepen toe om rechten in te stellen",
    inviteAnotherUser: "Nog een gebruiker uitnodigen",
    inviteUserHelp: `Nodig gebruikers uit om hen toegang te geven to Umbraco. Een uitnodiging wordt via
      e-mail verstuurd met instructies hoe de gebruiker kan inloggen.
    `,
    language: "Taal",
    languageHelp: "Stel de taal in die gebruiker zal zien in menu's en dialoogvensters",
    lastLockoutDate: "Laatst geblokkeerd datum",
    lastLogin: "Laatste keer ingelogd",
    lastPasswordChangeDate: "Laatste keer wachtwoord gewijzigd",
    loginname: "Loginnaam",
    mediastartnode: "Startnode in Mediabibliotheek",
    mediastartnodehelp: "Beperk de mediabibliotheek tot een specifieke startnode",
    mediastartnodes: "Startnodes in Mediabibliotheek",
    mediastartnodeshelp: "Beperk de mediabibliotheek tot een specifieke startnode",
    modules: "Secties",
    noConsole: "Blokkeer Umbraco toegang",
    noLogin: "heeft nog niet ingelogd",
    oldPassword: "Oude wachtwoord",
    password: "Wachtwoord",
    resetPassword: "Reset wachtwoord",
    passwordChanged: "Je wachtwoord is veranderd!",
    passwordChangedGeneric: "Wachtwoord aangepast",
    passwordConfirm: "Herhaal nieuwe wachtwoord",
    passwordEnterNew: "Voer nieuwe wachtwoord in",
    passwordIsBlank: "Je nieuwe wachtwoord mag niet leeg zijn!",
    passwordCurrent: "Huidig wachtwoord",
    passwordInvalid: "Ongeldig huidig wachtwoord",
    passwordIsDifferent: "Beide wachtwoorden waren niet hetzelfde. Probeer opnieuw!",
    passwordMismatch: "Beide wachtwoorden zijn niet hetzelfde!",
    permissionReplaceChildren: "Vervang rechten op de subitems",
    permissionSelectedPages: "U bent momenteel rechten aan het aanpassen voor volgende pagina's:",
    permissionSelectPages: "Selecteer pagina's om hun rechten aan te passen",
    removePhoto: "Verwijder je foto",
    permissionsDefault: "Standaard rechten",
    permissionsGranular: "Specifieke rechten",
    permissionsGranularHelp: "Geef rechten op specifieke nodes",
    profile: "Profiel",
    searchAllChildren: "Doorzoek alle subitems",
    sectionsHelp: "Geef de gebruiker toegang tot secties",
    languagesHelp: "Beperk de talen die gebruikers mogen bewerken",
    allowAccessToAllLanguages: "Toegang tot alle talen toestaan",
    selectUserGroups: "Selecteer een gebruikersgroep",
    noStartNode: "Geen startnode geselecteerd",
    noStartNodes: "Geen startnodes geselecteerd",
    startnode: "Startnode in Inhoud",
    startnodehelp: "Beperk de content toegang tot een specifieke startnode",
    startnodes: "Startnodes in Inhoud",
    startnodeshelp: "Beperk de Inhoud tot specifieke startnodes",
    updateDate: "Laatste keer bijgewerkt",
    userCreated: "is aangemaakt",
    userCreatedSuccessHelp: `De gebruiker is aangemaakt. Om in te loggen in Umbraco gebruik je onderstaand
      wachtwoord.
    `,
    userManagement: "Gebruikers beheren",
    username: "Gebruikersnaam",
    userPermissions: "Gebruikersrechten",
    usergroup: "Gebruikersgroep",
    userInvited: "is uitgenodigd",
    userInvitedSuccessHelp: `Een uitnodiging is gestuurd naar de nieuwe gebruiker met informatie over hoe in
      te loggen in Umbraco
    `,
    userinviteWelcomeMessage: `Hallo en welkom in Umbraco! Binnen ongeveer één minuut kan je aan de slag. Je
      moet enkel je wachtwoord instellen.
    `,
    userinviteExpiredMessage: `Welkom bij Umbraco! Helaas is je uitnodiging vervallen. Vraag aan je
      administrator om de uitnodiging opnieuw te versturen.
    `,
    writer: "Auteur",
    configureTwoFactor: "Configureer tweestapsverificatie",
    change: "Wijzig",
    yourProfile: "Je profiel",
    yourHistory: "Je recente historie",
    sessionExpires: "Sessie verloopt over",
    inviteUser: "Gebruiker uitnodigen",
    createUser: "Gebruiker aanmaken",
    sendInvite: "Uitnodiging versturen",
    backToUsers: "Terug naar gebruikers",
    inviteEmailCopySubject: "Umbraco: Uitnodiging",
    inviteEmailCopyFormat: `
        <html>
			<head>
				<meta name='viewport' content='width=device-width'>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
			</head>
			<body class='' style='font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; color: #392F54; line-height: 22px; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background: #1d1333; margin: 0; padding: 0;' bgcolor='#1d1333'>
				<style type='text/css'> @media only screen and (max-width: 620px) {table[class=body] h1 {font-size: 28px !important; margin-bottom: 10px !important; } table[class=body] .wrapper {padding: 32px !important; } table[class=body] .article {padding: 32px !important; } table[class=body] .content {padding: 24px !important; } table[class=body] .container {padding: 0 !important; width: 100% !important; } table[class=body] .main {border-left-width: 0 !important; border-radius: 0 !important; border-right-width: 0 !important; } table[class=body] .btn table {width: 100% !important; } table[class=body] .btn a {width: 100% !important; } table[class=body] .img-responsive {height: auto !important; max-width: 100% !important; width: auto !important; } } .btn-primary table td:hover {background-color: #34495e !important; } .btn-primary a:hover {background-color: #34495e !important; border-color: #34495e !important; } .btn  a:visited {color:#FFFFFF;} </style>
				<table border="0" cellpadding="0" cellspacing="0" class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;" bgcolor="#1d1333">
					<tr>
						<td style="font-family: sans-serif; font-size: 14px; vertical-align: top; padding: 24px;" valign="top">
							<table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;">
								<tr>
									<td background="https://umbraco.com/umbraco/assets/img/application/logo.png" bgcolor="#1d1333" width="28" height="28" valign="top" style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
										<!--[if gte mso 9]> <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:30px;height:30px;"> <v:fill type="tile" src="https://umbraco.com/umbraco/assets/img/application/logo.png" color="#1d1333" /> <v:textbox inset="0,0,0,0"> <![endif]-->
										<div> </div>
										<!--[if gte mso 9]> </v:textbox> </v:rect> <![endif]-->
									</td>
									<td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top"></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;' bgcolor='#1d1333'>
					<tr>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
						<td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 560px; width: 560px; margin: 0 auto; padding: 10px;' valign='top'>
							<div class='content' style='box-sizing: border-box; display: block; max-width: 560px; margin: 0 auto; padding: 10px;'>
								<br>
								<table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; border-radius: 3px; background: #FFFFFF;' bgcolor='#FFFFFF'>
									<tr>
										<td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 50px;' valign='top'>
											<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
												<tr>
													<td style='line-height: 24px; font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'>
														<h1 style='color: #392F54; font-family: sans-serif; font-weight: bold; line-height: 1.4; font-size: 24px; text-align: left; text-transform: capitalize; margin: 0 0 30px;' align='left'>
															Hallo %0%,
														</h1>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															U bent uitgenodigd door <a href="mailto:%4%" style="text-decoration: underline; color: #392F54; -ms-word-break: break-all; word-break: break-all;">%1%</a> om in te loggen in de Umbraco Backoffice.
														</p>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Bericht van <a href="mailto:%1%" style="text-decoration: none; color: #392F54; -ms-word-break: break-all; word-break: break-all;">%1%</a>:
															<br/>
															<em>%2%</em>
														</p>
														<table border='0' cellpadding='0' cellspacing='0' class='btn btn-primary' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; box-sizing: border-box;'>
															<tbody>
																<tr>
																	<td align='left' style='font-family: sans-serif; font-size: 14px; vertical-align: top; padding-bottom: 15px;' valign='top'>
																		<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
																			<tbody>
																				<tr>
																					<td style='font-family: sans-serif; font-size: 14px; vertical-align: top; border-radius: 5px; text-align: center; background: #35C786;' align='center' bgcolor='#35C786' valign='top'>
																						<a href='%3%' target='_blank' rel='noopener' style='color: #FFFFFF; text-decoration: none; -ms-word-break: break-all; word-break: break-all; border-radius: 5px; box-sizing: border-box; cursor: pointer; display: inline-block; font-size: 14px; font-weight: bold; text-transform: capitalize; background: #35C786; margin: 0; padding: 12px 30px; border: 1px solid #35c786;'>
																							Klik hier om de uitnodiging te accepteren
																						</a>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
															</tbody>
														</table>
														<p style='max-width: 400px; display: block; color: #392F54; font-family: sans-serif; font-size: 14px; line-height: 20px; font-weight: normal; margin: 15px 0;'>Als je niet op de link kunt klikken, kopieer deze dan in de adresbalk van je browser:</p>
															<table border='0' cellpadding='0' cellspacing='0'>
																<tr>
																	<td style='-ms-word-break: break-all; word-break: break-all; font-family: sans-serif; font-size: 11px; line-height:14px;'>
																		<font style="-ms-word-break: break-all; word-break: break-all; font-size: 11px; line-height:14px;">
																			<a style='-ms-word-break: break-all; word-break: break-all; color: #392F54; text-decoration: underline; font-size: 11px; line-height:15px;' href='%3%'>%3%</a>
																		</font>
																	</td>
																</tr>
															</table>
														</p>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
								<br><br><br>
							</div>
						</td>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
					</tr>
				</table>
			</body>
    </html>`,
    defaultInvitationMessage: "Uitnodiging opnieuw aan het versturen...",
    deleteUser: "Verwijder gebruiker",
    deleteUserConfirmation: "Weet je zeker dat je deze gebruiker wil verwijderen?",
    stateAll: "Alles",
    stateActive: "Actief",
    stateDisabled: "Uitgeschakeld",
    stateLockedOut: "Vergrendeld",
    stateInvited: "Uitgenodigd",
    stateInactive: "Inactief",
    sortNameAscending: "Naam (A-Z)",
    sortNameDescending: "Naam (Z-A)",
    sortCreateDateAscending: "Oudste",
    sortCreateDateDescending: "Nieuwste",
    sortLastLoginDateDescending: "Laatste login",
    noUserGroupsAdded: "Er zijn geen gebruikersgroepen toegevoegd"
  },
  validation: {
    validation: "Validatie",
    validateAsEmail: "Valideer als e-mailadres",
    validateAsNumber: "Valideer als nummer",
    validateAsUrl: "Valideer als URL",
    enterCustomValidation: "...of gebruik aangepaste validatie",
    fieldIsMandatory: "Veld is verplicht",
    mandatoryMessage: "Voer een foutmelding in voor de aangepaste validatie (optioneel)",
    validationRegExp: "Voer een reguliere expressie in",
    validationRegExpMessage: "Voer een foutmelding in voor de aangepaste validatie (optioneel)",
    minCount: "Je hebt minstens",
    maxCount: "Je mag maximum",
    addUpTo: "Geef maximum",
    items: "items",
    urls: "URL(s)",
    urlsSelected: "URL(s) geselecteerd",
    itemsSelected: "items geselecteerd",
    invalidDate: "Ongeldige datum",
    invalidNumber: "Geen nummer",
    invalidEmail: "Ongeldig e-mailadres",
    invalidNull: "Waarde mag niet null zijn",
    invalidEmpty: "Waarde mag niet leeg zijn",
    invalidPattern: "Ongeldige waarde, het komt niet overeen met het correcte patroon",
    customValidation: "Aangepaste validatie",
    entriesShort: "Minimum %0% items, nog <strong>%1%</strong> nodig.",
    entriesExceed: "Maximum %0% items, <strong>%1%</strong> te veel."
  },
  healthcheck: {
    checkSuccessMessage: "Waarde is insteld naar the aanbevolen waarde: '%0%'.",
    checkErrorMessageDifferentExpectedValue: `De verwachte waarde voor '%2%' is '%1%' in configuratiebestand
      '%3%', maar is '%0%'.
    `,
    checkErrorMessageUnexpectedValue: `Onverwachte waarde '%0%' gevonden voor '%2%' in configuratiebestand
      '%3%'.
    `,
    macroErrorModeCheckSuccessMessage: "Macro foutmeldingen zijn ingesteld op'%0%'.",
    macroErrorModeCheckErrorMessage: `Macro foutmeldingen zijn ingesteld op '%0%'. Dit zal er voor zorgen dat
      bepaalde, of alle, pagina's van de website niet geladen kunnen worden als er errors in een Macro zitten.
      Corrigeren zal deze waarde aanpassen naar '%1%'.
    `,
    httpsCheckValidCertificate: "Het cerficaat van de website is ongeldig.",
    httpsCheckInvalidCertificate: "Cerficaat validatie foutmelding: '%0%'",
    httpsCheckExpiredCertificate: "Het SSL certificaat van de website is vervallen.",
    httpsCheckExpiringCertificate: "Het SSL certificaat van de website zal vervallen binnen %0% dagen.",
    healthCheckInvalidUrl: "Fout bij pingen van URL %0% - '%1%'",
    httpsCheckIsCurrentSchemeHttps: "De site wordt momenteel %0% bekeken via HTTPS.",
    compilationDebugCheckSuccessMessage: "Debug compilatie mode staat uit.",
    compilationDebugCheckErrorMessage: `Debug compilatie mode staat momenteel aan. Wij raden aan deze
      instelling uit te zetten voor livegang.
    `,
    clickJackingCheckHeaderFound: "De <strong>X-Frame-Options</strong> header of meta-tag om IFRAMEing door andere websites te voorkomen is aanwezig!",
    clickJackingCheckHeaderNotFound: "De <strong>X-Frame-Options</strong> header of meta-tag om IFRAMEing door andere websites te voorkomen is NIET aanwezig.",
    noSniffCheckHeaderFound: "De header of meta-tag <strong>X-Content-Type-Options</strong> die beveiligt tegen MIME sniffing kwetsbaarheden is gevonden.",
    noSniffCheckHeaderNotFound: "De header of meta-tag <strong>X-Content-Type-Options</strong> die beveiligt tegen MIME sniffing kwetsbaarheden is niet gevonden.",
    hSTSCheckHeaderFound: "De <strong>Strict-Transport-Security</strong> header, ook bekend als de HSTS-header, is gevonden.",
    hSTSCheckHeaderNotFound: "De <strong>Strict-Transport-Security</strong>header is niet gevonden.",
    xssProtectionCheckHeaderFound: "De header <strong>X-XSS-Protection</strong> is gevonden.",
    xssProtectionCheckHeaderNotFound: "De header <strong>X-XSS-Protection</strong> is niet gevonden.",
    excessiveHeadersFound: "De volgende headers die informatie tonen over de gebruikte website technologieën zijn aangetroffen: <strong>%0%</strong>.",
    excessiveHeadersNotFound: `Er zijn geen headers gevonden die informatie vrijgeven over de gebruikte
      website technologie!
    `,
    smtpMailSettingsConnectionSuccess: `SMTP instellingen zijn correct ingesteld en werken zoals verwacht.
    `,
    notificationEmailsCheckSuccessMessage: "Notificatie e-mail is verzonden naar <strong>%0%</strong>.",
    notificationEmailsCheckErrorMessage: "Notificatie e-mail staat nog steeds op de standaard waarde van <strong>%0%</strong>.",
    checkGroup: "Groep controleren",
    helpText: `
    <p>De health checker evalueert verschillende delen van de website voor best practice instellingen, configuratie, mogelijke problemen, enzovoort. U kunt problemen eenvoudig oplossen met een druk op de knop.
    U kunt uw eigen health checks toevoegen, kijk even naar <a href="https://docs.umbraco.com/umbraco-cms/extending/health-check" target="_blank" rel="noopener" class="btn-link -underline">de documentatie voor meer informatie</a> over aangepaste health checks.</p>
    `
  },
  redirectUrls: {
    disableUrlTracker: "URL tracker uitschakelen",
    enableUrlTracker: "URL tracker inschakelen",
    culture: "Cultuur",
    originalUrl: "Originele URL",
    redirectedTo: "Doorgestuurd naar",
    redirectUrlManagement: "Redirect Url Beheer",
    panelInformation: "De volgende URLs verwijzen naar dit content item:",
    noRedirects: "Er zijn geen redirects",
    noRedirectsDescription: `Er wordt automatisch een redirect aangemaakt als een gepubliceerde pagina
      hernoemd of verplaatst wordt.
    `,
    redirectRemoved: "Redirect URL verwijderd.",
    redirectRemoveError: "Fout bij verwijderen redirect URL.",
    redirectRemoveWarning: "Dit zal de redirect verwijderen",
    confirmDisable: "Weet je zeker dat je de URL tracker wilt uitzetten?",
    disabledConfirm: "URL tracker staat nu uit.",
    disableError: `Fout bij het uitzetten van de URL Tracker. Meer informatie kan gevonden worden in de log
      file.
    `,
    enabledConfirm: "URL tracker staat nu aan.",
    enableError: `Fout bij het aanzetten van de URL tracker. Meer informatie kan gevonden worden in de log
      file.
    `
  },
  emptyStates: {
    emptyDictionaryTree: "Geen woordenboekitems om uit te kiezen"
  },
  textbox: {
    characters_left: "<strong>%0%</strong> karakters resterend.",
    characters_exceed: "Maximum %0% karakters, <strong>%1%</strong> te veel."
  },
  recycleBin: {
    contentTrashed: "Content verwijderd met id : {0} gerelateerd aan aan bovenliggend item met Id: {1}",
    mediaTrashed: "Media verwijderd met id: {0} gerelateerd aan aan bovenliggend item met Id: {1}",
    itemCannotBeRestored: "Kan dit item niet automatisch herstellen",
    itemCannotBeRestoredHelpText: `Er is geen locatie waar dit item automatisch kan worden hersteld. U kunt
      het item handmatig verplaatsen met behulp van de onderstaande boomstructuur.
    `,
    wasRestored: "was hersteld onder"
  },
  relationType: {
    direction: "Richting",
    parentToChild: "Bovenliggend naar onderliggend",
    bidirectional: "Bidirectioneel",
    parent: "Bovenliggend",
    child: "Onderliggend",
    count: "Aantal",
    relations: "Relaties",
    created: "Gemaakt",
    comment: "Commentaar",
    name: "Naam",
    noRelations: "Geen relaties voor dit relatietype.",
    tabRelationType: "Relatietype",
    tabRelations: "Relaties",
    isDependency: "Is Afhankelijkheid",
    dependency: "Ja",
    noDependency: "Nee"
  },
  dashboardTabs: {
    contentIntro: "Aan de slag",
    contentRedirectManager: "Redirect URL Beheer",
    mediaFolderBrowser: "Inhoud",
    settingsWelcome: "Welkom",
    settingsExamine: "Examine Beheer",
    settingsPublishedStatus: "Publicatiestatus",
    settingsModelsBuilder: "Models Builder",
    settingsHealthCheck: "Gezondheidscontrole",
    settingsProfiler: "Profilering",
    memberIntro: "Aan de slag",
    formsInstall: "Umbraco Forms installeren"
  },
  visuallyHiddenTexts: {
    goBack: "Terug",
    activeListLayout: "Actieve layout:",
    jumpTo: "Spring naar",
    group: "groep",
    passed: "geslaagd",
    warning: "Waarschuwing",
    failed: "mislukt",
    suggestion: "suggestie",
    checkPassed: "Controle geslaagd",
    checkFailed: "Controle mislukt",
    openBackofficeSearch: "Backoffice zoeken openen",
    openCloseBackofficeHelp: "Backoffice help openen/sluiten",
    openCloseBackofficeProfileOptions: "Jouw profiel opties openen/sluiten",
    assignDomainDescription: "Cultuur en Hostnamen instellen voor %0%",
    createDescription: "Nieuwe node aanmaken onder %0%",
    protectDescription: "Openbare toegang instellen op %0%",
    rightsDescription: "Rechten instellen op %0%",
    sortDescription: "Sorteervolgorde wijzigen voor %0%",
    createblueprintDescription: "Maak een Inhoudssjabloon op basis van %0%",
    openContextMenu: "Open context menu voor",
    currentLanguage: "Huidige taal",
    switchLanguage: "Taal wijzigen naar",
    createNewFolder: "Map aanmaken",
    newPartialView: "Partial View",
    newPartialViewMacro: "Partial View Macro",
    newMember: "Lid",
    newDataType: "Datatype",
    redirectDashboardSearchLabel: "Zoeken in het redirect dashboard",
    userGroupSearchLabel: "Zoeken in de gebruikersgroep sectie",
    userSearchLabel: "Zoeken in de gebruikers sectie",
    createItem: "Item aanmaken",
    create: "Aanmaken",
    edit: "Bewerken",
    name: "Naam",
    addNewRow: "Rij toevoegen",
    tabExpand: "Bekijk meer opties",
    hasTranslation: "Vertaling aanwezig",
    noTranslation: "Vertaling ontbreekt",
    dictionaryListCaption: "Woordenboek items"
  },
  references: {
    tabName: "Referenties",
    DataTypeNoReferences: "Dit Datatype heeft geen referenties.",
    labelUsedByDocumentTypes: "Gebruikt in Documenttypes",
    labelUsedByMediaTypes: "Gebruikt in Mediatypes",
    labelUsedByMemberTypes: "Gebruikt in Ledentypes",
    usedByProperties: "Gebruikt door",
    labelUsedByItems: "Heeft verwijzingen vanuit de volgende items",
    labelUsedByDocuments: "Gebruikt in Documenten",
    labelUsedByMembers: "Gebruikt in Leden",
    labelUsedByMedia: "Gebruikt in Media"
  },
  logViewer: {
    deleteSavedSearch: "Opgeslagen zoekopdracht verwijderen",
    logLevels: "Log Niveaus",
    selectAllLogLevelFilters: "Selecteer alles",
    deselectAllLogLevelFilters: "Deselecteer alles",
    savedSearches: "Opgeslagen Zoekopdrachten",
    saveSearch: "Zoekopdracht opslaan",
    saveSearchDescription: "Enter a friendly name for your search query",
    filterSearch: "Zoekopdracht filteren",
    totalItems: "Aantal items",
    timestamp: "Tijdstempel",
    level: "Niveau",
    machine: "Machine",
    message: "Bericht",
    exception: "Uitzondering",
    properties: "Eigenschappen",
    searchWithGoogle: "Zoeken Met Google",
    searchThisMessageWithGoogle: "Dit bericht met Google opzoeken",
    searchWithBing: "Zoeken Met Bing",
    searchThisMessageWithBing: "Dit bericht met Bing opzoeken",
    searchOurUmbraco: "Zoeken in Our Umbraco",
    searchThisMessageOnOurUmbracoForumsAndDocs: "Search this message on Our Umbraco forums and docs",
    searchOurUmbracoWithGoogle: "Our Umbraco met Google doorzoeken",
    searchOurUmbracoForumsUsingGoogle: "Our Umbraco forums met Google doorzoeken",
    searchUmbracoSource: "Umbraco broncode doorzoeken",
    searchWithinUmbracoSourceCodeOnGithub: "Zoeken in Umbraco broncode op Github",
    searchUmbracoIssues: "Umbraco Issues doorzoeken",
    searchUmbracoIssuesOnGithub: "Umbraco Issues op Github doorzoeken",
    deleteThisSearch: "Zoekopdracht verwijderen",
    findLogsWithRequestId: "Logs met Request ID zoeken",
    findLogsWithNamespace: "Logs met Namespace zoeken",
    findLogsWithMachineName: "Logs met Machine Naam zoeken",
    open: "Openen",
    polling: "Peilen",
    every2: "Elke 2 seconden",
    every5: "Elke 5 seconden",
    every10: "Elke 10 seconden",
    every20: "Elke 20 seconden",
    every30: "Elke 30 seconden",
    pollingEvery2: "Elke 2s peilen",
    pollingEvery5: "Elke 5s peilen",
    pollingEvery10: "Elke 10s peilen",
    pollingEvery20: "Elke 20s peilen",
    pollingEvery30: "Elke 30s peilen"
  },
  clipboard: {
    labelForCopyAllEntries: "Kopieer %0%",
    labelForArrayOfItemsFrom: "%0% van %1%",
    labelForRemoveAllEntries: "Alle items verwijderen",
    labelForClearClipboard: "Klembord leegmaken"
  },
  propertyActions: {
    tooltipForPropertyActionsMenu: "Eigenschapsacties openen",
    tooltipForPropertyActionsMenuClose: "Eigenschapsacties sluiten"
  },
  nuCache: {
    refreshStatus: "Status vernieuwen",
    memoryCache: "Geheugencache",
    memoryCacheDescription: `
          Deze knop vernieuwt de cache in het geheugen, door het volledig uit de cache in de database
          te laden (maar het bouwt de cache in de database niet opnieuw op). Dit is relatief snel.
          Gebruik het wanneer je denkt dat de geheugencache niet goed is vernieuwd nadat
          enkele gebeurtenissen waren geactiveerd&mdash;wat zou duiden op een klein Umbraco-probleem.
          (let op: activeert het herladen op alle servers in een LB-omgeving).
          `,
    reload: "Vernieuwen",
    databaseCache: "Database Cache",
    databaseCacheDescription: `
          Met deze knop kunt u de databasecache opnieuw opbouwen, dwz de inhoud van de cmsContentNu-tabel.
          <strong>Opnieuw bouwen kan duur zijn.</strong>
          Gebruik het wanneer herladen niet genoeg is en u denkt dat de databasecache niet correct
          is gegenereerd&mdash;wat zou duiden op een kritiek Umbraco-probleem.
          `,
    rebuild: "Opnieuw bouwen",
    internals: "Interne onderdelen",
    internalsDescription: `
          Met deze knop activeer je een ophaling van NuCache-snapshots (na het uitvoeren van een fullCLR GC).
          Tenzij je weet wat dat betekent, hoef je het waarschijnlijk <em>niet</em> te gebruiken.
          `,
    collect: "Verzamelen",
    publishedCacheStatus: "Gepubliceerde Cachestatus",
    caches: "Caches"
  },
  profiling: {
    performanceProfiling: "Prestatieprofilering",
    performanceProfilingDescription: `
              <p>
                  Umbraco wordt uitgevoerd in de foutopsporingsmodus. Dit betekent dat u de ingebouwde prestatieprofiler kunt gebruiken om de prestaties te beoordelen bij het renderen van pagina's.
              </p>
              <p>
                  Als je de profiler voor een specifieke paginaweergave wilt activeren, voeg je <strong>umbDebug=true</strong> toe aan de querystring wanneer je de pagina opvraagt.
              </p>
              <p>
                  Als je wil dat de profiler standaard wordt geactiveerd voor alle paginaweergaven, kun je de onderstaande schakelaar gebruiken.
                  Het plaatst een cookie in je browser, die vervolgens de profiler automatisch activeert.
                  Met andere woorden, de profiler zal alleen voor <em>jouw</em> browser actief zijn, niet voor andere bezoekers.
              </p>
      `,
    activateByDefault: "Activeer de profiler standaard",
    reminder: "Vriendelijke herinnering"
  },
  settingsDashboardVideos: {
    trainingHeadline: "Je bent slechts een klik verwijderd van uren aan Umbraco trainingvideo's.",
    trainingDescription: `
        <p>Wil je Umbraco onder de knie krijgen? Besteed een paar minuten aan het leren van enkele best practices door een van deze video's over het gebruik van Umbraco te bekijken. Bezoek <a href="https://umbraco.tv" target="_blank" rel="noopener">umbraco.tv</a> voor meer Umbraco videos</p>
    `,
    getStarted: "Om je op weg te helpen"
  },
  settingsDashboard: {
    start: "Start hier",
    startDescription: `Deze sectie bevat de bouwstenen voor jouw Umbraco-site. Volg de onderstaande links
      voor meer informatie over het werken met de items in de sectie Instellingen
    `,
    more: "Meer te weten komen",
    bulletPointOne: `
            Lees meer over het werken met de items in de sectie Instellingen <a class="btn-link -underline" href="https://docs.umbraco.com/umbraco-cms/fundamentals/backoffice/sections/" target="_blank" rel="noopener">in het Documentatiegedeelte</a> van Our Umbraco
        `,
    bulletPointTwo: `
            Stel een vraag op het <a class="btn-link -underline" href="https://our.umbraco.com/forum" target="_blank" rel="noopener">Community Forum</a>
        `,
    bulletPointThree: `
            Bekijk onze <a class="btn-link -underline" href="https://umbraco.tv" target="_blank" rel="noopener">instructievideo's</a> (sommige zijn gratis, andere vereisen een abonnement)
        `,
    bulletPointFour: `
            Lees meer over onze <a class="btn-link -underline" href="https://umbraco.com/products/" target="_blank" rel="noopener">productiviteitsverhogende programma's en commerciële ondersteuning</a>
        `,
    bulletPointFive: `
            Lees meer over real-life <a class="btn-link -underline" href="https://umbraco.com/training/" target="_blank" rel="noopener">training en certificering</a> opportuniteiten
        `
  },
  startupDashboard: {
    fallbackHeadline: "Welkom bij Het Vriendelijke CMS",
    fallbackDescription: `Bedankt om voor Umbraco te kiezen - We denken dat dit het begin van iets moois is.
      Hoewel het in het begin misschien overweldigend aanvoelt, hebben we er veel aan gedaan om de leercurve zo soepel
      en snel mogelijk te laten verlopen.
    `
  },
  formsDashboard: {
    formsHeadline: "Umbraco Forms",
    formsDescription: `Maak formulieren met behulp van een intuïtieve interface. Van eenvoudige
      contactformulieren die e-mails versturen tot geavanceerde vragenlijsten die integreren met CRM-systemen. Je
      klanten zullen er dol op zijn!
    `
  },
  blockEditor: {
    headlineCreateBlock: "Nieuwe blok aanmaken",
    headlineAddSettingsElementType: "Instellingensectie toevoegen",
    headlineAddCustomView: "Weergave selecteren",
    headlineAddCustomStylesheet: "Stylesheet selecteren",
    headlineAddThumbnail: "Miniatuur kiezen",
    labelcreateNewElementType: "Nieuwe aanmaken",
    labelCustomStylesheet: "Aangepaste stylesheet",
    addCustomStylesheet: "Stylesheet toevoegen",
    headlineEditorAppearance: "Editor uiterlijk",
    headlineDataModels: "Data modellen",
    headlineCatalogueAppearance: "Catalogus uiterlijk",
    labelBackgroundColor: "Achtergrondkleur",
    labelIconColor: "Icoon kleur",
    labelContentElementType: "Inhoud model",
    labelLabelTemplate: "Label",
    labelCustomView: "Aangepaste weergave",
    labelCustomViewInfoTitle: "Aangepaste weergave-omschrijving tonen",
    labelCustomViewDescription: `Overschrijf hoe dit blok wordt weergegeven in de
      BackOffice-gebruikersinterface. Kies een .html-bestand met je presentatie.
    `,
    labelSettingsElementType: "Instellingen model",
    labelEditorSize: "Grootte van overlay-editor",
    addCustomView: "Aangepaste weergave toevoegen",
    addSettingsElementType: "Instellingen toevoegen",
    confirmDeleteBlockMessage: "Weet je zeker dat je blok <strong>%0%</strong> wil verwijderen?",
    confirmDeleteBlockTypeMessage: "Weet je zeker dat je blok instellingen <strong>%0%</strong> wil verwijderen?",
    confirmDeleteBlockTypeNotice: `De inhoud van dit blok is nog steeds aanwezig, bewerken van deze inhoud is
      niet langer mogelijk en wordt weergegeven als niet-ondersteunde inhoud.
    `,
    blockConfigurationOverlayTitle: "Configuratie van '%0%'",
    thumbnail: "Miniatuur",
    addThumbnail: "Miniatuur toevoegen",
    tabCreateEmpty: "Lege aanmaken",
    tabClipboard: "Klembord",
    tabBlockSettings: "Instellingen",
    headlineAdvanced: "Geavanceerd",
    forceHideContentEditor: "Inhoudseditor geforceerd verbergen",
    blockHasChanges: "Je hebt aanpassingen gemaakt aan deze inhoud. Wil je deze wijzigingen verwerpen?",
    confirmCancelBlockCreationHeadline: "Wijzigingen opslaan?",
    confirmCancelBlockCreationMessage: "Ben je zeker dat je deze wijzigingen wil verwerpen?",
    elementTypeDoesNotExistHeadline: "Fout!",
    elementTypeDoesNotExistDescription: "Het Elementtype van dit blok bestaat niet meer",
    addBlock: "Inhoud toevoegen",
    addThis: "Voeg %0% toe",
    propertyEditorNotSupported: `Eigenschap '%0%' gebruikt editor '%1%' die niet ondersteund wordt in
      blokken.
    `,
    focusParentBlock: "Geef focus aan het container blok",
    areaIdentification: "Identificatie",
    areaValidation: "Validatie",
    areaValidationEntriesShort: "<strong>%0%</strong> moet minimaal <strong>%2%</strong> keer aanwezig zijn.",
    areaValidationEntriesExceed: "<strong>%0%</strong>mag maximaal <strong>%3%</strong> keer aanwezig zijn.",
    areaNumberOfBlocks: "Hoeveelheid blokken",
    areaDisallowAllBlocks: "Sta alleen specifiek bloktype toe",
    areaAllowedBlocks: "Toegestane bloktypes",
    areaAllowedBlocksHelp: "Definieer de type blokken die zijn toegestaan in dit gebied, en optioneel hoeveel van ieder type aanwezig moet zijn.",
    confirmDeleteBlockAreaMessage: "Weet je zeker dat je dit gebied wilt verwijderen?",
    confirmDeleteBlockAreaNotice: "Alle blokken op dit moment aangemaakt binnen dit gebied zullen worden verwijderd.",
    layoutOptions: "Lay-out opties",
    structuralOptions: "Structuur",
    sizeOptions: "Afmetingen",
    sizeOptionsHelp: "Definiëer een of meer afmetingen, dit maakt het mogelijk blokken te vergroten/verkleinen",
    allowedBlockColumns: "Beschikbare kolommen",
    allowedBlockColumnsHelp: "Definieer de verschillende aantal kolombreedtes dat dit blok mag in nemen. Dit voorkomt niet dat blokken in gebieden met kleine kolombreedtes kan worden geplaatst.",
    allowedBlockRows: "Beschikbare rijen",
    allowedBlockRowsHelp: "Definiëer de verschillende aantal rijen dat dit blok mag innemen.",
    allowBlockInRoot: "Sta toe in root",
    allowBlockInRootHelp: "Maak dit blok beschikbaar in de root van de lay-out",
    allowBlockInAreas: "Sta toe in gebieden",
    block: "Blok",
    tabBlock: "Blokken",
    tabBlockTypeSettings: "Instellingen",
    allowBlockInAreasHelp: "Maak dit blok standaard beschikbaar binnen de gebieden van andere blokken (behalve wanneer expliciete rechten zijn gezet voor deze gebieden).",
    areaAllowedBlocksEmpty: "Indien leeg kunnen alle blokken toegestaand in gebieden worden toegevoegd. ",
    areasLayoutColumns: "Grid Kolommen voor Gebieden.",
    areasLayoutColumnsHelp: "Definiëer hoeveel kolommen beschikbaar zijn in gebiede. Indien niet gedefinieerd wordt het aantal kolommen gedefinieerd voor de gehele lay-out gebruikt.",
    areasConfigurations: "Gebieden",
    areasConfigurationsHelp: "Om het nesten van blokken binnen-in dit blok toe te staan, definieer een of meer gebieden voor blokken om binnenin te nesten. Gebieden volgen hun eigen lay-out welke gedefinieerd is bij de Grid Kolommen voor Gebieden. Elk Gebied kolombreedte can worden gewijzigd door het gebruik van de schaal in de hoek rechtsonderin ",
    invalidDropPosition: "<strong>%0%</strong> is niet toegestaan op deze locatie.",
    defaultLayoutStylesheet: "Standaard lay-out stylesheet",
    confirmPasteDisallowedNestedBlockHeadline: "Niet-toegestane content is geweigerd",
    confirmPasteDisallowedNestedBlockMessage: "De toegevoegde content bevat niet-toegestaande content, welke niet is aangemaakt. Wil je de rest van de content bewaren?",
    scaleHandlerButtonTitle: "Sleep om te vergroten/verkleinen",
    areaCreateLabelTitle: "Maak Button Label",
    areaCreateLabelHelp: "Overschrijf het label van de create button van dit Gebied.",
    showSizeOptions: "Toon vergroot/verklein opties",
    addBlockType: "Voeg Blok toe",
    addBlockGroup: "Voeg groep toep",
    pickSpecificAllowance: "Selecteer groep of Blok",
    allowanceMinimum: "Zet een minimale vereiste",
    areas: "Gebieden",
    tabAreas: "Gebieden",
    tabAdvanced: "Geadvanceerd",
    headlineAllowance: "Rechten",
    getSampleHeadline: "Installeer Voorbeeld Configuratie",
    getSampleButton: "Installeer",
    actionEnterSortMode: "Sorteer mode",
    actionExitSortMode: "Sluit sorteer mode",
    areaAliasIsNotUnique: "Dit Gebieds' Alias moet uniek zijn ten opzichte van andere Gebieden in dit Blok.",
    configureArea: "Configureer gebied",
    deleteArea: "Verwijder gebied"
  },
  contentTemplatesDashboard: {
    whatHeadline: "Wat zijn Inhoudssjablonen?",
    whatDescription: `Inhoudssjablonen is vooraf gedefinieerde inhoud die kan worden geselecteerd bij het
      maken van een nieuwe node.
    `,
    createHeadline: "Hoe maak ik een Inhoudssjabloon?",
    createDescription: `
        <p>Er zijn 2 manieren om Inhoudssjablonen te maken:</p>
        <ul>
            <li>Klik met de rechtermuisknop op een inhoudsnode en selecteer "Inhoudssjabloon aanmaken" om een nieuwe Inhoudssjabloon te maken.</li>
            <li>Klik met de rechtermuisknop op Inhoudssjablonen in de boomstructuur in de sectie Instellingen en selecteer het documenttype waarvoor je een Inhoudssjabloon wilt maken.</li>
        </ul>
        <p>Nadat de Inhoudssjabloon een naam heeft, kunnen redacteuren ze gaan gebruiken als basis voor hun nieuwe pagina.</p>
    `,
    manageHeadline: "Hoe beheer ik Inhoudssjablonen?",
    manageDescription: `U kunt Inhoudssjablonen bewerken en verwijderen vanuit de boomstructuur
      "inhoudssjablonen" in de sectie Instellingen. Vouw het documenttype uit waarop de Inhoudssjabloon is gebaseerd en
      klik erop om het te bewerken of te verwijderen.
    `
  }
};
export {
  e as default
};
//# sourceMappingURL=nl-nl-DhIliJo2.js.map
