import { U as e } from "../property-action-menu.element-DHt2QH7Q.js";
import { U } from "../property-action-base-DoDWw2x7.js";
import { U as p } from "../manifests-fsCMI7-p.js";
export {
  p as UMB_PROPERTY_ACTION_DEFAULT_KIND_MANIFEST,
  U as UmbPropertyActionBase,
  e as UmbPropertyActionMenuElement
};
//# sourceMappingURL=index.js.map
