import { UmbContextToken as T } from "@umbraco-cms/backoffice/context-api";
const P = new T(
  "UmbWorkspaceContext",
  void 0,
  (o) => o.IS_PROPERTY_TYPE_WORKSPACE_CONTEXT
);
export {
  P as U
};
//# sourceMappingURL=property-type-workspace.context-token-Cbb8UB1S.js.map
