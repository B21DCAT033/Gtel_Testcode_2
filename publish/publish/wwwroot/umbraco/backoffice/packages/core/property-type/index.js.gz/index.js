import { a as E, U as T } from "../manifests-BReQksxD.js";
import { b as Y, c as A, U as O, a as U } from "../paths-CAM7NxJ3.js";
import { U as C } from "../property-type-workspace.context-token-Cbb8UB1S.js";
export {
  Y as UMB_CREATE_PROPERTY_TYPE_WORKSPACE_PATH_PATTERN,
  A as UMB_EDIT_PROPERTY_TYPE_WORKSPACE_PATH_PATTERN,
  E as UMB_PROPERTY_TYPE_ENTITY_TYPE,
  T as UMB_PROPERTY_TYPE_WORKSPACE_ALIAS,
  C as UMB_PROPERTY_TYPE_WORKSPACE_CONTEXT,
  O as UMB_PROPERTY_TYPE_WORKSPACE_MODAL,
  U as UMB_PROPERTY_TYPE_WORKSPACE_PATH
};
//# sourceMappingURL=index.js.map
