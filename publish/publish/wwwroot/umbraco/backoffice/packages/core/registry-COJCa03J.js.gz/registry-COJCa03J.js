import { UmbExtensionRegistry as s } from "@umbraco-cms/backoffice/extension-api";
const e = new s();
export {
  e as u
};
//# sourceMappingURL=registry-COJCa03J.js.map
