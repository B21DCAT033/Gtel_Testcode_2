import { UmbModalToken as e } from "@umbraco-cms/backoffice/modal";
const a = new e("Umb.Modal.RecycleBin.Restore", {
  modal: {
    type: "sidebar",
    size: "small"
  }
});
export {
  a as U
};
//# sourceMappingURL=restore-from-recycle-bin-modal.token-Dfw4-Cxp.js.map
