import { U as m } from "../text-style.style-BXyaVaXp.js";
export {
  m as UmbTextStyles
};
//# sourceMappingURL=index.js.map
