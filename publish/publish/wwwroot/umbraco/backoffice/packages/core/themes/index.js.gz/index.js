import { UMB_THEME_CONTEXT as m, UmbThemeContext as o } from "../theme.context-XzjZ20Xg.js";
export {
  m as UMB_THEME_CONTEXT,
  o as UmbThemeContext
};
//# sourceMappingURL=index.js.map
