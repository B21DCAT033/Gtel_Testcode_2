const e = {
  actions: {
    assigndomain: "Kültür ve Ana Bilgisayar Adları",
    auditTrail: "Denetim Yolu",
    browse: "Düğüme Göz At",
    changeDocType: "Belge Türünü Değiştir",
    copy: "Kopyala",
    create: "Oluştur",
    export: "Dışa Aktar",
    createPackage: "Paket Oluştur",
    createGroup: "Grup oluştur",
    delete: "Sil",
    disable: "Devre Dışı Bırak",
    editSettings: "Ayarları düzenle",
    emptyrecyclebin: "Geri dönüşüm kutusunu boşalt",
    enable: "Etkinleştir",
    exportDocumentType: "Belge Türünü Dışa Aktar",
    importdocumenttype: "Belge Türünü İçe Aktar",
    importPackage: "Paketi İçe Aktar",
    liveEdit: "Kanvas'ta Düzenle",
    logout: "Çıkış",
    move: "Taşı",
    notify: "Bildirimler",
    protect: "Genel erişim",
    publish: "Yayımla",
    unpublish: "Yayından Kaldır",
    refreshNode: "Yeniden Yükle",
    republish: "Tüm siteyi yeniden yayınla",
    remove: "Kaldır",
    rename: "Yeniden adlandır",
    restore: "Geri Yükle",
    chooseWhereToCopy: "Nereye kopyalayacağınızı seçin",
    chooseWhereToMove: "Taşınacağınız yeri seçin",
    toInTheTreeStructureBelow: "aşağıdaki ağaç yapısına",
    infiniteEditorChooseWhereToCopy: "Seçili öğelerin nereye kopyalanacağını seçin",
    infiniteEditorChooseWhereToMove: "Seçili öğelerin nereye taşınacağını seçin",
    wasMovedTo: "konumuna taşındı,",
    wasCopiedTo: "kopyalandı,",
    wasDeleted: "silindi,",
    rights: "İzinler",
    rollback: "Geri al",
    sendtopublish: "Yayınlamak İçin Gönder",
    sendToTranslate: "Çeviriye Gönder",
    setGroup: "Grup ayarla",
    sort: "Sırala",
    translate: "Çevir",
    update: "Güncelle",
    setPermissions: "İzinleri ayarlayın",
    unlock: "Kilidi Aç",
    createblueprint: "İçerik Şablonu Oluşturun",
    resendInvite: "Daveti Yeniden Gönder"
  },
  actionCategories: {
    content: "İçerik",
    administration: "Yönetim",
    structure: "Yapı",
    other: "Diğer"
  },
  actionDescriptions: {
    assignDomain: "Kültür ve ana bilgisayar adları atamak için erişime izin ver",
    auditTrail: "Bir düğümün geçmiş günlüğünü görüntülemek için erişime izin ver",
    browse: "Bir düğümü görüntülemek için erişime izin verin",
    changeDocType: "Bir düğüm için belge türünü değiştirmek üzere erişime izin ver",
    copy: "Bir düğümü kopyalamak için erişime izin ver",
    create: "Düğüm oluşturmak için erişime izin verin",
    delete: "Düğümleri silmek için erişime izin ver",
    move: "Bir düğümü taşımak için erişime izin ver",
    protect: "Erişime, bir düğüm için genel erişimi ayarlama ve değiştirme izni verme",
    publish: "Bir düğüm yayınlamak için erişime izin verin",
    unpublish: "Bir düğümü yayından kaldırmak için erişime izin ver",
    rights: "Bir düğüm için izinleri değiştirmek üzere erişime izin ver",
    rollback: "Bir düğümü önceki bir duruma geri döndürmek için erişime izin ver",
    sendtopublish: "Yayınlamadan önce onay için bir düğüm gönderme erişimine izin ver",
    sendToTranslate: "Çeviri için bir düğüm gönderme erişimine izin ver",
    sort: "Düğümler için sıralama düzenini değiştirmek için erişime izin ver",
    translate: "Bir düğümü çevirmek için erişime izin ver",
    update: "Bir düğümü kaydetme erişimine izin ver",
    createblueprint: "İçerik Şablonu oluşturma erişimine izin verin"
  },
  apps: {
    umbContent: "İçerik",
    umbInfo: "Bilgi"
  },
  assignDomain: {
    permissionDenied: "İzin reddedildi.",
    addNew: "Yeni Alan Ekle",
    remove: "kaldır",
    invalidNode: "Geçersiz düğüm.",
    invalidDomain: "Bir veya daha fazla alanın biçimi geçersiz.",
    duplicateDomain: "Etki alanı zaten atanmış.",
    language: "Dil",
    domain: "Alan",
    domainCreated: "Yeni '%0%' etki alanı oluşturuldu",
    domainDeleted: "'%0%' alan adı silindi",
    domainExists: "'%0%' etki alanı zaten atanmış",
    domainUpdated: "'%0%' etki alanı güncellendi",
    orEdit: "Mevcut Etki Alanlarını Düzenle",
    domainHelpWithVariants: `Geçerli alan adları: "example.com", "www.example.com", "example.com:8080" veya "https://www.example.com/".
     Ayrıca, alanlardaki tek seviyeli yollar da desteklenir, örn. "example.com/tr" veya "/en".`,
    inherit: "Devral",
    setLanguage: "Kültür",
    setLanguageHelp: `Geçerli düğümün altındaki düğümler için kültürü ayarlayın, <br /> veya kültürü üst düğümlerden devralın. Ayrıca <br />
        aşağıdaki alan da geçerli değilse geçerli düğüme.`,
    setDomains: "Alanlar"
  },
  buttons: {
    clearSelection: "Seçimi temizle",
    select: "Seç",
    somethingElse: "Başka bir şey yapın",
    bold: "Kalın",
    deindent: "Paragraf Girintisini İptal Et",
    formFieldInsert: "Form alanı ekle",
    graphicHeadline: "Grafik başlığı ekle",
    htmlEdit: "Html'yi Düzenle",
    indent: "Paragrafı Girintile",
    italic: "İtalik",
    justifyCenter: "Ortala",
    justifyLeft: "Sola Yasla",
    justifyRight: "Sağa Yasla",
    linkInsert: "Bağlantı Ekle",
    linkLocal: "Yerel bağlantı ekle (bağlantı)",
    listBullet: "Madde İşareti Listesi",
    listNumeric: "Sayısal Liste",
    macroInsert: "Makro ekle",
    pictureInsert: "Resim ekle",
    publishAndClose: "Yayınlayın ve kapatın",
    publishDescendants: "Nesillerle yayınlayın",
    relations: "İlişkileri düzenle",
    returnToList: "Listeye dön",
    save: "Kaydet",
    saveAndClose: "Kaydet ve kapat",
    saveAndPublish: "Kaydet ve yayınla",
    saveToPublish: "Kaydet ve onaya gönder",
    saveListView: "Liste görünümünü kaydet",
    schedulePublish: "Planla",
    saveAndPreview: "Kaydet ve önizle",
    showPageDisabled: "Atanmış şablon olmadığından önizleme devre dışı bırakıldı",
    styleChoose: "Stil seçin",
    styleShow: "Stilleri göster",
    tableInsert: "Tablo ekle",
    saveAndGenerateModels: "Modelleri kaydedin ve oluşturun",
    undo: "Geri Al",
    redo: "Yeniden yap",
    deleteTag: "Etiketi sil",
    confirmActionCancel: "İptal",
    confirmActionConfirm: "Onayla",
    morePublishingOptions: "Daha fazla yayınlama seçeneği",
    submitChanges: "Gönder"
  },
  auditTrailsMedia: {
    delete: "Medya silindi",
    move: "Medya taşındı",
    copy: "Medya kopyalandı",
    save: "Medya kaydedildi"
  },
  auditTrails: {
    atViewingFor: "Görüntüleniyor",
    delete: "İçerik silindi",
    unpublish: "Yayınlanmamış içerik",
    publish: "Kaydedilen ve Yayınlanan İçerik",
    publishvariant: "Diller için kaydedilen ve yayınlanan içerik: %0%",
    save: "İçerik kaydedildi",
    savevariant: "Diller için kaydedilen içerik: %0%",
    move: "İçerik taşındı",
    copy: "İçerik kopyalandı",
    rollback: "İçerik geri alındı ​​",
    sendtopublish: "Yayınlanmak için gönderilen içerik",
    sendtopublishvariant: "Diller için yayınlanmak üzere gönderilen içerik: %0%",
    sort: "Kullanıcı tarafından gerçekleştirilen alt öğeleri sıralama",
    custom: "%0%",
    smallCopy: "Kopyala",
    smallPublish: "Yayınla",
    smallPublishVariant: "Yayınla",
    smallMove: "Taşı",
    smallSave: "Kaydet",
    smallSaveVariant: "Kaydet",
    smallDelete: "Sil",
    smallUnpublish: "Yayından Kaldır",
    smallRollBack: "Geri Al",
    smallSendToPublish: "Yayınlamak İçin Gönder",
    smallSendToPublishVariant: "Yayınlamak İçin Gönder",
    smallSort: "Sırala",
    smallCustom: "Özel",
    historyIncludingVariants: "Geçmiş (tüm varyantlar)"
  },
  codefile: {
    createFolderIllegalChars: "Klasör adı geçersiz karakterler içeremez.",
    deleteItemFailed: "Öğe silinemedi: %0%"
  },
  content: {
    isPublished: "Yayınlandı",
    about: "Bu sayfa hakkında",
    alias: "Takma ad",
    alternativeTextHelp: "(resmi telefonda nasıl tarif edersiniz)",
    alternativeUrls: "Alternatif Bağlantılar",
    clickToEdit: "Bu öğeyi düzenlemek için tıklayın",
    createBy: "Oluşturan",
    createByDesc: "Orijinal yazar",
    updatedBy: "Güncelleyen",
    createDate: "Oluşturuldu",
    createDateDesc: "Bu belgenin oluşturulduğu tarih / saat",
    documentType: "Belge Türü",
    editing: "Düzenle",
    expireDate: "Kaldır",
    itemChanged: "Bu öğe yayınlandıktan sonra değiştirildi",
    itemNotPublished: "Bu öğe yayınlanmadı",
    lastPublished: "Son yayınlanan",
    noItemsToShow: "Gösterilecek öğe yok",
    listViewNoItems: "Listede gösterilecek öğe yok.",
    listViewNoContent: "Hiçbir içerik eklenmedi",
    listViewNoMembers: "Üye eklenmedi",
    mediatype: "Medya Türü",
    mediaLinks: "Medya öğelerine bağlantı",
    membergroup: "Üye Grubu",
    memberrole: "Rol",
    membertype: "Üye Türü",
    noChanges: "Hiçbir değişiklik yapılmadı",
    noDate: "Tarih seçilmedi",
    nodeName: "Sayfa başlığı",
    noMediaLink: "Bu medya öğesinin bağlantısı yok",
    otherElements: "Özellikler",
    parentNotPublished: "Bu belge yayınlandı, ancak '%0%' üst öğesi yayından kaldırıldığı için görünmüyor",
    parentCultureNotPublished: "Bu kültür yayınlandı, ancak '%0%' üst öğe üzerinde yayınlanmadığı için görünmüyor",
    parentNotPublishedAnomaly: "Bu belge yayınlandı, ancak önbellekte yok",
    getUrlException: "URL alınamadı",
    routeError: "Bu belge yayınlandı, ancak url'si %0% içeriğiyle çakışacak",
    routeErrorCannotRoute: "Bu belge yayınlandı, ancak url'si yönlendirilemez",
    publish: "Yayınla",
    published: "Yayınlandı",
    publishedPendingChanges: "Yayınlandı (bekleyen değişiklikler)",
    publishStatus: "Yayın Durumu",
    publishDescendantsHelp: "<strong>%0%</strong> ve altındaki tüm içerik öğelerini yayınlayın ve böylece içeriğini herkese açık hale getirin.",
    publishDescendantsWithVariantsHelp: "Altında aynı türdeki varyantları ve varyantları yayınlayın ve böylece içeriklerini herkese açık hale getirin.",
    releaseDate: "Yayınla",
    unpublishDate: "Yayından kaldır",
    removeDate: "Tarihi Temizle",
    setDate: "Tarihi ayarla",
    sortDone: "Sıralayıcı güncellendi",
    sortHelp: 'Düğümleri sıralamak için, düğümleri sürükleyin veya sütun başlıklarından birine tıklayın. Seçerken "shift" veya "kontrol" tuşunu basılı tutarak birden fazla düğüm seçebilirsiniz',
    statistics: "İstatistikler",
    titleOptional: "Başlık (isteğe bağlı)",
    altTextOptional: "Alternatif metin (isteğe bağlı)",
    type: "Tür",
    unpublish: "Yayından Kaldır",
    unpublished: "Yayınlanmadı",
    updateDate: "Son düzenleme",
    updateDateDesc: "Bu belgenin düzenlendiği tarih / saat",
    uploadClear: "Dosyaları kaldırın",
    uploadClearImageContext: "Resmi medya öğesinden kaldırmak için burayı tıklayın",
    uploadClearFileContext: "Dosyayı medya öğesinden kaldırmak için burayı tıklayın",
    urls: "Belgeye bağlantı",
    memberof: "Grup(lar) ın üyesi",
    notmemberof: "Grup(lar) ın üyesi değil",
    childItems: "Alt öğeler",
    target: "Hedef",
    scheduledPublishServerTime: "Bu, sunucuda şu zamana çevrilir:",
    scheduledPublishDocumentation: '<a href="https://docs.umbraco.com/umbraco-cms/fundamentals/data/scheduled-publishing#timezones" target="_ blank">Ne bu ne anlama geliyor? </a>',
    nestedContentDeleteItem: "Bu öğeyi silmek istediğinizden emin misiniz?",
    nestedContentEditorNotSupported: "%0% özelliği,%1% düzenleyiciyi kullanıyor ve bu, Yuvalanmış İçerik tarafından desteklenmiyor.",
    nestedContentDeleteAllItems: "Tüm öğeleri silmek istediğinizden emin misiniz?",
    nestedContentNoContentTypes: "Bu özellik için hiçbir içerik türü yapılandırılmadı.",
    nestedContentAddElementType: "Öğe türü ekle",
    nestedContentSelectElementTypeModalTitle: "Öğe türünü seçin",
    nestedContentGroupHelpText: "Özelliklerinin görüntülenmesi gereken grubu seçin. Boş bırakılırsa, eleman türündeki ilk grup kullanılacaktır.",
    nestedContentTemplateHelpTextPart1: "Adını her bir öğeyle karşılaştırmak için açısal bir ifade girin. kullanın ",
    nestedContentTemplateHelpTextPart2: "öğe dizinini görüntülemek için",
    addTextBox: "Başka bir metin kutusu ekle",
    removeTextBox: "Bu metin kutusunu kaldırın",
    contentRoot: "İçerik Kökü",
    includeUnpublished: "Yayınlanmamış içerik öğelerini dahil edin.",
    isSensitiveValue: "Bu değer gizlidir. Bu değeri görüntülemek için erişime ihtiyacınız varsa, lütfen web sitesi yöneticinizle iletişime geçin.",
    isSensitiveValue_short: "Bu değer gizlidir.",
    languagesToPublish: "Hangi dilleri yayınlamak istersiniz?",
    languagesToSendForApproval: "Onay için hangi dilleri göndermek istersiniz?",
    languagesToSchedule: "Hangi dilleri planlamak istersiniz?",
    languagesToUnpublish: "Yayından kaldırılacak dilleri seçin. Zorunlu bir dilin yayından kaldırılması tüm dilleri yayından kaldırır.",
    variantsWillBeSaved: "Tüm yeni varyantlar kaydedilecektir.",
    variantsToPublish: "Hangi çeşitleri yayınlamak istersiniz?",
    variantsToSave: "Hangi değişkenlerin kaydedileceğini seçin.",
    publishRequiresVariants: "Yayınlamanın gerçekleşmesi için aşağıdaki varyantlar gereklidir:",
    notReadyToPublish: "Yayınlamaya hazır değiliz",
    readyToPublish: "Yayınlamaya hazır mısınız?",
    readyToSave: "Kaydetmeye Hazır mısınız?",
    sendForApproval: "Onaya gönder",
    schedulePublishHelp: "İçerik öğesini yayınlamak ve / veya yayından kaldırmak için tarih ve saati seçin.",
    createEmpty: "Yeni oluştur",
    createFromClipboard: "Panodan yapıştır",
    nodeIsInTrash: "Bu öğe Geri Dönüşüm Kutusu'nda",
    saveModalTitle: "Kaydet"
  },
  blueprints: {
    createBlueprintFrom: "<em>%0%</em> den yeni bir İçerik Şablonu oluşturun",
    blankBlueprint: "Boş",
    selectBlueprint: "Bir İçerik Şablonu Seçin",
    createdBlueprintHeading: "İçerik Şablonu oluşturuldu",
    createdBlueprintMessage: "'%0%' üzerinden bir İçerik Şablonu oluşturuldu",
    duplicateBlueprintMessage: "Aynı ada sahip başka bir İçerik Şablonu zaten var",
    blueprintDescription: "İçerik Şablonu, bir düzenleyicinin yeni içerik oluşturmak için temel olarak kullanmak üzere seçebileceği önceden tanımlanmış içeriktir"
  },
  media: {
    clickToUpload: "Yüklemek için tıklayın",
    orClickHereToUpload: "veya dosyaları seçmek için burayı tıklayın",
    disallowedFileType: "Bu dosya yüklenemiyor, onaylanmış bir dosya türüne sahip değil",
    maxFileSize: "Maksimum dosya boyutu",
    mediaRoot: "Medya kökü",
    createFolderFailed: "%0% üst kimliği altında klasör oluşturulamadı",
    renameFolderFailed: "%0% kimliğine sahip klasör yeniden adlandırılamadı",
    dragAndDropYourFilesIntoTheArea: "Dosyalarınızı alana sürükleyip bırakın"
  },
  member: {
    createNewMember: "Yeni üye oluştur",
    allMembers: "Tüm Üyeler",
    memberGroupNoProperties: "Üye gruplarının düzenlenecek ek özellikleri yoktur."
  },
  create: {
    chooseNode: "Yeni %0% 'i nerede oluşturmak istiyorsunuz",
    createUnder: "Şu dizin altında bir öğe oluşturun: ",
    createContentBlueprint: "İçerik şablonu yapmak istediğiniz belge türünü seçin",
    enterFolderName: "Bir klasör adı girin",
    updateData: "Bir tür ve başlık seçin",
    noDocumentTypes: "Burada içerik oluşturmak için izin verilen doküman türü yok. Bunları, <strong>İzinler</strong> altında <strong>İzin verilen alt düğüm türlerini</strong> düzenleyerek <strong>Ayarlar</strong> bölümündeki <strong>Belge Türleri</strong> 'nde etkinleştirmelisiniz.",
    noDocumentTypesAtRoot: "Burada içerik oluşturmak için uygun bir belge türü yok. Öncelikle belge türlerini <strong>Ayarlar</strong> bölümündeki <strong>Belge Türleri</strong> 'nde oluşturmanız gerekiyor.",
    noDocumentTypesWithNoSettingsAccess: "İçerik ağacında seçilen sayfa, altında herhangi bir sayfanın oluşturulmasına izin vermiyor.",
    noDocumentTypesEditPermissions: "Şu belge türü için izinleri düzenleyin",
    noDocumentTypesCreateNew: "Yeni bir belge türü oluşturun",
    noDocumentTypesAllowedAtRoot: "Burada içerik oluşturmak için izin verilen belge türü yok. Bunları, <strong>İzinler</strong> altında <strong>Kök olarak izin ver</strong> seçeneğini değiştirerek, <strong>Ayarlar</strong> bölümündeki <strong>Belge Türleri</strong> 'nde etkinleştirmeniz gerekir. ",
    noMediaTypes: "Burada medya oluşturmak için izin verilen medya türü yok. Bunları, <strong>İzinler</strong> altında <strong>İzin verilen alt düğüm türlerini</strong> düzenleyerek <strong>Ayarlar</strong> bölümündeki <strong>Medya Türleri</strong> 'nde etkinleştirmelisiniz. .",
    noMediaTypesWithNoSettingsAccess: "Ağaçtaki seçili ortam, altında başka bir ortamın oluşturulmasına izin vermiyor.",
    noMediaTypesEditPermissions: "Şu medya türü için izinleri düzenleyin:",
    documentTypeWithoutTemplate: "Şablonsuz Belge Türü",
    newFolder: "Yeni klasör",
    newDataType: "Yeni veri türü",
    newJavascriptFile: "Yeni JavaScript dosyası",
    newEmptyPartialView: "Yeni boş kısmi görünüm",
    newPartialViewMacro: "Yeni kısmi görünüm makrosu",
    newPartialViewFromSnippet: "Ön bilgiden yeni kısmi görünüm",
    newPartialViewMacroFromSnippet: "Snippet'ten yeni kısmi görünüm makrosu",
    newPartialViewMacroNoMacro: "Yeni kısmi görünüm makrosu (makrosuz)",
    newStyleSheetFile: "Yeni stil sayfası dosyası",
    newRteStyleSheetFile: "Yeni Zengin Metin Düzenleyicisi stil sayfası dosyası"
  },
  dashboard: {
    browser: "Web sitenize göz atın",
    dontShowAgain: "- Gizle",
    nothinghappens: "Umbraco açılmıyorsa, bu siteden pop-up'lara izin vermeniz gerekebilir",
    openinnew: "yeni bir pencerede açıldı",
    restart: "Yeniden Başlat",
    visit: "Ziyaret edin",
    welcome: "Hoş geldiniz"
  },
  prompt: {
    stay: "Kal",
    discardChanges: "Değişiklikleri sil",
    unsavedChanges: "Kaydedilmemiş değişiklikleriniz var",
    unsavedChangesWarning: "Bu sayfadan ayrılmak istediğinizden emin misiniz? - Kaydedilmemiş değişiklikleriniz var",
    confirmListViewPublish: "Yayınlama, seçili öğelerin sitede görünür olmasını sağlar.",
    confirmListViewUnpublish: "Yayından kaldırma, seçili öğeler ile birlikte bu öğelerin tüm alt öğelerini de siteden kaldırır.",
    confirmUnpublish: "Yayından kaldırma, bu seçili öğe ile birlikte onun tüm alt öğelerini de siteden kaldırır.",
    doctypeChangeWarning: "Kaydedilmemiş değişiklikleriniz var. Belge Türü'nde değişiklik yapmak bu kaydedilmemiş değişikliklerinizi geçersiz kılacaktır."
  },
  bulk: {
    done: "Bitti",
    deletedItem: "%0% öğe silindi",
    deletedItems: "%0% öğe silindi",
    deletedItemOfItem: "%1% öğeden %0% silindi",
    deletedItemOfItems: "%1% öğeden %0% silindi",
    publishedItem: "%0% öğe yayınlandı",
    publishedItems: "%0% öğe yayınlandı",
    publishedItemOfItem: "%1% öğeden %0% yayınlandı",
    publishedItemOfItems: "%1% öğeden %0% yayınlandı",
    unpublishedItem: "Yayınlanmamış %0% öğe",
    unpublishedItems: "Yayınlanmamış %0% öğe",
    unpublishedItemOfItem: "Yayınlanmamış%1% öğeden %0%",
    unpublishedItemOfItems: "Yayınlanmamış%1% öğeden %0%",
    movedItem: "%0% öğe taşındı",
    movedItems: "%0% öğe taşındı",
    movedItemOfItem: "%0%,%1% öğeden taşındı",
    movedItemOfItems: "%1% öğeden %0% oranında taşındı",
    copiedItem: "%0% öğe kopyalandı",
    copiedItems: "%0% öğe kopyalandı",
    copiedItemOfItem: "%1% öğeden %0% kopyalandı",
    copiedItemOfItems: "%1% öğeden %0% kopyalandı"
  },
  defaultdialogs: {
    nodeNameLinkPicker: "Bağlantı başlığı",
    urlLinkPicker: "Bağlantı",
    anchorLinkPicker: "Bağlayıcı / sorgu dizesi",
    anchorInsert: "Ad",
    assignDomain: "Ana bilgisayar adlarını yönet",
    closeThisWindow: "Bu pencereyi kapat",
    confirmdelete: "Silmek istediğinizden emin misiniz",
    confirmdisable: "Devre dışı bırakmak istediğinizden emin misiniz",
    confirmremove: "Kaldırmak istediğinizden emin misiniz",
    confirmremoveusageof: "<strong>%0%</strong> kullanımını kaldırmak istediğinizden emin misiniz?",
    confirmlogout: "Emin misiniz?",
    confirmSure: "Emin misiniz?",
    cut: "Kes",
    editDictionary: "Sözlük Öğesini Düzenle",
    editLanguage: "Dili Düzenle",
    editSelectedMedia: "Seçili medyayı düzenle",
    insertAnchor: "Yerel bağlantı ekle",
    insertCharacter: "Karakter ekle",
    insertgraphicheadline: "Grafik başlığı ekle",
    insertimage: "Resim ekle",
    insertlink: "Link ekle",
    insertMacro: "Makro eklemek için tıklayın",
    inserttable: "Tablo ekle",
    languagedeletewarning: "Bu, dili silecek",
    languageChangeWarning: "Bir dil için kültürü değiştirmek pahalı bir işlem olabilir ve içerik önbelleğinin ve dizinlerin yeniden oluşturulmasına neden olabilir",
    lastEdited: "Son Düzenleme",
    link: "Bağlantı",
    linkinternal: "Dahili bağlantı",
    linklocaltip: 'Yerel bağlantıları kullanırken, bağlantının önüne "#" ekleyin',
    linknewwindow: "Yeni pencerede açılsın mı?",
    macroDoesNotHaveProperties: "Bu makro düzenleyebileceğiniz herhangi bir özellik içermiyor",
    paste: "Yapıştır",
    permissionsEdit: "için izinleri düzenle",
    permissionsSet: "için izinleri ayarlayın",
    permissionsSetForGroup: "%1% kullanıcı grubu için %0% için izinleri ayarla",
    permissionsHelp: "İzinlerini ayarlamak istediğiniz kullanıcı gruplarını seçin",
    recycleBinDeleting: "Geri dönüşüm kutusundaki öğeler artık siliniyor. Lütfen bu işlem yapılırken bu pencereyi kapatmayın",
    recycleBinIsEmpty: "Geri dönüşüm kutusu artık boş",
    recycleBinWarning: "Öğeler geri dönüşüm kutusundan silindiğinde bir daha geri gelmeyecek şekilde ortadan kaybolacaklar",
    regexSearchError: "<a target='_ blank' href='http: //regexlib.com'> regexlib.com </a> 'un web hizmeti şu anda bazı sorunlar yaşıyor ve biz üzerinde kontrol yok. Bu rahatsızlıktan dolayı çok üzgünüz.",
    regexSearchHelp: "Bir form alanına doğrulama eklemek için normal ifade arayın. Örnek: 'e-posta,'posta kodu','URL'",
    removeMacro: "Makroyu Kaldır",
    requiredField: "Gerekli Alan",
    sitereindexed: "Site yeniden dizine eklendi",
    siterepublished: "Web sitesi önbelleği yenilendi. Tüm yayın içeriği artık güncel. Yayınlanmamış içeriğin tamamı hâlâ yayınlanmamış olsa da",
    siterepublishHelp: "Web sitesi önbelleği yenilenecek. Yayınlanan tüm içerik güncellenecek, yayınlanmamış içerik ise yayınlanmayacak.",
    tableColumns: "Sütun sayısı",
    tableRows: "Satır sayısı",
    thumbnailimageclickfororiginal: "Tam boyutta görmek için resmi tıklayın",
    treepicker: "Öğe seçin",
    viewCacheItem: "Önbellek Öğesini Görüntüle",
    relateToOriginalLabel: "Orijinalle ilişkilendir",
    includeDescendants: "Torunları dahil et",
    theFriendliestCommunity: "En arkadaş canlısı topluluk",
    linkToPage: "Sayfaya bağla",
    openInNewWindow: "Bağlı belgeyi yeni bir pencerede veya sekmede açar",
    linkToMedia: "Medyaya bağlantı",
    selectContentStartNode: "İçerik başlangıç ​​düğümünü seçin",
    selectMedia: "Medya seçin",
    selectMediaType: "Ortam türünü seçin",
    selectIcon: "Simge seçin",
    selectItem: "Öğeyi seçin",
    selectLink: "Bağlantı seçin",
    selectMacro: "Makro seçin",
    selectContent: "İçerik seçin",
    selectContentType: "İçerik türünü seçin",
    selectMediaStartNode: "Medya başlangıç ​​düğümünü seçin",
    selectMember: "Üye seç",
    selectMemberGroup: "Üye grubu seçin",
    selectMemberType: "Üye türünü seçin",
    selectNode: "Düğüm seçin",
    selectSections: "Bölümleri seçin",
    selectUser: "Kullanıcı seçin",
    selectUsers: "Kullanıcıları seçin",
    noIconsFound: "​​Simge bulunamadı",
    noMacroParams: "Bu makro için parametre yok",
    noMacros: "Eklenecek makro yok",
    externalLoginProviders: "Harici giriş sağlayıcıları",
    exceptionDetail: "İstisna Ayrıntıları",
    stacktrace: "Yığın İzleme",
    innerException: "İç İstisna",
    linkYour: "Bağlayın",
    unLinkYour: "Bağlantınızı kaldırın",
    account: "hesap",
    selectEditor: "Düzenleyici seçin",
    selectSnippet: "Snippet seçin",
    variantdeletewarning: "Bu, düğümü ve tüm dillerini silecektir. Yalnızca bir dili silmek istiyorsanız, bunun yerine düğümü o dilde yayından kaldırmalısınız.",
    propertyuserpickerremovewarning: "Bu, <strong>%0%</strong> kullanıcısını kaldıracaktır.",
    userremovewarning: "Bu, <strong>%0% </strong> kullanıcısını <strong>%1%</strong> grubundan kaldıracak",
    yesRemove: "Evet, kaldır"
  },
  dictionary: {
    noItems: "Sözlük öğesi yok."
  },
  dictionaryItem: {
    description: "Aşağıdaki sözlük öğesi '%0%' için farklı dil sürümlerini düzenleyin",
    displayName: "Kültür Adı",
    changeKeyError: "'%0%' anahtarı zaten var.",
    overviewTitle: "Sözlüğe genel bakış"
  },
  examineManagement: {
    configuredSearchers: "Yapılandırılmış Arayıcılar",
    configuredSearchersDescription: "Yapılandırılmış herhangi bir Searcher için özellikleri ve araçları gösterir (yani, çoklu dizin arayıcı gibi)",
    fieldValues: "Alan değerleri",
    healthStatus: "Sağlık durumu",
    healthStatusDescription: "Dizinin sağlık durumu ve okunabiliyorsa",
    indexers: "Dizin oluşturucular",
    indexInfo: "Dizin bilgisi",
    indexInfoDescription: "Dizinin özelliklerini listeler",
    manageIndexes: "İnceleme dizinlerini yönetin",
    manageIndexesDescription: "Her dizinin ayrıntılarını görüntülemenizi sağlar ve dizinleri yönetmek için bazı araçlar sağlar",
    rebuildIndex: "Dizini yeniden oluştur",
    rebuildIndexWarning: `
      Bu, dizinin yeniden oluşturulmasına neden olacaktır. <br />
      Sitenizde ne kadar içerik olduğuna bağlı olarak bu biraz zaman alabilir. <br />
      Yüksek web sitesi trafiğinin olduğu zamanlarda veya editörler içeriği düzenlerken bir dizinin yeniden oluşturulması önerilmez.
     `,
    searchers: "Arayanlar",
    searchDescription: "Dizini arayın ve sonuçları görüntüleyin",
    tools: "Araçlar",
    toolsDescription: "Dizini yönetmek için araçlar",
    fields: "alanlar",
    indexCannotRead: "Dizin okunamıyor ve yeniden oluşturulması gerekecek",
    processIsTakingLonger: "İşlem beklenenden uzun sürüyor, bu işlem sırasında herhangi bir hata olup olmadığını görmek için Umbraco günlüğünü kontrol edin",
    indexCannotRebuild: "Bu dizin, atanmış olmadığı için yeniden oluşturulamaz",
    iIndexPopulator: "IIndexPopulator"
  },
  placeholders: {
    username: "Kullanıcı adınızı girin",
    password: "Şifrenizi girin",
    confirmPassword: "Şifrenizi onaylayın",
    nameentity: "%0% olarak adlandırın ...",
    entername: "Bir ad girin ...",
    enteremail: "Bir e-posta girin ...",
    enterusername: "Bir kullanıcı adı girin ...",
    label: "Etiket ...",
    enterDescription: "Bir açıklama girin ...",
    search: "Aramak için yazın ...",
    filter: "Filtrelemek için yazın ...",
    enterTags: "Etiket eklemek için yazın (her etiketten sonra enter tuşuna basın) ...",
    email: "E-postanızı girin",
    enterMessage: "Bir mesaj girin ...",
    usernameHint: "Kullanıcı adınız genellikle e-postanızdır",
    anchor: "# değer veya? anahtar=değer",
    enterAlias: "Takma ad girin ...",
    generatingAlias: "Takma ad oluşturuluyor ...",
    a11yCreateItem: "Öğe oluştur",
    a11yCreate: "Oluştur",
    a11yEdit: "Düzenle",
    a11yName: "Ad"
  },
  editcontenttype: {
    createListView: "Özel liste görünümü oluştur",
    removeListView: "Özel liste görünümünü kaldır",
    aliasAlreadyExists: "Bu takma ada sahip bir içerik türü, medya türü veya üye türü zaten var"
  },
  renamecontainer: {
    renamed: "Yeniden adlandırıldı",
    enterNewFolderName: "Buraya yeni bir klasör adı girin",
    folderWasRenamed: "%0%,%1% olarak yeniden adlandırıldı"
  },
  editdatatype: {
    addPrevalue: "Ön değer ekle",
    dataBaseDatatype: "Veritabanı veri türü",
    guid: "Özellik düzenleyici GUID",
    renderControl: "Mülk düzenleyici",
    rteButtons: "Düğmeler",
    rteEnableAdvancedSettings: "için gelişmiş ayarları etkinleştir",
    rteEnableContextMenu: "Bağlam menüsünü etkinleştir",
    rteMaximumDefaultImgSize: "Eklenen resimlerin maksimum varsayılan boyutu",
    rteRelatedStylesheets: "İlgili stil sayfaları",
    rteShowLabel: "Etiketi göster",
    rteWidthAndHeight: "Genişlik ve yükseklik",
    selectFolder: "Taşınacak klasörü seçin",
    inTheTree: "aşağıdaki ağaç yapısına",
    wasMoved: "altına taşındı"
  },
  errorHandling: {
    errorButDataWasSaved: "Verileriniz kaydedildi, ancak bu sayfayı yayınlamadan önce düzeltmeniz gereken bazı hatalar var:",
    errorChangingProviderPassword: "Mevcut üyelik sağlayıcısı, şifre değiştirmeyi desteklemiyor (EnablePasswordRetrieval'in doğru olması gerekiyor)",
    errorExistsWithoutTab: "%0% zaten var",
    errorHeader: "Hatalar vardı:",
    errorHeaderWithoutTab: "Hatalar vardı:",
    errorInPasswordFormat: "Parola minimum %0% karakter uzunluğunda olmalı ve en az%1% alfa olmayan sayısal karakter (ler) içermelidir",
    errorIntegerWithoutTab: "%0% tam sayı olmalıdır",
    errorMandatory: "%1% sekmesindeki %0% alanı zorunludur",
    errorMandatoryWithoutTab: "%0% zorunlu bir alandır",
    errorRegExp: "%1% konumunda %0% doğru biçimde değil",
    errorRegExpWithoutTab: "%0% doğru biçimde değil"
  },
  errors: {
    receivedErrorFromServer: "Sunucudan bir hata aldı",
    dissallowedMediaType: "Belirtilen dosya türüne yönetici tarafından izin verilmedi",
    codemirroriewarning: "NOT! CodeMirror yapılandırma ile etkinleştirilmiş olsa da, yeterince kararlı olmadığı için Internet Explorer'da devre dışı bırakılmıştır.",
    contentTypeAliasAndNameNotNull: "Lütfen yeni özellik türünde hem takma adı hem de adı girin!",
    filePermissionsError: "Belirli bir dosya veya klasöre okuma/yazma erişiminde sorun var",
    macroErrorLoadingPartialView: "Kısmi Görünüm komut dosyası yüklenirken hata oluştu (dosya: %0%)",
    missingTitle: "Lütfen bir başlık girin",
    missingType: "Lütfen bir tür seçin",
    pictureResizeBiggerThanOrg: "Resmi orijinal boyutundan daha büyük yapmak üzeresiniz. Devam etmek istediğinizden emin misiniz?",
    startNodeDoesNotExists: "Başlangıç ​​düğümü silindi, lütfen yöneticinizle iletişime geçin",
    stylesMustMarkBeforeSelect: "Lütfen stili değiştirmeden önce içeriği işaretleyin",
    stylesNoStylesOnPage: "Etkin stil yok",
    tableColMergeLeft: "Lütfen imleci birleştirmek istediğiniz iki hücrenin soluna yerleştirin",
    tableSplitNotSplittable: "Birleştirilmemiş bir hücreyi bölemezsiniz.",
    propertyHasErrors: "Bu özellik geçersiz"
  },
  general: {
    options: "Seçenekler",
    about: "Hakkında",
    action: "İşlem",
    actions: "İşlemler",
    add: "Ekle",
    alias: "Takma isim",
    all: "Tümü",
    areyousure: "Emin misiniz?",
    back: "Geri",
    backToOverview: "Gözden geçirmeye geri dön",
    border: "Kenarlık",
    cancel: "İptal",
    cellMargin: "Hücre kenar boşluğu",
    choose: "Seçin",
    clear: "Temizle",
    close: "Kapat",
    closewindow: "Pencereyi Kapat",
    closepane: "Pencereyi Kapat",
    comment: "Yorum",
    confirm: "Doğrula",
    constrain: "Sınırla",
    constrainProportions: "Oranları sınırlayın",
    content: "İçerik",
    continue: "Devam et",
    copy: "Kopyala",
    create: "Oluştur",
    cropSection: "Bölümü kırp",
    database: "Veritabanı",
    date: "Tarih",
    default: "Varsayılan",
    delete: "Sil",
    deleted: "Silindi",
    deleting: "Siliniyor ...",
    design: "Tasarım",
    dictionary: "Sözlük",
    dimensions: "Boyutlar",
    discard: "Gözden çıkar",
    down: "Aşağı",
    download: "İndir",
    edit: "Düzenle",
    edited: "Düzenlendi",
    elements: "Öğeler",
    email: "E-posta",
    error: "Hata",
    field: "Alan",
    findDocument: "Bul",
    first: "İlk",
    focalPoint: "Odak noktası",
    general: "Genel",
    generic: "Genel",
    groups: "Gruplar",
    group: "Grup",
    height: "Yükseklik",
    help: "Yardım",
    hide: "Gizle",
    history: "Geçmiş",
    icon: "Simge",
    id: "Belirleyici Numara",
    import: "İçe Aktar",
    excludeFromSubFolders: "Yalnızca bu klasörü ara",
    info: "Bilgi",
    innerMargin: "İç kenar boşluğu",
    insert: "Ekle",
    install: "Yükle",
    invalid: "Geçersiz",
    justify: "Yasla",
    label: "Etiket",
    language: "Dil",
    last: "Son",
    layout: "Düzen",
    links: "Bağlantılar",
    loading: "Yükleniyor",
    locked: "Kilitli",
    login: "Giriş",
    logoff: "Oturumu kapat",
    logout: "Çıkış",
    macro: "Makro",
    mandatory: "Zorunlu",
    message: "Mesaj",
    move: "Taşı",
    name: "Ad",
    new: "Yeni",
    next: "Sonraki",
    no: "Hayır",
    of: "arasında",
    off: "Kapalı",
    ok: "Tamam",
    open: "Aç",
    on: "Açık",
    or: "veya",
    orderBy: "Sıralama ölçütü",
    password: "Şifre",
    path: "Yol",
    pleasewait: "Bir dakika lütfen ...",
    previous: "Önceki",
    properties: "Özellikler",
    rebuild: "Yeniden Oluştur",
    reciept: "Form verilerini almak için e-posta",
    recycleBin: "Geri Dönüşüm Kutusu",
    recycleBinEmpty: "Geri dönüşüm kutunuz boş",
    reload: "Yeniden yükle",
    remaining: "Kalan",
    remove: "Kaldır",
    rename: "Yeniden adlandır",
    renew: "Yenile",
    required: "Gerekli",
    retrieve: "Al",
    retry: "Yeniden dene",
    rights: "daha",
    scheduledPublishing: "Planlanmış Yayınlama",
    search: "Ara",
    searchNoResult: "Üzgünüz, aradığınızı bulamıyoruz.",
    noItemsInList: "Hiçbir öğe eklenmedi",
    server: "Sunucu",
    settings: "Ayarlar",
    show: "Göster",
    showPageOnSend: "Sayfayı Gönderildiğinde Göster",
    size: "Boyut",
    sort: "Sırala",
    status: "Durum",
    submit: "Gönder",
    success: "Başarılı",
    type: "Tür",
    typeToSearch: "Aramak için yazın ...",
    under: "altında",
    up: "Yukarı",
    update: "Güncelle",
    upgrade: "Yükselt",
    upload: "Yükle",
    url: "URL",
    user: "Kullanıcı",
    username: "Kullanıcı adı",
    value: "Değer",
    view: "Görüntüle",
    welcome: "Hoş geldiniz ...",
    width: "Genişlik",
    yes: "Evet",
    folder: "Klasör",
    searchResults: "Arama sonuçları",
    reorder: "Yeniden sırala",
    reorderDone: "Yeniden sıralamayı tamamladım",
    preview: "Önizleme",
    changePassword: "Şifreyi değiştir",
    to: "için",
    listView: "Liste görünümü",
    saving: "Kaydediliyor ...",
    current: "mevcut",
    embed: "Göm",
    selected: "seçildi",
    other: "Diğer",
    articles: "Makaleler",
    videos: "Videolar"
  },
  colors: {
    blue: "Mavi"
  },
  shortcuts: {
    addGroup: "Grup ekle",
    addProperty: "Mülk ekle",
    addEditor: "Düzenleyici ekle",
    addTemplate: "Şablon ekle",
    addChildNode: "Alt düğüm ekle",
    addChild: "Çocuk ekle",
    editDataType: "Veri türünü düzenle",
    navigateSections: "Bölümlere git",
    shortcut: "Kısayollar",
    showShortcuts: "kısayolları göster",
    toggleListView: "Liste görünümünü değiştir",
    toggleAllowAsRoot: "Kök olarak izin ver arasında geçiş yap",
    commentLine: "Yorum / Yorum kaldırma satırları",
    removeLine: "Satırı kaldır",
    copyLineUp: "Satırları Yukarı Kopyala",
    copyLineDown: "Satırları Aşağı Kopyala",
    moveLineUp: "Satırları Yukarı Taşı",
    moveLineDown: "Satırları Aşağı Taşı",
    generalHeader: "Genel",
    editorHeader: "Düzenleyici",
    toggleAllowCultureVariants: "Kültür varyantlarına izin ver "
  },
  graphicheadline: {
    backgroundcolor: "Arka plan rengi",
    bold: "Kalın",
    color: "Metin rengi",
    font: "Yazı Tipi",
    text: "Metin"
  },
  headers: {
    page: "Sayfa"
  },
  installer: {
    databaseErrorCannotConnect: "Yükleyici veritabanına bağlanamıyor.",
    databaseFound: "​​Veritabanınız bulundu ve tanımlandı",
    databaseHeader: "Veritabanı yapılandırması",
    databaseInstall: `
      Umbraco %0% veritabanını yüklemek için <strong>kur</strong> düğmesine basın
    `,
    databaseInstallDone: "Umbraco %0% artık veritabanınıza kopyalandı. Devam etmek için <strong>İleri</strong>'ye basın.",
    databaseText: `Bu adımı tamamlamak için, veritabanı sunucunuzla ilgili bazı bilgileri bilmeniz gerekir ("bağlantı dizesi"). <br />
        Lütfen gerekirse ISS'niz ile iletişime geçin.
        Yerel bir makineye veya sunucuya kurulum yapıyorsanız, sistem yöneticinizden bilgi almanız gerekebilir.`,
    databaseUpgrade: `
      <p>
      Veritabanınızı Umbraco %0% sürümüne yükseltmek için <strong> yükselt </strong> düğmesine basın </p>
      <p>
      Endişelenmeyin - hiçbir içerik silinmeyecek ve daha sonra her şey çalışmaya devam edecek!
      </p>
      `,
    databaseUpgradeDone: `Veritabanınız son sürüme %0% yükseltildi. <br /> için <strong> İleri </strong> 'ye basın
      ilerlemek. `,
    databaseUpToDate: "Mevcut veritabanınız güncel !. Yapılandırma sihirbazına devam etmek için <strong> ileri </strong> 'yi tıklayın",
    defaultUserChangePass: "<strong> Varsayılan kullanıcıların şifresinin değiştirilmesi gerekiyor! </strong>",
    defaultUserDisabled: "<strong> Varsayılan kullanıcı devre dışı bırakıldı veya Umbraco'ya erişimi yok! </strong> </p> <p> Başka işlem yapılmasına gerek yok. Devam etmek için <strong> İleri </strong> 'yi tıklayın.",
    defaultUserPassChanged: "<strong> Varsayılan kullanıcının şifresi kurulumdan bu yana başarıyla değiştirildi! </strong> </p> <p> Başka işlem yapılmasına gerek yok. Devam etmek için <strong> İleri </strong> 'yi tıklayın.",
    defaultUserPasswordChanged: "Şifre değiştirildi!",
    greatStart: "Harika bir başlangıç ​​yapın, tanıtım videolarımızı izleyin",
    None: "Henüz yüklenmedi.",
    permissionsAffectedFolders: "Etkilenen dosyalar ve klasörler",
    permissionsAffectedFoldersMoreInfo: "Umbraco için izinlerin ayarlanmasıyla ilgili daha fazla bilgiyi burada bulabilirsiniz",
    permissionsAffectedFoldersText: "Aşağıdaki dosyalara / klasörlere ASP.NET değiştirme izinleri vermeniz gerekiyor",
    permissionsAlmostPerfect: `<strong> İzin ayarlarınız neredeyse mükemmel! </strong> <br /> <br />
        Umbraco'yu sorunsuz bir şekilde çalıştırabilirsiniz, ancak Umbraco'dan tam olarak yararlanmanız için önerilen paketleri kuramazsınız.`,
    permissionsHowtoResolve: "Nasıl Çözümlenir",
    permissionsHowtoResolveLink: "Metin sürümünü okumak için burayı tıklayın",
    permissionsHowtoResolveText: "Umbraco için klasör izinlerinin ayarlanmasıyla ilgili <strong> eğitim videosunu </strong> izleyin veya metin sürümünü okuyun.",
    permissionsMaybeAnIssue: `<strong> İzin ayarlarınız bir sorun olabilir! </strong>
      <br/> <br />
      Umbraco'yu sorunsuz bir şekilde çalıştırabilirsiniz, ancak Umbraco'dan tam olarak yararlanmanız için önerilen klasörler oluşturamaz veya paketleri yükleyemezsiniz.`,
    permissionsNotReady: `<strong> İzin ayarlarınız Umbraco için hazır değil! </strong>
          <br /> <br />
          Umbraco'yu çalıştırmak için izin ayarlarınızı güncellemeniz gerekir.`,
    permissionsPerfect: `<strong> İzin ayarlarınız mükemmel! </strong> <br /> <br />
              Umbraco'yu çalıştırmaya ve paketleri kurmaya hazırsınız!`,
    permissionsResolveFolderIssues: "Klasör sorununu çözme",
    permissionsResolveFolderIssuesLink: "ASP.NET ile ilgili sorunlar ve klasör oluşturma hakkında daha fazla bilgi için bu bağlantıyı takip edin",
    permissionsSettingUpPermissions: "Klasör izinlerini ayarlama",
    permissionsText: `
      Resimler ve PDF'ler gibi dosyaları depolamak için Umbraco'nun belirli dizinlere yazma / değiştirme erişimine ihtiyacı vardır.
      Ayrıca, web sitenizin performansını artırmak için geçici verileri önbellekte tutar.
    `,
    runwayFromScratch: "Sıfırdan başlamak istiyorum",
    runwayFromScratchText: `
        Web siteniz şu anda tamamen boş, bu nedenle sıfırdan başlamak ve kendi belge türlerinizi ve şablonlarınızı oluşturmak istiyorsanız bu mükemmel.
        (<a href="https://umbraco.tv/documentation/videos/for-site-builders/foundation/document-types">nasıl yapılacağını öğrenin </a>)
        Yine de Runway'i daha sonra kurmayı seçebilirsiniz. Lütfen Geliştirici bölümüne gidin ve Paketleri seçin.
      `,
    runwayHeader: "Temiz bir Umbraco platformu kurdunuz. Bundan sonra ne yapmak istiyorsunuz?",
    runwayInstalled: "Runway yüklendi",
    runwayInstalledText: `
      Temeliniz yerinde. Üzerine yüklemek istediğiniz modülleri seçin. <br />
      Bu, önerilen modüller listemizdir, yüklemek istediklerinizi işaretleyin veya <a href="#" onclick="toggleModules (); return false;" id="toggleModuleList">modüllerin tam listesi </a>
      `,
    runwayOnlyProUsers: "Yalnızca deneyimli kullanıcılar için önerilir",
    runwaySimpleSite: "Basit bir web sitesiyle başlamak istiyorum",
    runwaySimpleSiteText: `
      <p>
      "Runway", bazı temel belge türlerini ve şablonlarını sunan basit bir web sitesidir. Yükleyici sizin için otomatik olarak Runway kurabilir,
        ancak kolayca düzenleyebilir, genişletebilir veya kaldırabilirsiniz. Bu gerekli değildir ve Umbraco'yu onsuz mükemmel bir şekilde kullanabilirsiniz. Ancak,
        Runway, her zamankinden daha hızlı başlamanız için en iyi uygulamalara dayalı kolay bir temel sunar.
        Runway'i kurmayı seçerseniz, Runway sayfalarınızı geliştirmek için isteğe bağlı olarak Pist Modülleri adı verilen temel yapı bloklarını seçebilirsiniz.
        </p>
        <small>
        <em> Runway'e Dahildir: </em> Ana sayfa, Başlarken sayfası, Modülleri Takma sayfası. <br />
        <em> İsteğe Bağlı Modüller: </em> Üst Gezinme, Site Haritası, İletişim, Galeri.
        </small>
      `,
    runwayWhatIsRunway: "Runway Nedir",
    step1: "Adım 1/5 Lisansın kabulü",
    step2: "Adım 2/5: Veritabanı yapılandırması",
    step3: "Adım 3/5: Dosya izinlerini doğrulama",
    step4: "Adım 4/5: Umbraco güvenliğinin kontrolü",
    step5: "Adım 5/5: Umbraco, üzerinde çalışmaya başlamanız için hazır",
    thankYou: "Umbraco'yu seçtiğiniz için teşekkürler",
    theEndBrowseSite: `<h3> Yeni sitenize göz atın </h3>
Runway'i kurdunuz, öyleyse neden yeni web sitenizin nasıl göründüğüne bakmıyorsunuz.`,
    theEndFurtherHelp: `<h3> Daha fazla yardım ve bilgi </h3>
Ödüllü topluluğumuzdan yardım alın, belgelere göz atın veya basit bir sitenin nasıl oluşturulacağı, paketlerin nasıl kullanılacağı ve Umbraco terminolojisine yönelik hızlı bir kılavuzla ilgili bazı ücretsiz videolar izleyin`,
    theEndHeader: "Umbraco %0% yüklendi ve kullanıma hazır",
    theEndInstallSuccess: `Aşağıdaki "Umbraco'yu Başlat" düğmesini tıklayarak <strong> anında başlayabilirsiniz </strong>. <br /> <strong> Umbraco'da yeniyseniz </strong>,
başlangıç ​​sayfalarımızda birçok kaynak bulabilirsiniz.`,
    theEndOpenUmbraco: `<h3> Umbraco’yu Başlat </h3>
Web sitenizi yönetmek için, Umbraco'nun arka ofisini açın ve içerik eklemeye başlayın, şablonları ve stil sayfalarını güncelleyin veya yeni işlevler ekleyin`,
    Unavailable: "Veritabanına bağlantı başarısız oldu.",
    Version3: "Umbraco Sürüm 3",
    Version4: "Umbraco Sürüm 4",
    watch: "İzle",
    welcomeIntro: `Bu sihirbaz, yeni bir yükleme veya sürüm 3.0'dan yükseltme için <strong> Umbraco %0% </strong> 'u yapılandırma sürecinde size yol gösterecektir.
                                <br /> <br />
                                Sihirbazı başlatmak için <strong> "ileri" </strong> seçeneğine basın.`
  },
  language: {
    cultureCode: "Kültür Kodu",
    displayName: "Kültür Adı"
  },
  lockout: {
    lockoutWillOccur: "Herhangi bir işlem yapmadınız ve sistemden çıkış otomatik olarak şu belirtilen süre içinde gerçekleşecek",
    renewSession: "Çalışmanızı kaydetmek için şimdi yenileyin"
  },
  login: {
    greeting0: "Hoş geldiniz",
    greeting1: "Hoş geldiniz",
    greeting2: "Hoş geldiniz",
    greeting3: "Hoş geldiniz",
    greeting4: "Hoş geldiniz",
    greeting5: "Hoş geldiniz",
    greeting6: "Hoş geldiniz",
    instruction: "Aşağıda oturum açın",
    signInWith: "ile oturum açın",
    timeout: "Oturum zaman aşımına uğradı",
    bottomText: '<p style="text-align: right;">&copy; 2015 - %0% <br /> <a href="https://umbraco.com" style="text-decoration: none" target="_blank" rel="noopener">Umbraco.com </a> </p>',
    forgottenPassword: "Şifrenizi mi unuttunuz?",
    forgottenPasswordInstruction: "Şifrenizi yenilemeniz için belirtilen adrese bir bağlantı bilgisi gönderilecektir",
    requestPasswordResetConfirmation: "Eğer kayıtlarımızla eşleşirse, şifre yenileme talimatlarını içeren bir e-posta belirtilen adrese gönderilecektir",
    showPassword: "Şifreyi göster",
    hidePassword: "Şifreyi gizle",
    returnToLogin: "Giriş formuna dön",
    setPasswordInstruction: "Lütfen yeni bir şifre girin",
    setPasswordConfirmation: "Şifreniz güncellendi",
    resetCodeExpired: "Tıkladığınız bağlantı geçersiz veya süresi dolmuş",
    resetPasswordEmailCopySubject: "Umbraco: Şifreyi Yenile",
    resetPasswordEmailCopyFormat: `
        <html>
			<head>
				<meta name='viewport' content='width=device-width'>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
			</head>
			<body class='' style='font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; color: #392F54; line-height: 22px; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background: #1d1333; margin: 0; padding: 0;' bgcolor='#1d1333'>
				<style type='text/css'> @media only screen and (max-width: 620px) {table[class=body] h1 {font-size: 28px !important; margin-bottom: 10px !important; } table[class=body] .wrapper {padding: 32px !important; } table[class=body] .article {padding: 32px !important; } table[class=body] .content {padding: 24px !important; } table[class=body] .container {padding: 0 !important; width: 100% !important; } table[class=body] .main {border-left-width: 0 !important; border-radius: 0 !important; border-right-width: 0 !important; } table[class=body] .btn table {width: 100% !important; } table[class=body] .btn a {width: 100% !important; } table[class=body] .img-responsive {height: auto !important; max-width: 100% !important; width: auto !important; } } .btn-primary table td:hover {background-color: #34495e !important; } .btn-primary a:hover {background-color: #34495e !important; border-color: #34495e !important; } .btn  a:visited {color:#FFFFFF;} </style>
				<table border="0" cellpadding="0" cellspacing="0" class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;" bgcolor="#1d1333">
					<tr>
						<td style="font-family: sans-serif; font-size: 14px; vertical-align: top; padding: 24px;" valign="top">
							<table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;">
								<tr>
									<td background="https://umbraco.com/umbraco/assets/img/application/logo.png" bgcolor="#1d1333" width="28" height="28" valign="top" style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
										<!--[if gte mso 9]> <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:30px;height:30px;"> <v:fill type="tile" src="https://umbraco.com/umbraco/assets/img/application/logo.png" color="#1d1333" /> <v:textbox inset="0,0,0,0"> <![endif]-->
										<div> </div>
										<!--[if gte mso 9]> </v:textbox> </v:rect> <![endif]-->
									</td>
									<td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top"></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;' bgcolor='#1d1333'>
					<tr>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
						<td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 560px; width: 560px; margin: 0 auto; padding: 10px;' valign='top'>
							<div class='content' style='box-sizing: border-box; display: block; max-width: 560px; margin: 0 auto; padding: 10px;'>
								<br>
								<table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; border-radius: 3px; background: #FFFFFF;' bgcolor='#FFFFFF'>
									<tr>
										<td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 50px;' valign='top'>
											<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
												<tr>
													<td style='line-height: 24px; font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'>
														<h1 style='color: #392F54; font-family: sans-serif; font-weight: bold; line-height: 1.4; font-size: 24px; text-align: left; text-transform: capitalize; margin: 0 0 30px;' align='left'>
															Şifre yenileme istendi
														</h1>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Umbraco arka ofisinde oturum açmak için kullanıcı adınız: <strong>%0%</strong>
														</p>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
																<tbody>
																	<tr>
																		<td style='font-family: sans-serif; font-size: 14px; vertical-align: top; border-radius: 5px; text-align: center; background: #35C786;' align='center' bgcolor='#35C786' valign='top'>
																			<a href='%1%' target='_blank' rel='noopener' style='color: #FFFFFF; text-decoration: none; -ms-word-break: break-all; word-break: break-all; border-radius: 5px; box-sizing: border-box; cursor: pointer; display: inline-block; font-size: 14px; font-weight: bold; text-transform: capitalize; background: #35C786; margin: 0; padding: 12px 30px; border: 1px solid #35c786;'>
																				Şifrenizi yenilemek için bu bağlantıyı tıklayın
																			</a>
																		</td>
																	</tr>
																</tbody>
															</table>
														</p>
														<p style='max-width: 400px; display: block; color: #392F54; font-family: sans-serif; font-size: 14px; line-height: 20px; font-weight: normal; margin: 15px 0;'>Bağlantıya tıklayamazsanız, bu URL'yi kopyalayıp tarayıcı pencerenize yapıştırın:</p>
															<table border='0' cellpadding='0' cellspacing='0'>
																<tr>
																	<td style='-ms-word-break: break-all; word-break: break-all; font-family: sans-serif; font-size: 11px; line-height:14px;'>
																		<font style="-ms-word-break: break-all; word-break: break-all; font-size: 11px; line-height:14px;">
																			<a style='-ms-word-break: break-all; word-break: break-all; color: #392F54; text-decoration: underline; font-size: 11px; line-height:15px;' href='%1%'>%1%</a>
																		</font>
																	</td>
																</tr>
															</table>
														</p>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
								<br><br><br>
							</div>
						</td>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
					</tr>
				</table>
			</body>
		</html>
  `,
    mfaSecurityCodeSubject: "Umbraco: Güvenlik Kodu",
    mfaSecurityCodeMessage: "Güvenlik kodunuz: %0%",
    "2faTitle": "Son adım",
    "2faText": "2-aşamalı kimlik doğrulamayı etkinleştirdiniz ve kimliğinizi doğrulamanız gerekmekte.",
    "2faMultipleText": "Lütfen bir tane 2-aşamalı kimlik doğrulama hizmet sağlayıcı seçin",
    "2faCodeInput": "Doğrulama kodu",
    "2faCodeInputHelp": "Lütfen doğrulama kodunu girin",
    "2faInvalidCode": "Geçersiz kod girildi"
  },
  main: {
    dashboard: "Gösterge Paneli",
    sections: "Bölümler",
    tree: "İçerik"
  },
  moveOrCopy: {
    choose: "Yukarıdaki sayfayı seçin ...",
    copyDone: "%0%,%1% konumuna kopyalandı",
    copyTo: "%0% belgesinin kopyalanacağı yeri aşağıdan seçin",
    moveDone: "%0%,%1% konumuna taşındı",
    moveTo: "%0% belgesinin taşınacağı yeri aşağıdan seçin",
    nodeSelected: ", yeni içeriğinizin kökü olarak seçildi, aşağıdaki 'tamam'ı tıklayın.",
    noNodeSelected: "Henüz düğüm seçilmedi, lütfen 'tamam'ı tıklamadan önce yukarıdaki listeden bir düğüm seçin",
    notAllowedByContentType: "Geçerli düğüme, türü nedeniyle, seçilen düğüm altında izin verilmiyor",
    notAllowedByPath: "Geçerli düğüm, alt sayfalarından birine taşınamaz",
    notAllowedAtRoot: "Geçerli düğüm kök düğüm seviyesinde bulunamaz",
    notValid: "1 veya daha fazla alt belge üzerinde yetersiz izniniz olduğundan işleme izin verilmiyor.",
    relateToOriginal: "Kopyalanan öğeleri asıl öğe ile ilişkilendir"
  },
  notifications: {
    editNotifications: "%0% için bildiriminizi seçin",
    notificationsSavedFor: "Bildirim ayarları bu belirtilen öğe için kaydedildi %0%",
    notifications: "Bildirimler"
  },
  packager: {
    actions: "İşlemler",
    created: "Oluşturuldu",
    createPackage: "Paket oluştur",
    chooseLocalPackageText: `
      Gözat düğmesine tıklayarak ve paketi bularak makinenizden Paketi seçin. <br/>
      Umbraco paketleri genellikle ".umb" veya ".zip" uzantısına sahiptir.
      `,
    deletewarning: "Bu, paketi silecek",
    includeAllChildNodes: "Tüm alt düğümleri dahil et",
    installed: "Yüklendi",
    installedPackages: "Yüklü paketler",
    noConfigurationView: "Bu pakette yapılandırma görünümü yok",
    noPackagesCreated: "Henüz paket oluşturulmadı",
    noPackages: "Kurulu paketiniz yok",
    noPackagesDescription: "Kurulu paketiniz yok. Makinenizden seçerek yerel bir paket kurun veya ekranınızın sağ üst kısmındaki <strong>'Paketler'</strong> simgesini kullanarak mevcut paketlere göz atın",
    packageContent: "Paket İçeriği",
    packageLicense: "Lisans",
    packageSearch: "Paket arayın",
    packageSearchResults: "Sonuçlar",
    packageNoResults: "için hiçbir şey bulamadık",
    packageNoResultsDescription: "Lütfen başka bir paket aramayı deneyin veya kategorilere göz atın",
    packagesPopular: "Popüler",
    packagesNew: "Yeni sürümler",
    packageHas: "vardır",
    packageKarmaPoints: "karma noktaları",
    packageInfo: "Bilgi",
    packageOwner: "Sahip",
    packageContrib: "Katkıda bulunanlar",
    packageCreated: "Oluşturuldu",
    packageCurrentVersion: "Mevcut sürüm",
    packageNetVersion: ". NET sürümü",
    packageDownloads: "İndirmeler",
    packageLikes: "Beğeniler",
    packageCompatibility: "Uyumluluk",
    packageCompatibilityDescription: "Bu paket, topluluk üyeleri tarafından bildirildiği üzere aşağıdaki Umbraco sürümleriyle uyumludur. % 100'ün altında rapor edilen sürümler için tam uyumluluk garanti edilemez",
    packageExternalSources: "Harici kaynaklar",
    packageAuthor: "Yazar",
    packageDocumentation: "Belgeler",
    packageMetaData: "Meta verilerini paketle",
    packageName: "Paket adı",
    packageNoItemsHeader: "Paket herhangi bir öğe içermiyor",
    packageNoItemsText: `Bu paket dosyası kaldırılacak hiçbir öğe içermiyor.<br /><br/>
      Aşağıdaki "Paketi kaldır"'ı tıklayarak bunu sistemden güvenle kaldırabilirsiniz.`,
    packageOptions: "Paket seçenekleri",
    packageReadme: "Paketi beni oku",
    packageRepository: "Paket deposu",
    packageUninstallConfirm: "Paketi kaldırmayı onayla",
    packageUninstalledHeader: "Paket kaldırıldı",
    packageUninstalledText: "Paket başarıyla kaldırıldı",
    packageUninstallHeader: "Paketi kaldır",
    packageUninstallText: `Şu anda aşağıda, kaldırmak istemediğiniz öğelerin seçimini kaldırabilirsiniz. "Kaldırmayı onayla" yı tıkladığınızda işaretlenen tüm öğeler kaldırılacaktır. <br />
      <span style="color: Red; font-weight: bold;">Uyarı:</span> kaldırdığınız öğelere bağlı olarak herhangi bir belge, ortam vb. çalışmayı durdurur ve sistem kararsızlığına neden olabilir,
      bu yüzden dikkatli bir şekilde kaldırın. Şüpheniz varsa, paket yazarıyla iletişime geçin.`,
    packageVersion: "Paket versiyonu"
  },
  paste: {
    doNothing: "Tam biçimlendirmeyle yapıştırın (Önerilmez)",
    errorMessage: "Yapıştırmaya çalıştığınız metin özel karakterler veya biçimlendirme içeriyor. Bunun nedeni Microsoft Word'den metin kopyalanması olabilir. Umbraco, özel karakterleri veya biçimlendirmeyi otomatik olarak kaldırabilir, böylece yapıştırılan içerik web için daha uygun olacaktır.",
    removeAll: "Hiçbir biçimlendirme olmadan ham metin olarak yapıştırın",
    removeSpecialFormattering: "Yapıştır, ancak biçimlendirmeyi kaldırın (Önerilir)"
  },
  publicAccess: {
    paGroups: "Grup tabanlı koruma",
    paGroupsHelp: "Belirli üye gruplarının tüm üyelerine erişim vermek istiyorsanız",
    paGroupsNoGroups: "Grup tabanlı kimlik doğrulamasını kullanmadan önce bir üye grubu oluşturmanız gerekir",
    paErrorPage: "Hata Sayfası",
    paErrorPageHelp: "Kişiler oturum açtığında ancak erişimi olmadığında kullanılır",
    paHowWould: "Sayfaya erişimi nasıl kısıtlayacağınızı seçin <strong>%0%</strong>",
    paIsProtected: "<strong>%0%</strong> artık korumalı",
    paIsRemoved: "Koruma, <strong>%0%</strong> sayfasından kaldırılmıştır.",
    paLoginPage: "Giriş Sayfası",
    paLoginPageHelp: "Giriş formunu içeren sayfayı seçin",
    paRemoveProtection: "Korumayı kaldır ...",
    paRemoveProtectionConfirm: "Korumayı <strong>%0%</strong> sayfasından kaldırmak istediğinizden emin misiniz?",
    paSelectPages: "Giriş formu ve hata mesajları içeren sayfaları seçin",
    paSelectGroups: "<strong>%0%</strong> sayfasına erişimi olan grupları seçin",
    paSelectMembers: "<strong>%0%</strong> sayfasına erişimi olan üyeleri seçin",
    paMembers: "Belirli üyelerin korunması",
    paMembersHelp: "Belirli üyelere erişim vermek istiyorsanız"
  },
  publish: {
    contentPublishedFailedAwaitingRelease: `
     %0%, öğenin yayınlanması planlandığından yayınlanamadı.
    `,
    contentPublishedFailedExpired: `
      Öğenin süresi dolduğu için %0% yayınlanamadı.
    `,
    contentPublishedFailedInvalid: `
     %0%, şu özellikler nedeniyle yayınlanamadı:%1% doğrulama kurallarını geçemedi.
    `,
    contentPublishedFailedByEvent: `
     %0% yayınlanamadı, 3. taraf eklenti işlemi iptal etti.
    `,
    contentPublishedFailedByParent: `
      Bir üst sayfa yayınlanmadığı için %0% yayınlanamaz.
    `,
    contentPublishedFailedByMissingName: " %0%, adı eksik olduğu için yayınlanamaz.",
    includeUnpublished: "Yayınlanmamış alt sayfaları dahil et",
    inProgress: "Yayınlanıyor - lütfen bekleyin ...",
    inProgressCounter: "%1% sayfadan %0% yayınlandı ...",
    nodePublish: "%0% yayınlandı",
    nodePublishAll: "%0% ve alt sayfalar yayınlandı",
    publishAll: "%0% ve tüm alt sayfalarını yayınlayın",
    publishHelp: `<strong>%0%</strong> yayınlamak ve böylece içeriğini herkese açık hale getirmek için <em>Yayınla</em>'yı tıklayın. <br/><br />
      Aşağıdaki <em>Yayınlanmamış alt sayfaları ekle</em> 'yi işaretleyerek bu sayfayı ve tüm alt sayfalarını yayınlayabilirsiniz.
      `
  },
  colorpicker: {
    noColors: "Onaylanmış herhangi bir renk yapılandırmadınız"
  },
  contentPicker: {
    allowedItemTypes: "Yalnızca şu türdeki öğeleri seçebilirsiniz: %0%",
    pickedTrashedItem: "Şu anda silinmiş veya geri dönüşüm kutusunda bulunan bir içerik öğesini seçtiniz",
    pickedTrashedItems: "Şu anda silinmiş veya geri dönüşüm kutusunda bulunan içerik öğelerini seçtiniz"
  },
  mediaPicker: {
    deletedItem: "Silinen öğe",
    pickedTrashedItem: "Şu anda silinmiş veya geri dönüşüm kutusunda bulunan bir medya öğesini seçtiniz",
    pickedTrashedItems: "Şu anda silinmiş veya geri dönüşüm kutusunda bulunan medya öğelerini seçtiniz",
    trashed: "Çöp kutusuna gönderildi"
  },
  relatedlinks: {
    enterExternal: "harici bağlantı girin",
    chooseInternal: "dahili sayfayı seç",
    caption: "Başlık",
    link: "Bağlantı",
    newWindow: "Yeni pencerede aç",
    captionPlaceholder: "ekran başlığını girin",
    externalLinkPlaceholder: "Bağlantıyı girin"
  },
  imagecropper: {
    reset: "Kırpmayı sıfırla",
    updateEditCrop: "Bitti",
    undoEditCrop: "Düzenlemeleri geri alın",
    customCrop: "Kullanıcı tanımlı"
  },
  rollback: {
    changes: "Değişiklikler",
    diffHelp: "Bu, mevcut sürüm ile seçili sürüm arasındaki farkları gösterir <br /> <del> Kırmızı </del> metin seçili sürümde gösterilmeyecektir. , <ins> yeşil eklendi demektir </ins>",
    documentRolledBack: "Belge geri alındı ​​",
    headline: "Mevcut sürümle karşılaştırmak için bir sürüm seçin",
    htmlHelp: "Bu, seçilen sürümü HTML olarak görüntüler, 2 sürüm arasındaki farkı aynı anda görmek isterseniz, fark görünümünü kullanın",
    rollbackTo: "Geri alın",
    selectVersion: "Sürüm seçin",
    view: "Görüntüle"
  },
  scripts: {
    editscript: "Komut dosyasını düzenle"
  },
  sections: {
    concierge: "Konsiyerj",
    content: "İçerik",
    courier: "Kurye",
    developer: "Geliştirici",
    forms: "Formlar",
    help: "Yardım",
    installer: "Umbraco Yapılandırma Sihirbazı",
    media: "Medya",
    member: "Üyeler",
    newsletters: "Bültenler",
    packages: "Paketler",
    settings: "Ayarlar",
    statistics: "İstatistikler",
    translation: "Çeviri",
    users: "Kullanıcılar"
  },
  help: {
    tours: "Turlar",
    theBestUmbracoVideoTutorials: "En iyi Umbraco video eğitimleri",
    umbracoForum: "our.umbraco.com adresini ziyaret edin",
    umbracoTv: "umbraco.tv'yi ziyaret edin"
  },
  settings: {
    defaulttemplate: "Varsayılan şablon",
    importDocumentTypeHelp: `
      Bir belge türünü içe aktarmak için, "Gözat" düğmesini tıklayarak bilgisayarınızda ".udt" dosyasını bulun ve "İçe Aktar" ı tıklayın (sonraki ekranda onay vermeniz istenir) `,
    newtabname: "Yeni Sekme Başlığı",
    nodetype: "Düğüm türü",
    objecttype: "Tür",
    stylesheet: "Stil Sayfası",
    script: "Komut Dosyası",
    tab: "Sekme",
    tabname: "Sekme Başlığı",
    tabs: "Sekmeler",
    contentTypeEnabled: "Ana İçerik Türü etkinleştirildi",
    contentTypeUses: "Bu İçerik Türü kullanır",
    noPropertiesDefinedOnTab: 'Bu sekmede tanımlanmış özellik yok. Yeni bir mülk oluşturmak için üstteki "yeni mülk ekle" bağlantısını tıklayın.',
    createMatchingTemplate: "Eşleşen şablon oluştur",
    addIcon: "Simge ekle"
  },
  sort: {
    sortOrder: "Sıralama düzeni",
    sortCreationDate: "Oluşturma tarihi",
    sortDone: "Sıralama tamamlandı.",
    sortHelp: "Nasıl düzenleneceklerini ayarlamak için farklı öğeleri aşağı veya yukarı sürükleyin. Veya tüm öğe koleksiyonunu sıralamak için sütun başlıklarını tıklayın",
    sortPleaseWait: "Lütfen bekleyin. Öğeler sıralanıyor, bu biraz zaman alabilir."
  },
  speechBubbles: {
    validationFailedHeader: "Doğrulama",
    validationFailedMessage: "Öğe kaydedilmeden önce doğrulama hataları düzeltilmelidir",
    operationFailedHeader: "Başarısız",
    operationSavedHeader: "Kaydedildi",
    invalidUserPermissionsText: "Yetersiz kullanıcı izni, işlemi tamamlayamadı",
    operationCancelledHeader: "İptal Edildi",
    operationCancelledText: "İşlem, üçüncü taraf bir eklenti tarafından iptal edildi",
    contentPublishedFailedByEvent: "Yayınlama, üçüncü taraf bir eklenti tarafından iptal edildi",
    contentTypeDublicatePropertyType: "Mülk türü zaten var",
    contentTypePropertyTypeCreated: "Mülk türü oluşturuldu",
    contentTypePropertyTypeCreatedText: "Ad: %0% <br /> DataType:%1%",
    contentTypePropertyTypeDeleted: "Mülk türü silindi",
    contentTypeSavedHeader: "Belge Türü kaydedildi",
    contentTypeTabCreated: "Sekme oluşturuldu",
    contentTypeTabDeleted: "Sekme silindi",
    contentTypeTabDeletedText: "Şu kimliğe sahip sekme: %0% silindi",
    cssErrorHeader: "Stil sayfası kaydedilmedi",
    cssSavedHeader: "Stil sayfası kaydedildi",
    cssSavedText: "Stil sayfası hatasız kaydedildi",
    dataTypeSaved: "Veri türü kaydedildi",
    dictionaryItemSaved: "Sözlük öğesi kaydedildi",
    editContentPublishedFailedByParent: "Üst sayfa yayınlanmadığı için yayınlama başarısız oldu",
    editContentPublishedHeader: "İçerik yayınlandı",
    editContentPublishedText: "ve web sitesinde görünür",
    editContentSavedHeader: "İçerik kaydedildi",
    editContentSavedText: "Değişiklikleri görünür kılmak için yayınlamayı unutmayın",
    editContentSendToPublish: "Onay İçin Gönderildi",
    editContentSendToPublishText: "Değişiklikler onay için gönderildi",
    editMediaSaved: "Medya kaydedildi",
    editMediaSavedText: "Medya hatasız kaydedildi",
    editMemberSaved: "Üye kaydedildi",
    editStylesheetPropertySaved: "Stil Sayfası Özelliği Kaydedildi",
    editStylesheetSaved: "Stil Sayfası kaydedildi",
    editTemplateSaved: "Şablon kaydedildi",
    editUserError: "Kullanıcı kaydedilirken hata oluştu (günlüğü kontrol edin)",
    editUserSaved: "Kullanıcı Kaydedildi",
    editUserTypeSaved: "Kullanıcı türü kaydedildi",
    editUserGroupSaved: "Kullanıcı grubu kaydedildi",
    editCulturesAndHostnamesSaved: "Kaydedilen kültürler ve ana bilgisayar adları",
    editCulturesAndHostnamesError: "Kültürleri ve ana bilgisayar adlarını kaydetme hatası",
    fileErrorHeader: "Dosya kaydedilmedi",
    fileErrorText: "dosyası kaydedilemedi. Lütfen dosya izinlerini kontrol edin",
    fileSavedHeader: "Dosya kaydedildi",
    fileSavedText: "Dosya hatasız kaydedildi",
    languageSaved: "Dil kaydedildi",
    mediaTypeSavedHeader: "Medya Türü kaydedildi",
    memberTypeSavedHeader: "Üye Türü kaydedildi",
    memberGroupSavedHeader: "Üye Grubu kaydedildi",
    templateErrorHeader: "Şablon kaydedilmedi",
    templateErrorText: "Lütfen aynı takma ada sahip 2 şablonunuz olmadığından emin olun",
    templateSavedHeader: "Şablon kaydedildi",
    templateSavedText: "Şablon hatasız kaydedildi!",
    contentUnpublished: "Yayınlanmamış içerik",
    partialViewSavedHeader: "Kısmi görünüm kaydedildi",
    partialViewSavedText: "Kısmi görünüm, herhangi bir hata olmadan kaydedildi!",
    partialViewErrorHeader: "Kısmi görünüm kaydedilmedi",
    partialViewErrorText: "Dosyayı kaydederken bir hata oluştu.",
    permissionsSavedFor: "için kaydedilen izinler",
    deleteUserGroupsSuccess: "%0% kullanıcı grubu silindi",
    deleteUserGroupSuccess: "%0% silindi",
    enableUsersSuccess: "%0% kullanıcı etkinleştirildi",
    disableUsersSuccess: "%0% kullanıcı devre dışı bırakıldı",
    enableUserSuccess: "%0% artık etkinleştirildi",
    disableUserSuccess: "%0% artık devre dışı",
    setUserGroupOnUsersSuccess: "Kullanıcı grupları ayarlandı",
    unlockUsersSuccess: "%0% kullanıcının kilidi kaldırıldı",
    unlockUserSuccess: "%0% artık kilitli",
    memberExportedSuccess: "Üye dosyaya aktarıldı",
    memberExportedError: "Üyeyi dışa aktarırken bir hata oluştu",
    deleteUserSuccess: "Kullanıcı %0% silindi",
    resendInviteHeader: "Kullanıcıyı davet et",
    resendInviteSuccess: "Davet %0% 'a yeniden gönderildi",
    documentTypeExportedSuccess: "Belge türü dosyaya aktarıldı",
    documentTypeExportedError: "Belge türü dışa aktarılırken bir hata oluştu"
  },
  stylesheet: {
    addRule: "Stil ekle",
    editRule: "Stili düzenle",
    editorRules: "Zengin metin düzenleyici stilleri",
    editorRulesHelp: "Bu stil sayfası için zengin metin düzenleyicide bulunması gereken stilleri tanımlayın",
    editstylesheet: "Stil sayfasını düzenle",
    editstylesheetproperty: "Stil sayfası özelliğini düzenle",
    nameHelp: "Düzenleyici stili seçicide görüntülenen ad",
    preview: "Önizleme",
    previewHelp: "Zengin metin düzenleyicide metin nasıl görünecek.",
    selector: "Seçici",
    selectorHelp: 'CSS sözdizimini kullanır, ör. "h1" veya ".redHeader"',
    styles: "Stiller",
    stylesHelp: 'Zengin metin düzenleyicide uygulanması gereken CSS, ör. "color: red;"',
    tabCode: "Kod",
    tabRules: "Düzenleyici"
  },
  template: {
    deleteByIdFailed: "%0% kimliğine sahip şablon silinemedi",
    edittemplate: "Şablonu düzenle",
    insertSections: "Bölümler",
    insertContentArea: "İçerik alanı ekle",
    insertContentAreaPlaceHolder: "İçerik alanı yer tutucusu ekle",
    insert: "Ekle",
    insertDesc: "Şablonunuza ne ekleyeceğinizi seçin",
    insertDictionaryItem: "Sözlük öğesi",
    insertDictionaryItemDesc: "Sözlük öğesi, çevrilebilir bir metin parçası için yer tutucudur ve çok dilli web siteleri için tasarımlar oluşturmayı kolaylaştırır.",
    insertMacro: "Makro",
    insertMacroDesc: `
      Makro, yapılandırılabilir bir bileşendir ve aşağıdakiler için idealdir:
      parametreler sağlama seçeneğine ihtiyaç duyduğunuz tasarımınızın yeniden kullanılabilir parçaları,
      galeriler, formlar ve listeler gibi.
    `,
    insertPageField: "Değer",
    insertPageFieldDesc: "Geçerli sayfadaki adlandırılmış bir alanın değerini, değeri değiştirme veya alternatif değerlere geri dönüş seçenekleri ile birlikte görüntüler.",
    insertPartialView: "Kısmi görünüm",
    insertPartialViewDesc: `
      Kısmi görünüm, başka bir şablonun içinde oluşturulabilen ayrı bir şablon dosyasıdır.
      şablonu, işaretlemeyi yeniden kullanmak veya karmaşık şablonları ayrı dosyalara ayırmak için harikadır.
    `,
    mastertemplate: "Ana şablon",
    noMaster: "Ana yok",
    renderBody: "Alt şablonu oluştur",
    renderBodyDesc: `
     Ekleyerek bir alt şablonun içeriğini işler
     <code>@RenderBody()</code> yer tutucusu.
      `,
    defineSection: "Adlandırılmış bir bölüm tanımlayın",
    defineSectionDesc: `
         Şablonunuzun bir bölümünü, içine sararak adlandırılmış bir bölüm olarak tanımlar
          <code>@section { ... }</code>. Bu bir
          <code>@RenderSection</code> kullanarak bu şablonun üst öğesinin belirli bir alanı.
      `,
    renderSection: "Adlandırılmış bir bölüm oluşturun",
    renderSectionDesc: `
      Bir <code>@RenderSection(ad)</code> yer tutucusu ekleyerek bir alt şablonun adlandırılmış alanını oluşturur.
      Bu, karşılık gelen bir <code>@section [ad] {...}</code> tanımına sarılmış bir alt şablon alanını oluşturur.
      `,
    sectionName: "Bölüm Adı",
    sectionMandatory: "Bölüm zorunludur",
    sectionMandatoryDesc: `
      Zorunlu ise, alt şablon bir <code>@section</code> tanımı içermelidir, aksi takdirde bir hata gösterilir.
    `,
    queryBuilder: "Sorgu oluşturucu",
    itemsReturned: "öğe iade edildi,",
    iWant: "istiyorum",
    allContent: "tüm içerik",
    contentOfType: '"%0%" türünde içerik',
    from: "dan",
    websiteRoot: "web sitem",
    where: "nerede",
    and: "ve",
    is: "=",
    isNot: "değil",
    before: "önce",
    beforeIncDate: "önce (seçilen tarih dahil)",
    after: "sonra",
    afterIncDate: "sonra (seçilen tarih dahil)",
    equals: "şuna eşittir",
    doesNotEqual: "eşit değildir",
    contains: "içerir",
    doesNotContain: "içermez",
    greaterThan: "büyüktür",
    greaterThanEqual: "büyük veya eşittir",
    lessThan: "küçüktür",
    lessThanEqual: "küçüktür veya eşittir",
    id: "kimlik",
    name: "Ad",
    createdDate: "Oluşturulma Tarihi",
    lastUpdatedDate: "Son Güncelleme Tarihi",
    orderBy: "sırala",
    ascending: "artan",
    descending: "azalan",
    template: "Şablon"
  },
  grid: {
    media: "Resim",
    macro: "Makro",
    insertControl: "İçerik türünü seçin",
    chooseLayout: "Bir düzen seçin",
    addRows: "Satır ekle",
    addElement: "İçerik ekle",
    dropElement: "İçeriği bırak",
    settingsApplied: "Ayarlar uygulandı",
    contentNotAllowed: "Bu içeriğe burada izin verilmiyor",
    contentAllowed: "Bu içeriğe burada izin verilir",
    clickToEmbed: "Yerleştirmek için tıklayın",
    clickToInsertImage: "Resim eklemek için tıklayın",
    placeholderWriteHere: "Buraya yazın ...",
    gridLayouts: "Izgara Düzenleri",
    gridLayoutsDetail: "Düzenler, ızgara düzenleyicinin genel çalışma alanıdır, genellikle yalnızca bir veya iki farklı düzene ihtiyacınız vardır",
    addGridLayout: "Izgara Düzeni Ekle",
    editGridLayout: "Izgara Düzenini Düzenle",
    addGridLayoutDetail: "Sütun genişliklerini ayarlayarak ve ek bölümler ekleyerek düzeni ayarlayın",
    rowConfigurations: "Satır yapılandırmaları",
    rowConfigurationsDetail: "Satırlar, yatay olarak düzenlenmiş önceden tanımlanmış hücrelerdir",
    addRowConfiguration: "Satır yapılandırması ekle",
    editRowConfiguration: "Satır yapılandırmasını düzenle",
    addRowConfigurationDetail: "Hücre genişliklerini ayarlayarak ve ilave hücreler ekleyerek satırı ayarlayın",
    columns: "Sütunlar",
    columnsDetails: "Izgara düzenindeki toplam birleşik sütun sayısı",
    settings: "Ayarlar",
    settingsDetails: "Hangi ayarları düzenleyicilerin değiştirebileceğini yapılandırın",
    styles: "Stiller",
    stylesDetails: "Stil editörlerinin neleri değiştirebileceğini yapılandırma",
    allowAllEditors: "Tüm düzenleyicilere izin ver",
    allowAllRowConfigurations: "Tüm satır yapılandırmalarına izin ver",
    maxItems: "Maksimum öğe",
    maxItemsDescription: "Boş bırakın veya sınırsız için 0 olarak ayarlayın",
    setAsDefault: "Varsayılan olarak ayarla",
    chooseExtra: "Fazladan birini seçin",
    chooseDefault: "Varsayılanı seçin",
    areAdded: "eklendi",
    youAreDeleting: "Satır yapılandırmasını siliyorsunuz",
    deletingARow: `
      Bir satır yapılandırma adının silinmesi, bu yapılandırmaya dayalı mevcut herhangi bir içerik için veri kaybına neden olur.
    `
  },
  contentTypeEditor: {
    compositions: "Kompozisyonlar",
    group: "Grup",
    noGroups: "Hiçbir grup eklemediniz",
    addGroup: "Grup ekle",
    inheritedFrom: "devralındı ​​",
    addProperty: "Mülk ekle",
    requiredLabel: "Gerekli etiket",
    enableListViewHeading: "Liste görünümünü etkinleştir",
    enableListViewDescription: "İçerik öğesini, alt öğelerinin sıralanabilir ve aranabilir bir listesini gösterecek şekilde yapılandırır, alt öğeler ağaçta gösterilmez",
    allowedTemplatesHeading: "İzin Verilen Şablonlar",
    allowedTemplatesDescription: "Bu tür içerik üzerinde hangi şablon düzenleyicilerinin kullanmasına izin verileceğini seçin",
    allowAsRootHeading: "Kök olarak izin ver",
    allowAsRootDescription: "Düzenleyicilerin, içerik ağacının kök dizininde bu türden içerik oluşturmasına izin verin.",
    childNodesHeading: "İzin verilen alt düğüm türleri",
    childNodesDescription: "Belirtilen türlerdeki içeriğin, bu tür içeriğin altında oluşturulmasına izin verin.",
    chooseChildNode: "Alt düğümü seçin",
    compositionsDescription: "Mevcut bir belge türünden sekmeleri ve özellikleri devralın. Mevcut belge türüne yeni sekmeler eklenecek veya aynı ada sahip bir sekme varsa birleştirilecektir.",
    compositionInUse: "Bu içerik türü bir bestede kullanıldığından kendi başına oluşturulamaz.",
    noAvailableCompositions: "Beste olarak kullanılabilecek içerik türü yok.",
    compositionRemoveWarning: "Bir kompozisyonun kaldırılması, ilişkili tüm özellik verilerini silecektir. Belge türünü kaydettikten sonra geri dönüş yoktur.",
    availableEditors: "Yeni oluştur",
    reuse: "Mevcut olanı kullan",
    editorSettings: "Düzenleyici ayarları",
    configuration: "Yapılandırma",
    yesDelete: "Evet, sil",
    movedUnderneath: "altına taşındı",
    copiedUnderneath: "altına kopyalandı",
    folderToMove: "Taşınacak klasörü seçin",
    folderToCopy: "Kopyalanacak klasörü seçin",
    structureBelow: "aşağıdaki ağaç yapısına",
    allDocumentTypes: "Tüm Belge türleri",
    allDocuments: "Tüm Belgeler",
    allMediaItems: "Tüm medya öğeleri",
    usingThisDocument: "bu belge türünün kullanılması kalıcı olarak silinecektir, lütfen bunları da silmek istediğinizi onaylayın.",
    usingThisMedia: "bu medya türünün kullanılması kalıcı olarak silinecek, lütfen bunları da silmek istediğinizi onaylayın.",
    usingThisMember: "bu üye türünün kullanılması kalıcı olarak silinecek, lütfen bunları da silmek istediğinizi onaylayın",
    andAllDocuments: "ve bu türü kullanan tüm belgeler",
    andAllMediaItems: "ve bu türü kullanan tüm medya öğeleri",
    andAllMembers: "ve bu türü kullanan tüm üyeler",
    memberCanEdit: "Üye düzenleyebilir",
    memberCanEditDescription: "Bu özellik değerinin üye tarafından profil sayfasında düzenlenmesine izin ver",
    isSensitiveData: "Hassas verilerdir",
    isSensitiveDataDescription: "Bu özellik değerini, hassas bilgileri görüntüleme erişimi olmayan içerik düzenleyicilerinden gizleyin",
    showOnMemberProfile: "Üye profilinde göster",
    showOnMemberProfileDescription: "Bu özellik değerinin üye profil sayfasında görüntülenmesine izin ver",
    tabHasNoSortOrder: "sekmesinde sıralama düzeni yok",
    compositionUsageHeading: "Bu beste nerede kullanılıyor?",
    compositionUsageSpecification: "Bu beste şu anda aşağıdaki içerik türlerinin oluşturulmasında kullanılmaktadır:",
    cultureVariantHeading: "Kültüre göre değişikliklere izin ver",
    segmentVariantHeading: "Segmentasyona izin ver",
    cultureVariantLabel: "Kültüre göre değişiklik yapın",
    segmentVariantLabel: "Segmentlere göre değişiklik yapın",
    cultureVariantDescription: "Düzenleyenlerin farklı dillerde içerik oluşturmasına izin ver.",
    segmentVariantDescription: "Editörlerin bu içeriğin segmentlerini oluşturmasına izin ver.",
    allowVaryByCulture: "Kültüre göre değişiklik yapmaya izin ver",
    allowVaryBySegment: "Segmentasyona izin ver",
    elementType: "Öğe türü",
    elementHeading: "Bir Öğe türüdür",
    elementDescription: "Bir Öğe türü, ağaçta değil, örneğin Yuvalanmış İçerikte kullanılmak üzere tasarlanmıştır.",
    elementCannotToggle: "Bir belge türü, bir veya daha fazla içerik öğesi oluşturmak için kullanıldıktan sonra Öğe türü olarak değiştirilemez.",
    elementDoesNotSupport: "Bu, bir Öğe türü için geçerli değildir",
    propertyHasChanges: "Bu özellikte değişiklikler yaptınız. Onları atmak istediğinizden emin misiniz?"
  },
  languages: {
    addLanguage: "Dil ekle",
    mandatoryLanguage: "Zorunlu dil",
    mandatoryLanguageHelp: "Düğüm yayınlanmadan önce bu dildeki özelliklerin doldurulması gerekir.",
    defaultLanguage: "Varsayılan dil",
    defaultLanguageHelp: "Bir Umbraco sitesinde yalnızca bir varsayılan dil ayarı olabilir.",
    changingDefaultLanguageWarning: "Varsayılan dili değiştirmek, varsayılan içeriğin kaybolmasına neden olabilir.",
    fallsbackToLabel: "Geri döner",
    noFallbackLanguageOption: "Geri dönüş dili yok",
    fallbackLanguageDescription: "Çok dilli içeriğin, istenen dilde yoksa başka bir dile geri dönmesine izin vermek için, buradan seçin.",
    fallbackLanguage: "Geri dönüş dili",
    none: "yok"
  },
  macro: {
    addParameter: "Parametre ekle",
    editParameter: "Parametreyi düzenle",
    enterMacroName: "Makro adını girin",
    parameters: "Parametreler",
    parametersDescription: "Bu makroyu kullanırken mevcut olması gereken parametreleri tanımlayın.",
    selectViewFile: "Kısmi görünüm makro dosyasını seçin"
  },
  modelsBuilder: {
    buildingModels: "Model oluşturma",
    waitingMessage: "bu biraz zaman alabilir, endişelenmeyin",
    modelsGenerated: "Oluşturulan modeller",
    modelsGeneratedError: "Modeller oluşturulamadı",
    modelsExceptionInUlog: "Model oluşturma başarısız oldu, U günlüğünde istisnaya bakın"
  },
  templateEditor: {
    addDefaultValue: "Varsayılan değer ekle",
    defaultValue: "Varsayılan değer",
    alternativeField: "Yedek alanı",
    alternativeText: "Varsayılan değer",
    casing: "Kasa",
    encoding: "Kodlama",
    chooseField: "Alan seçin",
    convertLineBreaks: "Satır sonlarını dönüştür",
    convertLineBreaksHelp: "Satır sonlarını 'br' html etiketiyle değiştirir",
    customFields: "Özel Alanlar",
    dateOnly: "Yalnızca tarih",
    formatAsDate: "Tarih olarak biçimlendir",
    htmlEncode: "HTML kodlama",
    htmlEncodeHelp: "Özel karakterleri HTML eşdeğerleriyle değiştirir.",
    insertedAfter: "Alan değerinden sonra eklenecek",
    insertedBefore: "Alan değerinden önce eklenecek",
    lowercase: "Küçük harf",
    none: "Yok",
    outputSample: "Çıktı örneği",
    postContent: "Alanın sonrasına ekle",
    preContent: "Alanın önüne ekle",
    recursive: "Özyinelemeli",
    recursiveDescr: "Evet, yinelemeli yap",
    standardFields: "Standart Alanlar",
    uppercase: "Büyük harf",
    urlEncode: "URL kodlama",
    urlEncodeHelp: "URL'lerdeki özel karakterleri biçimlendirecek",
    usedIfAllEmpty: "Yalnızca yukarıdaki alan değerleri boş olduğunda kullanılacaktır",
    usedIfEmpty: "Bu alan yalnızca birincil alan boşsa kullanılacaktır",
    withTime: "Tarih ve saat"
  },
  translation: {
    details: "Çeviri ayrıntıları",
    DownloadXmlDTD: "XML DTD'yi İndir",
    fields: "Alanlar",
    includeSubpages: "Alt sayfaları dahil et",
    mailBody: `
      Merhaba %0%

      Bu, '%1%' belgesinin size bildirilmesi için otomatik bir postadır.
      %2% tarafından '%5%' e çevrilmesi istendi.

      Düzenlemek için http://%3%/translation/details.aspx?id=%4% adresine gidin.

      Veya çeviri görevlerinize genel bir bakış için Umbraco'da oturum açın
      http://%3%

      İyi günler!

      Umbraco robotdan teşekkürler
      `,
    noTranslators: "Çevirmen kullanıcısı bulunamadı. Lütfen çeviriye içerik göndermeye başlamadan önce bir çevirmen kullanıcısı oluşturun",
    pageHasBeenSendToTranslation: "'%0%' sayfası çeviriye gönderildi",
    sendToTranslate: "'%0%' sayfasını çeviriye gönder",
    totalWords: "Toplam kelime",
    translateTo: "Şu dile çevir",
    translationDone: "Çeviri tamamlandı.",
    translationDoneHelp: "Aşağıya tıklayarak yeni çevirdiğiniz sayfaların önizlemesini yapabilirsiniz. Orijinal sayfa bulunursa, 2 sayfanın bir karşılaştırmasını alacaksınız.",
    translationFailed: "Çeviri başarısız oldu, XML dosyası bozulmuş olabilir",
    translationOptions: "Çeviri seçenekleri",
    translator: "Çevirmen",
    uploadTranslationXml: "Çeviri XML'sini yükle"
  },
  treeHeaders: {
    content: "İçerik",
    contentBlueprints: "İçerik Şablonları",
    media: "Medya",
    cacheBrowser: "Önbellek Tarayıcısı",
    contentRecycleBin: "Geri Dönüşüm Kutusu",
    createdPackages: "Oluşturulan paketler",
    dataTypes: "Veri Türleri",
    dictionary: "Sözlük",
    installedPackages: "Yüklü paketler",
    installSkin: "Dış görünümü yükleyin",
    installStarterKit: "Başlangıç ​​kitini yükleyin",
    languages: "Diller",
    localPackage: "Yerel paketi yükle",
    macros: "Makrolar",
    mediaTypes: "Medya Türleri",
    member: "Üyeler",
    memberGroups: "Üye Grupları",
    memberRoles: "Üye Rolleri",
    memberTypes: "Üye Türleri",
    documentTypes: "Belge Türleri",
    relationTypes: "İlişki Türleri",
    packager: "Paketler",
    packages: "Paketler",
    partialViews: "Kısmi Görünümler",
    partialViewMacros: "Makro Dosyalarını Kısmi Görüntüle",
    repositories: "Depodan yükle",
    runway: "Runway'i Kur",
    runwayModules: "Runway modülleri",
    scripting: "Komut Dosyası Dosyaları",
    scripts: "Komut Dosyaları",
    stylesheets: "Stil Sayfaları",
    templates: "Şablonlar",
    logViewer: "Günlük Görüntüleyici",
    users: "Kullanıcılar",
    settingsGroup: "Ayarlar",
    templatingGroup: "Şablon Oluşturma",
    thirdPartyGroup: "Üçüncü Taraf"
  },
  update: {
    updateAvailable: "Yeni güncelleme hazır",
    updateDownloadText: "%0% hazır, indirmek için burayı tıklayın",
    updateNoServer: "Sunucuyla bağlantı yok",
    updateNoServerError: "Güncelleme için hata denetimi. Daha fazla bilgi için lütfen izleme yığınını inceleyin"
  },
  user: {
    access: "Erişim",
    accessHelp: "Atanan gruplara ve başlangıç ​​düğümlerine bağlı olarak, kullanıcının aşağıdaki düğümlere erişimi vardır",
    assignAccess: "Erişim ata",
    administrators: "Yönetici",
    categoryField: "Kategori alanı",
    createDate: "Kullanıcı oluşturuldu",
    changePassword: "Şifrenizi değiştirin",
    changePhoto: "Fotoğrafı değiştir",
    newPassword: "Yeni şifre",
    noLockouts: "kilitlenmedi",
    noPasswordChange: "Şifre değiştirilmedi",
    confirmNewPassword: "Yeni şifreyi onaylayın",
    changePasswordDescription: "Aşağıdaki formu doldurarak ve 'Şifreyi Değiştir' düğmesini tıklayarak Umbraco Arka Ofisine erişim şifrenizi değiştirebilirsiniz",
    contentChannel: "İçerik Kanalı",
    createAnotherUser: "Başka bir kullanıcı oluşturun",
    createUserHelp: "Umbraco'ya erişim sağlamak için yeni kullanıcılar oluşturun. Yeni bir kullanıcı oluşturulduğunda, kullanıcıyla paylaşabileceğiniz bir şifre oluşturulacaktır.",
    descriptionField: "Açıklama alanı",
    disabled: "Kullanıcıyı Devre Dışı Bırak",
    documentType: "Belge Türü",
    editors: "Düzenleyici",
    excerptField: "Alıntı alanı",
    failedPasswordAttempts: "Başarısız giriş denemeleri",
    goToProfile: "Kullanıcı profiline gidin",
    groupsHelp: "Erişim ve izinler atamak için gruplar ekleyin",
    inviteAnotherUser: "Başka bir kullanıcıyı davet edin",
    inviteUserHelp: "Yeni kullanıcıları Umbraco'ya erişim vermeleri için davet edin. Kullanıcıya, Umbraco'da nasıl oturum açılacağına dair bilgiler içeren bir davet e-postası gönderilecektir. Davetler 72 saat sürer.",
    language: "Dil",
    languageHelp: "Menülerde ve iletişim kutularında göreceğiniz dili ayarlayın",
    lastLockoutDate: "Son kilitlenme tarihi",
    lastLogin: "Son giriş",
    lastPasswordChangeDate: "Parola son değiştirildi",
    loginname: "Kullanıcı Adı",
    mediastartnode: "Medya başlangıç ​​düğümü",
    mediastartnodehelp: "Medya kitaplığını belirli bir başlangıç ​​düğümüyle sınırlayın",
    mediastartnodes: "Medya başlangıç ​​düğümleri",
    mediastartnodeshelp: "Medya kitaplığını belirli başlangıç ​​düğümleriyle sınırlayın",
    modules: "Bölümler",
    noConsole: "Umbraco Erişimini Devre Dışı Bırak",
    noLogin: "henüz giriş yapmadı",
    oldPassword: "Eski şifre",
    password: "Şifre",
    resetPassword: "Şifreyi sıfırla",
    passwordChanged: "Şifreniz değiştirildi!",
    passwordChangedGeneric: "Şifre değiştirildi",
    passwordConfirm: "Lütfen yeni şifreyi onaylayın",
    passwordEnterNew: "Yeni şifrenizi girin",
    passwordIsBlank: "Yeni şifreniz boş olamaz!",
    passwordCurrent: "Mevcut şifre",
    passwordInvalid: "Geçersiz mevcut şifre",
    passwordIsDifferent: "Yeni parola ile onaylanan parola arasında bir fark vardı. Lütfen tekrar deneyin!",
    passwordMismatch: "Onaylanan şifre yeni şifreyle eşleşmiyor!",
    permissionReplaceChildren: "Alt düğüm izinlerini değiştirin",
    permissionSelectedPages: "Şu anda sayfaların izinlerini değiştiriyorsunuz:",
    permissionSelectPages: "İzinlerini değiştirmek için sayfaları seçin",
    removePhoto: "Fotoğrafı kaldır",
    permissionsDefault: "Varsayılan izinler",
    permissionsGranular: "Ayrıntılı izinler",
    permissionsGranularHelp: "Belirli düğümler için izinleri ayarlayın",
    profile: "Profil",
    searchAllChildren: "Tüm çocukları ara",
    sectionsHelp: "Kullanıcılara erişim vermek için bölümler ekleyin",
    selectUserGroups: "Kullanıcı gruplarını seçin",
    noStartNode: "Seçili başlangıç ​​düğümü yok",
    noStartNodes: "Seçili başlangıç ​​düğümü yok",
    startnode: "İçerik başlangıç ​​düğümü",
    startnodehelp: "İçerik ağacını belirli bir başlangıç ​​düğümüyle sınırlayın",
    startnodes: "İçerik başlangıç ​​düğümleri",
    startnodeshelp: "İçerik ağacını belirli başlangıç ​​düğümleriyle sınırlayın",
    updateDate: "Kullanıcının son güncellenme tarihi",
    userCreated: "oluşturuldu",
    userCreatedSuccessHelp: "Yeni kullanıcı başarıyla oluşturuldu. Umbraco'da oturum açmak için aşağıdaki şifreyi kullanın.",
    userManagement: "Kullanıcı yönetimi",
    username: "Ad",
    userPermissions: "Kullanıcı izinleri",
    usergroup: "Kullanıcı grubu",
    userInvited: "davet edildi",
    userInvitedSuccessHelp: "Yeni kullanıcıya, Umbraco'da nasıl oturum açılacağına ilişkin ayrıntıları içeren bir davetiye gönderildi.",
    userinviteWelcomeMessage: "Merhabalar, Umbraco'ya hoş geldiniz! Sadece 1 dakika içinde hazır olacaksınız, sadece bir şifre belirlemeniz.",
    userinviteExpiredMessage: "Umbraco'ya hoş geldiniz! Maalesef davetinizin süresi doldu. Lütfen yöneticinizle iletişime geçin ve yeniden göndermesini isteyin.",
    writer: "Yazar",
    change: "Değiştir",
    yourProfile: "Profiliniz",
    yourHistory: "Yakın geçmişiniz",
    sessionExpires: "Oturum sona eriyor",
    inviteUser: "Kullanıcıyı davet et",
    createUser: "Kullanıcı oluştur",
    sendInvite: "Davet gönder",
    backToUsers: "Kullanıcılara dön",
    inviteEmailCopySubject: "Umbraco: Davet",
    inviteEmailCopyFormat: `
    <html>
    <head>
        <meta name='viewport' content='width=device-width'>
        <meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
    </head>
    <body class='' style='font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; color: #392F54; line-height: 22px; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background: #1d1333; margin: 0; padding: 0;' bgcolor='#1d1333'>
        <style type='text/css'> @media only screen and (max-width: 620px) {table[class=body] h1 {font-size: 28px !important; margin-bottom: 10px !important; } table[class=body] .wrapper {padding: 32px !important; } table[class=body] .article {padding: 32px !important; } table[class=body] .content {padding: 24px !important; } table[class=body] .container {padding: 0 !important; width: 100% !important; } table[class=body] .main {border-left-width: 0 !important; border-radius: 0 !important; border-right-width: 0 !important; } table[class=body] .btn table {width: 100% !important; } table[class=body] .btn a {width: 100% !important; } table[class=body] .img-responsive {height: auto !important; max-width: 100% !important; width: auto !important; } } .btn-primary table td:hover {background-color: #34495e !important; } .btn-primary a:hover {background-color: #34495e !important; border-color: #34495e !important; } .btn  a:visited {color:#FFFFFF;} </style>
        <table border="0" cellpadding="0" cellspacing="0" class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;" bgcolor="#1d1333">
            <tr>
                <td style="font-family: sans-serif; font-size: 14px; vertical-align: top; padding: 24px;" valign="top">
                    <table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;">
                        <tr>
                            <td background="https://umbraco.com/umbraco/assets/img/application/logo.png" bgcolor="#1d1333" width="28" height="28" valign="top" style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
                                <!--[if gte mso 9]> <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:30px;height:30px;"> <v:fill type="tile" src="https://umbraco.com/umbraco/assets/img/application/logo.png" color="#1d1333" /> <v:textbox inset="0,0,0,0"> <![endif]-->
                                <div> </div>
                                <!--[if gte mso 9]> </v:textbox> </v:rect> <![endif]-->
                            </td>
                            <td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top"></td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
        <table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;' bgcolor='#1d1333'>
            <tr>
                <td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
                <td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 560px; width: 560px; margin: 0 auto; padding: 10px;' valign='top'>
                    <div class='content' style='box-sizing: border-box; display: block; max-width: 560px; margin: 0 auto; padding: 10px;'>
                        <br>
                        <table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; border-radius: 3px; background: #FFFFFF;' bgcolor='#FFFFFF'>
                            <tr>
                                <td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 50px;' valign='top'>
                                    <table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
                                        <tr>
                                            <td style='line-height: 24px; font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'>
                                                <h1 style='color: #392F54; font-family: sans-serif; font-weight: bold; line-height: 1.4; font-size: 24px; text-align: left; text-transform: capitalize; margin: 0 0 30px;' align='left'>
                                                    Merhaba %0%,
                                                </h1>
                                                <p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
                                                    <a href="mailto:%4%" style="text-decoration: underline; color: #392F54; -ms-word-break: break-all; word-break: break-all;">%1%</a> tarafından Umbraco Arka Ofisine davet edildiniz.
                                                </p>
                                                <p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
                                                    <a href="mailto:%1%" style="text-decoration: none; color: #392F54; -ms-word-break: break-all; word-break: break-all;">%1%</a> tarafından gönderilen mesaj:
                                                    <br/>
                                                    <em>%2%</em>
                                                </p>
                                                <table border='0' cellpadding='0' cellspacing='0' class='btn btn-primary' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; box-sizing: border-box;'>
                                                    <tbody>
                                                        <tr>
                                                            <td align='left' style='font-family: sans-serif; font-size: 14px; vertical-align: top; padding-bottom: 15px;' valign='top'>
                                                                <table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td style='font-family: sans-serif; font-size: 14px; vertical-align: top; border-radius: 5px; text-align: center; background: #35C786;' align='center' bgcolor='#35C786' valign='top'>
                                                                                <a href='%3%' target='_blank' rel='noopener' style='color: #FFFFFF; text-decoration: none; -ms-word-break: break-all; word-break: break-all; border-radius: 5px; box-sizing: border-box; cursor: pointer; display: inline-block; font-size: 14px; font-weight: bold; text-transform: capitalize; background: #35C786; margin: 0; padding: 12px 30px; border: 1px solid #35c786;'>
                                                                                    Daveti Kabul Etmek İçin Bu Bağlantıyı Tıklayın
                                                                                </a>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <p style='max-width: 400px; display: block; color: #392F54; font-family: sans-serif; font-size: 14px; line-height: 20px; font-weight: normal; margin: 15px 0;'>Bağlantıya tıklayamazsanız, bu URL'yi kopyalayıp tarayıcı pencerenize yapıştırın:</p>
                                                    <table border='0' cellpadding='0' cellspacing='0'>
                                                        <tr>
                                                            <td style='-ms-word-break: break-all; word-break: break-all; font-family: sans-serif; font-size: 11px; line-height:14px;'>
                                                                <font style="-ms-word-break: break-all; word-break: break-all; font-size: 11px; line-height:14px;">
                                                                    <a style='-ms-word-break: break-all; word-break: break-all; color: #392F54; text-decoration: underline; font-size: 11px; line-height:15px;' href='%3%'>%3%</a>
                                                                </font>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </p>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                        <br><br><br>
                    </div>
                </td>
                <td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
            </tr>
        </table>
    </body>
</html>`,
    defaultInvitationMessage: "Davetiye yeniden gönderiliyor ...",
    deleteUser: "Kullanıcıyı Sil",
    deleteUserConfirmation: "Bu kullanıcı hesabını silmek istediğinizden emin misiniz?",
    stateAll: "Tümü",
    stateActive: "Etkin",
    stateDisabled: "Devre Dışı",
    stateLockedOut: "Kilitlendi",
    stateInvited: "Davet edildi",
    stateInactive: "Etkin Değil",
    sortNameAscending: "Ad (AZ)",
    sortNameDescending: "Ad (ZA)",
    sortCreateDateAscending: "En eski",
    sortCreateDateDescending: "En yeni",
    sortLastLoginDateDescending: "Son giriş",
    noUserGroupsAdded: "Hiçbir kullanıcı grubu eklenmedi"
  },
  validation: {
    validation: "Doğrulama",
    noValidation: "Doğrulama yok",
    validateAsEmail: "E-posta adresi olarak doğrula",
    validateAsNumber: "Sayı olarak doğrula",
    validateAsUrl: "URL olarak doğrula",
    enterCustomValidation: "... veya özel bir doğrulama girin",
    fieldIsMandatory: "Alan zorunludur",
    mandatoryMessage: "Özel bir doğrulama hata mesajı girin (isteğe bağlı)",
    validationRegExp: "Bir normal ifade girin",
    validationRegExpMessage: "Özel bir doğrulama hata mesajı girin (isteğe bağlı)",
    minCount: "En az eklemeniz gerekiyor",
    maxCount: "Yalnızca sahip olabilirsiniz",
    addUpTo: "En fazla ekle",
    items: "öğeler",
    urls: "url(ler)",
    urlsSelected: "url(ler) seçildi",
    itemsSelected: "öğe seçildi",
    invalidDate: "Geçersiz tarih",
    invalidNumber: "Sayı değil",
    invalidEmail: "Geçersiz e-posta",
    customValidation: "Özel doğrulama",
    entriesShort: "Minimum %0% giriş, <strong>%1% </strong> daha fazla gerektirir.",
    entriesExceed: "Maksimum %0% giriş, <strong>%1% </strong> çok fazla."
  },
  healthcheck: {
    checkSuccessMessage: "Değer, önerilen değere ayarlandı: '%0%'.",
    checkErrorMessageDifferentExpectedValue: "'%3%' yapılandırma dosyasında '%2%' için '%1%' değeri bekleniyordu, ancak '%0%' bulundu.",
    checkErrorMessageUnexpectedValue: "'%3%' yapılandırma dosyasında '%2%' için beklenmeyen '%0%' değeri bulundu.",
    macroErrorModeCheckSuccessMessage: "Makro Hatalar '%0%' olarak ayarlandı.",
    macroErrorModeCheckErrorMessage: `MacroErrors, makrolarda herhangi bir hata olması durumunda sitenizdeki bazı veya tüm sayfaların tamamen yüklenmesini önleyecek olan '%0%' olarak ayarlanmıştır. Bunu düzeltmek, değeri "%1%" olarak ayarlayacaktır.`,
    httpsCheckValidCertificate: "Web sitenizin sertifikası geçerlidir.",
    httpsCheckInvalidCertificate: "Sertifika doğrulama hatası: '%0%'",
    httpsCheckExpiredCertificate: "Web sitenizin SSL sertifikasının süresi doldu.",
    httpsCheckExpiringCertificate: "Web sitenizin SSL sertifikasının süresi %0% gün içinde doluyor.",
    healthCheckInvalidUrl: "URL %0% - '%1%' pinglenirken hata oluştu",
    httpsCheckIsCurrentSchemeHttps: "Şu anda HTTPS şemasını kullanarak siteyi %0% görüntülüyorsunuz.",
    compilationDebugCheckSuccessMessage: "Hata ayıklama derleme modu devre dışı.",
    compilationDebugCheckErrorMessage: "Hata ayıklama derleme modu şu anda etkin. Yayınlanmadan önce bu ayarı devre dışı bırakmanız önerilir.",
    clickJackingCheckHeaderFound: "​​Bir sitenin başka bir site tarafından IFRAMEd olup olmadığını kontrol etmek için kullanılan başlık veya meta etiketi <strong> X-Frame-Options </strong>.",
    clickJackingCheckHeaderNotFound: "Bir sitenin başka bir site tarafından IFRAMEd olup olmadığını kontrol etmek için kullanılan başlık veya meta etiketi <strong> X-Frame-Options </strong> bulunamadı.",
    noSniffCheckHeaderFound: "​​MIME koklama güvenlik açıklarına karşı koruma sağlamak için kullanılan başlık veya meta etiketi <strong> X-Content-Type-Options </strong> bulundu.",
    noSniffCheckHeaderNotFound: "​​MIME koklama güvenlik açıklarına karşı koruma sağlamak için kullanılan başlık veya meta etiketi <strong> X-Content-Type-Options </strong> bulunamadı.",
    hSTSCheckHeaderFound: "​​HSTS başlığı olarak da bilinen <strong> Strict-Transport-Security </strong> başlığı bulundu.",
    hSTSCheckHeaderNotFound: "​​<strong> Strict-Transport-Security </strong> başlığı bulunamadı.",
    xssProtectionCheckHeaderFound: "​​<strong> X-XSS-Protection </strong> başlığı bulundu.",
    xssProtectionCheckHeaderNotFound: "​​<strong> X-XSS-Protection </strong> başlığı bulunamadı.",
    excessiveHeadersFound: "​​Web sitesi teknolojisi hakkında bilgi veren şu başlıklar bulundu: <strong>%0%</strong>.",
    excessiveHeadersNotFound: "​​Web sitesi teknolojisi hakkında bilgi veren hiçbir başlık bulunamadı.",
    smtpMailSettingsConnectionSuccess: "SMTP ayarları doğru yapılandırıldı ve hizmet beklendiği gibi çalışıyor.",
    notificationEmailsCheckSuccessMessage: "Bildirim e-postası <strong>%0%</strong> olarak ayarlandı",
    notificationEmailsCheckErrorMessage: "Bildirim e-postası hâlâ varsayılan değer olan <strong>%0%</strong>.",
    checkGroup: "Grubu kontrol et",
    helpText: `
        <p> Durum denetleyicisi, sitenizin çeşitli alanlarını en iyi uygulama ayarları, yapılandırma, olası sorunlar vb. için değerlendirir. Sorunları bir düğmeye basarak kolayca düzeltebilirsiniz.
        Kendi sağlık kontrollerinizi ekleyebilir, <a href="https://docs.umbraco.com/umbraco-cms/extending/health-check" target="_blank" rel="noopener" class="btn-link -underline">özel durum kontrolleri hakkında daha fazla bilgi için belgeler </a>. </p>
        `
  },
  redirectUrls: {
    disableUrlTracker: "URL izleyiciyi devre dışı bırakın",
    enableUrlTracker: "URL izleyiciyi etkinleştir",
    originalUrl: "Orijinal URL",
    redirectedTo: "Yönlendirildi",
    redirectUrlManagement: "URL Yönetimini Yeniden Yönlendir",
    panelInformation: "Aşağıdaki URL'ler bu içerik öğesine yönlendiriyor:",
    noRedirects: "Yönlendirme yapılmadı",
    noRedirectsDescription: "Yayınlanan bir sayfa yeniden adlandırıldığında veya taşındığında, yeni sayfaya otomatik olarak bir yönlendirme yapılır.",
    redirectRemoved: "Yönlendirme URL'si kaldırıldı.",
    redirectRemoveError: "Yönlendirme URL'sini kaldırma hatası.",
    redirectRemoveWarning: "Bu, yönlendirmeyi kaldırır",
    confirmDisable: "URL izleyiciyi devre dışı bırakmak istediğinizden emin misiniz?",
    disabledConfirm: "URL izleyici artık devre dışı bırakıldı.",
    disableError: "URL izleyici devre dışı bırakılırken hata oluştu, günlük dosyanızda daha fazla bilgi bulunabilir.",
    enabledConfirm: "URL izleyici artık etkinleştirildi.",
    enableError: "URL izleyici etkinleştirilirken hata oluştu, günlük dosyanızda daha fazla bilgi bulunabilir."
  },
  emptyStates: {
    emptyDictionaryTree: "Aralarından seçim yapabileceğiniz Sözlük öğesi yok"
  },
  textbox: {
    characters_left: "<strong>%0% </strong> karakter kaldı.",
    characters_exceed: "Maksimum %0% karakter, <strong>%1% </strong> çok fazla."
  },
  recycleBin: {
    contentTrashed: "Çöp kutusuna gönderilmiş içerik: {0} Şu kimliğe sahip orijinal ana içerikle ilgili: {1}",
    mediaTrashed: "Şu kimliğe sahip çöp kutusuna gönderilen medya: {0} Şu kimliğe sahip orijinal ana medya öğesiyle ilgili: {1}",
    itemCannotBeRestored: "Bu öğe otomatik olarak geri yüklenemez",
    itemCannotBeRestoredHelpText: "Bu öğenin otomatik olarak geri yüklenebileceği bir yer yok. Aşağıdaki ağacı kullanarak öğeyi manuel olarak taşıyabilirsiniz.",
    wasRestored: "altında geri yüklendi ,"
  },
  relationType: {
    direction: "Yön",
    parentToChild: "Ebeveynden alt öğeye",
    bidirectional: "Çift yönlü",
    parent: "Üst",
    child: "Çocuk",
    count: "Sayım",
    relations: "İlişkiler",
    created: "Oluşturuldu",
    comment: "Yorum",
    name: "Adı",
    noRelations: "Bu ilişki türü için ilişki yok.",
    tabRelationType: "İlişki Türü",
    tabRelations: "İlişkiler"
  },
  dashboardTabs: {
    contentIntro: "Başlarken",
    contentRedirectManager: "Yeniden Yönlendirme URL Yönetimi",
    mediaFolderBrowser: "İçerik",
    settingsWelcome: "Hoş Geldiniz",
    settingsExamine: "Yönetimi İnceleyin",
    settingsPublishedStatus: "Yayınlanma Durumu",
    settingsModelsBuilder: "Model Oluşturucu",
    settingsHealthCheck: "Durum Kontrolü",
    settingsProfiler: "Profil oluşturma",
    memberIntro: "Başlarken",
    formsInstall: "Umbraco Formlarını Yükleyin"
  },
  visuallyHiddenTexts: {
    goBack: "Geri dön",
    activeListLayout: "Etkin düzen:",
    jumpTo: "Git",
    group: "grup",
    passed: "geçti",
    warning: "uyarı",
    failed: "başarısız oldu",
    suggestion: "öneri",
    checkPassed: "Kontrol geçti",
    checkFailed: "Kontrol başarısız oldu",
    openBackofficeSearch: "Arka ofis aramasını aç",
    openCloseBackofficeHelp: "Backoffice yardımını Aç / Kapat",
    openCloseBackofficeProfileOptions: "Profil seçeneklerinizi açın / kapatın",
    assignDomainDescription: "%0% için Kurulum Kültürü ve Ana Bilgisayar Adları",
    createDescription: "%0% altında yeni düğüm oluştur",
    protectDescription: "%0% üzerinde genel erişim kurun",
    rightsDescription: "%0% için Kurulum İzinleri",
    sortDescription: "%0% için sıralama düzenini değiştir",
    createblueprintDescription: "%0% temelinde İçerik Şablonu oluşturun",
    openContextMenu: "için bağlam menüsünü aç",
    currentLanguage: "Mevcut dil",
    switchLanguage: "Dili değiştir",
    createNewFolder: "Yeni klasör oluştur",
    newPartialView: "Kısmi Görünüm",
    newPartialViewMacro: "Kısmi Görünüm Makrosu",
    newMember: "Üye",
    newDataType: "Veri türü",
    redirectDashboardSearchLabel: "Yönlendirme kontrol panelinde ara",
    userGroupSearchLabel: "Kullanıcı grubu bölümünde ara",
    userSearchLabel: "Kullanıcılar bölümünde ara",
    createItem: "Öğe oluştur",
    create: "Oluştur",
    edit: "Düzenle",
    name: "Reklam",
    addNewRow: "Yeni satır ekle",
    tabExpand: "Diğer seçenekleri görüntüleyin",
    hasTranslation: "Çeviri var",
    noTranslation: "Eksik çeviri",
    dictionaryListCaption: "Sözlük öğeleri"
  },
  references: {
    tabName: "Referanslar",
    DataTypeNoReferences: "Bu Veri Türünde referans yok.",
    labelUsedByDocumentTypes: "Belge Türlerinde Kullanılır",
    labelUsedByMediaTypes: "Medya Türlerinde Kullanılır",
    labelUsedByMemberTypes: "Üye Türlerinde Kullanılır",
    usedByProperties: "Kullanan",
    labelUsedByDocuments: "Belgelerde Kullanıldı",
    labelUsedByMembers: "Üyelerde Kullanıldı",
    labelUsedByMedia: "Medyada Kullanıldı"
  },
  logViewer: {
    deleteSavedSearch: "Kaydedilmiş Aramayı Sil",
    logLevels: "Günlük Düzeyleri",
    selectAllLogLevelFilters: "Hepsini seç",
    deselectAllLogLevelFilters: "Tüm seçimleri kaldır",
    savedSearches: "Kaydedilmiş Aramalar",
    saveSearch: "Aramayı Kaydet",
    saveSearchDescription: "Arama sorgunuz için kolay bir ad girin",
    filterSearch: "Aramayı Filtrele",
    totalItems: "Toplam Öğeler",
    timestamp: "Zaman damgası",
    level: "Seviye",
    machine: "Makine",
    message: "Mesaj",
    exception: "İstisna",
    properties: "Özellikler",
    searchWithGoogle: "Google ile Ara",
    searchThisMessageWithGoogle: "Bu mesajı Google ile ara",
    searchWithBing: "Bing ile Ara",
    searchThisMessageWithBing: "Bu iletiyi Bing ile ara",
    searchOurUmbraco: "Umbraco'yu Arayın",
    searchThisMessageOnOurUmbracoForumsAndDocs: "Bu iletiyi Umbraco forumlarımızda ve belgelerimizde arayın",
    searchOurUmbracoWithGoogle: "Google ile Umbraco'muzda arama yapın",
    searchOurUmbracoForumsUsingGoogle: "Umbraco forumlarımızda Google'ı kullanarak arama yapın",
    searchUmbracoSource: "Umbraco Kaynağını Ara",
    searchWithinUmbracoSourceCodeOnGithub: "Github'da Umbraco kaynak kodu içinde arama",
    searchUmbracoIssues: "Umbraco Sorunlarını Ara",
    searchUmbracoIssuesOnGithub: "Github'da Umbraco Sorunlarını Ara",
    deleteThisSearch: "Bu aramayı sil",
    findLogsWithRequestId: "İstek Kimliği Olan Günlükleri Bul",
    findLogsWithNamespace: "Ad Alanına Sahip Günlükleri Bul",
    findLogsWithMachineName: "Makine Adına Sahip Günlükleri Bul",
    open: "Aç"
  },
  clipboard: {
    labelForCopyAllEntries: "%0% Kopyala",
    labelForArrayOfItemsFrom: "%0%, %1%'den",
    labelForRemoveAllEntries: "Tüm öğeleri kaldır",
    labelForClearClipboard: "Panoyu temizle"
  },
  propertyActions: {
    tooltipForPropertyActionsMenu: "Mülk Eylemlerini Aç",
    tooltipForPropertyActionsMenuClose: "Özellik Eylemlerini Kapat"
  },
  nuCache: {
    refreshStatus: "Durumu yenile",
    memoryCache: "Bellek Önbelleği",
    memoryCacheDescription: `
            Bu düğme, bellek içi önbelleği veritabanından tamamen yeniden yükleyerek yeniden yüklemenizi sağlar.
    önbellek (ancak bu veritabanı önbelleğini yeniden oluşturmaz). Bu nispeten hızlıdır.
    Bazı olaylardan sonra önbelleğin düzgün şekilde yenilenmediğini düşündüğünüzde kullanın.
    küçük bir Umbraco sorununu gösterecek olan & mdash;
    (not: bir LB ortamındaki tüm sunucularda yeniden yüklemeyi tetikler).
    `,
    reload: "Yeniden yükle",
    databaseCache: "Veritabanı Önbelleği",
    databaseCacheDescription: `
    Bu düğme, veritabanı önbelleğini, yani cmsContentNu tablosunun içeriğini yeniden oluşturmanıza olanak sağlar.
    <strong> Yeniden oluşturmak pahalı olabilir. </strong>
    Yeniden yükleme yeterli olmadığında ve veritabanı önbelleğinin yüklenmediğini düşündüğünüzde kullanın.
    uygun şekilde oluşturulmuş&mdash; bu bazı kritik Umbraco sorunlarına işaret eder.
    `,
    rebuild: "Yeniden Oluştur",
    internals: "Dahili",
    internalsDescription: `
    Bu düğme, bir NuCache anlık görüntü koleksiyonunu tetiklemenizi sağlar (bir fullCLR GC çalıştırdıktan sonra).
    Bunun ne anlama geldiğini bilmiyorsanız, muhtemelen kullanmanız <em>gerekmez</em>.
    `,
    collect: "Topla",
    publishedCacheStatus: "Yayınlanmış Önbellek Durumu",
    caches: "Önbellekler"
  },
  profiling: {
    performanceProfiling: "Performans profili oluşturma",
    performanceProfilingDescription: `
            <p>
                Umbraco şu anda hata ayıklama modunda çalışıyor. Bu, sayfaları işlerken performansı değerlendirmek için yerleşik performans profilleyicisini kullanabileceğiniz anlamına gelir.
            </p>
            <p>
                Profil oluşturucuyu belirli bir sayfa oluşturma için etkinleştirmek istiyorsanız, sayfayı talep ederken sorgu dizesine <strong> umbDebug=true </strong> eklemeniz yeterlidir.
            </p>
            <p>
                Profilcinin tüm sayfa görüntülemeleri için varsayılan olarak etkinleştirilmesini istiyorsanız, aşağıdaki geçişi kullanabilirsiniz.
                Tarayıcınızda, profil oluşturucuyu otomatik olarak etkinleştiren bir çerez ayarlayacaktır.
                Başka bir deyişle, profil oluşturucu yalnızca <em>tarayıcınızda</em> varsayılan olarak etkin olacaktır - diğer herkesin değil.
            </p>
    `,
    activateByDefault: "Profil oluşturucuyu varsayılan olarak etkinleştirin",
    reminder: "Kolay hatırlatma"
  },
  settingsDashboardVideos: {
    trainingHeadline: "Umbraco eğitim videolarının saatleri yalnızca bir tıklama uzaklıkta",
    trainingDescription: `
            <p> Umbraco'da ustalaşmak mı istiyorsunuz? Umbraco'nun kullanımıyla ilgili bu videolardan birini izleyerek en iyi uygulamaları öğrenmek için birkaç dakikanızı ayırın. Daha da fazla Umbraco videosu için <a href="http://umbraco.tv" target="_blank" rel="noopener">umbraco.tv </a> adresini ziyaret edin </p>
        `,
    getStarted: "Başlamak için"
  },
  settingsDashboard: {
    start: "Buradan başlayın",
    startDescription: "Bu bölüm, Umbraco siteniz için yapı taşlarını içerir. Ayarlar bölümündeki öğelerle çalışma hakkında daha fazla bilgi edinmek için aşağıdaki bağlantıları izleyin",
    more: "Daha fazla bilgi edinin",
    bulletPointOne: `
        Ayarlar <a class="btn-link -underline" href="https://docs.umbraco.com/umbraco-cms/fundamentals/backoffice/sections/" target="_blank" rel="noopener">öğelerle çalışma hakkında daha fazla bilgi edinin Our Umbraco'nun Dokümantasyon bölümünde </a>
    `,
    bulletPointTwo: `
        <a class="btn-link -underline" href="https://our.umbraco.com/forum" target="_blank" rel="noopener">Topluluk Forumu</a>'nda bir soru sorun
    `,
    bulletPointThree: `
        <a class="btn-link -underline" href="https://umbraco.tv" target="_blank" rel="noopener">Eğitici videolarımızı</a> izleyin (bazıları ücretsiz, bazıları abonelik gerektirir)
    `,
    bulletPointFour: `
        <a class="btn-link -underline" href="https://umbraco.com/products/" target="_blank" rel="noopener">Üretkenliği artıran araçlarımız ve ticari desteğimiz </a> hakkında bilgi edinin
    `,
    bulletPointFive: `
        Gerçek hayattaki <a class="btn-link -underline" href="https://umbraco.com/training/" target="_blank" rel="noopener">eğitim ve sertifika </a> fırsatları hakkında bilgi edinin
    `
  },
  startupDashboard: {
    fallbackHeadline: "Dost Canlısı CMS'e Hoş Geldiniz",
    fallbackDescription: "Umbraco'yu seçtiğiniz için teşekkür ederiz - bunun güzel bir şeyin başlangıcı olabileceğini düşünüyoruz. İlk başta bunaltıcı gibi görünse de, öğrenme eğrisini olabildiğince sorunsuz ve hızlı hale getirmek için çok şey yaptık."
  },
  formsDashboard: {
    formsHeadline: "Umbraco Formları",
    formsDescription: "Sezgisel bir sürükle ve bırak arayüzü kullanarak formlar oluşturun. E-postalar gönderen basit iletişim formlarından CRM sistemleriyle entegre olan gelişmiş anketlere kadar. Müşterileriniz buna bayılacak!"
  },
  blockEditor: {
    headlineCreateBlock: "Yeni blok oluştur",
    headlineAddSettingsElementType: "Bir ayarlar bölümü ekleyin",
    headlineAddCustomView: "Görünümü seçin",
    headlineAddCustomStylesheet: "Stil sayfasını seçin",
    headlineAddThumbnail: "Küçük resim seçin",
    labelcreateNewElementType: "Yeni oluştur",
    labelCustomStylesheet: "Özel stil sayfası",
    addCustomStylesheet: "Stil sayfası ekle",
    headlineEditorAppearance: "Düzenleyici görünümü",
    headlineDataModels: "Veri modelleri",
    headlineCatalogueAppearance: "Katalog görünümü",
    labelBackgroundColor: "Arka plan rengi",
    labelIconColor: "Simge rengi",
    labelContentElementType: "İçerik modeli",
    labelLabelTemplate: "Etiket",
    labelCustomView: "Özel görünüm",
    labelSettingsElementType: "Ayarlar modeli",
    labelEditorSize: "Yer paylaşımı düzenleyici boyutu",
    addCustomView: "Özel görünüm ekle",
    addSettingsElementType: "Ayarları ekle",
    confirmDeleteBlockMessage: "<strong>%0%</strong> içeriğini silmek istediğinizden emin misiniz?",
    confirmDeleteBlockTypeMessage: "<strong>%0%</strong> blok yapılandırmasını silmek istediğinizden emin misiniz?",
    confirmDeleteBlockTypeNotice: "Bu bloğun içeriği hala mevcut olacak, bu içeriğin düzenlenmesi artık kullanılamayacak ve desteklenmeyen içerik olarak gösterilecek.",
    blockConfigurationOverlayTitle: "'%0%' Konfigürasyonu",
    thumbnail: "Küçük Resim",
    addThumbnail: "Küçük resim ekle",
    tabCreateEmpty: "Boş oluştur",
    tabClipboard: "Pano",
    tabBlockSettings: "Ayarlar",
    headlineAdvanced: "Gelişmiş",
    forceHideContentEditor: "İçerik düzenleyiciyi gizlemeye zorla",
    blockHasChanges: "Bu içerikte değişiklikler yaptınız. Onları atmak istediğinizden emin misiniz?",
    confirmCancelBlockCreationHeadline: "Oluşturma iptal edilsin mi?",
    confirmCancelBlockCreationMessage: "Oluşturmayı iptal etmek istediğinizden emin misiniz.",
    elementTypeDoesNotExistHeadline: "Hata!",
    elementTypeDoesNotExistDescription: "Bu bloğun ElementType'ı artık mevcut değil",
    propertyEditorNotSupported: "'%0%' özelliği, bloklarda desteklenmeyen '%1%' düzenleyicisini kullanıyor."
  },
  contentTemplatesDashboard: {
    whatHeadline: "İçerik Şablonları Nedir?",
    whatDescription: "İçerik Şablonları, yeni bir içerik düğümü oluştururken seçilebilen önceden tanımlanmış içeriklerdir.",
    createHeadline: "Nasıl İçerik Şablonu oluşturabilirim?",
    createDescription: `
            <p> İçerik Şablonu oluşturmanın iki yolu vardır: </p>
            <ul>
                <li> Bir içerik düğümünü sağ tıklayın ve yeni bir İçerik Şablonu oluşturmak için "İçerik Şablonu Oluştur" u seçin. </li>
                <li> Ayarlar bölümündeki İçerik Şablonları ağacını sağ tıklayın ve İçerik Şablonu oluşturmak istediğiniz Belge Türünü seçin. </li>
            </ul>
            <p> Bir ad verildiğinde, editörler İçerik Şablonunu yeni sayfalarının temeli olarak kullanmaya başlayabilir. </p>
        `,
    manageHeadline: "İçerik Şablonlarını nasıl yönetirim?",
    manageDescription: 'Ayarlar bölümündeki "İçerik Şablonları" ağacından İçerik Şablonlarını düzenleyebilir ve silebilirsiniz. İçerik Şablonunun dayandığı Belge Türünü genişletin ve düzenlemek veya silmek için tıklayın.'
  }
};
export {
  e as default
};
//# sourceMappingURL=tr-tr-Dwk65MlM.js.map
