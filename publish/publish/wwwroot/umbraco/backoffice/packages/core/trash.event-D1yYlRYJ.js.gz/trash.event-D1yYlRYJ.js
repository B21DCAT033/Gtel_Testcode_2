import { UmbEntityActionEvent as e } from "@umbraco-cms/backoffice/entity-action";
class t extends e {
  static {
    this.TYPE = "entity-trashed";
  }
  constructor(s) {
    super(t.TYPE, s);
  }
}
export {
  t as U
};
//# sourceMappingURL=trash.event-D1yYlRYJ.js.map
