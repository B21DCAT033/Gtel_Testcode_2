import { U as t } from "./tree-item-element-base-B4c7_4K1.js";
class o extends t {
  constructor(e) {
    super(e);
  }
}
export {
  o as UmbDefaultTreeItemContext,
  o as default
};
//# sourceMappingURL=tree-item-default.context-1RiDlQsY.js.map
