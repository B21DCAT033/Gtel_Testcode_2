import { a as o } from "./tree-item-element-base-B4c7_4K1.js";
import { customElement as f } from "@umbraco-cms/backoffice/external/lit";
var u = Object.getOwnPropertyDescriptor, p = (m, l, n, a) => {
  for (var e = a > 1 ? void 0 : a ? u(l, n) : l, t = m.length - 1, s; t >= 0; t--)
    (s = m[t]) && (e = s(e) || e);
  return e;
};
let r = class extends o {
};
r = p([
  f("umb-default-tree-item")
], r);
const v = r;
export {
  r as UmbDefaultTreeItemElement,
  v as default
};
//# sourceMappingURL=tree-item-default.element-CxJLzELG.js.map
