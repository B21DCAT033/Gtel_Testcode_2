const e = {
  actions: {
    assigndomain: "Мови та домени",
    auditTrail: "Історія виправлень",
    browse: "Переглянути",
    changeDocType: "Змінити тип документу",
    copy: "Копіювати",
    create: "Створити",
    createblueprint: "Створити шаблон вмістимого",
    createGroup: "Створити групу",
    createPackage: "Створити пакет",
    defaultValue: "Значення за замовчуванням",
    delete: "Видалити",
    disable: "Відключити",
    emptyrecyclebin: "Очистити корзину",
    enable: "Включити",
    export: "Експорт",
    exportDocumentType: "Експортувати",
    importdocumenttype: "Імпортувати",
    importPackage: "Імпортувати пакет",
    liveEdit: "Правити на місці",
    logout: "Вийти",
    move: "Перемістити",
    notify: "Сповіщення",
    protect: "Публічний доступ",
    publish: "Опублікувати",
    refreshNode: "Оновити вузли",
    rename: "Переіменувати",
    republish: "Опублікувати весь сайт",
    restore: "Відновити",
    rights: "Дозволи",
    rollback: "Відкатити",
    sendtopublish: "Надіслати на публікацію",
    sendToTranslate: "Надіслати на переклад",
    setGroup: "Задати групу",
    setPermissions: "Задати права",
    sort: "Сортувати",
    translate: "Перекласти",
    unpublish: "Скасувати публікацію",
    unlock: "Разблокувати",
    update: "Оновити"
  },
  actionCategories: {
    content: "Вміст",
    administration: "Адміністрування",
    structure: "Структура",
    other: "Інше"
  },
  actionDescriptions: {
    assignDomain: "Дозволити доступ до призначення мов і доменів",
    auditTrail: "Дозволити доступ до журналу історії вузла",
    browse: "Дозволити доступ до перегляду вузла",
    changeDocType: "Дозволити доступ до зміни типу документа для вузла",
    copy: "Дозволити доступ до копіювання вузла",
    create: "Дозволити доступ до створення вузлів",
    delete: "Дозволити доступ до видалення вузлів",
    move: "Дозволити доступ до переміщення вузла",
    protect: "Дозволити доступ до встановлення та зміни правил публічного доступу для вузла",
    publish: "Дозволити доступ до публікації вузла",
    rights: "Дозволити доступ до зміни прав доступу до вузла",
    rollback: "Дозволити доступ на повернення до попередніх станів вузла",
    sendtopublish: "Дозволити доступ до відправки вузла на схвалення перед публікацією",
    sendToTranslate: "Дозволити доступ до відправки вузла на переклад даних",
    sort: "Дозволити доступ до зміни порядку сортування вузлів",
    translate: "Дозволити доступ до перекладу даних вузла",
    update: "Дозволити доступ до збереження вузла",
    createblueprint: "Дозволити доступ до створення шаблону вмісту"
  },
  assignDomain: {
    addNew: "Додати новий домен",
    domain: "Домен",
    domainCreated: "Створено новий домен '%0%'",
    domainDeleted: "Домен '%0%' видалено",
    domainExists: "Домен із іменем '%0%' вже існує",
    domainUpdated: "Домен '%0%' оновлено",
    duplicateDomain: "Такий домен вже призначено.",
    inherit: "Успадкувати",
    invalidDomain: "Неприпустимий формат домену.",
    invalidNode: "Неприпустимий вузол.",
    language: "Мова",
    orEdit: "Редагувати існуючі домени",
    permissionDenied: "Недостатньо повноважень.",
    remove: "видалити",
    setDomains: "Домени",
    setLanguage: "Мова (культура)",
    setLanguageHelp: `Встановіть мову (культуру) для всіх дочірніх вузлів,<br /> бо успадкуйте мову від батьківських вузлів.<br />
		Це налаштування буде застосовано також і до поточного вузла, якщо для нього нижче явно не заданий домен.`
  },
  auditTrails: {
    atViewingFor: "Спостерігати за"
  },
  blueprints: {
    createBlueprintFrom: "Створити новий шаблон вмісту з <em>%0%</em>",
    blankBlueprint: "Порожній",
    selectBlueprint: "Вибрати шаблон вмісту",
    createdBlueprintHeading: "Шаблон вмісту створено",
    createdBlueprintMessage: "Створено шаблон вмісту з '%0%'",
    duplicateBlueprintMessage: "Інший шаблон вмісту з такою самою назвою вже існує",
    blueprintDescription: "Шаблон вмісту — це набір даних, який редактор може використовувати для початкового заповнення властивостей при створенні вузлів вмісту."
  },
  bulk: {
    done: "Завершено",
    deletedItem: "Видалений %0% елемент",
    deletedItems: "Видалено %0% елементів",
    deletedItemOfItem: "Видалений %0% з %1% елементів",
    deletedItemOfItems: "Видалено %0% з %1% елементів",
    publishedItem: "Опублікований %0% елемент",
    publishedItems: "Опубліковано %0% елементів",
    publishedItemOfItem: "Опублікований %0% з %1% елементів",
    publishedItemOfItems: "Опубліковано %0% з %1% елементів",
    unpublishedItem: "Скасовано публікацію %0% елементу",
    unpublishedItems: "Скасовано публікацію %0% елементів",
    unpublishedItemOfItem: "Скасовано публікацію %0% з %1% елементів",
    unpublishedItemOfItems: "Скасовано публікацію %0% з %1% елементів",
    movedItem: "Перенесений %0% елемент",
    movedItems: "Перенесено %0% елементів",
    movedItemOfItem: "Перенесений %0% з %1% елементів",
    movedItemOfItems: "Перенесено %0% з %1% елементів",
    copiedItem: "Скопійований %0% елемент",
    copiedItems: "Скопійовано %0% елементів",
    copiedItemOfItem: "Скопійований %0% з %1% елементів",
    copiedItemOfItems: "Скопійовано %0% з %1% елементів"
  },
  buttons: {
    bold: "Напівжирний",
    clearSelection: "Очистити виділення",
    deindent: "Зменшити відступ",
    formFieldInsert: "Вставити поле форми",
    graphicHeadline: "Вставити графічний заголовок",
    htmlEdit: "Редагувати код HTML",
    indent: "Збільшити відступ",
    italic: "Курсив",
    justifyCenter: "По центру",
    justifyLeft: "Ліворуч",
    justifyRight: "Праворуч",
    linkInsert: "Вставити посилання",
    linkLocal: "Вставити якір (локальне посилання)",
    listBullet: "Маркований список",
    listNumeric: "Нумерований список",
    macroInsert: "Вставити макрос",
    pictureInsert: "Вставити зображення",
    redo: "Повторити",
    relations: "Правити зв'язки",
    returnToList: "Повернутись до списку",
    save: "Зберегти",
    saveAndGenerateModels: "Зберегти та побудувати моделі",
    saveAndPublish: "Опублікувати",
    saveToPublish: "Надіслати на публікацію",
    saveListView: "Зберегти список",
    select: "Вибрати",
    saveAndPreview: "Попередній перегляд",
    showPageDisabled: "Попередній перегляд заборонено, тому що документу не зіставлено шаблон",
    somethingElse: "Інші дії",
    styleChoose: "Вибрати стиль",
    styleShow: "Показати стилі",
    tableInsert: "Вставити таблицю",
    undo: "Скасувати"
  },
  colorpicker: {
    noColors: "Ви не вказали жодного допустимого кольору"
  },
  colors: {
    blue: "Синій"
  },
  content: {
    about: "Про цю сторінку",
    alias: "Аліас",
    alternativeTextHelp: "(як би Ви описали зображення по телефону)",
    alternativeUrls: "Альтернативні посилання",
    altTextOptional: "Альтернативний текст (необов'язково)",
    childItems: "Елементи списку",
    clickToEdit: "Натисніть для редагування цього елемента",
    contentRoot: "Початковий вузол з вмістом",
    createBy: "Створено користувачем",
    createByDesc: "Початковий автор",
    createDate: "Дата створення",
    createDateDesc: "Дата/час створення документа",
    documentType: "Тип документа",
    editing: "Редагування",
    expireDate: "Приховати",
    getUrlException: "УВАГА: неможливо отримати URL-адресу документа (внутрішня помилка - подробиці в системному журналі)",
    isPublished: "Опубліковано",
    isSensitiveValue: "Це значення приховано. Якщо Вам потрібний доступ до цього значення, зв'яжіться з адміністратором веб-сайту.",
    isSensitiveValue_short: "Це значення приховано.",
    itemChanged: "Цей документ було змінено після публікації",
    itemNotPublished: "Цей документ не опубліковано",
    lastPublished: "Документ опубліковано",
    noItemsToShow: "Немає елементів.",
    listViewNoItems: "У цьому списку поки що немає елементів.",
    listViewNoContent: "Вміст поки що не додано",
    listViewNoMembers: "Учасники поки що не додані",
    mediaLinks: "Посилання на медіа-елементи",
    mediatype: "Тип медіа-контенту",
    membergroup: "Група учасників",
    memberof: "Включено в групу(и)",
    memberrole: "Роль учасника",
    membertype: "Тип учасника",
    nestedContentDeleteItem: "Ви впевнені, що хочете видалити цей елемент?",
    nestedContentEditorNotSupported: "Властивість '%0%' використовує редактор '%1%', який не підтримується для вкладеного вмісту.",
    noChanges: "Не було зроблено жодних змін",
    noDate: "Дата не вказана",
    nodeName: "Заголовок сторінки",
    noMediaLink: "Цей медіа-елемент не містить посилання",
    notmemberof: "Доступні групи",
    otherElements: "Властивості",
    parentNotPublished: "Цей документ опубліковано, але приховано, тому що його батьківський документ '%0%' не опублікований",
    parentNotPublishedAnomaly: "УВАГА: цей документ опубліковано, але його немає у глобальному кеші (внутрішня помилка - подробиці в системному журналі)",
    publish: "Опублікувати",
    published: "Опубліковано",
    publishedPendingChanges: "Опубліковано (є зміни)",
    publishStatus: "Стан публікації",
    releaseDate: "Опублікувати",
    removeDate: "Очистити дату",
    routeError: "УВАГА: цей документ опубліковано, але його URL такий самий як в документа %0%",
    scheduledPublishServerTime: "Цей час буде відповідати наступному часу на сервері:",
    scheduledPublishDocumentation: '<a href="https://docs.umbraco.com/umbraco-cms/fundamentals/data/scheduled-publishing#timezones" target="_blank" rel="noopener">Що це означає?</a>',
    setDate: "Задати дату",
    sortDone: "Порядок сортування оновлено",
    sortHelp: 'Для сортування вузлів просто перетягуйте вузли або натисніть на заголовок стовпця. Ви можете вибрати кілька вузлів, утримуючи клавіші "shift" або "ctrl" при виборі',
    statistics: "Статистика",
    target: "Ціль",
    titleOptional: "Заголовок (необов'язково)",
    type: "Тип",
    unpublish: "Скасувати публікацію",
    unpublished: "Публікацію скасовано",
    unpublishDate: "Скасувати публікацію",
    updateDate: "Останнє редагування",
    updateDateDesc: "Дата/час редагування документа",
    updatedBy: "Оновлено",
    uploadClear: "Видалити файл",
    urls: "Посилання на документ",
    addTextBox: "Додати нове текстове поле",
    removeTextBox: "Видалити це текстове поле",
    saveModalTitle: "Зберегти"
  },
  contentPicker: {
    pickedTrashedItem: "Вибрано елемент вмісту, який вилучено або знаходиться в корзині.",
    pickedTrashedItems: "Вибрані елементи вмісту, які в даний час видалені або знаходяться в корзині"
  },
  contentTypeEditor: {
    compositions: "Композиції",
    noGroups: "Ви не додали жодної вкладки",
    inheritedFrom: "Успадковано від",
    addProperty: "Додати властивість",
    requiredLabel: "Обов'язкова позначка",
    enableListViewHeading: "Відображення у форматі списку",
    enableListViewDescription: "Встановлює подання документа даного типу у вигляді сортованого списку дочірніх документів з функцією пошуку, на відміну від звичайного подання дочірніх документів у вигляді дерева",
    allowedTemplatesHeading: "Допустимі шаблони",
    allowedTemplatesDescription: "Виберіть список допустимих шаблонів для зіставлення документів цього типу",
    allowAsRootHeading: "Дозволити як кореневий елемента",
    allowAsRootDescription: "Дозволяє створювати документи цього типу у самому корені дерева вмісту",
    childNodesHeading: "Допустимі типи дочірніх документів",
    childNodesDescription: "Дозволяє вказати перелік типів документів, допустимих для створення документів, дочірніх до цього типу",
    chooseChildNode: "Вибрати дочірній вузол",
    compositionsDescription: "Успадкувати вкладки та властивості з існуючого типу документів. Вкладки будуть або додані до створюваного типу, або у разі збігу назв вкладок будуть додані успадковані властивості.",
    compositionInUse: "Цей тип документів вже бере участь у композиції іншого типу, тому сам може бути композицією.",
    compositionUsageHeading: "Де використовується ця композиція?",
    compositionUsageSpecification: "Ця композиція зараз використовується при створенні таких типів документів:",
    noAvailableCompositions: "Наразі немає типів документів, допустимих побудови композиції.",
    availableEditors: "Доступні редактори",
    reuse: "Перевикористати",
    editorSettings: "Налаштування редактора",
    configuration: "Конфігурування",
    yesDelete: "ТАК, видалити",
    movedUnderneath: "переміщені всередину",
    copiedUnderneath: "скопійовані всередину",
    folderToMove: "Вибрати папку для переміщення",
    folderToCopy: "Вибрати папку для копіювання",
    structureBelow: "у структурі дерева",
    allDocumentTypes: "Всі типи документів",
    allDocuments: "Всі документи",
    allMediaItems: "Всі медіа-елементи",
    usingThisDocument: ", що використовують цей тип документів, будуть безповоротно видалені, будь ласка, підтвердьте цю дію.",
    usingThisMedia: ", що використовують цей тип медіа, будуть безповоротно видалені, будь ласка, підтвердьте цю дію.",
    usingThisMember: ", що використовують цей тип учасників, будуть безповоротно видалені, будь ласка, підтвердьте цю дію.",
    andAllDocuments: "і всі документи, які використовують цей тип",
    andAllMediaItems: "і всі медіа-елементи, які використовують цей тип",
    andAllMembers: "і всі учасники, які використовують цей тип",
    memberCanEdit: "Учасник може змінити",
    memberCanEditDescription: "Дозволяє редагування значення цієї властивості учасником у своєму профілі",
    isSensitiveData: "Конфіденційні дані",
    isSensitiveDataDescription: "Приховує значення цієї властивості від редакторів вмісту, які не мають доступу до конфіденційної інформації",
    showOnMemberProfile: "Показати у профілі користувача",
    showOnMemberProfileDescription: "Дозволяє показ цієї властивості у профілі учасника",
    tabHasNoSortOrder: "для вкладки не вказано порядок сортування"
  },
  create: {
    chooseNode: "Де ви хочете створити новий %0%",
    createContentBlueprint: "Виберіть тип документів, для якого потрібно створити шаблон вмісту",
    createUnder: "Створити у вузлі",
    newFolder: "Нова папка",
    newDataType: "Новий тип даних",
    noDocumentTypes: 'Немає жодного дозволеного типу документів для створення. Необхідно дозволити потрібні Вам типи у секції "Налаштування" в дереві <strong>"Типи документів"</strong>.',
    noMediaTypes: 'Немає жодного дозволеного типу медіа-матеріалів для створення. Необхідно дозволити потрібні Вам типи у секції "Налаштування" в дереві <strong>"Типы медіа-матеріалів"</strong>.',
    updateData: "Виберіть тип та заголовок",
    documentTypeWithoutTemplate: "Тип документа без зіставленого шаблону",
    newJavascriptFile: "Новий файл javascript",
    newEmptyPartialView: "Нове порожнє часткове представлення",
    newPartialViewMacro: "Новий макрос-представлення",
    newPartialViewFromSnippet: "Нове часткове представлення за зразком (сніпетом)",
    newPartialViewMacroFromSnippet: "Нове макрос-представлення за зразком (сніпетом)",
    newPartialViewMacroNoMacro: "Нове макрос-представлення (без реєстрації макроса)"
  },
  dashboard: {
    browser: "Огляд сайту",
    dontShowAgain: "- Приховати - ",
    nothinghappens: "Якщо адміністративна панель не завантажується, Вам, можливо, слід дозволити спливаючі вікна даного сайту",
    openinnew: "було відкрито у новому вікні",
    restart: "Перезапустити",
    visit: "Відвідати",
    welcome: "Вітаємо"
  },
  defaultdialogs: {
    anchorInsert: "Назва",
    assignDomain: "Управління доменами",
    closeThisWindow: "Закрити це вікно",
    confirmdelete: "Ви впевнені, що хочете видалити",
    confirmdisable: "Ви впевнені, що хочете заборонити",
    confirmlogout: "Ви впевнені?",
    confirmSure: "Ви впевнені?",
    cut: "Вирізати",
    editDictionary: "Редагувати статтю словника",
    editLanguage: "Змінити мову",
    insertAnchor: "Вставити локальне посилання (якір)",
    insertCharacter: "Вставити символ",
    insertgraphicheadline: "Вставити графічний заголовок",
    insertimage: "Вставити зображення",
    insertlink: "Вставити посилання",
    insertMacro: "Вставити макрос",
    inserttable: "Вставити таблицю",
    lastEdited: "Остання зміна",
    link: "Посилання",
    linkinternal: "Внутрішнє посилання",
    linklocaltip: 'Для визначення локального посилання, використовуйте "#" першим символом',
    linknewwindow: "Відкрити у новому вікні?",
    macroDoesNotHaveProperties: "Цей макрос не має властивостей, що редагуються.",
    nodeNameLinkPicker: "Заголовок посилання",
    noIconsFound: "Жодної піктограми не знайдено",
    paste: "Вставити",
    permissionsEdit: "Змінити дозволи для",
    permissionsSet: "Встановити дозволи для",
    permissionsSetForGroup: "Встановити права доступу до '%0%' для групи користувачів '%1%'",
    permissionsHelp: "Виберіть групу (и) користувачів, для яких потрібно встановити дозвіл",
    recycleBinDeleting: "Всі елементи у кошику зараз видаляються. Будь ласка, не закривайте це вікно до закінчення процесу видалення",
    recycleBinIsEmpty: "Корзина порожня",
    recycleBinWarning: "Ви більше не зможете відновити елементи, видалені з кошика",
    regexSearchError: "Сервіс <a target='_blank' rel='noopener' href='http://regexlib.com'>regexlib.com</a> недоступний, це незалежить від нас. Просимо вибачити за завдані незручності.",
    regexSearchHelp: "Використовуйте пошук регулярних виразів, щоб додати сервіс перевірки до поля Вашої форми. Наприклад: 'email, 'zip-code', 'URL'",
    removeMacro: "Видалити макрос",
    requiredField: "Обов'язкове поле",
    sitereindexed: "Сайт переіндексований",
    siterepublished: "Кеш сайту було оновлено. Весь опублікований вміст приведено в актуальний стан, у той час як неопублікований вміст, як і раніше, не опубліковано",
    siterepublishHelp: "Кеш сайту буде повністю оновлено. Весь опублікований вміст буде оновлено, тоді як неопублікований вміст, як і раніше, залишиться неопублікованим.",
    tableColumns: "Кількість стовпців",
    tableRows: "Кількість рядків",
    thumbnailimageclickfororiginal: "Клацніть на зображенні, щоб побачити повнорозмірну версію",
    treepicker: "Виберіть елемент",
    urlLinkPicker: "Посилання",
    viewCacheItem: "Перегляд елемента кешу",
    relateToOriginalLabel: "Зв'язати із оригіналом",
    includeDescendants: "Включаючи всі дочірні",
    theFriendliestCommunity: "Найдружелюбніша спільнота",
    linkToPage: "Посилання на сторінку",
    openInNewWindow: "Відкривати посилання у новому вікні або вкладці браузера",
    linkToMedia: "Посилання на медіа-елемент",
    selectMedia: "Вибрати медіа",
    selectMediaStartNode: "Вибрати початковий вузол медіа-бібліотеки",
    selectIcon: "Вибрати піктограму",
    selectItem: "Вибрати елемент",
    selectLink: "Вибрати посилання",
    selectMacro: "Вибрати макрос",
    selectContent: "Вибрати вміст",
    selectContentStartNode: "Вибрати початковий вузол вмісту",
    selectMember: "Вибрати учасника",
    selectMemberGroup: "Вибрати групу учасників",
    selectNode: "Вибрати вузол",
    selectSections: "Вибрати розділи",
    selectUsers: "Вибрати користувачів",
    noMacroParams: "Це макрос без параметрів",
    noMacros: "Немає макросів, доступних для вставки в редактор",
    externalLoginProviders: "Провайдери автентифікації",
    exceptionDetail: "Детальне повідомлення про помилку",
    stacktrace: "Трасування стеку",
    innerException: "Внутрішня помилка",
    linkYour: "Зв'язати",
    unLinkYour: "Розірвати зв'язок",
    account: "облікового запису",
    selectEditor: "Вибрати редактор",
    selectSnippet: "Вибрати зразок"
  },
  dictionaryItem: {
    description: "Ниже Ви можете вказати різні переклади даної статті словника '%0%'. Додати інші мови можна, скориставшись пунктом 'Мови' в меню зліва.",
    displayName: "Назва мови (культури)",
    changeKeyError: "Ключ '%0%' вже існує у словнику.",
    overviewTitle: "Огляд словника"
  },
  editcontenttype: {
    createListView: "Створити список користувача",
    removeListView: "Видалити список користувача"
  },
  editdatatype: {
    addPrevalue: "Додати попередньо встановлене значення",
    dataBaseDatatype: "Тип даних у БД",
    guid: "GUID типу даних",
    renderControl: "Редактор властивості",
    rteButtons: "Кнопки",
    rteEnableAdvancedSettings: "Увімкнути розширені налаштування для",
    rteEnableContextMenu: "Увімкнути контекстне меню",
    rteMaximumDefaultImgSize: "Максимальний розмір для зображень за замовчуванням",
    rteRelatedStylesheets: "Зіставлені стилі CSS",
    rteShowLabel: "Показати мітку",
    rteWidthAndHeight: "Ширина та висота",
    selectFolder: "Виберіть папку, щоб перемістити до неї",
    inTheTree: "у структурі дерева нижче",
    wasMoved: "був переміщений до папки"
  },
  emptyStates: {
    emptyDictionaryTree: "Немає доступних елементів словника"
  },
  errorHandling: {
    errorButDataWasSaved: "Ваші дані збережені, але для того, щоб опублікувати цей документ, Ви повинні спочатку виправити такі помилки:",
    errorExistsWithoutTab: "%0% вже існує",
    errorHeader: "Виявлено такі помилки:",
    errorHeaderWithoutTab: "Виявлено такі помилки:",
    errorInPasswordFormat: "Пароль повинен складатися як мінімум з %0% символів, хоча б %1% з яких не є літерами",
    errorIntegerWithoutTab: "%0% має бути цілочисельним значенням",
    errorMandatory: "%0% в %1% є обов'язковим полем",
    errorMandatoryWithoutTab: "%0% є обов'язковим полем",
    errorRegExp: "%0% в %1%: дані у некоректному форматі",
    errorRegExpWithoutTab: "%0% - дані у некоректному форматі"
  },
  errors: {
    receivedErrorFromServer: "Отримано повідомлення про помилку від сервера",
    codemirroriewarning: "ПРЕДУПРЕЖДЕНИЕ! Незважаючи на те, що CodeMirror за замовчуванням дозволено в цій конфігурації, він, як і раніше, відключений для браузерів Internet Explorer через нестабільну роботу",
    contentTypeAliasAndNameNotNull: "Вкажіть, будь ласка, аліас та ім'я для цієї властивості!",
    dissallowedMediaType: "Використання даного типу файлів на сайті заборонено адміністратором",
    filePermissionsError: "Помилка доступу до вказаного файлу або папки",
    macroErrorLoadingPartialView: "Помилка завантаження коду у частковому преставленні (файл: %0%)",
    missingTitle: "Вкажіть заголовок",
    missingType: "Виберіть тип",
    pictureResizeBiggerThanOrg: "Ви намагаєтеся збільшити зображення порівняно з його вихідним розміром. Впевнені, що хочете це зробити?",
    startNodeDoesNotExists: "Початковий вузол було видалено, зв'яжіться з Вашим адміністратором",
    stylesMustMarkBeforeSelect: "Для зміни стилю відзначте фрагмент тексту",
    stylesNoStylesOnPage: "Не визначено жодного доступного стилю",
    tableColMergeLeft: "Помістіть курсор у ліву з двох комірок, які хочете об'єднати",
    tableSplitNotSplittable: "Не можна розділити комірку, яка не була до цього об'єднана"
  },
  general: {
    about: "Про систему",
    action: "Дія",
    actions: "Дії",
    add: "Додати",
    alias: "Аліас",
    all: "Все",
    areyousure: "Ви впевнені?",
    back: "Назад",
    border: "Межі",
    by: "користувачем",
    cancel: "Відміна",
    cellMargin: "Відступ комірки",
    choose: "Вибрати",
    close: "Закрити",
    closewindow: "Закрити вікно",
    comment: "Примітка",
    confirm: "Підтвердити",
    constrain: "Зберігати пропорції",
    constrainProportions: "Зберігати пропорції",
    continue: "Далі",
    copy: "Копіювати",
    create: "Створити",
    database: "База даних",
    date: "Дата",
    default: "За замовчуванням",
    delete: "Видалити",
    deleted: "Видалено",
    deleting: "Видаляється...",
    design: "Дизайн",
    dictionary: "Словник",
    dimensions: "Розміри",
    down: "Вниз",
    download: "Завантажити",
    edit: "Змінити",
    edited: "Змінено",
    elements: "Елементи",
    email: "Email адреса",
    error: "Помилка",
    findDocument: "Знайти",
    first: "Початок",
    general: "Загальне",
    groups: "Групи",
    folder: "Папка",
    height: "Висота",
    help: "Довідка",
    hide: "Приховати",
    history: "Історія",
    icon: "Піктограма",
    import: "Імпорт",
    info: "Інфо",
    innerMargin: "Внутрішній відступ",
    insert: "Вставити",
    install: "Встановити",
    invalid: "Невірно",
    justify: "Вирівнювання",
    label: "Назва",
    language: "Мова",
    last: "Кінець",
    layout: "Макет",
    links: "Посилання",
    loading: "Завантаження",
    locked: "БЛОКУВАННЯ",
    login: "Увійти",
    logoff: "Вийти",
    logout: "Вихід",
    macro: "Макрос",
    mandatory: "Обов'язково",
    message: "Повідомлення",
    move: "Перемістити",
    name: "Назва",
    new: "Новий",
    next: "Наст.",
    no: "Ні",
    noItemsInList: "Тут поки що немає елементів",
    of: "з",
    off: "Вимк",
    ok: "Ok",
    open: "Відкрити",
    on: "Вкл",
    options: "Варіанти",
    or: "або",
    orderBy: "Сортування за",
    password: "Пароль",
    path: "Шлях",
    pleasewait: "Хвилинку...",
    previous: "Попер.",
    properties: "Властивості",
    reciept: "Email адреса для отримання даних",
    recycleBin: "Корзина",
    recycleBinEmpty: "Ваша корзина порожня",
    remaining: "Залишилось",
    remove: "Видалити",
    rename: "Перейменувати",
    renew: "Оновити",
    required: "Обов'язкове",
    retrieve: "Отримати",
    retry: "Повторити",
    rights: "Дозволи",
    scheduledPublishing: "Публікація за розкладом",
    search: "Пошук",
    searchNoResult: "На жаль, нічого не знайшлося",
    searchResults: "Результати пошуку",
    server: "Сервер",
    show: "Показати",
    showPageOnSend: "Показати сторінку при надсиланні",
    size: "Розмір",
    sort: "Сортувати",
    status: "Стан",
    submit: "Відправити",
    type: "Тип",
    typeToSearch: "Що шукати?",
    up: "Вгору",
    update: "Оновити",
    upgrade: "Оновлення",
    upload: "Завантажити",
    url: "Інтернет-посилання",
    user: "Користувач",
    username: "Ім'я користувача",
    value: "Значення",
    view: "Перегляд",
    welcome: "Ласкаво просимо...",
    width: "Ширина",
    yes: "Так",
    reorder: "Пересортувати",
    reorderDone: "Пересортування завершено",
    preview: "Попередній перегляд",
    changePassword: "Змінити пароль",
    to: "до",
    listView: "Список",
    saving: "Збереження...",
    current: "поточний",
    selected: "вибрано",
    embed: "Вбудувати"
  },
  graphicheadline: {
    backgroundcolor: "Колір фону",
    bold: "Напівжирний",
    color: "Колір тексту",
    font: "Шрифт",
    text: "Текст"
  },
  grid: {
    media: "Зображення",
    macro: "Макрос",
    addElement: "Додати вміст",
    dropElement: "Скинути вміст",
    addGridLayout: "Додати шаблон сітки",
    addGridLayoutDetail: "Налаштуйте шаблон, задаючи ширину колонок або додаючи додаткові розділи",
    addRowConfiguration: "Додати конфігурацію рядка",
    addRowConfigurationDetail: "Налаштуйте рядок, задаючи ширину комірок або додаючи додаткові комірки",
    addRows: "Додати нові рядки",
    allowAllEditors: "Доступні всі редактори",
    allowAllRowConfigurations: "Доступні всі конфігурації рядків",
    chooseLayout: "Виберіть шаблон",
    clickToEmbed: "Клацніть для вбудовування",
    clickToInsertImage: "Натисніть, щоб вставити зображення",
    columns: "Колонки",
    contentNotAllowed: "Неприпустимий тип вмісту",
    contentAllowed: "Даний тип вмісту дозволено",
    columnsDetails: "Сумарна кількість колонок у шаблоні сітки",
    gridLayouts: "Шаблони сітки",
    gridLayoutsDetail: "Шаблони є робочим простором для редактора сітки, зазвичай Вам знадобиться не більше одного або двох шаблонів.",
    insertControl: "Вставити елемент",
    placeholderWriteHere: "Напишіть...",
    rowConfigurations: "Конфігурації рядків",
    rowConfigurationsDetail: "Рядки - це послідовності комірок з горизонтальним розташуванням",
    settings: "Налаштування",
    settingsApplied: "Налаштування застосовані",
    settingsDetails: "Вкажіть налаштування, доступні редакторам для зміни",
    styles: "Стилі",
    stylesDetails: "Вкажіть стилі, доступні редакторам для зміни",
    setAsDefault: "Встановити за замовчуванням",
    chooseExtra: "Вибрати додатково",
    chooseDefault: "Вибрати за замовчуванням",
    areAdded: "додані",
    maxItemsDescription: "Залиште порожнім або задайте 0 для зняття ліміту",
    maxItems: "Максимальна кількість"
  },
  headers: {
    page: "Сторінка"
  },
  healthcheck: {
    checkSuccessMessage: "Для параметра встановлено рекомендоване значення: '%0%'.",
    checkErrorMessageDifferentExpectedValue: "Очікуване значення '%1%' для параметра '%2%' в файлі конфігурації '%3%', знайдене значення: '%0%'.",
    checkErrorMessageUnexpectedValue: "Знайдено неочікуване значення '%0%' для параметра '%2%' в файлі конфігурації '%3%'.",
    macroErrorModeCheckSuccessMessage: "Параметр 'MacroErrors' встановлений в '%0%'.",
    macroErrorModeCheckErrorMessage: "Параметр 'MacroErrors' встановлений в '%0%', що може спричинити неповну обробку частини сторінок або всіх сторінок сайту за наявності помилок у макросах. Усунути це можна шляхом встановлення значення в '%1%'.",
    httpsCheckValidCertificate: "Сертифікат вашого веб-сайту відзначений як перевірений.",
    httpsCheckInvalidCertificate: "Помилка перевірки сертифіката: '%0%'",
    httpsCheckIsCurrentSchemeHttps: "Зараз Ви %0% переглядаєте сайт, використовуючи протокол HTTPS.",
    compilationDebugCheckSuccessMessage: "Режим компіляції з налагодженням вимкнено.",
    compilationDebugCheckErrorMessage: "Режим компіляції з налагодженням зараз увімкнено. Перед розміщенням сайту в мережі рекомендується вимкнути.",
    clickJackingCheckHeaderFound: "Заголовок або мета-тег <strong>X-Frame-Options</strong>, що використовується для управління можливістю розміщувати сайт у IFRAME на іншому сайті, знайдено.",
    clickJackingCheckHeaderNotFound: "Заголовок або мета-тег <strong>X-Frame-Options</strong>, що використовується для управління можливістю розміщувати сайт у IFRAME на іншому сайті, не знайдено.",
    noSniffCheckHeaderFound: "Заголовок або мета-тег <strong>X-Content-Type-Options</strong>, що використовується для захисту від MIME-уязвимостей, знайдено.",
    noSniffCheckHeaderNotFound: "Заголовок або мета-тег <strong>X-Content-Type-Options</strong>, що використовується для захисту від MIME-уязвимостей, не знайдено.",
    hSTSCheckHeaderFound: "Заголовок <strong>Strict-Transport-Security</strong>, відомий також як HSTS-header, знайдено.",
    hSTSCheckHeaderNotFound: "Заголовок <strong>Strict-Transport-Security</strong> не знайдено.",
    xssProtectionCheckHeaderFound: "Заголовок <strong>X-XSS-Protection</strong> знайдено.",
    xssProtectionCheckHeaderNotFound: "Заголовок <strong>X-XSS-Protection</strong> не знайдено.",
    excessiveHeadersFound: "Виявлено наступні заголовки, що дозволяють з'ясувати базову технологію сайту: <strong>%0%</strong>.",
    excessiveHeadersNotFound: "Заголовки, які дають змогу з'ясувати базову технологію сайту, не виявлено.",
    smtpMailSettingsConnectionSuccess: "Параметри надсилання електронної пошти (SMTP) налаштовані коректно, сервіс працює як очікується.",
    notificationEmailsCheckSuccessMessage: "Адреса для надсилання повідомлень є наступною: <strong>%0%</strong>.",
    notificationEmailsCheckErrorMessage: "Адреса для надсилання повідомлень все ще встановлена за замовчуванням <strong>%0%</strong>."
  },
  help: {
    theBestUmbracoVideoTutorials: "Найкращі навчальні відео-курси з Umbraco"
  },
  imagecropper: {
    reset: "Скинути"
  },
  installer: {
    databaseErrorCannotConnect: "Програма інсталяції не може встановити підключення до бази даних.",
    databaseFound: "База даних виявлена та ідентифікована як",
    databaseHeader: "Конфігурація бази даних",
    databaseInstall: `
		Натисніть кнопку <strong>Встановити</strong> щоб встановити базу даних Umbraco %0%
		`,
    databaseInstallDone: "Ваша База даних налаштована для роботи Umbraco %0%. Натисніть кнопку <strong>Далі</strong> для продовження.",
    databaseText: `Для завершення цього кроку Вам потрібно мати деяку інформацію про Ваш сервер бази даних
		(рядок підключення "connection string")<br />
		Будь ласка, зв'яжіться з Вашим хостинг-провайдером, якщо є необхідність, а якщо встановлюєте на локальну робочу станцію або сервер, отримайте інформацію у Вашого системного адміністратора.`,
    databaseUpgrade: `
		<p>Натисніть кнопку <strong>Оновлення</strong>
		для того, щоб привести Вашу базу даних
		у відповідність до версії Umbraco %0%</p>
		<p>Будь ласка, не хвилюйтеся, жодного рядка Вашої бази даних
		не буде втрачено при цій операції, і після її завершення все буде працювати!</p>
		`,
    databaseUpgradeDone: "Вашу базу даних успішно оновлено до останньої версії %0%.<br/>Натисніть <strong>Далі</strong> для продовження. ",
    databaseUpToDate: "Вказана Вами база даних знаходиться в актуальному стані. Натисніть кнопку <strong>Далі</strong> для продовження роботи майстра налаштувань",
    defaultUserChangePass: "<strong>Пароль користувача за замовчуванням необхідно змінити!</strong>",
    defaultUserDisabled: "<strong>Користувач за замовчуванням заблокований або не має доступу до Umbraco!</strong></p><p>Не буде вжито жодних подальших дій. Натисніть кнопку <strong>Далі</strong> для продовження.",
    defaultUserPassChanged: "<strong>Пароль користувача за умовчанням успішно змінено в процесі встановлення!</strong></p><p>Немає потреби у будь-яких подальших діях. Натисніть кнопку <strong>Далі</strong> для продовження.",
    defaultUserPasswordChanged: "Пароль змінений!",
    greatStart: "Для початкового огляду можливостей системи рекомендуємо переглянути відеоматеріали для ознайомлення",
    None: "Система не встановлена.",
    permissionsAffectedFolders: "Зачеплені файли та папки",
    permissionsAffectedFoldersMoreInfo: "Більш детально про встановлення дозволів для Umbraco розказано тут",
    permissionsAffectedFoldersText: "Вам слід встановити дозволи для облікового запису ASP.NET на модифікацію наступних файлів та папок",
    permissionsAlmostPerfect: `<strong>Налаштування дозволів у Вашій системі майже повністю відповідають вимогам Umbraco!</strong>
		<br /><br />Ви маєте можливість запускати Umbraco без проблем, проте не зможете скористатися такою сильною стороною системи Umbraco, як встановлення додаткових пакетів розширень та доповнень.`,
    permissionsHowtoResolve: "Як вирішити проблему",
    permissionsHowtoResolveLink: "Натисніть тут, щоб прочитати текстову версію документа",
    permissionsHowtoResolveText: "Будь ласка, подивіться наш <strong>відео-матеріал</strong>, присвячений установці дозволів для файлів та папок в Umbraco або прочитайте текстову версію документа.",
    permissionsMaybeAnIssue: `<strong>Налаштування дозволів у Вашій файловій системі можуть бути неправильними!</strong>
		<br /><br />Ви маєте можливість запускати Umbraco без проблем,
		однак не зможете скористатися такою сильною стороною системи Umbraco як встановлення додаткових пакетів розширень та доповнень.`,
    permissionsNotReady: `<strong>Установки дозволів у файловій системі не підходять для роботи Umbraco!</strong>
		<br /><br />Якщо Ви хочете продовжити роботу з Umbraco,
		Вам необхідно скоригувати налаштування дозволів.`,
    permissionsPerfect: `<strong>Налаштування дозволів у Вашій системі ідеальні!</strong>
		<br /><br />Ви маєте можливість працювати з Umbraco в повному обсязі, включаючи встановлення додаткових пакетів розширень і доповнень!`,
    permissionsResolveFolderIssues: "Вирішення проблеми з папками",
    permissionsResolveFolderIssuesLink: "Скористайтеся цим посиланням для отримання більш детальної інформації про проблеми створення папок від імені облікового запису ASP.NET",
    permissionsSettingUpPermissions: "Встановлення дозволів на папки",
    permissionsText: `
		Системі Umbraco необхідні права на читання та запис файлів до деяких папок, щоб зберігати в них такі матеріали як, наприклад, зображення або документи PDF.
		Також подібним чином система зберігає кешовані дані вашого сайту з метою підвищення його продуктивності.
		`,
    runwayFromScratch: "Я хочу почати з 'чистої сторінки'",
    runwayFromScratchText: `
		На даний момент Ваш сайт абсолютно порожній, що є найкращим варіантом для старту
		"з чистої сторінки", щоб почати створювати власні типи документів і шаблони.
		(<a href="https://umbraco.tv/documentation/videos/for-site-builders/foundation/document-types">Тут можна дізнатися про це детальніше</a>) Ви також можете відкласти установку "Runway" на більш пізній час. Перейдіть до розділу "Розробка" та виберіть пункт "Пакети".
		`,
    runwayHeader: "Ви тільки що встановили чисту платформу Umbraco. Який крок буде наступним?",
    runwayInstalled: '"Runway" встановлений',
    runwayInstalledText: `
		Базовий пакет системи встановлено. Виберіть, які модулі Ви хочете встановити поверх
		базового пакету.<br />Нижче наведено список модулів, рекомендованих до встановлення, змініть його за необхідності, або ознайомтеся з <a href="#" onclick="toggleModules(); return false;" id="toggleModuleList">повним списком модулів</a>
		`,
    runwayOnlyProUsers: "Рекомендовано лише для досвідчених користувачів",
    runwaySimpleSite: "Я хочу почати з встановлення простого демонстраційного сайту",
    runwaySimpleSiteText: `
		<p>"Runway" - це простий демонстраційний сайт, що надає базовий перелік шаблонів та типів документів.
		Програма установки може налаштувати "Runway" для Вас автоматично,
		але Ви можете надалі вільно змінювати, розширювати чи видалити його.
		Цей демонстраційний сайт не є необхідною частиною, і Ви можете вільно
		використовувати Umbraco без нього. Однак, "Runway" надає Вам можливість
		максимально швидко познайомитися з базовими принципами та технікою побудови сайтів
		на основі Umbraco. Якщо Ви оберете варіант із встановленням "Runway",
		Вам буде запропоновано вибір базових будівельних блоків (т.зв. модулів Runway) для розширення можливостей сторінок сайту Runway.</p>
		<small><em>В "Runway" входять:</em>"Домашня" (головна) сторінка, сторінка "Початок роботи",
		сторінка встановлення модулів.<br /> <em>Додаткові модулі:</em>Базова навігація, Карта сайту, Форма зворотнього зв'язку, Галерея.</small>
		`,
    runwayWhatIsRunway: 'Що таке "Runway"',
    step1: "Крок 1 з 5: Ліцензійна угода",
    step2: "Крок 2 з 5: конфігурація бази даних",
    step3: "Крок 3 з 5: перевірка файлових дозволів",
    step4: "Крок 4 з 5: перевірка безпеки",
    step5: "Крок 5 з 5: система готова для початку роботи",
    thankYou: "Дякуємо, що вибрали Umbraco",
    theEndBrowseSite: `<h3>Огляд Вашого нового сайту</h3>Ви встановили "Runway",
		чому б не подивитися, як виглядає Ваш новий сайт?`,
    theEndFurtherHelp: `<h3>Подальше вивчення та допомога</h3>
		Отримуйте допомогу від нашої чудової спільноти користувачів, вивчайте документацію або переглядайте наші вільно розповсюджувані відео-матеріали про те, як створити власний нескладний сайт, використовувати розширення та пакети, а також короткий посібник з термінології Umbraco.`,
    theEndHeader: "Система Umbraco %0% встановлена та готова до роботи",
    theEndInstallSuccess: `Ви можете розпочати роботу <strong>прямо зараз</strong>,
		скориставшись посиланням "Почати роботу з Umbraco". <br />Якщо Ви <strong>новачок у світі Umbraco</strong>, Ви зможете знайти багато корисних посилань на ресурси на сторінці "Початок роботи".`,
    theEndOpenUmbraco: `<h3>Почніть роботу з Umbraco</h3>
		Для того, щоб почати адмініструвати свій сайт, просто відкрийте адміністративну панель Umbraco та почніть оновлювати контент, змінювати шаблони сторінок та стилі CSS або додавати нову функціональність`,
    Unavailable: "Спроба з'єднання з базою даних зазнала невдачі.",
    Version3: "Версія Umbraco 3",
    Version4: "Версія Umbraco 4",
    watch: "Дивитись",
    welcomeIntro: `Цей майстер проведе Вас через конфігураційний процес
		<strong>Umbraco %0%</strong> у формі "чистого" встановлення або оновлення попередньої версії 3.x.
		<br /><br />Натисніть кнопку <strong>"Далі"</strong> для початку роботи майстра.`
  },
  language: {
    cultureCode: "Код мови",
    displayName: "Назва мови"
  },
  lockout: {
    lockoutWillOccur: "Ви були відсутній деякий час. Було здійснено автоматичний вихід у",
    renewSession: "Оновіть зараз, щоб зберегти зроблені зміни"
  },
  login: {
    bottomText: '<p style="text-align:right;">&copy; 2001 - %0% <br /><a href="https://umbraco.com" style="text-decoration: none" target="_blank" rel="noopener">umbraco.com</a></p>',
    greeting0: "Вітаємо",
    greeting1: "Вітаємо",
    greeting2: "Вітаємо",
    greeting3: "Вітаємо",
    greeting4: "Вітаємо",
    greeting5: "Вітаємо",
    greeting6: "Вітаємо",
    instruction: "Вкажіть ім'я користувача та пароль",
    timeout: "Час сесії закінчився",
    forgottenPassword: "Забули пароль?",
    forgottenPasswordInstruction: "На email-адрес буде надіслано листа з посиланням на скидання пароля",
    requestPasswordResetConfirmation: "Буде надіслано листа з інструкціями щодо скидання пароля на вказаний email-адрес, якщо він збігається з адресою користувача",
    returnToLogin: "Повернутися до форми входу",
    setPasswordInstruction: "Будь ласка, вкажіть новий пароль",
    setPasswordConfirmation: "Ваш пароль оновлено",
    signInWith: "Увійти за допомогою",
    resetCodeExpired: "Посилання, по якому Ви потрапили сюди, неправильне або застаріло",
    resetPasswordEmailCopySubject: "Umbraco: скидання пароля",
    resetPasswordEmailCopyFormat: `
        <html>
			<head>
				<meta name='viewport' content='width=device-width'>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
			</head>
			<body class='' style='font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; color: #392F54; line-height: 22px; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background: #1d1333; margin: 0; padding: 0;' bgcolor='#1d1333'>
				<style type='text/css'> @media only screen and (max-width: 620px) {table[class=body] h1 {font-size: 28px !important; margin-bottom: 10px !important; } table[class=body] .wrapper {padding: 32px !important; } table[class=body] .article {padding: 32px !important; } table[class=body] .content {padding: 24px !important; } table[class=body] .container {padding: 0 !important; width: 100% !important; } table[class=body] .main {border-left-width: 0 !important; border-radius: 0 !important; border-right-width: 0 !important; } table[class=body] .btn table {width: 100% !important; } table[class=body] .btn a {width: 100% !important; } table[class=body] .img-responsive {height: auto !important; max-width: 100% !important; width: auto !important; } } .btn-primary table td:hover {background-color: #34495e !important; } .btn-primary a:hover {background-color: #34495e !important; border-color: #34495e !important; } .btn  a:visited {color:#FFFFFF;} </style>
				<table border="0" cellpadding="0" cellspacing="0" class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;" bgcolor="#1d1333">
					<tr>
						<td style="font-family: sans-serif; font-size: 14px; vertical-align: top; padding: 24px;" valign="top">
							<table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;">
								<tr>
									<td background="https://umbraco.com/umbraco/assets/img/application/logo.png" bgcolor="#1d1333" width="28" height="28" valign="top" style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
										<!--[if gte mso 9]> <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:30px;height:30px;"> <v:fill type="tile" src="https://umbraco.com/umbraco/assets/img/application/logo.png" color="#1d1333" /> <v:textbox inset="0,0,0,0"> <![endif]-->
										<div> </div>
										<!--[if gte mso 9]> </v:textbox> </v:rect> <![endif]-->
									</td>
									<td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top"></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;' bgcolor='#1d1333'>
					<tr>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
						<td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 560px; width: 560px; margin: 0 auto; padding: 10px;' valign='top'>
							<div class='content' style='box-sizing: border-box; display: block; max-width: 560px; margin: 0 auto; padding: 10px;'>
								<br>
								<table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; border-radius: 3px; background: #FFFFFF;' bgcolor='#FFFFFF'>
									<tr>
										<td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 50px;' valign='top'>
											<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
												<tr>
													<td style='line-height: 24px; font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'>
														<h1 style='color: #392F54; font-family: sans-serif; font-weight: bold; line-height: 1.4; font-size: 24px; text-align: left; text-transform: capitalize; margin: 0 0 30px;' align='left'>
															Запитано скидання пароля
														</h1>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Ваше ім'я користувача для входу до адміністративної панелі Umbraco: <strong>%0%</strong>
														</p>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
																<tbody>
																	<tr>
																		<td style='font-family: sans-serif; font-size: 14px; vertical-align: top; border-radius: 5px; text-align: center; background: #35C786;' align='center' bgcolor='#35C786' valign='top'>
																			<a href='%1%' target='_blank' rel='noopener' style='color: #FFFFFF; text-decoration: none; -ms-word-break: break-all; word-break: break-all; border-radius: 5px; box-sizing: border-box; cursor: pointer; display: inline-block; font-size: 14px; font-weight: bold; text-transform: capitalize; background: #35C786; margin: 0; padding: 12px 30px; border: 1px solid #35c786;'>
																				Натисніть на це посилання, щоб скинути пароль
																			</a>
																		</td>
																	</tr>
																</tbody>
															</table>
														</p>
														<p style='max-width: 400px; display: block; color: #392F54; font-family: sans-serif; font-size: 14px; line-height: 20px; font-weight: normal; margin: 15px 0;'>Якщо Ви не маєте можливості натиснути на посилання, скопіюйте наступну адресу (URL) та вставте в адресний рядок Вашого браузера:</p>
															<table border='0' cellpadding='0' cellspacing='0'>
																<tr>
																	<td style='-ms-word-break: break-all; word-break: break-all; font-family: sans-serif; font-size: 11px; line-height:14px;'>
																		<font style="-ms-word-break: break-all; word-break: break-all; font-size: 11px; line-height:14px;">
																			<a style='-ms-word-break: break-all; word-break: break-all; color: #392F54; text-decoration: underline; font-size: 11px; line-height:15px;' href='%1%'>%1%</a>
																		</font>
																	</td>
																</tr>
															</table>
														</p>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
								<br><br><br>
							</div>
						</td>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
					</tr>
				</table>
			</body>
		</html>
      `
  },
  main: {
    dashboard: "Панель керування",
    sections: "Розділи",
    tree: "Вміст"
  },
  media: {
    clickToUpload: "Натисніть, щоб завантажити",
    disallowedFileType: "Неможливе завантаження цього файлу, цей тип файлів не дозволяється для завантаження",
    orClickHereToUpload: "або натисніть тут, щоб вибрати файли",
    maxFileSize: "Максимально допустимий розмір файлу: ",
    mediaRoot: "Початковий вузол медіа"
  },
  mediaPicker: {
    pickedTrashedItem: "Вибрано медіа-елемент, який в даний час видалено або знаходиться в кошику",
    pickedTrashedItems: "Вибрані медіа-елементи, які в даний час видалені або знаходяться в кошику"
  },
  member: {
    createNewMember: "Створити нового учасника",
    allMembers: "Всі учасники"
  },
  modelsBuilder: {
    buildingModels: "Побудова моделей",
    waitingMessage: "це може зайняти деякий час, будь ласка, зачекайте",
    modelsGenerated: "Моделі побудовані",
    modelsGeneratedError: "Моделі не можуть бути побудовані",
    modelsExceptionInUlog: "Процес побудови моделей завершився помилкою, подробиці у системному журналі Umbraco"
  },
  moveOrCopy: {
    choose: "Виберіть сторінку...",
    copyDone: "Вузол %0% був скопійований в %1%",
    copyTo: "Виберіть, куди має бути скопійований вузол %0%",
    moveDone: "Вузол %0% був переміщений в %1%",
    moveTo: "Виберіть, куди має бути переміщений вузол %0%",
    nodeSelected: "був обраний як батьківський вузол для нового елемента, натисніть 'Ок'.",
    noNodeSelected: "Не вибраний вузол! Будь ласка, оберіть вузол призначення, перш ніж натиснути 'Ок'.",
    notAllowedAtRoot: "Поточний вузол не може бути розміщений безпосередньо в корені дерева",
    notAllowedByContentType: "Поточний вузол не може бути розміщений у вибраному Вами вузлі через невідповідність типів.",
    notAllowedByPath: "Поточний вузол не може бути переміщений усередину своїх дочірніх вузлів",
    notValid: "Ця дія не може бути здійснена, оскільки Ви не маєте достатніх прав для здійснення дій над одним або більше дочірніми документами.",
    relateToOriginal: "Пов'язати нові копії з оригіналами"
  },
  notifications: {
    editNotifications: "Ви можете змінити повідомлення для %0%",
    notificationsSavedFor: "Повідомлення збережено для %0%",
    notifications: "Сповіщення"
  },
  packager: {
    chooseLocalPackageText: `
		Виберіть файл пакета на своєму комп'ютері, натиснувши кнопку 'Огляд'<br />
		та вказавши на потрібний файл. Пакети Umbraco зазвичай є архівами із розширенням '.zip'.
		`,
    packageLicense: "Ліцензія",
    installedPackages: "Встановлені пакети",
    noPackages: "Жодного пакету ще не встановлено",
    noPackagesDescription: "Ви поки що не встановлювали жодного пакету. Ви можете встановити локальний пакет, вибравши файл на Вашому комп'ютері, так і пакет з репозиторію, натиснувши на значок <strong>'Packages'</strong> зверху праворуч",
    packageSearch: "Пошук по пакетам",
    packageSearchResults: "Результати пошуку по",
    packageNoResults: "Нічого не знайдено за запитом",
    packageNoResultsDescription: "Будь ласка, повторіть пошук, уточнивши запит, або скористайтесь переглядом за категоріями",
    packagesPopular: "Популярні",
    packagesNew: "Нещодавно створені",
    packageHas: "має на рахунку",
    packageKarmaPoints: "очок карми",
    packageInfo: "Інформація",
    packageOwner: "Власник",
    packageContrib: "Співавтори",
    packageCreated: "Створено",
    packageCurrentVersion: "Поточна версія",
    packageNetVersion: "Версія .NET",
    packageDownloads: "Завантажень",
    packageLikes: "Подобається",
    packageCompatibility: "Сумісність",
    packageCompatibilityDescription: "Цей пакет сумісний з наступними версіями Umbraco за повідомленнями учасників спільноти. Повна сумісність не гарантується для версій зі значенням нижче 100%",
    packageExternalSources: "Зовнішні джерела",
    packageAuthor: "Автор",
    packageDocumentation: "Документація (опис)",
    packageMetaData: "Мета-дані пакету",
    packageName: "Назва пакету",
    packageNoItemsHeader: "Пакет нічого не містить",
    packageNoItemsText: `Цей файл пакета не містить жодного елемента
		для видалення.<br/><br/>Ви можете безпечно видалити цей пакет із системи, натиснувши на кнопку "Деінсталювати пакет".`,
    packageOptions: "Опції пакету",
    packageReadme: "Короткий огляд пакету",
    packageRepository: "Репозиторій пакету",
    packageUninstallConfirm: "Підтвердження деінсталяції пакету",
    packageUninstalledHeader: "Пакет деінстальований",
    packageUninstalledText: "Вказаний пакет успішно видалено із системи",
    packageUninstallHeader: "Деінсталювати пакет",
    packageUninstallText: `Сейчас Ви можете зняти позначки з тих опцій пакета, які НЕ бажаєте видаляти. Після натискання кнопки "Підтвердження деінсталяції" всі зазначені опції будуть видалені.<br />
		<span style="color: Red; font-weight: bold;">Зверніть увагу:</span> всі документи, медіа-файли та інший контент, що залежить від цього пакета, перестане нормально працювати, що може призвести до нестабільної поведінки системи,
		тому видаляйте пакети дуже обережно. За наявності сумнівів, зв'яжіться з автором пакета.`,
    packageVersion: "Версія пакету"
  },
  paste: {
    doNothing: "Вставити, повністю зберігши форматування (не рекомендується)",
    errorMessage: "Текст, який Ви намагаєтесь вставити, містить спеціальні символи та/або елементи форматування. Це можливо, якщо ви вставляєте текст, скопійований з Microsoft Word або подібного редактора. Система може видалити ці елементи автоматично, щоб зробити текст, що вставляється, більш придатним для веб-публікації.",
    removeAll: "Вставити як простий текст без форматування",
    removeSpecialFormattering: "Вставити з очищенням форматування (рекомендується)"
  },
  placeholders: {
    confirmPassword: "Підтвердіть пароль",
    email: "Вкажіть Ваш email...",
    enterDescription: "Вкажіть опис...",
    enteremail: "Вкажіть email...",
    enterMessage: "Вкажіть повідомлення...",
    entername: "Вкажіть ім'я...",
    enterTags: "Вкажіть теги (натискайте Enter після кожного тега)...",
    enterusername: "Вкажіть ім'я користувача...",
    filter: "Вкажіть фільтр...",
    label: "Мітка...",
    nameentity: "Назвіть %0%...",
    password: "Вкажіть пароль",
    search: "Що шукати...",
    username: "Вкажіть ім'я користувача",
    usernameHint: "Ім'я користувача (зазвичай це Ваша email-адреса)"
  },
  prompt: {
    stay: "Залишитися",
    discardChanges: "Відмінити зміни",
    unsavedChanges: "Є незбережені зміни",
    unsavedChangesWarning: "Ви впевнені, що хочете піти з цієї сторінки? - на ній є незбережені зміни"
  },
  publicAccess: {
    paAdvanced: "Розширений: Захист на основі ролей (груп)",
    paAdvancedHelp: "Застосовуйте, якщо бажаєте контролювати доступ до документа на основі рольової моделі безпеки,<br /> із використанням груп учасників Umbraco.",
    paAdvancedNoGroups: "Вам необхідно створити хоча б одну групу для застосування рольової моделі безпеки.",
    paErrorPage: "Сторінка повідомлення про помилку",
    paErrorPageHelp: "Використовується у випадку, коли користувач авторизований у системі, але не має доступу до документа.",
    paHowWould: "Виберіть спосіб обмеження доступу до документа",
    paIsProtected: "Правила доступу до документа %0% встановлені",
    paIsRemoved: "Правила доступу до документа %0% видалені",
    paLoginPage: "Сторінка авторизації (входу)",
    paLoginPageHelp: "Використовуйте як сторінку з формою для авторизації користувачів",
    paRemoveProtection: "Зняти захист",
    paSelectPages: "Виберіть сторінки авторизації та повідомлень про помилки",
    paSelectRoles: "Виберіть ролі користувачів, які мають доступ до документа",
    paSetLogin: "Встановіть ім'я користувача та пароль для доступу до цього документа",
    paSimple: "Простий: Захист по імені користувача та паролю",
    paSimpleHelp: "Застосовуйте, якщо хочете встановити найпростіший спосіб доступу до документа - явно вказані ім'я користувача та пароль"
  },
  publish: {
    contentPublishedFailedAwaitingRelease: `
      Документ %0% не можна опубліковати зараз, оскільки для нього встановлено розклад публікації.
    `,
    contentPublishedFailedByEvent: `
		Документ %0% не можна опубліковати. Операцію скасував встановлений у системі пакет доповнень.
		`,
    contentPublishedFailedExpired: `
      Документ %0% не можна опубліковати, тому що поточна інформація в ньому застаріла.
    `,
    contentPublishedFailedByParent: `
      Документ %0% не можна опубліковати, тому що не опубліковано його батьківський документ.
    `,
    contentPublishedFailedInvalid: `
      Документ %0% не можна опубліковати, тому що не всі його властивості пройшли перевірку згідно з встановленими правилами валідації.
    `,
    includeUnpublished: "Включно з неопублікованими дочірніми документами",
    inProgress: "Йде публікація. Будь ласка зачекайте...",
    inProgressCounter: "%0% з %1% документів опубліковано...",
    nodePublish: "Документ %0% опубліковано.",
    nodePublishAll: "Документ %0% та його дочірні документи опубліковані",
    publishAll: "Опублікувати документ %0% та всі його дочірні документи",
    publishHelp: `Натисніть кнопку <em>Опублікувати</em> для публікації документа <strong>%0%</strong>.
		Таким чином Ви зробите вміст документа доступним для перегляду.<br /><br />
		Ви можете опублікувати цей документ та всі його дочірні документи, відмітивши опцію <em>Опублікувати усі дочірні документи</em>.
		Щоб опублікувати раніше неопубліковані документи серед дочірніх, відмітьте опцію <em>Включаючи неопубліковані дочірні документи</em>.
		`
  },
  redirectUrls: {
    disableUrlTracker: "Зупинити відстеження URL",
    enableUrlTracker: "Запустити відстеження URL",
    originalUrl: "Початковий URL",
    redirectedTo: "Перенаправлено в",
    noRedirects: "На даний момент немає жодного перенаправлення",
    noRedirectsDescription: "Якщо опублікований документ перейменовується або змінює розташування в дереві, а отже, змінюється адреса (URL), автоматично створюється перенаправлення на нове розташування цього документа.",
    redirectRemoved: "Перенаправлення видалено.",
    redirectRemoveError: "Помилка видалення перенаправлення.",
    confirmDisable: "Ви впевнені, що хочете зупинити відстеження URL?",
    disabledConfirm: "Відстеження URL зараз зупинено.",
    disableError: "Помилка зупинки відстеження URL, докладніші відомості знаходяться в системному журналі.",
    enabledConfirm: "Відстеження URL зараз запущено.",
    enableError: "Помилка запуску відстеження URL, докладніші відомості знаходяться в системному журналі."
  },
  relatedlinks: {
    caption: "Заголовок",
    captionPlaceholder: "Вкажіть заголовок посилання",
    chooseInternal: "вибрати сторінку сайту",
    enterExternal: "вказати зовнішнє посилання",
    externalLinkPlaceholder: "Вкажіть посилання",
    link: "Посилання",
    newWindow: "Відкрити у новому вікні"
  },
  renamecontainer: {
    renamed: "Перейменована",
    enterNewFolderName: "Вкажіть тут нову назву для папки",
    folderWasRenamed: "'%0%' була перейменована на '%1%'"
  },
  rollback: {
    diffHelp: "Тут показано різницю між останньою версією документа і обраною Вами версією.<br /><del>Червоним</del> відзначено текст, якого вже немає в останній версії, <ins>зеленим</ins> - текст, який був доданий",
    documentRolledBack: "Зроблено відкат до ранньої версії",
    htmlHelp: "Поточна версія показана як HTML. Щоб переглянути відмінності у версіях, виберіть режим порівняння",
    rollbackTo: "Відкатати до версії",
    selectVersion: "Виберіть версію",
    view: "Перегляд"
  },
  scripts: {
    editscript: "Редагувати файл скрипта"
  },
  sections: {
    concierge: "Консьєрж",
    content: "Вміст",
    courier: "Кур'єр",
    developer: "Розробка",
    forms: "Форми",
    help: "Допомога",
    installer: "Майстер конфігурування Umbraco",
    media: "Медіа-матеріали",
    member: "Учасники",
    newsletters: "Розсилки",
    settings: "Налаштування",
    statistics: "Статистика",
    translation: "Переклад",
    users: "Користувачі"
  },
  settings: {
    addIcon: "Додати піктограму",
    contentTypeEnabled: "Батьківський тип контенту дозволено",
    contentTypeUses: "Цей тип контенту використовує",
    defaulttemplate: "Шаблон за замовчуванням",
    importDocumentTypeHelp: `Щоб імпортувати тип документа, знайдіть файл ".udt" на своєму комп'ютері, натиснувши кнопку "Огляд", потім натисніть "Імпортувати" (на наступному екрані буде запитано підтвердження для цієї операції).`,
    newtabname: "Заголовок нової вкладки",
    nodetype: "Тип вузла (документу)",
    noPropertiesDefinedOnTab: 'Для цієї вкладки не визначено характеристики. Клацніть на посилання "Click here to add a new property" зверху, щоб створити нову властивість.',
    objecttype: "Тип",
    script: "Скрипт",
    stylesheet: "Стилі CSS",
    tab: "Вкладка",
    tabname: "Заголовок вкладки",
    tabs: "Вкладки"
  },
  shortcuts: {
    addGroup: "Додати вкладку",
    addProperty: "Додати властивість",
    addEditor: "Додати редактор",
    addTemplate: "Додати шаблон",
    addChildNode: "Додати дочірній вузол",
    addChild: "Додати дочірній",
    editDataType: "Змінити тип даних",
    navigateSections: "Навігація по розділам",
    shortcut: "Ярлики",
    showShortcuts: "показати ярлики",
    toggleListView: "У форматі списку",
    toggleAllowAsRoot: "Дозволити як кореневий",
    commentLine: "Закоментувати/розкоментувати рядки",
    removeLine: "Видалити рядок",
    copyLineUp: "Копіювати рядки вгору",
    copyLineDown: "Копіювати рядки вниз",
    moveLineUp: "Перемістити рядки вгору",
    moveLineDown: "Перемістити рядки вниз",
    generalHeader: "Загальне",
    editorHeader: "Редактор"
  },
  sort: {
    sortOrder: "Порядок сортування",
    sortCreationDate: "Дата створення",
    sortDone: "Сортування завершено",
    sortHelp: "Перетягуйте елементи на потрібне місце вгору або вниз для визначення потрібного порядку сортування. Також можна використовувати заголовки стовпців, щоб відсортувати всі елементи одразу.",
    sortPleaseWait: "Зачекайте, будь ласка... Сторінки сортуються, це може зайняти деякий час."
  },
  speechBubbles: {
    contentPublishedFailedByEvent: "Процес публікації скасовано встановленим пакетом доповнень.",
    contentTypeDublicatePropertyType: "Така властивість вже існує.",
    contentTypePropertyTypeCreated: "Властивість створена",
    contentTypePropertyTypeCreatedText: "Назва: %0% <br /> Тип даних: %1%",
    contentTypePropertyTypeDeleted: "Властивість видалена",
    contentTypeSavedHeader: "Тип документа збережено",
    contentTypeTabCreated: "Вкладка створена",
    contentTypeTabDeleted: "Вкладка видалена",
    contentTypeTabDeletedText: "Вкладка з ідентифікатором (id): %0% видалена",
    contentUnpublished: "Документ прихований (публікацію скасовано)",
    cssErrorHeader: "Стиль CSS не збережено",
    cssSavedHeader: "Стиль CSS збережено",
    cssSavedText: "Стиль CSS збережено без помилок",
    dataTypeSaved: "Тип даних збережено",
    dictionaryItemSaved: "Стаття у словнику збережена",
    editContentPublishedFailedByParent: "Публікацію не завершено, оскільки батьківський документ не опубліковано",
    editContentPublishedHeader: "Документ опубліковано",
    editContentPublishedText: "і є доступним",
    editContentSavedHeader: "Документ збережено",
    editContentSavedText: "Не забудьте опублікувати, щоб зробити доступним",
    editContentSendToPublish: "Надіслано на затвердження",
    editContentSendToPublishText: "Зміни надіслані на затвердження",
    editMediaSaved: "Медіа-елемент збережено",
    editMediaSavedText: "Медіа-елемент збережено без помилок",
    editMemberSaved: "Учасник збережений",
    editStylesheetPropertySaved: "Правило стилю CSS збережено",
    editStylesheetSaved: "Стиль CSS збережено",
    editTemplateSaved: "Шаблон збережено",
    editUserError: "При збереженні користувача виникла помилка (перевірте журнали помилок)",
    editUserGroupSaved: "Група користувачів збережена",
    editUserSaved: "Користувач збережений",
    editUserTypeSaved: "Тип користувачів збережено",
    fileErrorHeader: "Файл не збережено",
    fileErrorText: "Файл не може бути збережений. Будь ласка, перевірте налаштування файлових дозволів",
    fileSavedHeader: "Файл збережено",
    fileSavedText: "Файл збережено без помилок",
    invalidUserPermissionsText: "У поточного користувача недостатньо прав, неможливо завершити операцію",
    languageSaved: "Мова збережена",
    mediaTypeSavedHeader: "Тип медіа збережено",
    memberTypeSavedHeader: "Тип учасника збережено",
    operationCancelledHeader: "Скасовано",
    operationCancelledText: "Операцію скасовано встановленим стороннім розширенням або блоком коду",
    operationFailedHeader: "Помилка",
    operationSavedHeader: "Збережено",
    partialViewErrorHeader: "Представлення не збережено",
    partialViewErrorText: "Виникла помилка при збереженні файлу",
    partialViewSavedHeader: "Представлення збережено",
    partialViewSavedText: "Представлення збережено без помилок",
    permissionsSavedFor: "Права доступу збережені для",
    templateErrorHeader: "Шаблон не збережено",
    templateErrorText: "Будь ласка, перевірте, що немає двох шаблонів з одним і тим самим аліасом (назвою)",
    templateSavedHeader: "Шаблон збережено",
    templateSavedText: "Шаблон збережено без помилок",
    validationFailedHeader: "Перевірка значень",
    validationFailedMessage: "Помилки, знайдені під час перевірки значень, мають бути виправлені, щоб було можливо зберегти документ",
    deleteUserGroupsSuccess: "Видалено %0% груп користувачів",
    deleteUserGroupSuccess: "'%0%' була видалена",
    enableUsersSuccess: "Активовано %0% користувачів",
    disableUsersSuccess: "Заблоковано %0% користувачів",
    enableUserSuccess: "'%0%' активований",
    disableUserSuccess: "'%0%' заблокований",
    setUserGroupOnUsersSuccess: "Групи користувачів встановлені",
    unlockUsersSuccess: "Розблоковано %0% користувачів",
    unlockUserSuccess: "'%0%' зараз розблоковано",
    memberExportedSuccess: "Дані учасника успішно експортовано у файл",
    memberExportedError: "Під час експорту даних учасника сталася помилка"
  },
  stylesheet: {
    aliasHelp: "Використовується синтаксис селекторів CSS, наприклад: h1, .redHeader, .blueTex",
    editstylesheet: "Змінити стиль CSS",
    editstylesheetproperty: "Змінити правило стилю CSS",
    nameHelp: "Назва правила для відображення у редакторі документа",
    preview: "Попередній перегляд",
    styles: "Стилі"
  },
  template: {
    edittemplate: "Змінити шаблон",
    insertSections: "Секції",
    insertContentArea: "Вставити контент-область",
    insertContentAreaPlaceHolder: "Вставити контейнер (placeholder)",
    insert: "Вставити",
    insertDesc: "Виберіть, що хочете вставити в шаблон",
    insertDictionaryItem: "Статтю словника",
    insertDictionaryItemDesc: "Стаття словника - це контейнер для частини тексту, що перекладається різними мовами, це дозволяє спростити створення багатомовних сайтів.",
    insertMacro: "Макрос",
    insertMacroDesc: `
      Макроси - це компоненти, що мають налаштування, які добре підходять для
      реалізації блоків, що перевикористовуються, (особливо, якщо необхідно змінювати їх зовнішній вигляд і/або поведінку за допомогою параметрів)
      таких як галереї, форми, списки тощо.
    `,
    insertPageField: "Значення поля",
    insertPageFieldDesc: `Відображає значення вказаного поля даних поточної сторінки,
       з можливістю вказати альтернативні поля та/або підстановку константи.
    `,
    insertPartialView: "Часткове представлення",
    insertPartialViewDesc: `
      Часткове представлення - це шаблон в окремому файлі, який може бути викликаний для відображення всередині
      іншого шаблону, добре підходить для реалізації фрагментів розмітки, що перевикористовуються, або для розбиття складних шаблонів на складові частини.
    `,
    mastertemplate: "Майстер-шаблон",
    noMaster: "Не вибраний",
    renderBody: "Вставити дочірній шаблон",
    renderBodyDesc: `
     Відображає вміст дочірнього шаблону за допомогою вставки конструкції
     <code>@RenderBody()</code> у вибраному місці.
      `,
    defineSection: "Визначити іменовану секцію",
    defineSectionDesc: `
         Визначає спеціальну область шаблону як іменовану секцію шляхом огортання її в конструкцію
          <code>@section { ... }</code>. Така секція може бути відображена в потрібному місці батьківського шаблону
          за допомогою конструкції <code>@RenderSection</code>.
      `,
    renderSection: "Вставити іменовану секцію",
    renderSectionDesc: `
      Відображає вміст іменованої області дочірнього шаблону за допомогою вставки конструкції <code>@RenderSection(name)</code>.
      Таким чином, з дочірнього шаблону відображається вміст усередині конструкції. <code>@section [name]{ ... }</code>.
      `,
    sectionName: "Назва секції",
    sectionMandatory: "Секція є обов'язковою",
    sectionMandatoryDesc: `
      Якщо секція позначена як обов'язкова, дочірній шаблон повинен обов'язково містити її визначення <code>@section</code>, інакше генерується помилка.
    `,
    queryBuilder: "Генератор запитів",
    itemsReturned: "елементів в результаті, за",
    iWant: "Мені потрібні",
    allContent: "всі документи",
    contentOfType: 'документи типу "%0%"',
    from: "з",
    websiteRoot: "всього сайту",
    where: "де",
    and: "та",
    is: "є",
    isNot: "не є",
    before: "до",
    beforeIncDate: "до (включаючи вибрану дату)",
    after: "після",
    afterIncDate: "після (включаючи обрану дату)",
    equals: "дорівнює",
    doesNotEqual: "не дорівнює",
    contains: "містить",
    doesNotContain: "не містить",
    greaterThan: "більше ніж",
    greaterThanEqual: "більше або дорівнює",
    lessThan: "менше ніж",
    lessThanEqual: "менше або дорівнює",
    id: "Id",
    name: "Назва",
    createdDate: "Створено",
    lastUpdatedDate: "Оновлено",
    orderBy: "сортувати",
    ascending: "за зростанням",
    descending: "за спаданням",
    template: "Шаблон"
  },
  templateEditor: {
    addDefaultValue: "Додати значення за замовчуванням",
    defaultValue: "Значення за замовчуванням",
    alternativeField: "Поле заміни",
    alternativeText: "Значення за замовчуванням",
    casing: "Реєстр",
    chooseField: "Вибрати поле",
    convertLineBreaks: "Перетворити розриви рядків",
    convertLineBreaksHelp: "Змінює розриви рядків на тег html 'br'",
    customFields: "Користувальницькі",
    dateOnly: "Тільки дата",
    encoding: "Кодування",
    formatAsDate: "Форматувати як дату",
    htmlEncode: "Кодування HTML",
    htmlEncodeHelp: "Замінює спецсимволи еквівалентами у форматі HTML",
    insertedAfter: "Буде вставлено після поля",
    insertedBefore: "Буде вставлено перед полем",
    lowercase: "У нижньому регістрі",
    none: "-Не вказано-",
    outputSample: "Приклад результату",
    postContent: "Вставити після поля",
    preContent: "Вставити перед полем",
    recursive: "Рекурсивно",
    recursiveDescr: "Так, використовувати рекурсію",
    standardFields: "Стандартні",
    uppercase: "У верхньому регістрі",
    urlEncode: "Кодування URL",
    urlEncodeHelp: "Форматування спеціальних символів у URL",
    usedIfAllEmpty: "Це значення буде використано лише якщо попередні поля порожні",
    usedIfEmpty: "Це значення буде використано лише якщо первинне поле порожнє",
    withTime: "Дата і час"
  },
  textbox: {
    characters_left: "символів залишилося"
  },
  translation: {
    details: "Подробиці перекладу",
    DownloadXmlDTD: "Загрузити xml DTD",
    fields: "Поля",
    includeSubpages: "Включити дочірні документи",
    mailBody: `
		Вітаємо, %0%.

		Цей автоматично згенерований лист був відправлений, щоб поінформувати Вас про те,
		що документ '%1%' був надісланий для перекладу на '%5%' мову користувачем %2%.

		Перейдіть за посиланням http://%3%/translation/details.aspx?id=%4% для редагування.

		Або авторизуйтесь для перегляду Ваших завдань з перекладу
		http://%3%.

		Успіхів!

		Генератор повідомлень Umbraco.
		`,
    noTranslators: "Користувачів-перекладачів не виявлено. Будь ласка, створіть користувача з роллю перекладача, перш ніж надсилати вміст на переклад",
    pageHasBeenSendToTranslation: "Документ '%0%' був відправлений на переклад",
    sendToTranslate: "Надіслати документ '%0%' на переклад",
    totalWords: "Усього слів",
    translateTo: "Перекласти на",
    translationDone: "Переклад завершено.",
    translationDoneHelp: "Ви можете переглянути документи, перекладені Вами, натиснувши посилання нижче. Якщо буде знайдено оригінал документа, Ви побачите його та переведений варіант у режимі порівняння.",
    translationFailed: "Переклад не збережено, файл xml може бути пошкоджено",
    translationOptions: "Опції перекладу",
    translator: "Перекладач",
    uploadTranslationXml: "Завантажити перекладений xml"
  },
  treeHeaders: {
    cacheBrowser: "Огляд кешу",
    content: "Матеріали",
    contentBlueprints: "Шаблони вмісту",
    contentRecycleBin: "Корзина",
    createdPackages: "Створені пакети",
    dataTypes: "Типи даних",
    dictionary: "Словник",
    installedPackages: "Встановлені пакети",
    installSkin: "Встановити тему",
    installStarterKit: "Встановити стартовий набір",
    languages: "Мови",
    localPackage: "Встановити локальний пакет",
    macros: "Макроси",
    media: "Медіа-матеріали",
    mediaTypes: "Типи медіа-матеріалів",
    member: "Учасники",
    memberGroups: "Групи учасників",
    memberRoles: "Ролі учасників",
    memberTypes: "Типи учасників",
    documentTypes: "Типи документів",
    packager: "Пакети доповнень",
    packages: "Пакети доповнень",
    partialViews: "Часткові представлення",
    partialViewMacros: "Файли макросів",
    relationTypes: "Типи зв'язків",
    repositories: "Встановити з репозиторію",
    runway: "Встановити Runway",
    runwayModules: "Модулі Runway ",
    scripting: "Файли скриптів",
    scripts: "Скрипти",
    stylesheets: "Стилі CSS",
    templates: "Шаблони",
    users: "Користувачі"
  },
  update: {
    updateAvailable: "Доступні оновлення",
    updateDownloadText: "Оновлення %0% готово, натисніть для завантаження",
    updateNoServer: "Немає зв'язку із сервером",
    updateNoServerError: "Під час перевірки оновлень виникла помилка. Будь ласка, перегляньте журнал для отримання додаткової інформації."
  },
  user: {
    access: "Доступ",
    accessHelp: "На підставі встановлених груп та призначених початкових вузлів, користувач має доступ до наступних вузлів.",
    administrators: "Адміністратор",
    assignAccess: "Призначення доступу",
    backToUsers: "Повернутись до користувачів",
    categoryField: "Поле категорії",
    change: "Змінити",
    changePassword: "Змінити пароль",
    changePasswordDescription: "Ви можете змінити свій пароль для доступу до адміністративної панелі Umbraco, заповнивши нижченаведені поля та натиснувши кнопку 'Змінити пароль'",
    changePhoto: "Змінити аватар",
    confirmNewPassword: "Підтвердження нового пароля",
    contentChannel: "Канал вмісту",
    createAnotherUser: "Створити ще одного користувача",
    createDate: "Створено",
    createUser: "Створити користувача",
    createUserHelp: "Створюйте нових користувачів, яким потрібний доступ до адміністративної панелі Umbraco. При створенні користувача генерується новий первинний пароль, який потрібно повідомити користувачеві.",
    descriptionField: "Поле опису",
    disabled: "Вимкнути користувача",
    documentType: "Тип документа",
    editors: "Редактор",
    excerptField: "Виключити поле",
    failedPasswordAttempts: "Невдалих спроб входу",
    goToProfile: "До профілю користувача",
    groupsHelp: "Додайте користувача до групи(ів), щоб визначити права доступу",
    inviteEmailCopySubject: "Запрошення до панелі адміністрування Umbraco",
    inviteEmailCopyFormat: `<html><body><p>Здравствуйте, %0%,<br><br>Ви були запрошені користувачем %1%, та Вам надано доступ до панелі адміністрування Umbraco.</p><p>Повідомлення від %1%: <em>%2%</em></p><p>Перейдіть по <a href="%3%" target="_blank" rel="noopener">цьому посиланні</a>, щоб прийняти запрошення.</p><p><small>Якщо ви не можете перейти за посиланням, скопіюйте нижченаведений текст посилання і вставте в адресний рядок вашого браузера.<br/><br/>%3%</small></p></body></html>
        <html>
			<head>
				<meta name='viewport' content='width=device-width'>
				<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
			</head>
			<body class='' style='font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; color: #392F54; line-height: 22px; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; background: #1d1333; margin: 0; padding: 0;' bgcolor='#1d1333'>
				<style type='text/css'> @media only screen and (max-width: 620px) {table[class=body] h1 {font-size: 28px !important; margin-bottom: 10px !important; } table[class=body] .wrapper {padding: 32px !important; } table[class=body] .article {padding: 32px !important; } table[class=body] .content {padding: 24px !important; } table[class=body] .container {padding: 0 !important; width: 100% !important; } table[class=body] .main {border-left-width: 0 !important; border-radius: 0 !important; border-right-width: 0 !important; } table[class=body] .btn table {width: 100% !important; } table[class=body] .btn a {width: 100% !important; } table[class=body] .img-responsive {height: auto !important; max-width: 100% !important; width: auto !important; } } .btn-primary table td:hover {background-color: #34495e !important; } .btn-primary a:hover {background-color: #34495e !important; border-color: #34495e !important; } .btn  a:visited {color:#FFFFFF;} </style>
				<table border="0" cellpadding="0" cellspacing="0" class="body" style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;" bgcolor="#1d1333">
					<tr>
						<td style="font-family: sans-serif; font-size: 14px; vertical-align: top; padding: 24px;" valign="top">
							<table style="border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;">
								<tr>
									<td background="https://umbraco.com/umbraco/assets/img/application/logo.png" bgcolor="#1d1333" width="28" height="28" valign="top" style="font-family: sans-serif; font-size: 14px; vertical-align: top;">
										<!--[if gte mso 9]> <v:rect xmlns:v="urn:schemas-microsoft-com:vml" fill="true" stroke="false" style="width:30px;height:30px;"> <v:fill type="tile" src="https://umbraco.com/umbraco/assets/img/application/logo.png" color="#1d1333" /> <v:textbox inset="0,0,0,0"> <![endif]-->
										<div> </div>
										<!--[if gte mso 9]> </v:textbox> </v:rect> <![endif]-->
									</td>
									<td style="font-family: sans-serif; font-size: 14px; vertical-align: top;" valign="top"></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
				<table border='0' cellpadding='0' cellspacing='0' class='body' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #1d1333;' bgcolor='#1d1333'>
					<tr>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
						<td class='container' style='font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; max-width: 560px; width: 560px; margin: 0 auto; padding: 10px;' valign='top'>
							<div class='content' style='box-sizing: border-box; display: block; max-width: 560px; margin: 0 auto; padding: 10px;'>
								<br>
								<table class='main' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; border-radius: 3px; background: #FFFFFF;' bgcolor='#FFFFFF'>
									<tr>
										<td class='wrapper' style='font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 50px;' valign='top'>
											<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;'>
												<tr>
													<td style='line-height: 24px; font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'>
														<h1 style='color: #392F54; font-family: sans-serif; font-weight: bold; line-height: 1.4; font-size: 24px; text-align: left; text-transform: capitalize; margin: 0 0 30px;' align='left'>
															Вітаємо, %0%,
														</h1>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Ви були запрошені користувачем <a href="mailto:%4%" style="text-decoration: underline; color: #392F54; -ms-word-break: break-all; word-break: break-all;">%1%</a> в панель адміністрування веб-сайту.
														</p>
														<p style='color: #392F54; font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0 0 15px;'>
															Повідомлення від користувача <a href="mailto:%1%" style="text-decoration: none; color: #392F54; -ms-word-break: break-all; word-break: break-all;">%1%</a>:
															<br/>
															<em>%2%</em>
														</p>
														<table border='0' cellpadding='0' cellspacing='0' class='btn btn-primary' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; box-sizing: border-box;'>
															<tbody>
																<tr>
																	<td align='left' style='font-family: sans-serif; font-size: 14px; vertical-align: top; padding-bottom: 15px;' valign='top'>
																		<table border='0' cellpadding='0' cellspacing='0' style='border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;'>
																			<tbody>
																				<tr>
																					<td style='font-family: sans-serif; font-size: 14px; vertical-align: top; border-radius: 5px; text-align: center; background: #35C786;' align='center' bgcolor='#35C786' valign='top'>
																						<a href='%3%' target='_blank' rel='noopener' style='color: #FFFFFF; text-decoration: none; -ms-word-break: break-all; word-break: break-all; border-radius: 5px; box-sizing: border-box; cursor: pointer; display: inline-block; font-size: 14px; font-weight: bold; text-transform: capitalize; background: #35C786; margin: 0; padding: 12px 30px; border: 1px solid #35c786;'>
																							Натисніть на це посилання, щоб прийняти запрошення
																						</a>
																					</td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
															</tbody>
														</table>
														<p style='max-width: 400px; display: block; color: #392F54; font-family: sans-serif; font-size: 14px; line-height: 20px; font-weight: normal; margin: 15px 0;'>Якщо Ви не маєте можливості натиснути на посилання, скопіюйте наступну адресу (URL) та вставте в адресний рядок Вашого браузера:</p>
															<table border='0' cellpadding='0' cellspacing='0'>
																<tr>
																	<td style='-ms-word-break: break-all; word-break: break-all; font-family: sans-serif; font-size: 11px; line-height:14px;'>
																		<font style="-ms-word-break: break-all; word-break: break-all; font-size: 11px; line-height:14px;">
																			<a style='-ms-word-break: break-all; word-break: break-all; color: #392F54; text-decoration: underline; font-size: 11px; line-height:15px;' href='%3%'>%3%</a>
																		</font>
																	</td>
																</tr>
															</table>
														</p>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
								<br><br><br>
							</div>
						</td>
						<td style='font-family: sans-serif; font-size: 14px; vertical-align: top;' valign='top'> </td>
					</tr>
				</table>
			</body>
      </html>
    `,
    inviteAnotherUser: "Запросити ще одного користувача",
    inviteUser: "Запросити користувача",
    inviteUserHelp: "Запросіть нових користувачів, яким потрібний доступ до адміністративної панелі Umbraco. Запрошеному буде надіслано електронного листа з інструкціями щодо доступу до Umbraco.",
    language: "Мова",
    languageHelp: "Встановіть мову відображення інтерфейсу адміністрування",
    lastLockoutDate: "Час останнього блокування",
    lastLogin: "Час останнього входу",
    lastPasswordChangeDate: "Пароль востаннє змінювався",
    loginname: "Ім'я входу (логін)",
    mediastartnode: "Початковий вузол медіа-бібліотеки",
    mediastartnodehelp: "Можна обмежити доступ до медіа-бібліотеки (якійсь її частини), задавши початковий вузол",
    mediastartnodes: "Початкові вузли медіа-бібліотеки",
    mediastartnodeshelp: "Можна обмежити доступ до медіа-бібліотеки (якихось її частин), задавши перелік початкових вузлів.",
    modules: "Розділи",
    newPassword: "Новий пароль",
    noConsole: "Вимкнути доступ до адміністративної панелі Umbraco",
    noLogin: "поки що не входив",
    noLockouts: "поки не блокувався",
    noPasswordChange: "Пароль не змінювався",
    oldPassword: "Попередній пароль",
    password: "Пароль",
    passwordChanged: "Ваш пароль доступу змінено!",
    passwordConfirm: "Підтвердіть новий пароль",
    passwordCurrent: "Поточний пароль",
    passwordEnterNew: "Вкажіть новий пароль",
    passwordInvalid: "Поточний пароль вказано неправильно",
    passwordIsBlank: "Пароль не може бути порожнім",
    passwordIsDifferent: "Новий пароль та його підтвердження не збігаються. Спробуйте ще раз",
    passwordMismatch: "Новий пароль та його підтвердження не співпадають",
    permissionReplaceChildren: "Замінити дозволи для дочірніх документів",
    permissionSelectedPages: "Ви змінюєте дозволи для таких документів:",
    permissionSelectPages: "Виберіть документи, щоб змінити їх дозволи",
    removePhoto: "Видалити аватар",
    permissionsDefault: "Права доступу за замовчуванням",
    permissionsGranular: "Атомарні права доступу",
    permissionsGranularHelp: "Можна встановити права доступу до конкретних вузлів",
    profile: "Профіль",
    resetPassword: "Скинути пароль",
    searchAllChildren: "Пошук усіх дочірніх документів",
    selectUserGroups: "Вибрати групи користувачів",
    sendInvite: "Відправити запрошення",
    sessionExpires: "Сесія закінчується через",
    sectionsHelp: "Розділи, доступні користувачеві",
    noStartNode: "Початковий вузол не заданий",
    noStartNodes: "Початкові вузли не задані",
    startnode: "Початковий вузол вмісту",
    startnodehelp: "Можна обмежити доступ до дерева вмісту (будь-якої його частини), задавши початковий вузол",
    startnodes: "Початкові вузли вмісту",
    startnodeshelp: "Можна обмежити доступ до дерева вмісту (якимось його частинам), задавши перелік початкових вузлів",
    userCreated: "Був створений",
    userCreatedSuccessHelp: "Новий первинний пароль успішно згенеровано. Для входу використовуйте наведений нижче пароль.",
    updateDate: "Час останнього оновлення",
    username: "Ім'я користувача",
    usergroup: "Група користувачів",
    userInvited: " був запрошений",
    userInvitedSuccessHelp: "Новому користувачеві було надіслано запрошення, яке містить інструкції для входу в панель Umbraco.",
    userinviteWelcomeMessage: "Привіт і ласкаво просимо до Umbraco! Все буде готове протягом декількох хвилин, нам потрібно задати пароль для входу.",
    userManagement: "Управління користувачами",
    userPermissions: "Дозволи для користувача",
    writer: "Автор",
    yourHistory: "Ваша нещодавня активність",
    yourProfile: "Ваш профіль"
  },
  validation: {
    validation: "Валідація",
    validateAsEmail: "Валідація за форматом email",
    validateAsNumber: "Валідація числового значення",
    validateAsUrl: "Валідація за форматом URL",
    enterCustomValidation: "...або вказати свої правила валідації",
    fieldIsMandatory: "Обов'язково для заповнення",
    validationRegExp: "Задайте регулярний вираз",
    minCount: "Необхідно вибрати як мінімум",
    maxCount: "Можливо вибрати максимум",
    items: "елементів",
    itemsSelected: "елементів",
    invalidDate: "Невірний формат дати",
    invalidNumber: "Не є числом",
    invalidEmail: "Невірний формат email-адреси"
  },
  logViewer: {
    selectAllLogLevelFilters: "Вибрати все",
    deselectAllLogLevelFilters: "Прибрати виділення з усього"
  }
};
export {
  e as default
};
//# sourceMappingURL=uk-ua-CDMubcHB.js.map
