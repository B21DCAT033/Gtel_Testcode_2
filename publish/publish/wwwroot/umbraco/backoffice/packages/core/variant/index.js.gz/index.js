import { U as o, a as u, v as i } from "../variant-id.class-CeC8XiHF.js";
function r(t, e) {
  return t.culture === e.culture && t.segment === e.segment;
}
export {
  o as UMB_INVARIANT_CULTURE,
  u as UmbVariantId,
  r as umbVariantObjectCompare,
  i as variantPropertiesObjectToString
};
//# sourceMappingURL=index.js.map
