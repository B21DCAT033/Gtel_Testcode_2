import { U as r } from "./workspace.element-eIsSWjJt.js";
class p {
  getPath() {
    return r.toString();
  }
  setup(t, e) {
    t.entityType = e.match.params.entityType;
  }
  destroy() {
  }
}
export {
  p as UmbWorkspaceSectionRouteEntry,
  p as api
};
//# sourceMappingURL=workspace-section-route.route-entry-D69JYK5q.js.map
