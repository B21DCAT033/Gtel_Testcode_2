import { D as t } from "./constants-D-HH3gx6.js";
import { UmbDetailStoreBase as o } from "@umbraco-cms/backoffice/store";
class m extends o {
  /**
   * Creates an instance of UmbDataTypeStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbDataTypeStore
   */
  constructor(r) {
    super(r, t.toString());
  }
}
export {
  m as UmbDataTypeFolderStore,
  m as api
};
//# sourceMappingURL=data-type-folder.store-jXk7VRPK.js.map
