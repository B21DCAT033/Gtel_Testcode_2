import { w as r } from "./constants-D-HH3gx6.js";
import { UmbItemStoreBase as e } from "@umbraco-cms/backoffice/store";
class a extends e {
  /**
   * Creates an instance of UmbDataTypeItemStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbDataTypeItemStore
   */
  constructor(t) {
    super(t, r.toString());
  }
}
export {
  a as UmbDataTypeItemStore,
  a as api
};
//# sourceMappingURL=data-type-item.store-DCBKYIgk.js.map
