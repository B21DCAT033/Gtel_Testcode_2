import { x as t } from "./constants-D-HH3gx6.js";
import { UmbMenuTreeStructureWorkspaceContextBase as r } from "@umbraco-cms/backoffice/menu";
class u extends r {
  constructor(e) {
    super(e, { treeRepositoryAlias: t });
  }
}
export {
  u as UmbDataTypeMenuStructureWorkspaceContext,
  u as default
};
//# sourceMappingURL=data-type-menu-structure.context-CB4d3LsF.js.map
