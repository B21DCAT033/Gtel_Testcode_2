import { A as e } from "./constants-D-HH3gx6.js";
import { UmbUniqueTreeStore as t } from "@umbraco-cms/backoffice/tree";
class a extends t {
  /**
   * Creates an instance of UmbDataTypeTreeStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbDataTypeTreeStore
   */
  constructor(r) {
    super(r, e.toString());
  }
}
export {
  a as UmbDataTypeTreeStore,
  a as api
};
//# sourceMappingURL=data-type-tree.store-CQqmNWpK.js.map
