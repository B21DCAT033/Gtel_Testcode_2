const e = "Umbraco.Core.DataTypes", a = [
  {
    name: "Data Type Bundle",
    alias: "Umb.Bundle.DataType",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  a as extensions,
  e as name
};
//# sourceMappingURL=umbraco-package.js.map
