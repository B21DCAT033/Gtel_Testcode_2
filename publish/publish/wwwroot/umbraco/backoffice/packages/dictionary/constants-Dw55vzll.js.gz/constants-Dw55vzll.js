import { UMB_DASHBOARD_PATH_PATTERN as A } from "@umbraco-cms/backoffice/dashboard";
import { UMB_TRANSLATION_SECTION_PATHNAME as _ } from "@umbraco-cms/backoffice/translation";
const o = "dictionary-overview", e = A.generateAbsolute({
  sectionName: _,
  dashboardPathname: o
});
export {
  o as U,
  e as a
};
//# sourceMappingURL=constants-Dw55vzll.js.map
