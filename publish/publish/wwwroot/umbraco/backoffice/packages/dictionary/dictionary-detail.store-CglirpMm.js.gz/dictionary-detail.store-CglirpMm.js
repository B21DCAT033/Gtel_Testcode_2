import { i as r } from "./paths-DZopmHn1.js";
import { UmbDetailStoreBase as o } from "@umbraco-cms/backoffice/store";
class s extends o {
  /**
   * Creates an instance of UmbDictionaryDetailStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbDictionaryDetailStore
   */
  constructor(t) {
    super(t, r.toString());
  }
}
export {
  s as UmbDictionaryDetailStore,
  s as api
};
//# sourceMappingURL=dictionary-detail.store-CglirpMm.js.map
