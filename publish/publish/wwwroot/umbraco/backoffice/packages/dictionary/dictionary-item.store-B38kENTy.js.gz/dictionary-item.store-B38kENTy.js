import { m as r } from "./paths-DZopmHn1.js";
import { UmbItemStoreBase as o } from "@umbraco-cms/backoffice/store";
class a extends o {
  /**
   * Creates an instance of UmbDictionaryItemStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbDictionaryItemStore
   */
  constructor(t) {
    super(t, r.toString());
  }
}
export {
  a as UmbDictionaryItemStore,
  a as api
};
//# sourceMappingURL=dictionary-item.store-B38kENTy.js.map
