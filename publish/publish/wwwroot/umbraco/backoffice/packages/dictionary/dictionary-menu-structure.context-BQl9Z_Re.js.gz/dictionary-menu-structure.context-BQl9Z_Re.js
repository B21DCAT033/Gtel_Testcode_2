import "@umbraco-cms/backoffice/tree";
import "@umbraco-cms/backoffice/external/backend-api";
import { o as t } from "./paths-DZopmHn1.js";
import { UmbMenuTreeStructureWorkspaceContextBase as e } from "@umbraco-cms/backoffice/menu";
class c extends e {
  constructor(r) {
    super(r, { treeRepositoryAlias: t });
  }
}
export {
  c as UmbDictionaryMenuStructureWorkspaceContext,
  c as default
};
//# sourceMappingURL=dictionary-menu-structure.context-BQl9Z_Re.js.map
