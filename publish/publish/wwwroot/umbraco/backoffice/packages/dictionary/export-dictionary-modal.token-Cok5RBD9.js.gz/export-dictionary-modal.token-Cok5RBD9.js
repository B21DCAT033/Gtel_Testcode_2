import { UmbModalToken as o } from "@umbraco-cms/backoffice/modal";
const e = new o("Umb.Modal.Dictionary.Export", {
  modal: {
    type: "sidebar",
    size: "small"
  }
});
export {
  e as U
};
//# sourceMappingURL=export-dictionary-modal.token-Cok5RBD9.js.map
