import { UmbModalToken as o } from "@umbraco-cms/backoffice/modal";
const m = new o("Umb.Modal.Dictionary.Import", {
  modal: {
    type: "sidebar",
    size: "small"
  }
});
export {
  m as U
};
//# sourceMappingURL=import-dictionary-modal.token-CKI-F1TP.js.map
