const n = "Umbraco.Core.DictionaryManagement", a = [
  {
    name: "Dictionary Management Bundle",
    alias: "Umb.Dictionary.TranslationManagement",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  a as extensions,
  n as name
};
//# sourceMappingURL=umbraco-package.js.map
