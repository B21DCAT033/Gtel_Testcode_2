import { k as r } from "./paths-BF32ZUyU.js";
import { UmbDetailStoreBase as e } from "@umbraco-cms/backoffice/store";
class i extends e {
  /**
   * Creates an instance of UmbDocumentBlueprintDetailStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbDocumentBlueprintDetailStore
   */
  constructor(t) {
    super(t, r.toString());
  }
}
export {
  i as UmbDocumentBlueprintDetailStore,
  i as api
};
//# sourceMappingURL=document-blueprint-detail.store-Ctc14hsK.js.map
