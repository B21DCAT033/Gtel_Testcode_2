import { r as t } from "./paths-BF32ZUyU.js";
import { UmbDetailStoreBase as o } from "@umbraco-cms/backoffice/store";
class a extends o {
  /**
   * Creates an instance of UmbDocumentBlueprintStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbDocumentBlueprintStore
   */
  constructor(r) {
    super(r, t.toString());
  }
}
export {
  a as UmbDocumentBlueprintFolderStore,
  a as api
};
//# sourceMappingURL=document-blueprint-folder.store-B5NoWDzi.js.map
