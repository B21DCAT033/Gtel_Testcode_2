import { h as r } from "./paths-BF32ZUyU.js";
import { UmbItemStoreBase as e } from "@umbraco-cms/backoffice/store";
class p extends e {
  /**
   * Creates an instance of UmbDocumentBlueprintItemStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbDocumentBlueprintItemStore
   */
  constructor(t) {
    super(t, r.toString());
  }
}
export {
  p as UmbDocumentBlueprintItemStore,
  p as api
};
//# sourceMappingURL=document-blueprint-item.store-D44gA2EQ.js.map
