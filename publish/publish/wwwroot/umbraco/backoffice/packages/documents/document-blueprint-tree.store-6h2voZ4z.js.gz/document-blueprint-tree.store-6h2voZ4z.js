import { o as e } from "./paths-BF32ZUyU.js";
import { UmbUniqueTreeStore as o } from "@umbraco-cms/backoffice/tree";
class s extends o {
  /**
   * Creates an instance of UmbDocumentBlueprintTreeStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbDocumentBlueprintTreeStore
   */
  constructor(r) {
    super(r, e.toString());
  }
}
export {
  s as UmbDocumentBlueprintTreeStore,
  s as api
};
//# sourceMappingURL=document-blueprint-tree.store-6h2voZ4z.js.map
