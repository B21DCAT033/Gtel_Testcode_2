import { c as t } from "./manifests-ByHRH93l.js";
import { UmbDefaultCollectionContext as e } from "@umbraco-cms/backoffice/collection";
class n extends e {
  constructor(o) {
    super(o, t);
  }
}
export {
  n as UmbDocumentCollectionContext,
  n as api
};
//# sourceMappingURL=document-collection.context-WbrgQHFT.js.map
