import { r } from "./manifests-ByHRH93l.js";
import { UmbDetailStoreBase as o } from "@umbraco-cms/backoffice/store";
class m extends o {
  /**
   * Creates an instance of UmbDocumentDetailStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbDocumentDetailStore
   */
  constructor(t) {
    super(t, r.toString());
  }
}
export {
  m as UmbDocumentDetailStore,
  m as api
};
//# sourceMappingURL=document-detail.store-BJg2eCKD.js.map
