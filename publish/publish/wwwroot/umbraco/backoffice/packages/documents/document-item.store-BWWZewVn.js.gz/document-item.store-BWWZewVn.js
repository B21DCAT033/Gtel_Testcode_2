import { p as o } from "./manifests-ByHRH93l.js";
import { UmbItemStoreBase as r } from "@umbraco-cms/backoffice/store";
class p extends r {
  /**
   * Creates an instance of UmbDocumentItemStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbDocumentItemStore
   */
  constructor(t) {
    super(t, o.toString());
  }
}
export {
  p as UmbDocumentItemStore,
  p as api
};
//# sourceMappingURL=document-item.store-BWWZewVn.js.map
