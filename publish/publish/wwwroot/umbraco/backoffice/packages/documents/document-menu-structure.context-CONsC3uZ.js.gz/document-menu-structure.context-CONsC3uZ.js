import "@umbraco-cms/backoffice/tree";
import "@umbraco-cms/backoffice/external/backend-api";
import { b as e } from "./manifests-ByHRH93l.js";
import { UmbMenuVariantTreeStructureWorkspaceContextBase as r } from "@umbraco-cms/backoffice/menu";
class n extends r {
  constructor(t) {
    super(t, { treeRepositoryAlias: e });
  }
}
export {
  n as UmbDocumentMenuStructureContext,
  n as default
};
//# sourceMappingURL=document-menu-structure.context-CONsC3uZ.js.map
