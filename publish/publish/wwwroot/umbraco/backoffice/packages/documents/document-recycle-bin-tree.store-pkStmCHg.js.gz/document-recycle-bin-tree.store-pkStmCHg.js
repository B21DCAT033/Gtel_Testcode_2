import { x as r } from "./manifests-ByHRH93l.js";
import { UmbUniqueTreeStore as o } from "@umbraco-cms/backoffice/tree";
class E extends o {
  /**
   * Creates an instance of UmbDocumentRecycleBinTreeStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbDocumentRecycleBinTreeStore
   */
  constructor(e) {
    super(e, r.toString());
  }
}
export {
  E as UmbDocumentRecycleBinTreeStore,
  E as api
};
//# sourceMappingURL=document-recycle-bin-tree.store-pkStmCHg.js.map
