import { U as o } from "./document-recycle-bin.server.data-source-1eKBuGkA.js";
import { UmbRecycleBinRepositoryBase as r } from "@umbraco-cms/backoffice/recycle-bin";
class m extends r {
  constructor(e) {
    super(e, o);
  }
}
export {
  m as UmbDocumentRecycleBinRepository,
  m as api
};
//# sourceMappingURL=document-recycle-bin.repository-yWZ0VJ-Q.js.map
