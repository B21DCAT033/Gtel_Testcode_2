import { customElement as a } from "@umbraco-cms/backoffice/external/lit";
import { UmbDefaultTreeElement as c } from "@umbraco-cms/backoffice/tree";
var u = Object.getOwnPropertyDescriptor, p = (r, m, s, n) => {
  for (var e = n > 1 ? void 0 : n ? u(m, s) : m, t = r.length - 1, l; t >= 0; t--)
    (l = r[t]) && (e = l(e) || e);
  return e;
};
const f = "umb-document-tree";
let o = class extends c {
};
o = p([
  a(f)
], o);
export {
  o as UmbDocumentTreeElement,
  o as element
};
//# sourceMappingURL=document-tree.element-Bz15inPx.js.map
