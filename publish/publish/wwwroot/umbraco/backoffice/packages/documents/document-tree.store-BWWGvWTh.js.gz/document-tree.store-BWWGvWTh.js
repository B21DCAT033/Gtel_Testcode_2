import { a as r } from "./manifests-ByHRH93l.js";
import { UmbUniqueTreeStore as t } from "@umbraco-cms/backoffice/tree";
class T extends t {
  /**
   * Creates an instance of UmbDocumentTreeStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbDocumentTreeStore
   */
  constructor(e) {
    super(e, r.toString());
  }
}
export {
  T as UmbDocumentTreeStore,
  T as default
};
//# sourceMappingURL=document-tree.store-BWWGvWTh.js.map
