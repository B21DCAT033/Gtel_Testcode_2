import { f as e } from "./constants-DpZUosyT.js";
import { UmbDetailStoreBase as o } from "@umbraco-cms/backoffice/store";
class m extends o {
  /**
   * Creates an instance of UmbDocumentTypeStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbDocumentTypeStore
   */
  constructor(t) {
    super(t, e.toString());
  }
}
export {
  m as UmbDocumentTypeDetailStore,
  m as api
};
//# sourceMappingURL=document-type-detail.store-DR99-33X.js.map
