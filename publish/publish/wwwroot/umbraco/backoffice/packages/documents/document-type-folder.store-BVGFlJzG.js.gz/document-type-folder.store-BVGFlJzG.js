import { i as r } from "./constants-DpZUosyT.js";
import { UmbDetailStoreBase as t } from "@umbraco-cms/backoffice/store";
class a extends t {
  /**
   * Creates an instance of UmbDocumentTypeStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbDocumentTypeStore
   */
  constructor(o) {
    super(o, r.toString());
  }
}
export {
  a as UmbDocumentTypeFolderStore,
  a as api
};
//# sourceMappingURL=document-type-folder.store-BVGFlJzG.js.map
