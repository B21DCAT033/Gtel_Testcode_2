import { U as e } from "./constants-DpZUosyT.js";
import "@umbraco-cms/backoffice/external/backend-api";
import "@umbraco-cms/backoffice/resources";
import "@umbraco-cms/backoffice/id";
import "@umbraco-cms/backoffice/repository";
import { UmbMenuTreeStructureWorkspaceContextBase as r } from "@umbraco-cms/backoffice/menu";
class i extends r {
  constructor(t) {
    super(t, { treeRepositoryAlias: e });
  }
}
export {
  i as UmbDocumentTypeMenuStructureWorkspaceContext,
  i as default
};
//# sourceMappingURL=document-type-menu-structure.context-Q_Maj7f1.js.map
