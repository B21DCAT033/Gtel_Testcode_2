import { a as r } from "./constants-DpZUosyT.js";
import { UmbUniqueTreeStore as o } from "@umbraco-cms/backoffice/tree";
class s extends o {
  /**
   * Creates an instance of UmbDocumentTypeTreeStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbDocumentTypeTreeStore
   */
  constructor(e) {
    super(e, r.toString());
  }
}
export {
  s as UmbDocumentTypeTreeStore,
  s as api
};
//# sourceMappingURL=document-type.tree.store-CiNm6Syd.js.map
