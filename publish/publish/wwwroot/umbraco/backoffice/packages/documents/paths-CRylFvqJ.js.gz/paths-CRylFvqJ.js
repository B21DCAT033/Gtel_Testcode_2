import { UMB_SECTION_PATH_PATTERN as e } from "@umbraco-cms/backoffice/section";
const t = "content";
e.generateAbsolute({
  sectionName: t
});
export {
  t as U
};
//# sourceMappingURL=paths-CRylFvqJ.js.map
