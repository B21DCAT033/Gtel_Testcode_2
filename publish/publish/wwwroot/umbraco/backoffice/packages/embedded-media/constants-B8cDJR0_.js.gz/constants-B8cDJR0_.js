const o = "Umb.Repository.OEmbed";
export {
  o as U
};
//# sourceMappingURL=constants-B8cDJR0_.js.map
