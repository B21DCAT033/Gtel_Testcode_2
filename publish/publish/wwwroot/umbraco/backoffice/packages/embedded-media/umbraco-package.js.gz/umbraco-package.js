const e = "Umbraco.Core.EmbeddedMedia", d = [
  {
    name: "Embedded Media Bundle",
    alias: "Umb.Bundle.EmbeddedMedia",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  d as extensions,
  e as name
};
//# sourceMappingURL=umbraco-package.js.map
