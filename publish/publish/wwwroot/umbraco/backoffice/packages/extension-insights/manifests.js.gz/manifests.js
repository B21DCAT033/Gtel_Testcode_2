import { m as a } from "./manifests-BbstC2c7.js";
export {
  a as manifests
};
//# sourceMappingURL=manifests.js.map
