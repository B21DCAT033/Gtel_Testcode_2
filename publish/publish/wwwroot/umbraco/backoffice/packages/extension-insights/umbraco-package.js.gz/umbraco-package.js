const n = "Umbraco.Core.ExtensionInsight", e = [
  {
    name: "Extension Insight Bundle",
    alias: "Umb.Bundle.ExtensionInsight",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  e as extensions,
  n as name
};
//# sourceMappingURL=umbraco-package.js.map
