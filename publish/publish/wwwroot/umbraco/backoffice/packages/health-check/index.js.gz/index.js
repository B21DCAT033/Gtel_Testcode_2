import { U as C } from "./health-check-dashboard.context-BL_IqXB2.js";
export {
  C as UMB_HEALTHCHECK_DASHBOARD_CONTEXT
};
//# sourceMappingURL=index.js.map
