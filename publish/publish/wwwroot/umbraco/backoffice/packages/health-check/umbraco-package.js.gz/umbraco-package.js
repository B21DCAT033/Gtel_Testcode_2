const e = "Umbraco.Core.HealthCheck", n = [
  {
    name: "Health Check Bundle",
    alias: "Umb.Bundle.HealthCheck",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  n as extensions,
  e as name
};
//# sourceMappingURL=umbraco-package.js.map
