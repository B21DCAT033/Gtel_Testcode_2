const e = "Umb.Menu.Help";
export {
  e as UMB_HELP_MENU_ALIAS
};
//# sourceMappingURL=index.js.map
