const e = "Umbraco.Core.Language", n = [
  {
    name: "Language Bundle",
    alias: "Umb.Bundle.Language",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  n as extensions,
  e as name
};
//# sourceMappingURL=umbraco-package.js.map
