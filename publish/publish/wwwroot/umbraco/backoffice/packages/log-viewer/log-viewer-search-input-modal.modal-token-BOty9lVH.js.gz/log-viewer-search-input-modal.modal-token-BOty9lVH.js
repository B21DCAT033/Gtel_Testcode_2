import { UmbModalToken as o } from "@umbraco-cms/backoffice/modal";
const a = new o("Umb.Modal.LogViewer.SaveSearch", {
  modal: {
    type: "dialog",
    size: "small"
  }
});
export {
  a as U
};
//# sourceMappingURL=log-viewer-search-input-modal.modal-token-BOty9lVH.js.map
