import { UmbContextToken as o } from "@umbraco-cms/backoffice/context-api";
const t = new o(
  "UmbLogViewerWorkspaceContext"
);
export {
  t as U
};
//# sourceMappingURL=logviewer-workspace.context-token-xHiG9Gw7.js.map
