const e = "Umbraco.Core.LogViewer", o = [
  {
    name: "Log Viewer Bundle",
    alias: "Umb.Bundle.LogViewer",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  o as extensions,
  e as name
};
//# sourceMappingURL=umbraco-package.js.map
