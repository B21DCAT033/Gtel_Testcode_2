import { U as n } from "./input-markdown.element-CQJE1U5E.js";
export {
  n as UmbInputMarkdownElement
};
//# sourceMappingURL=index.js.map
