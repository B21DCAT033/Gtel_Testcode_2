class t {
  async processValue(a, e) {
    const s = e.find((r) => r.alias === "defaultValue")?.value;
    return a !== void 0 ? a : s;
  }
  destroy() {
  }
}
export {
  t as UmbMarkdownPropertyValuePreset,
  t as api
};
//# sourceMappingURL=markdown-editor-property-value-preset-GHoXKPdI.js.map
