const o = "Umbraco.Core.MarkdownEditor", n = [
  {
    name: "Markdown Editor Bundle",
    alias: "Umb.Bundle.MarkdownEditor",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  n as extensions,
  o as name
};
//# sourceMappingURL=umbraco-package.js.map
