import { UmbContextToken as o } from "@umbraco-cms/backoffice/context-api";
const t = new o("UmbImagingStore"), m = "Umb.Repository.Imaging", n = "Umb.Store.Imaging";
export {
  t as U,
  m as a,
  n as b
};
//# sourceMappingURL=constants-C418HnkF.js.map
