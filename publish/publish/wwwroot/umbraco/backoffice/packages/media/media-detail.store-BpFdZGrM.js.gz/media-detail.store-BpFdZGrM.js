import { r } from "./input-upload-field.element-DpMbvzUB.js";
import { UmbDetailStoreBase as e } from "@umbraco-cms/backoffice/store";
class i extends e {
  /**
   * Creates an instance of UmbMediaDetailStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbMediaDetailStore
   */
  constructor(t) {
    super(t, r.toString());
  }
}
export {
  i as UmbMediaDetailStore,
  i as default
};
//# sourceMappingURL=media-detail.store-BpFdZGrM.js.map
