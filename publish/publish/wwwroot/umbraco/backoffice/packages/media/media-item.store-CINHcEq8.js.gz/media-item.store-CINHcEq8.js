import { u as e } from "./input-upload-field.element-DpMbvzUB.js";
import { UmbItemStoreBase as r } from "@umbraco-cms/backoffice/store";
class a extends r {
  /**
   * Creates an instance of UmbMediaItemStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbMediaItemStore
   */
  constructor(t) {
    super(t, e.toString());
  }
}
export {
  a as UmbMediaItemStore,
  a as default
};
//# sourceMappingURL=media-item.store-CINHcEq8.js.map
