import "./input-upload-field.element-DpMbvzUB.js";
import { r as t } from "./dropzone.element-DyItP5Bd.js";
import "./media-url.repository-DUerHiJb.js";
import { UmbMenuVariantTreeStructureWorkspaceContextBase as e } from "@umbraco-cms/backoffice/menu";
class m extends e {
  constructor(r) {
    super(r, { treeRepositoryAlias: t });
  }
}
export {
  m as UmbMediaMenuStructureContext,
  m as default
};
//# sourceMappingURL=media-menu-structure.context-3FcVLfhw.js.map
