import { q as r } from "./input-upload-field.element-DpMbvzUB.js";
import { UmbUniqueTreeStore as o } from "@umbraco-cms/backoffice/tree";
class E extends o {
  /**
   * Creates an instance of UmbMediaRecycleBinTreeStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbMediaRecycleBinTreeStore
   */
  constructor(e) {
    super(e, r.toString());
  }
}
export {
  E as UmbMediaRecycleBinTreeStore,
  E as api
};
//# sourceMappingURL=media-recycle-bin-tree.store-AR7luMYE.js.map
