import { U as r } from "./media-recycle-bin.server.data-source-CsPKTmut.js";
import { UmbRecycleBinRepositoryBase as o } from "@umbraco-cms/backoffice/recycle-bin";
class a extends o {
  constructor(e) {
    super(e, r);
  }
}
export {
  a as UmbMediaRecycleBinRepository,
  a as api
};
//# sourceMappingURL=media-recycle-bin.repository-DB9dfBvR.js.map
