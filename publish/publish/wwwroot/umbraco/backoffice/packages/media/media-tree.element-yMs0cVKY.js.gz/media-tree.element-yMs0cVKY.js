import { customElement as o } from "@umbraco-cms/backoffice/external/lit";
import { UmbDefaultTreeElement as p } from "@umbraco-cms/backoffice/tree";
var c = Object.getOwnPropertyDescriptor, f = (r, m, a, l) => {
  for (var e = l > 1 ? void 0 : l ? c(m, a) : m, t = r.length - 1, n; t >= 0; t--)
    (n = r[t]) && (e = n(e) || e);
  return e;
};
const u = "umb-media-tree";
let s = class extends p {
};
s = f([
  o(u)
], s);
export {
  s as UmbMediaTreeElement,
  s as element
};
//# sourceMappingURL=media-tree.element-yMs0cVKY.js.map
