import { w as r } from "./input-upload-field.element-DpMbvzUB.js";
import { UmbUniqueTreeStore as t } from "@umbraco-cms/backoffice/tree";
class T extends t {
  /**
   * Creates an instance of UmbMediaTreeStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbMediaTreeStore
   */
  constructor(e) {
    super(e, r.toString());
  }
}
export {
  T as UmbMediaTreeStore,
  T as default
};
//# sourceMappingURL=media-tree.store-EWhzCFeZ.js.map
