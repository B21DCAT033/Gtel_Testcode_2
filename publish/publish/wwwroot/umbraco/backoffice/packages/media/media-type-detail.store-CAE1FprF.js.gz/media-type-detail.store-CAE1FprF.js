import { e as t } from "./constants-vViimo-q.js";
import { UmbDetailStoreBase as r } from "@umbraco-cms/backoffice/store";
class i extends r {
  /**
   * Creates an instance of UmbMediaTypeStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbMediaTypeStore
   */
  constructor(e) {
    super(e, t.toString());
  }
}
export {
  i as UmbMediaTypeDetailStore,
  i as default
};
//# sourceMappingURL=media-type-detail.store-CAE1FprF.js.map
