import { h as e } from "./constants-vViimo-q.js";
import { UmbDetailStoreBase as o } from "@umbraco-cms/backoffice/store";
class i extends o {
  /**
   * Creates an instance of UmbMediaTypeStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbMediaTypeStore
   */
  constructor(r) {
    super(r, e.toString());
  }
}
export {
  i as UmbMediaTypeFolderStore,
  i as api
};
//# sourceMappingURL=media-type-folder.store-kEUrQYGV.js.map
