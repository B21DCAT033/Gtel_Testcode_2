import { f as e } from "./constants-vViimo-q.js";
import { UmbItemStoreBase as r } from "@umbraco-cms/backoffice/store";
class a extends r {
  /**
   * Creates an instance of UmbMediaTypeItemStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbMediaTypeItemStore
   */
  constructor(t) {
    super(t, e.toString());
  }
}
export {
  a as UmbMediaTypeItemStore,
  a as default
};
//# sourceMappingURL=media-type-item.store-d2pBwE_G.js.map
