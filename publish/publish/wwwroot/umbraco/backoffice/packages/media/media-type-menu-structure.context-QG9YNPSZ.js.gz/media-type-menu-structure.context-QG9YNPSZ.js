import { U as r } from "./constants-vViimo-q.js";
import { UmbMenuTreeStructureWorkspaceContextBase as t } from "@umbraco-cms/backoffice/menu";
class u extends t {
  constructor(e) {
    super(e, { treeRepositoryAlias: r });
  }
}
export {
  u as UmbMediaTypeMenuStructureWorkspaceContext,
  u as default
};
//# sourceMappingURL=media-type-menu-structure.context-QG9YNPSZ.js.map
