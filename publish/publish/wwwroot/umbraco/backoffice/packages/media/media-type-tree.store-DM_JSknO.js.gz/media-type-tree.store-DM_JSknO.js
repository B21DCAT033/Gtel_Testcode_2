import { a as r } from "./constants-vViimo-q.js";
import { UmbUniqueTreeStore as t } from "@umbraco-cms/backoffice/tree";
class a extends t {
  /**
   * Creates an instance of UmbMediaTypeTreeStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbMediaTypeTreeStore
   */
  constructor(e) {
    super(e, r.toString());
  }
}
export {
  a as UmbMediaTypeTreeStore,
  a as default
};
//# sourceMappingURL=media-type-tree.store-DM_JSknO.js.map
