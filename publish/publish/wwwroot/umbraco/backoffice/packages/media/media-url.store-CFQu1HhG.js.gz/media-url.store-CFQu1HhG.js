import { U as t } from "./media-url.repository-DUerHiJb.js";
import { UmbItemStoreBase as e } from "@umbraco-cms/backoffice/store";
class a extends e {
  /**
   * Creates an instance of UmbMediaUrlStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbMediaUrlStore
   */
  constructor(r) {
    super(r, t.toString());
  }
}
export {
  a as UmbMediaUrlStore,
  a as default
};
//# sourceMappingURL=media-url.store-CFQu1HhG.js.map
