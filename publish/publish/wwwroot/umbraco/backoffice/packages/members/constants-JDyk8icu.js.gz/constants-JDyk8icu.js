import "./manifests-C4T1daBS.js";
import "@umbraco-cms/backoffice/workspace";
import "@umbraco-cms/backoffice/content";
const n = {
  culture: null,
  segment: null,
  name: "",
  createDate: null,
  updateDate: null
};
export {
  n as U
};
//# sourceMappingURL=constants-JDyk8icu.js.map
