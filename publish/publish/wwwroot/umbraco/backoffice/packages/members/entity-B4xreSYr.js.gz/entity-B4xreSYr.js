import { UmbContextToken as E } from "@umbraco-cms/backoffice/context-api";
const e = new E("UmbMemberTypeTreeStore"), _ = "member-type-root", o = "member-type";
export {
  _ as U,
  o as a,
  e as b
};
//# sourceMappingURL=entity-B4xreSYr.js.map
