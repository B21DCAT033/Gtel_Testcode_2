const e = Object.freeze({
  DEFAULT: "Default",
  API: "Api"
});
export {
  e as U
};
//# sourceMappingURL=index-L-35ogTa.js.map
