import { m as e } from "./manifests-BrICGTAo.js";
import "./manifests-C4T1daBS.js";
import "@umbraco-cms/backoffice/collection";
import "@umbraco-cms/backoffice/workspace";
import "@umbraco-cms/backoffice/content";
import "@umbraco-cms/backoffice/picker-input";
import "./member-group-picker-modal.element-CPMPuZSG.js";
export {
  e as manifests
};
//# sourceMappingURL=manifests.js.map
