import { h as t } from "./member-group-picker-modal.element-CPMPuZSG.js";
import { UmbDetailStoreBase as e } from "@umbraco-cms/backoffice/store";
class m extends e {
  /**
   * Creates an instance of UmbMemberGroupDetailStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbMemberGroupDetailStore
   */
  constructor(r) {
    super(r, t.toString());
  }
}
export {
  m as UmbMemberGroupDetailStore,
  m as default
};
//# sourceMappingURL=member-group-detail.store-CBHvEui1.js.map
