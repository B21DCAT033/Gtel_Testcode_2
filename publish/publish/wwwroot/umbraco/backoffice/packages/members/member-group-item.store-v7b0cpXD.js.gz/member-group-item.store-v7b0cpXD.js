import { k as t } from "./member-group-picker-modal.element-CPMPuZSG.js";
import { UmbItemStoreBase as e } from "@umbraco-cms/backoffice/store";
class a extends e {
  /**
   * Creates an instance of UmbMemberGroupItemStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbMemberGroupItemStore
   */
  constructor(r) {
    super(r, t.toString());
  }
}
export {
  a as UmbMemberGroupItemStore,
  a as default
};
//# sourceMappingURL=member-group-item.store-v7b0cpXD.js.map
