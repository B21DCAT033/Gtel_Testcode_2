import { o as e } from "./manifests-C4T1daBS.js";
import { UmbItemStoreBase as r } from "@umbraco-cms/backoffice/store";
class a extends r {
  /**
   * Creates an instance of UmbMemberItemStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbMemberItemStore
   */
  constructor(t) {
    super(t, e.toString());
  }
}
export {
  a as UmbMemberItemStore,
  a as default
};
//# sourceMappingURL=member-item.store-to3AotJR.js.map
