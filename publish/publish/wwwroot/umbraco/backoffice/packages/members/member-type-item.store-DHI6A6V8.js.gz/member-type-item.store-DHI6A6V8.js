import { h as t } from "./input-member-type.element-9xTb0eJi.js";
import { UmbItemStoreBase as r } from "@umbraco-cms/backoffice/store";
class E extends r {
  /**
   * Creates an instance of UmbMemberTypeItemStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbMemberTypeItemStore
   */
  constructor(e) {
    super(e, t.toString());
  }
}
export {
  E as UmbMemberTypeItemStore,
  E as default
};
//# sourceMappingURL=member-type-item.store-DHI6A6V8.js.map
