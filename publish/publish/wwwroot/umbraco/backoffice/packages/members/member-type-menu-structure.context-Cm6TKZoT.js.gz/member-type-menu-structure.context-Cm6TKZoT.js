import { j as r } from "./input-member-type.element-9xTb0eJi.js";
import { UmbMenuTreeStructureWorkspaceContextBase as t } from "@umbraco-cms/backoffice/menu";
class a extends t {
  constructor(e) {
    super(e, { treeRepositoryAlias: r });
  }
}
export {
  a as UmbMemberTypeMenuStructureWorkspaceContext,
  a as default
};
//# sourceMappingURL=member-type-menu-structure.context-Cm6TKZoT.js.map
