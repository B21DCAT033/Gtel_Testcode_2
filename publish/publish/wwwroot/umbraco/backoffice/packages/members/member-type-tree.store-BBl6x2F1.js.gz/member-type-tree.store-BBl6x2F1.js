import { b as r } from "./entity-B4xreSYr.js";
import { UmbUniqueTreeStore as t } from "@umbraco-cms/backoffice/tree";
class s extends t {
  /**
   * Creates an instance of UmbMemberTypeTreeStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbMemberTypeTreeStore
   */
  constructor(e) {
    super(e, r.toString());
  }
}
export {
  s as UmbMemberTypeTreeStore,
  s as default
};
//# sourceMappingURL=member-type-tree.store-BBl6x2F1.js.map
