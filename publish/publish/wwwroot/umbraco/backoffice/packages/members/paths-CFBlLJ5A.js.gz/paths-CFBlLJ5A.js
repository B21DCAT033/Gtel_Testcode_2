import { UMB_SECTION_PATH_PATTERN as e } from "@umbraco-cms/backoffice/section";
const E = "member-management";
e.generateAbsolute({
  sectionName: E
});
export {
  E as U
};
//# sourceMappingURL=paths-CFBlLJ5A.js.map
