const e = "Umbraco.Core.MemberManagement", n = [
  {
    name: "Member Management Bundle",
    alias: "Umb.Bundle.MemberManagement",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  n as extensions,
  e as name
};
//# sourceMappingURL=umbraco-package.js.map
