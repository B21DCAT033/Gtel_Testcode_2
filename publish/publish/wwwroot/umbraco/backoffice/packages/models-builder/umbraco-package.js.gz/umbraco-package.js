const e = "Umbraco.Core.ModelsBuilder", n = [
  {
    name: "Models Builder Management Bundle",
    alias: "Umb.Bundle.ModelsBuilder",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  n as extensions,
  e as name
};
//# sourceMappingURL=umbraco-package.js.map
