import { U as o } from "./constants-C0Snq3yb.js";
import { UmbModalToken as m } from "@umbraco-cms/backoffice/modal";
const U = new m(
  o,
  {
    modal: {
      type: "sidebar",
      size: "medium"
    }
  }
);
export {
  U
};
//# sourceMappingURL=link-picker-modal.token-D9E3VS6O.js.map
