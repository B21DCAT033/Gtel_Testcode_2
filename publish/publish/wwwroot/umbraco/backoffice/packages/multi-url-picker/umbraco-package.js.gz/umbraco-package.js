const e = "Umbraco.Core.MultiUrlPicker", l = [
  {
    name: "Multi Url Picker Bundle",
    alias: "Umb.Bundle.MultiUrlPicker",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  l as extensions,
  e as name
};
//# sourceMappingURL=umbraco-package.js.map
