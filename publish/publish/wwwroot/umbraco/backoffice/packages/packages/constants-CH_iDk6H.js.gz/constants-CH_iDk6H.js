import { UmbContextToken as o } from "@umbraco-cms/backoffice/context-api";
const e = new o("UmbPackageStore"), t = "Umb.Repository.Package", A = "Umb.Store.Package";
export {
  t as U,
  A as a,
  e as b
};
//# sourceMappingURL=constants-CH_iDk6H.js.map
