import { U as E, a, b as o } from "../constants-CH_iDk6H.js";
import { UmbPackageRepository as O } from "../package.repository-C5jRBs59.js";
export {
  E as UMB_PACKAGE_REPOSITORY_ALIAS,
  a as UMB_PACKAGE_STORE_ALIAS,
  o as UMB_PACKAGE_STORE_TOKEN,
  O as UmbPackageRepository
};
//# sourceMappingURL=index.js.map
