const e = "Umbraco.Core.PackageManagement", a = [
  {
    name: "Package Management Bundle",
    alias: "Umb.Bundle.PackageManagement",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  a as extensions,
  e as name
};
//# sourceMappingURL=umbraco-package.js.map
