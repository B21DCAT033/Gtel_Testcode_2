const e = "Umbraco.Core.PerformanceProfiling", n = [
  {
    name: "Performance Profiling Bundle",
    alias: "Umb.Bundle.PerformanceProfiling",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  n as extensions,
  e as name
};
//# sourceMappingURL=umbraco-package.js.map
