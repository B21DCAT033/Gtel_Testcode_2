import { m as a } from "./manifests-Bbe0yDH2.js";
export {
  a as manifests
};
//# sourceMappingURL=manifests.js.map
