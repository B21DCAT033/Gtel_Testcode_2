class l {
  async processValue(e, a) {
    const s = a.find((t) => t.alias === "default")?.value ?? !1;
    return e !== void 0 ? e : s;
  }
  destroy() {
  }
}
export {
  l as UmbTrueFalsePropertyValuePreset,
  l as api
};
//# sourceMappingURL=true-false-property-value-preset-CxWCkYDy.js.map
