const e = "Umbraco.Core.PublishCache", n = [
  {
    name: "Publish Cache Bundle",
    alias: "Umb.Bundle.PublishCache",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  n as extensions,
  e as name
};
//# sourceMappingURL=umbraco-package.js.map
