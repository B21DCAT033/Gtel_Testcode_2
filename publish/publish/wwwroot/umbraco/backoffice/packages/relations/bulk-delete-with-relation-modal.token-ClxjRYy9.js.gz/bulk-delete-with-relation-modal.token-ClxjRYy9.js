import { UmbModalToken as o } from "@umbraco-cms/backoffice/modal";
const l = new o("Umb.Modal.BulkDeleteWithRelation", {
  modal: {
    type: "dialog"
  }
});
export {
  l as U
};
//# sourceMappingURL=bulk-delete-with-relation-modal.token-ClxjRYy9.js.map
