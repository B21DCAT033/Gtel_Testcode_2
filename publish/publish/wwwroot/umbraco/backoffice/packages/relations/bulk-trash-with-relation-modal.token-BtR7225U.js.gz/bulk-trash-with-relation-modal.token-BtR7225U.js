import { UmbModalToken as o } from "@umbraco-cms/backoffice/modal";
const l = new o("Umb.Modal.BulkTrashWithRelation", {
  modal: {
    type: "dialog"
  }
});
export {
  l as U
};
//# sourceMappingURL=bulk-trash-with-relation-modal.token-BtR7225U.js.map
