import { UmbModalToken as o } from "@umbraco-cms/backoffice/modal";
const t = new o("Umb.Modal.DeleteWithRelation", {
  modal: {
    type: "dialog"
  }
});
export {
  t as U
};
//# sourceMappingURL=delete-with-relation-modal.token-BiSZyd7F.js.map
