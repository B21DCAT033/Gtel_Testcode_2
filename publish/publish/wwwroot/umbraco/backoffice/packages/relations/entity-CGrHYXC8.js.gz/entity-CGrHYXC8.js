const T = "relation-type-root", _ = "relation-type";
export {
  T as U,
  _ as a
};
//# sourceMappingURL=entity-CGrHYXC8.js.map
