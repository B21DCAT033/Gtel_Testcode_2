import { U as e } from "./relation-type-detail.store.context-token-Dk0XD8Vu.js";
import { UmbDetailStoreBase as o } from "@umbraco-cms/backoffice/store";
class T extends o {
  /**
   * Creates an instance of UmbRelationTypeDetailStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbRelationTypeDetailStore
   */
  constructor(t) {
    super(t, e.toString());
  }
}
export {
  T as UmbRelationTypeDetailStore,
  T as default
};
//# sourceMappingURL=relation-type-detail.store-CIBrYVU4.js.map
