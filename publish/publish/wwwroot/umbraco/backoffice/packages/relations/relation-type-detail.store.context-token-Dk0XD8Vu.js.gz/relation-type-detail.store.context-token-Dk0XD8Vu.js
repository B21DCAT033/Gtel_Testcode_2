import { UmbContextToken as e } from "@umbraco-cms/backoffice/context-api";
const t = new e(
  "UmbRelationTypeDetailStore"
);
export {
  t as U
};
//# sourceMappingURL=relation-type-detail.store.context-token-Dk0XD8Vu.js.map
