import { UmbContextToken as e } from "@umbraco-cms/backoffice/context-api";
const n = new e(
  "UmbWorkspaceContext",
  void 0,
  (t) => t.getEntityType?.() === "relation-type"
);
export {
  n as U
};
//# sourceMappingURL=relation-type-workspace.context-token-D96LZ9-c.js.map
