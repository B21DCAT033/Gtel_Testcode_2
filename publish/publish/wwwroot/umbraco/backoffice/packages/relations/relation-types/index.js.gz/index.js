import { UmbRelationTypeCollectionRepository as E } from "../relation-type-collection.repository-BoynEkFv.js";
import { U as A, a as I, b as R, c as L, d as o } from "../manifests-CSolryi_.js";
import { U as P } from "../relation-type-detail.store.context-token-Dk0XD8Vu.js";
import { U as Y } from "../relation-type-workspace.context-token-D96LZ9-c.js";
import { a as e, U as r } from "../entity-CGrHYXC8.js";
import { UmbRelationTypeDetailRepository as s } from "../relation-type-detail.repository-Dhk-kMCW.js";
export {
  A as UMB_RELATION_TYPE_COLLECTION_ALIAS,
  I as UMB_RELATION_TYPE_COLLECTION_REPOSITORY_ALIAS,
  R as UMB_RELATION_TYPE_DETAIL_REPOSITORY_ALIAS,
  L as UMB_RELATION_TYPE_DETAIL_STORE_ALIAS,
  P as UMB_RELATION_TYPE_DETAIL_STORE_CONTEXT,
  e as UMB_RELATION_TYPE_ENTITY_TYPE,
  r as UMB_RELATION_TYPE_ROOT_ENTITY_TYPE,
  o as UMB_RELATION_TYPE_WORKSPACE_ALIAS,
  Y as UMB_RELATION_TYPE_WORKSPACE_CONTEXT,
  E as UmbRelationTypeCollectionRepository,
  s as UmbRelationTypeDetailRepository
};
//# sourceMappingURL=index.js.map
