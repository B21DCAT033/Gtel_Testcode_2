import { U as t, a as E } from "../relation-collection.repository-C2TUl7kE.js";
import { a as L, b as O, U as R } from "../bulk-trash-with-relation.action.kind-KJodVnkL.js";
import { U as f } from "../bulk-delete-with-relation-modal.token-ClxjRYy9.js";
import { U } from "../bulk-trash-with-relation-modal.token-BtR7225U.js";
import { U as a } from "../delete-with-relation-modal.token-BiSZyd7F.js";
import { U as p } from "../trash-with-relation-modal.token-CJFEoSES.js";
function e(_) {
  return typeof _.documentType < "u";
}
function T(_) {
  return typeof _.mediaType < "u";
}
function I(_) {
  return typeof _.type < "u";
}
export {
  f as UMB_BULK_DELETE_WITH_RELATION_CONFIRM_MODAL,
  U as UMB_BULK_TRASH_WITH_RELATION_CONFIRM_MODAL,
  a as UMB_DELETE_WITH_RELATION_CONFIRM_MODAL,
  L as UMB_ENTITY_BULK_ACTION_DELETE_WITH_RELATION_KIND,
  O as UMB_ENTITY_BULK_ACTION_TRASH_WITH_RELATION_KIND,
  R as UMB_RELATION_COLLECTION_REPOSITORY_ALIAS,
  t as UMB_RELATION_ENTITY_TYPE,
  p as UMB_TRASH_WITH_RELATION_CONFIRM_MODAL,
  E as UmbRelationCollectionRepository,
  I as isDefaultReference,
  e as isDocumentReference,
  T as isMediaReference
};
//# sourceMappingURL=index.js.map
