import { UmbModalToken as o } from "@umbraco-cms/backoffice/modal";
const t = new o("Umb.Modal.TrashWithRelation", {
  modal: {
    type: "dialog"
  }
});
export {
  t as U
};
//# sourceMappingURL=trash-with-relation-modal.token-CJFEoSES.js.map
