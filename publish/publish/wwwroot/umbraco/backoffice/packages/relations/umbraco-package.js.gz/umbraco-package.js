const e = "Umbraco.Core.Relations", n = [
  {
    name: "Relations Bundle",
    alias: "Umb.Bundle.Relations",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  n as extensions,
  e as name
};
//# sourceMappingURL=umbraco-package.js.map
