const _ = "Umbraco.RichText", T = "data-content-key";
export {
  _ as U,
  T as a
};
//# sourceMappingURL=constants-CCLuR4UJ.js.map
