import { UmbModalToken as e } from "@umbraco-cms/backoffice/modal";
const s = new e("Umb.Modal.Examine.FieldsSettings", {
  modal: {
    type: "sidebar",
    size: "small"
  }
}), i = new e("Umb.Modal.Examine.FieldsViewer", {
  modal: {
    type: "sidebar",
    size: "small"
  }
});
export {
  s as U,
  i as a
};
//# sourceMappingURL=examine-fields-viewer-modal.token-ML1Zowxx.js.map
