import { UmbModalToken as o } from "@umbraco-cms/backoffice/modal";
const e = new o("Umb.Modal.Search");
export {
  e as U
};
//# sourceMappingURL=search-modal.token-CTxun4lq.js.map
