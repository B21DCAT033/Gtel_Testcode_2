const e = "Umbraco.Core.Search", n = [
  {
    name: "Search Bundle",
    alias: "Umb.Bundle.Search",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  n as extensions,
  e as name
};
//# sourceMappingURL=umbraco-package.js.map
