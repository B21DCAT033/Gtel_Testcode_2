export const UMB_ADVANCED_SETTINGS_MENU_ALIAS = 'Umb.Menu.AdvancedSettings';
