export const UMB_SETTINGS_SECTION_ALIAS = 'Umb.Section.Settings';
export * from './paths.js';
