export const UMB_STRUCTURE_SETTINGS_MENU_ALIAS = 'Umb.Menu.StructureSettings';
