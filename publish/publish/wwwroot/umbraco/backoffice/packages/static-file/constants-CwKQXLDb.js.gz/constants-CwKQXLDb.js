import { UmbContextToken as T } from "@umbraco-cms/backoffice/context-api";
const t = new T("UmbStaticFileItemStore"), I = "Umb.Repository.StaticFileItem", E = "Umb.Store.StaticFileItem", e = new T("UmbStaticFileTreeStore"), S = "Umb.Repository.StaticFile.Tree", o = "Umb.Store.StaticFile.Tree", s = "Umb.Tree.StaticFile", i = "Umb.TreeItem.StaticFile", a = "static-file", c = "static-file-root", A = "static-file-folder";
export {
  I as U,
  E as a,
  t as b,
  S as c,
  o as d,
  s as e,
  i as f,
  a as g,
  c as h,
  A as i,
  e as j
};
//# sourceMappingURL=constants-CwKQXLDb.js.map
