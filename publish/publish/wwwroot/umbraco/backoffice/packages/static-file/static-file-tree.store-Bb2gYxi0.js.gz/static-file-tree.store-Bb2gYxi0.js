import { j as r } from "./constants-CwKQXLDb.js";
import { UmbUniqueTreeStore as t } from "@umbraco-cms/backoffice/tree";
class i extends t {
  /**
   * Creates an instance of UmbStaticFileTreeStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbStaticFileTreeStore
   */
  constructor(e) {
    super(e, r.toString());
  }
}
export {
  i as UmbStaticFileTreeStore,
  i as default
};
//# sourceMappingURL=static-file-tree.store-Bb2gYxi0.js.map
