const e = "Umbraco.Core.StaticFileManagement", n = [
  {
    name: "Static File Management Bundle",
    alias: "Umb.Bundle.StaticFileManagement",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  n as extensions,
  e as name
};
//# sourceMappingURL=umbraco-package.js.map
