import { UmbModalToken as o } from "@umbraco-cms/backoffice/modal";
import { U as a } from "./sysinfo.repository-ZruRTk51.js";
const m = new o("Umb.Modal.NewVersion", {
  modal: {
    type: "dialog",
    size: "medium"
  }
}), i = new o("Umb.Modal.Sysinfo", {
  modal: {
    type: "dialog",
    size: "medium"
  }
});
export {
  m as UMB_NEWVERSION_MODAL,
  i as UMB_SYSINFO_MODAL,
  a as UmbSysinfoRepository
};
//# sourceMappingURL=index.js.map
