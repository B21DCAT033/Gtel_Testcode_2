import { U as A } from "./tags-input.element-DrOuVmGf.js";
import { U as o, a as U, c as r, b as s } from "./constants-BHP6V-qT.js";
import { UmbTagRepository as O } from "./tag.repository-wQ3wpabd.js";
export {
  o as UMB_TAG_REPOSITORY_ALIAS,
  U as UMB_TAG_STORE_ALIAS,
  r as UMB_TAG_STORE_CONTEXT,
  s as UMB_TAG_STORE_CONTEXT_ALIAS,
  O as UmbTagRepository,
  A as UmbTagsInputElement
};
//# sourceMappingURL=index.js.map
