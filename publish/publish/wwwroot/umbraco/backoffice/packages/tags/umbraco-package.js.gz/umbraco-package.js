const e = "Umbraco.Core.TagManagement", n = "0.0.1", a = [
  {
    name: "Tags Management Bundle",
    alias: "Umb.Bundle.TagsManagement",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  a as extensions,
  e as name,
  n as version
};
//# sourceMappingURL=umbraco-package.js.map
