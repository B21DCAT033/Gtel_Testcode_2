const e = "Umbraco.Core.Telemetry", n = [
  {
    name: "Telemetry Bundle",
    alias: "Umb.Bundle.Telemetry",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  n as extensions,
  e as name
};
//# sourceMappingURL=umbraco-package.js.map
