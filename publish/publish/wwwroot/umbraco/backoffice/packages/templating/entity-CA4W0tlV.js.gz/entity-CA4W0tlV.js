const E = "stylesheet", T = "stylesheet-root", s = "stylesheet-folder";
export {
  E as U,
  T as a,
  s as b
};
//# sourceMappingURL=entity-CA4W0tlV.js.map
