import { UmbModalToken as o } from "@umbraco-cms/backoffice/modal";
const a = new o(
  "Umb.Modal.Script.CreateOptions",
  {
    modal: {
      type: "sidebar",
      size: "small"
    }
  }
);
export {
  a as U
};
//# sourceMappingURL=index-DTLu03tH.js.map
