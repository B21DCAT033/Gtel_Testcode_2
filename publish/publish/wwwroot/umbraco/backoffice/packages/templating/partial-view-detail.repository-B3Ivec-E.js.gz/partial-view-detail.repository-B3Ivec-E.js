import { U as e } from "./partial-view-detail.server.data-source-BjQtFKoW.js";
import { b as t } from "./partial-view-workspace.context-token-BPSaKQI9.js";
import { UmbDetailRepositoryBase as a } from "@umbraco-cms/backoffice/repository";
class l extends a {
  constructor(r) {
    super(r, e, t);
  }
}
export {
  l as UmbPartialViewDetailRepository,
  l as default
};
//# sourceMappingURL=partial-view-detail.repository-B3Ivec-E.js.map
