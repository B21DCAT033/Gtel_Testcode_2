import { b as r } from "./partial-view-workspace.context-token-BPSaKQI9.js";
import { UmbDetailStoreBase as e } from "@umbraco-cms/backoffice/store";
class i extends e {
  /**
   * Creates an instance of UmbPartialViewDetailStore.
   * @param {UmbControllerHostInterface} host
   * @memberof UmbPartialViewDetailStore
   */
  constructor(t) {
    super(t, r.toString());
  }
}
export {
  i as UmbPartialViewDetailStore,
  i as default
};
//# sourceMappingURL=partial-view-detail.store-BP2_QFsQ.js.map
