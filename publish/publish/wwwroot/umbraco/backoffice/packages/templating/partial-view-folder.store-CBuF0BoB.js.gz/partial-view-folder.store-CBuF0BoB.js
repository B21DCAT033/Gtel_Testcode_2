import { k as t } from "./partial-view-workspace.context-token-BPSaKQI9.js";
import { UmbDetailStoreBase as o } from "@umbraco-cms/backoffice/store";
class i extends o {
  /**
   * Creates an instance of UmbPartialViewFolderStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbPartialViewFolderStore
   */
  constructor(r) {
    super(r, t.toString());
  }
}
export {
  i as UmbPartialViewFolderStore,
  i as api
};
//# sourceMappingURL=partial-view-folder.store-CBuF0BoB.js.map
