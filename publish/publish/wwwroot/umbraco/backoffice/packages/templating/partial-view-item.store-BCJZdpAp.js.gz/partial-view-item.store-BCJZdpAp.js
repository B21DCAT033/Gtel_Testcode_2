import { c as r } from "./partial-view-workspace.context-token-BPSaKQI9.js";
import { UmbItemStoreBase as e } from "@umbraco-cms/backoffice/store";
class a extends e {
  /**
   * Creates an instance of UmbPartialViewItemStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbPartialViewItemStore
   */
  constructor(t) {
    super(t, r.toString());
  }
}
export {
  a as UmbPartialViewItemStore,
  a as default
};
//# sourceMappingURL=partial-view-item.store-BCJZdpAp.js.map
