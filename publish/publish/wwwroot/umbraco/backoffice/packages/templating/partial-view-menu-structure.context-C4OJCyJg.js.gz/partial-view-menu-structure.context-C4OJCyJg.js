import "@umbraco-cms/backoffice/server-file-system";
import "@umbraco-cms/backoffice/tree";
import "@umbraco-cms/backoffice/external/backend-api";
import { d as t } from "./partial-view-workspace.context-token-BPSaKQI9.js";
import { UmbMenuTreeStructureWorkspaceContextBase as e } from "@umbraco-cms/backoffice/menu";
class u extends e {
  constructor(r) {
    super(r, { treeRepositoryAlias: t });
  }
}
export {
  u as UmbPartialViewMenuStructureWorkspaceContext,
  u as default
};
//# sourceMappingURL=partial-view-menu-structure.context-C4OJCyJg.js.map
