import { f as o } from "./partial-view-workspace.context-token-BPSaKQI9.js";
import { UmbModalToken as e } from "@umbraco-cms/backoffice/modal";
import { UMB_TREE_PICKER_MODAL_ALIAS as _ } from "@umbraco-cms/backoffice/tree";
const a = new e(_, {
  modal: {
    type: "sidebar",
    size: "small"
  },
  data: { treeAlias: o, hideTreeRoot: !0 }
});
export {
  a as U
};
//# sourceMappingURL=partial-view-picker-modal.token-me6dTR2i.js.map
