import { h as S, U, b as W, o as V, q as B, i as r, j as t, k as o, l as e, m as C, a as N, c as i, p as m, f as D, d as p, e as Y, g as c, n as f } from "../partial-view-workspace.context-token-BPSaKQI9.js";
import { U as A } from "../manifests-ChE0t90n.js";
import { c as x, d as F, e as b, f as l, b as X, a as K } from "../manifests-ChE0t90n.js";
import { U as E } from "../partial-view-picker-modal.token-me6dTR2i.js";
import "@umbraco-cms/backoffice/workspace";
import { UmbPickerInputContext as I } from "@umbraco-cms/backoffice/picker-input";
import { UmbPartialViewDetailRepository as u } from "../partial-view-detail.repository-B3Ivec-E.js";
class a extends I {
  constructor(_) {
    super(_, A, E);
  }
}
export {
  S as UMB_DELETE_PARTIAL_VIEW_FOLDER_ENTITY_ACTION_ALIAS,
  U as UMB_PARTIAL_VIEW_CREATE_OPTIONS_MODAL,
  x as UMB_PARTIAL_VIEW_DETAIL_REPOSITORY_ALIAS,
  F as UMB_PARTIAL_VIEW_DETAIL_STORE_ALIAS,
  W as UMB_PARTIAL_VIEW_DETAIL_STORE_CONTEXT,
  V as UMB_PARTIAL_VIEW_ENTITY_TYPE,
  B as UMB_PARTIAL_VIEW_FOLDER_ENTITY_TYPE,
  r as UMB_PARTIAL_VIEW_FOLDER_REPOSITORY_ALIAS,
  t as UMB_PARTIAL_VIEW_FOLDER_STORE_ALIAS,
  o as UMB_PARTIAL_VIEW_FOLDER_STORE_CONTEXT,
  e as UMB_PARTIAL_VIEW_FOLDER_WORKSPACE_ALIAS,
  C as UMB_PARTIAL_VIEW_FOLDER_WORKSPACE_CONTEXT,
  N as UMB_PARTIAL_VIEW_FROM_SNIPPET_MODAL,
  A as UMB_PARTIAL_VIEW_ITEM_REPOSITORY_ALIAS,
  b as UMB_PARTIAL_VIEW_ITEM_STORE_ALIAS,
  i as UMB_PARTIAL_VIEW_ITEM_STORE_CONTEXT,
  E as UMB_PARTIAL_VIEW_PICKER_MODAL,
  m as UMB_PARTIAL_VIEW_ROOT_ENTITY_TYPE,
  D as UMB_PARTIAL_VIEW_TREE_ALIAS,
  p as UMB_PARTIAL_VIEW_TREE_REPOSITORY_ALIAS,
  Y as UMB_PARTIAL_VIEW_TREE_STORE_ALIAS,
  c as UMB_PARTIAL_VIEW_TREE_STORE_CONTEXT,
  l as UMB_PARTIAL_VIEW_WORKSPACE_ALIAS,
  f as UMB_PARTIAL_VIEW_WORKSPACE_CONTEXT,
  X as UMB_RENAME_PARTIAL_VIEW_ENTITY_ACTION_ALIAS,
  K as UMB_RENAME_PARTIAL_VIEW_REPOSITORY_ALIAS,
  u as UmbPartialViewDetailRepository,
  a as UmbPartialViewPickerContext,
  a as UmbPartialViewPickerInputContext
};
//# sourceMappingURL=index.js.map
