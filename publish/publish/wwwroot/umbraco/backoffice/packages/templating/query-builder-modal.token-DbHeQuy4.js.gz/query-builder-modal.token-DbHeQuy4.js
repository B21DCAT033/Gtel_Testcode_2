import { UmbModalToken as e } from "@umbraco-cms/backoffice/modal";
const a = new e("Umb.Modal.Template.QueryBuilder", {
  modal: {
    type: "sidebar",
    size: "large"
  }
});
export {
  a as U
};
//# sourceMappingURL=query-builder-modal.token-DbHeQuy4.js.map
