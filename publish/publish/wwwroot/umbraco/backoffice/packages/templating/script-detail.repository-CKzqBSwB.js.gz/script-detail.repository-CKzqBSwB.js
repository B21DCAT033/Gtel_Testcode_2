import { g as t } from "./manifests-DuLlkyg0.js";
import { U as e } from "./script-detail.server.data-source-jRKAt4lI.js";
import { UmbDetailRepositoryBase as o } from "@umbraco-cms/backoffice/repository";
class p extends o {
  constructor(r) {
    super(r, e, t);
  }
}
export {
  p as UmbScriptDetailRepository,
  p as default
};
//# sourceMappingURL=script-detail.repository-CKzqBSwB.js.map
