import { g as r } from "./manifests-DuLlkyg0.js";
import { UmbDetailStoreBase as e } from "@umbraco-cms/backoffice/store";
class i extends e {
  /**
   * Creates an instance of UmbScriptDetailStore.
   * @param {UmbControllerHostInterface} host
   * @memberof UmbScriptDetailStore
   */
  constructor(t) {
    super(t, r.toString());
  }
}
export {
  i as UmbScriptDetailStore,
  i as default
};
//# sourceMappingURL=script-detail.store-DQapv_qk.js.map
