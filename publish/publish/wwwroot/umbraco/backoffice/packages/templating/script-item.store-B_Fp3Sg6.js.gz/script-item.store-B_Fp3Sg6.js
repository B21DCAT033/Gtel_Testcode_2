import { U as r } from "./script-item.store.context-token-5j5GfCRe.js";
import { UmbItemStoreBase as e } from "@umbraco-cms/backoffice/store";
class S extends e {
  /**
   * Creates an instance of UmbScriptItemStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbScriptItemStore
   */
  constructor(t) {
    super(t, r.toString());
  }
}
export {
  S as UmbScriptItemStore,
  S as default
};
//# sourceMappingURL=script-item.store-B_Fp3Sg6.js.map
