import { UmbContextToken as t } from "@umbraco-cms/backoffice/context-api";
const e = new t("UmbScriptItemStore");
export {
  e as U
};
//# sourceMappingURL=script-item.store.context-token-5j5GfCRe.js.map
