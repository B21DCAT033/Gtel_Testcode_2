import "@umbraco-cms/backoffice/server-file-system";
import "@umbraco-cms/backoffice/tree";
import "@umbraco-cms/backoffice/external/backend-api";
import { i as t } from "./manifests-DuLlkyg0.js";
import { UmbMenuTreeStructureWorkspaceContextBase as e } from "@umbraco-cms/backoffice/menu";
class a extends e {
  constructor(r) {
    super(r, { treeRepositoryAlias: t });
  }
}
export {
  a as UmbScriptMenuStructureWorkspaceContext,
  a as default
};
//# sourceMappingURL=script-menu-structure.context-DUAhe7Hr.js.map
