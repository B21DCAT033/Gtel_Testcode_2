import { UmbModalToken as e } from "@umbraco-cms/backoffice/modal";
import { UMB_TREE_PICKER_MODAL_ALIAS as o } from "@umbraco-cms/backoffice/tree";
const a = new e(
  o,
  {
    modal: {
      type: "sidebar",
      size: "small"
    },
    data: {
      treeAlias: "Umb.Tree.Script",
      hideTreeRoot: !0
    }
  }
);
export {
  a as U
};
//# sourceMappingURL=script-picker-modal.token-40IoQpW7.js.map
