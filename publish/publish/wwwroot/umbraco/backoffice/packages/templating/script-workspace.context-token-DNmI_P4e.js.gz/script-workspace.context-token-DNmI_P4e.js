import { UmbContextToken as o } from "@umbraco-cms/backoffice/context-api";
const n = new o(
  "UmbWorkspaceContext",
  void 0,
  (t) => t.getEntityType?.() === "script"
);
export {
  n as U
};
//# sourceMappingURL=script-workspace.context-token-DNmI_P4e.js.map
