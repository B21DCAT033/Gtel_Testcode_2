import { U as t } from "./stylesheet-detail.server.data-source-C2Md6SyO.js";
import { c as r } from "./stylesheet-rule-settings-modal.token-5NdpIj8O.js";
import { UmbDetailRepositoryBase as o } from "@umbraco-cms/backoffice/repository";
class l extends o {
  constructor(e) {
    super(e, t, r);
  }
}
export {
  l as UmbStylesheetDetailRepository,
  l as default
};
//# sourceMappingURL=stylesheet-detail.repository-CC8KcT_f.js.map
