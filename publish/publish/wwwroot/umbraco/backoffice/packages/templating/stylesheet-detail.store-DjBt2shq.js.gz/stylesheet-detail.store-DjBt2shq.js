import { c as e } from "./stylesheet-rule-settings-modal.token-5NdpIj8O.js";
import { UmbDetailStoreBase as r } from "@umbraco-cms/backoffice/store";
class S extends r {
  /**
   * Creates an instance of UmbStylesheetDetailStore.
   * @param {UmbControllerHostInterface} host
   * @memberof UmbStylesheetDetailStore
   */
  constructor(t) {
    super(t, e.toString());
  }
}
export {
  S as UmbStylesheetDetailStore,
  S as default
};
//# sourceMappingURL=stylesheet-detail.store-DjBt2shq.js.map
