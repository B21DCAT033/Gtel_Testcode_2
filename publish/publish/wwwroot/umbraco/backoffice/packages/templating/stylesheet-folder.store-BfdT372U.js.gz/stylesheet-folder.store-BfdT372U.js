import { l as e } from "./manifests-CYOZ__fg.js";
import { UmbDetailStoreBase as r } from "@umbraco-cms/backoffice/store";
class a extends r {
  /**
   * Creates an instance of UmbStylesheetFolderStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbStylesheetFolderStore
   */
  constructor(t) {
    super(t, e.toString());
  }
}
export {
  a as UmbStylesheetFolderStore,
  a as api
};
//# sourceMappingURL=stylesheet-folder.store-BfdT372U.js.map
