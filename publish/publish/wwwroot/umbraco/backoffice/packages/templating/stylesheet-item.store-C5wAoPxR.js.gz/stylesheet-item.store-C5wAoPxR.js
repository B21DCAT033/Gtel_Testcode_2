import { f as e } from "./stylesheet-rule-settings-modal.token-5NdpIj8O.js";
import { UmbItemStoreBase as r } from "@umbraco-cms/backoffice/store";
class S extends r {
  /**
   * Creates an instance of UmbStylesheetItemStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbStylesheetItemStore
   */
  constructor(t) {
    super(t, e.toString());
  }
}
export {
  S as UmbStylesheetItemStore,
  S as default
};
//# sourceMappingURL=stylesheet-item.store-C5wAoPxR.js.map
