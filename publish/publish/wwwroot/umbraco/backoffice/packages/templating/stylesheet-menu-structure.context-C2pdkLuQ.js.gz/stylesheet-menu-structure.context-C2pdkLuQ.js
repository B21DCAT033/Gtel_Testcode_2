import { e as r } from "./manifests-CYOZ__fg.js";
import "@umbraco-cms/backoffice/server-file-system";
import "@umbraco-cms/backoffice/resources";
import "@umbraco-cms/backoffice/external/backend-api";
import "./stylesheet-rule-settings-modal.token-5NdpIj8O.js";
import "@umbraco-cms/backoffice/repository";
import "@umbraco-cms/backoffice/store";
import "@umbraco-cms/backoffice/id";
import "@umbraco-cms/backoffice/workspace";
import { UmbMenuTreeStructureWorkspaceContextBase as e } from "@umbraco-cms/backoffice/menu";
class T extends e {
  constructor(t) {
    super(t, { treeRepositoryAlias: r });
  }
}
export {
  T as UmbStylesheetMenuStructureWorkspaceContext,
  T as default
};
//# sourceMappingURL=stylesheet-menu-structure.context-C2pdkLuQ.js.map
