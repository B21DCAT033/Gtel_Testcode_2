import { a as e } from "./template-item.store.context-token-rCTaUJ7s.js";
import { UmbItemStoreBase as r } from "@umbraco-cms/backoffice/store";
class a extends r {
  /**
   * Creates an instance of UmbTemplateItemStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbTemplateItemStore
   */
  constructor(t) {
    super(t, e.toString());
  }
}
export {
  a as UmbTemplateItemStore,
  a as default
};
//# sourceMappingURL=template-item.store-CWC3jsVb.js.map
