import { UmbContextToken as T } from "@umbraco-cms/backoffice/context-api";
const E = "template-root", e = "template", _ = new T("UmbTemplateDetailStore"), o = new T("UmbTemplateItemStore");
export {
  _ as U,
  o as a,
  E as b,
  e as c
};
//# sourceMappingURL=template-item.store.context-token-rCTaUJ7s.js.map
