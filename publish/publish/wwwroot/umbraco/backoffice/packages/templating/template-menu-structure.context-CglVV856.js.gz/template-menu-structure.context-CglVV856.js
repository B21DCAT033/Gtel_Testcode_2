import "@umbraco-cms/backoffice/tree";
import "@umbraco-cms/backoffice/external/backend-api";
import { h as t } from "./manifests-H0KeU9t1.js";
import { UmbMenuTreeStructureWorkspaceContextBase as r } from "@umbraco-cms/backoffice/menu";
class u extends r {
  constructor(e) {
    super(e, { treeRepositoryAlias: t });
  }
}
export {
  u as UmbTemplateMenuStructureWorkspaceContext,
  u as default
};
//# sourceMappingURL=template-menu-structure.context-CglVV856.js.map
