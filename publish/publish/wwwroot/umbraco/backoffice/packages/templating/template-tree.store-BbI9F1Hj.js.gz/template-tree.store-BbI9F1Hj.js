import { k as r } from "./manifests-H0KeU9t1.js";
import { UmbUniqueTreeStore as t } from "@umbraco-cms/backoffice/tree";
class s extends t {
  /**
   * Creates an instance of UmbTemplateTreeStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbTemplateTreeStore
   */
  constructor(e) {
    super(e, r.toString());
  }
}
export {
  s as UmbTemplateTreeStore,
  s as default
};
//# sourceMappingURL=template-tree.store-BbI9F1Hj.js.map
