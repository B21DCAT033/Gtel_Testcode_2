import { UmbModalToken as e } from "@umbraco-cms/backoffice/modal";
const l = new e("Umb.Modal.TemplatingPageFieldBuilder", {
  modal: {
    type: "sidebar",
    size: "small"
  }
});
export {
  l as U
};
//# sourceMappingURL=templating-page-field-builder-modal.token-BA7RzHZB.js.map
