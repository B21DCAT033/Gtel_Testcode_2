var r = /* @__PURE__ */ ((e) => (e.partialView = "partialView", e.dictionaryItem = "dictionaryItem", e.pageField = "pageField", e))(r || {}), a = /* @__PURE__ */ ((e) => (e.renderChildTemplate = "RenderChildTemplate", e.renderANamedSection = "RenderANamedSection", e.defineANamedSection = "DefineANamedSection", e))(a || {});
export {
  r as C,
  a as T
};
//# sourceMappingURL=types--hMpZOew.js.map
