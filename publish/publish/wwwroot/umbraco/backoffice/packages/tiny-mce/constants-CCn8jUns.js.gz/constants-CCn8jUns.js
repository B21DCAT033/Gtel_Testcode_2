const _ = "Umb.PropertyEditorUi.TinyMCE";
export {
  _ as U
};
//# sourceMappingURL=constants-CCn8jUns.js.map
