import { U as s } from "./constants-CCn8jUns.js";
import { U as _, a as t, b as i, d as n, p as T, u as U } from "./input-tiny-mce.element-CKNj2_nS.js";
import { U as o } from "./tiny-mce-plugin-BKLu9hN_.js";
export {
  _ as UMB_BLOCK_ENTRY_WEB_COMPONENTS_ABSOLUTE_PATH,
  s as UMB_BLOCK_RTE_PROPERTY_EDITOR_UI_ALIAS,
  t as UmbInputTinyMceElement,
  o as UmbTinyMcePluginBase,
  i as availableLanguages,
  n as defaultFallbackConfig,
  T as pastePreProcessHandler,
  U as uriAttributeSanitizer
};
//# sourceMappingURL=index.js.map
