import { UmbControllerBase as t } from "@umbraco-cms/backoffice/class-api";
class e extends t {
  constructor(o) {
    super(o.host), this.editor = o.editor, this.configuration = o.host.configuration;
  }
}
export {
  e as U
};
//# sourceMappingURL=tiny-mce-plugin-BKLu9hN_.js.map
