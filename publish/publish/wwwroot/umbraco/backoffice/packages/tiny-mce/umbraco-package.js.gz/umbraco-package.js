const n = "Umbraco.Core.TinyMCE", e = [
  {
    name: "TinyMCE Bundle",
    alias: "Umb.Bundle.TinyMCE",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  e as extensions,
  n as name
};
//# sourceMappingURL=umbraco-package.js.map
