import { a as o } from "./base-CzBFGKJV.js";
class l extends o {
  execute(e) {
    e?.chain().focus().toggleBlockquote().run();
  }
}
export {
  l as default
};
//# sourceMappingURL=blockquote.tiptap-toolbar-api-DNVsYgyu.js.map
