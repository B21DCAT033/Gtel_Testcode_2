import { a as o } from "./base-CzBFGKJV.js";
class l extends o {
  execute(e) {
    e?.chain().focus().toggleBold().run();
  }
}
export {
  l as default
};
//# sourceMappingURL=bold.tiptap-toolbar-api-CGY7la_R.js.map
