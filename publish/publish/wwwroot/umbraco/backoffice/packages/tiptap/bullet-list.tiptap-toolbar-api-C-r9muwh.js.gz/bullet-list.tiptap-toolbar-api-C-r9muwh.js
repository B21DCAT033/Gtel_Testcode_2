import { a as t } from "./base-CzBFGKJV.js";
class o extends t {
  execute(e) {
    e?.chain().focus().toggleBulletList().run();
  }
}
export {
  o as default
};
//# sourceMappingURL=bullet-list.tiptap-toolbar-api-C-r9muwh.js.map
