import { a as e } from "./base-CzBFGKJV.js";
class s extends e {
  execute(a) {
    a?.chain().focus().unsetAllMarks().run();
  }
}
export {
  s as default
};
//# sourceMappingURL=clear-formatting.tiptap-toolbar-api-B0jhjI5c.js.map
