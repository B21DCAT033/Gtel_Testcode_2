import { a as o } from "./base-CzBFGKJV.js";
class l extends o {
  execute(e) {
    e?.chain().focus().toggleCodeBlock().run();
  }
}
export {
  l as default
};
//# sourceMappingURL=code-block.tiptap-toolbar-api-Cj1E8BmL.js.map
