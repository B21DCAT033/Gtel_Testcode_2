import { a as e } from "./base-CzBFGKJV.js";
class o extends e {
  execute() {
  }
}
export {
  o as default
};
//# sourceMappingURL=default-tiptap-toolbar-element.api-D-CoaOsg.js.map
