import { U as t } from "./base-CzBFGKJV.js";
import { Figcaption as i, Figure as s } from "@umbraco-cms/backoffice/external/tiptap";
class r extends t {
  constructor() {
    super(...arguments), this.getTiptapExtensions = () => [i, s];
  }
}
export {
  r as default
};
//# sourceMappingURL=figure.tiptap-api-70h53txb.js.map
