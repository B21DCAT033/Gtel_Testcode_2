import { a } from "./base-CzBFGKJV.js";
class l extends a {
  isActive(e) {
    return e?.isActive("heading", { level: 1 }) === !0;
  }
  execute(e) {
    e?.chain().focus().toggleHeading({ level: 1 }).run();
  }
}
export {
  l as default
};
//# sourceMappingURL=heading1.tiptap-toolbar-api-PhIYhl8p.js.map
