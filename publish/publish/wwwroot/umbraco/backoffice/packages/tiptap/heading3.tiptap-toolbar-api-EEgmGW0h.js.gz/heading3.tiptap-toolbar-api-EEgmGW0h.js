import { a } from "./base-CzBFGKJV.js";
class l extends a {
  isActive(e) {
    return e?.isActive("heading", { level: 3 }) === !0;
  }
  execute(e) {
    e?.chain().focus().toggleHeading({ level: 3 }).run();
  }
}
export {
  l as default
};
//# sourceMappingURL=heading3.tiptap-toolbar-api-EEgmGW0h.js.map
