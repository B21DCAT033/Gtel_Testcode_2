import { a } from "./base-CzBFGKJV.js";
class i extends a {
  execute(e) {
    e?.chain().focus().setHorizontalRule().run();
  }
}
export {
  i as default
};
//# sourceMappingURL=horizontal-rule.tiptap-toolbar-api-yALTbnKv.js.map
