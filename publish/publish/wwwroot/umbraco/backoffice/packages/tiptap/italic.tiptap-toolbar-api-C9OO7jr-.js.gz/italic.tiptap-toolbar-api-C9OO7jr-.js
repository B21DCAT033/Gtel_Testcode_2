import { a as e } from "./base-CzBFGKJV.js";
class i extends e {
  execute(a) {
    a?.chain().focus().toggleItalic().run();
  }
}
export {
  i as default
};
//# sourceMappingURL=italic.tiptap-toolbar-api-C9OO7jr-.js.map
