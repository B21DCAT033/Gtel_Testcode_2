import { U as t } from "./base-CzBFGKJV.js";
import { UmbLink as i } from "@umbraco-cms/backoffice/external/tiptap";
class p extends t {
  constructor() {
    super(...arguments), this.getTiptapExtensions = () => [i.configure({ openOnClick: !1 })];
  }
}
export {
  p as default
};
//# sourceMappingURL=link.tiptap-api-DYeSjxA_.js.map
