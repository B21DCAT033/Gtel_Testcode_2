import { a as s } from "./base-CzBFGKJV.js";
class a extends s {
  constructor() {
    super(...arguments), this.isActive = (e) => e?.can().redo() === !0, this.isDisabled = (e) => !this.isActive(e);
  }
  execute(e) {
    e?.chain().focus().redo().run();
  }
}
export {
  a as default
};
//# sourceMappingURL=redo.tiptap-toolbar-api-CqDHvMN2.js.map
