import { a as t } from "./base-CzBFGKJV.js";
class i extends t {
  execute(e) {
    e?.chain().focus().toggleStrike().run();
  }
}
export {
  i as default
};
//# sourceMappingURL=strike.tiptap-toolbar-api-BrWIUJiP.js.map
