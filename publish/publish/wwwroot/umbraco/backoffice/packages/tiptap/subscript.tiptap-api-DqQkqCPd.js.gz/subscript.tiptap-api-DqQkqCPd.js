import { U as t } from "./base-CzBFGKJV.js";
import { Subscript as s } from "@umbraco-cms/backoffice/external/tiptap";
class o extends t {
  constructor() {
    super(...arguments), this.getTiptapExtensions = () => [s];
  }
}
export {
  o as default
};
//# sourceMappingURL=subscript.tiptap-api-DqQkqCPd.js.map
