import { a as t } from "./base-CzBFGKJV.js";
class p extends t {
  execute(e) {
    e?.chain().focus().toggleSubscript().run();
  }
}
export {
  p as default
};
//# sourceMappingURL=subscript.tiptap-toolbar-api-CMmUknZS.js.map
