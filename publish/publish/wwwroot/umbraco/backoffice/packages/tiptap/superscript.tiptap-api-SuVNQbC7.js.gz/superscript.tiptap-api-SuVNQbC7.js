import { U as t } from "./base-CzBFGKJV.js";
import { Superscript as s } from "@umbraco-cms/backoffice/external/tiptap";
class o extends t {
  constructor() {
    super(...arguments), this.getTiptapExtensions = () => [s];
  }
}
export {
  o as default
};
//# sourceMappingURL=superscript.tiptap-api-SuVNQbC7.js.map
