import { a as p } from "./base-CzBFGKJV.js";
class o extends p {
  execute(e) {
    e?.chain().focus().toggleSuperscript().run();
  }
}
export {
  o as default
};
//# sourceMappingURL=superscript.tiptap-toolbar-api-Br-iJiXI.js.map
