import { a as t } from "./base-CzBFGKJV.js";
class r extends t {
  isActive(e) {
    return e?.isActive({ textAlign: "center" }) === !0;
  }
  execute(e) {
    e?.chain().focus().setTextAlign("center").run();
  }
}
export {
  r as default
};
//# sourceMappingURL=text-align-center.tiptap-toolbar-api-DD3kmVxK.js.map
