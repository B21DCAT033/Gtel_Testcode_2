import { a as e } from "./base-CzBFGKJV.js";
class a extends e {
  isActive(t) {
    return t?.isActive({ textAlign: "justify" }) === !0;
  }
  execute(t) {
    t?.chain().focus().setTextAlign("justify").run();
  }
}
export {
  a as default
};
//# sourceMappingURL=text-align-justify.tiptap-toolbar-api-IlIfFZM1.js.map
