import { a as t } from "./base-CzBFGKJV.js";
class s extends t {
  isActive(e) {
    return e?.isActive({ textAlign: "left" }) === !0;
  }
  execute(e) {
    e?.chain().focus().setTextAlign("left").run();
  }
}
export {
  s as default
};
//# sourceMappingURL=text-align-left.tiptap-toolbar-api-BhNCdgRO.js.map
