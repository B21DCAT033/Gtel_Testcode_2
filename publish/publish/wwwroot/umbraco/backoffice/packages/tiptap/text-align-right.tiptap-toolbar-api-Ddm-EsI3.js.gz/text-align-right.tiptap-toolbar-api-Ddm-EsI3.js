import { a as e } from "./base-CzBFGKJV.js";
class r extends e {
  isActive(t) {
    return t?.isActive({ textAlign: "right" }) === !0;
  }
  execute(t) {
    t?.chain().focus().setTextAlign("right").run();
  }
}
export {
  r as default
};
//# sourceMappingURL=text-align-right.tiptap-toolbar-api-Ddm-EsI3.js.map
