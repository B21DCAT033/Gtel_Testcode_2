import { UmbContextToken as o } from "@umbraco-cms/backoffice/context-api";
const T = new o(
  "UmbTiptapToolbarConfigurationContext"
);
export {
  T as U
};
//# sourceMappingURL=tiptap-toolbar-configuration.context-token-yqUn7jq0.js.map
