const e = "Umbraco.Core.Tiptap", t = [
  {
    name: "Tiptap Bundle",
    alias: "Umb.Bundle.tiptap",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  t as extensions,
  e as name
};
//# sourceMappingURL=umbraco-package.js.map
