import { U as t } from "./base-CzBFGKJV.js";
import { Underline as e } from "@umbraco-cms/backoffice/external/tiptap";
class p extends t {
  constructor() {
    super(...arguments), this.getTiptapExtensions = () => [e];
  }
}
export {
  p as default
};
//# sourceMappingURL=underline.tiptap-api-COh5SyGi.js.map
