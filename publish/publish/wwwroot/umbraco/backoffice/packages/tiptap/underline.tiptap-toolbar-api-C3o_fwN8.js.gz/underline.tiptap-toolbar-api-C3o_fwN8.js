import { a } from "./base-CzBFGKJV.js";
class t extends a {
  execute(e) {
    e?.chain().focus().toggleUnderline().run();
  }
}
export {
  t as default
};
//# sourceMappingURL=underline.tiptap-toolbar-api-C3o_fwN8.js.map
