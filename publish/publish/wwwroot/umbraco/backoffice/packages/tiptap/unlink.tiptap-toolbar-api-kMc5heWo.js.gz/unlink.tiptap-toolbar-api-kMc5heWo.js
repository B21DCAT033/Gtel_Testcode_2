import { a as s } from "./base-CzBFGKJV.js";
class a extends s {
  constructor() {
    super(...arguments), this.isActive = (i) => i?.isActive("umbLink") === !0, this.isDisabled = (i) => !this.isActive(i);
  }
  execute(i) {
    i?.chain().focus().unsetUmbLink().run();
  }
}
export {
  a as default
};
//# sourceMappingURL=unlink.tiptap-toolbar-api-kMc5heWo.js.map
