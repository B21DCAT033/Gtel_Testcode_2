export const UMB_TRANSLATION_MENU_ALIAS = 'Umb.Menu.Translation';
