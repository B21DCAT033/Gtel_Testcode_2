export const UMB_TRANSLATION_SECTION_ALIAS = 'Umb.Section.Translation';
