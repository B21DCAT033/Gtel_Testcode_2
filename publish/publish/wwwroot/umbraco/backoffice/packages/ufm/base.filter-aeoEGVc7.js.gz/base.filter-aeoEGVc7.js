class e {
  destroy() {
  }
}
export {
  e as U
};
//# sourceMappingURL=base.filter-aeoEGVc7.js.map
