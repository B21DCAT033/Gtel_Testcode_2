import { U as i } from "./base.filter-aeoEGVc7.js";
class l extends i {
  filter(e, a) {
    return typeof e != "string" || e ? e : a;
  }
}
export {
  l as api
};
//# sourceMappingURL=fallback.filter-DJfvJ7jO.js.map
