import { U as r } from "./base.filter-aeoEGVc7.js";
class t extends r {
  filter(e) {
    return e?.toLocaleLowerCase();
  }
}
export {
  t as api
};
//# sourceMappingURL=lowercase.filter-DqJ28aVu.js.map
