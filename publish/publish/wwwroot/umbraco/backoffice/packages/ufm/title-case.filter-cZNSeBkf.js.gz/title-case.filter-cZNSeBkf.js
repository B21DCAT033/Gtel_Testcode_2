import { U as s } from "./base.filter-aeoEGVc7.js";
class i extends s {
  filter(r) {
    return r?.replace(/\w\S*/g, (e) => e.charAt(0).toUpperCase() + e.substring(1).toLowerCase());
  }
}
export {
  i as api
};
//# sourceMappingURL=title-case.filter-cZNSeBkf.js.map
