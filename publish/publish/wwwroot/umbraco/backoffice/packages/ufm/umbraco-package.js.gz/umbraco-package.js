const e = [
  {
    name: "Umbraco Flavored Markdown Bundle",
    alias: "Umb.Bundle.UmbracoFlavoredMarkdown",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  e as extensions
};
//# sourceMappingURL=umbraco-package.js.map
