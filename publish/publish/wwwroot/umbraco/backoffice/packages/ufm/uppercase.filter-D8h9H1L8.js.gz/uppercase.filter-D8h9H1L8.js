import { U as r } from "./base.filter-aeoEGVc7.js";
class s extends r {
  filter(e) {
    return e?.toLocaleUpperCase();
  }
}
export {
  s as api
};
//# sourceMappingURL=uppercase.filter-D8h9H1L8.js.map
