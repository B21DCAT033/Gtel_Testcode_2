const e = "Umbraco.Core.UmbracoNews", o = [
  {
    name: "Umbraco News Bundle",
    alias: "Umb.Bundle.UmbracoNews",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  o as extensions,
  e as name
};
//# sourceMappingURL=umbraco-package.js.map
