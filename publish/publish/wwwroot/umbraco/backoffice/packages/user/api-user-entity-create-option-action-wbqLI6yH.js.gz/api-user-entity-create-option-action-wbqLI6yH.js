import { U as e } from "./user-entity-create-option-action-base-bLbcG6GU.js";
import { U as i } from "./constants-vWMF1ODp.js";
class a extends e {
  constructor(t, r) {
    super(t, {
      ...r,
      kind: i.API
    });
  }
}
export {
  a as UmbApiUserEntityCreateOptionAction,
  a as api
};
//# sourceMappingURL=api-user-entity-create-option-action-wbqLI6yH.js.map
