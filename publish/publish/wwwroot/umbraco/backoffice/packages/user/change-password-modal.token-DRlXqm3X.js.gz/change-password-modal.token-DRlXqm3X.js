import { UmbModalToken as o } from "@umbraco-cms/backoffice/modal";
const d = new o(
  "Umb.Modal.ChangePassword",
  {
    modal: {
      type: "dialog"
    }
  }
);
export {
  d as U
};
//# sourceMappingURL=change-password-modal.token-DRlXqm3X.js.map
