import { U as o } from "../change-password-modal.token-DRlXqm3X.js";
export {
  o as UMB_CHANGE_PASSWORD_MODAL
};
//# sourceMappingURL=index.js.map
