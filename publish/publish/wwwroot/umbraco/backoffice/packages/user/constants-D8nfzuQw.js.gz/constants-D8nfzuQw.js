const U = "Umb.Condition.CurrentUser.GroupId", _ = "Umb.Condition.CurrentUser.IsAdmin", I = "Umb.Repository.CurrentUser";
export {
  U,
  _ as a,
  I as b
};
//# sourceMappingURL=constants-D8nfzuQw.js.map
