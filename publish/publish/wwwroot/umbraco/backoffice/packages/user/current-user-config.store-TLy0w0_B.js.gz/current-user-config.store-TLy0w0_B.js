import { k as t } from "./constants-vWMF1ODp.js";
import { UmbStoreObjectBase as e } from "@umbraco-cms/backoffice/store";
class U extends e {
  constructor(r) {
    super(r, t.toString());
  }
}
export {
  U as UmbCurrentUserConfigStore,
  U as default
};
//# sourceMappingURL=current-user-config.store-TLy0w0_B.js.map
