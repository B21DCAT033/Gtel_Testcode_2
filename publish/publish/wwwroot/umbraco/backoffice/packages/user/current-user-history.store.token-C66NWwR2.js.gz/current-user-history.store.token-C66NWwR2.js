import { UmbContextToken as o } from "@umbraco-cms/backoffice/context-api";
const t = new o(
  "UmbCurrentUserHistoryStore"
);
export {
  t as U
};
//# sourceMappingURL=current-user-history.store.token-C66NWwR2.js.map
