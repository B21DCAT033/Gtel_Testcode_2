import { UmbModalToken as e } from "@umbraco-cms/backoffice/modal";
const r = new e("Umb.Modal.CurrentUserMfaDisableProvider", {
  modal: {
    type: "sidebar",
    size: "small"
  }
}), o = new e(
  "Umb.Modal.CurrentUserMfaEnableProvider",
  {
    modal: {
      type: "sidebar",
      size: "small"
    }
  }
);
export {
  o as U,
  r as a
};
//# sourceMappingURL=current-user-mfa-enable-modal.token-Daw2B3OI.js.map
