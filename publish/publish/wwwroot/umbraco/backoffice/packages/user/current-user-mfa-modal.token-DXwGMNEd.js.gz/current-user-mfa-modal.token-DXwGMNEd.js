import { UmbModalToken as e } from "@umbraco-cms/backoffice/modal";
const a = new e("Umb.Modal.CurrentUserMfa", {
  modal: {
    type: "sidebar",
    size: "small"
  }
});
export {
  a as U
};
//# sourceMappingURL=current-user-mfa-modal.token-DXwGMNEd.js.map
