import { UmbModalToken as e } from "@umbraco-cms/backoffice/modal";
const r = new e("Umb.Modal.CurrentUser", {
  modal: {
    type: "sidebar",
    size: "small"
  }
});
export {
  r as U
};
//# sourceMappingURL=current-user-modal.token-AO0ePjaF.js.map
