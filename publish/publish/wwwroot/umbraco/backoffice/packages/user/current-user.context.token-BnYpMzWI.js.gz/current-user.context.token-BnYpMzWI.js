import { UmbContextToken as t } from "@umbraco-cms/backoffice/context-api";
const o = new t("UmbCurrentUserContext");
export {
  o as U
};
//# sourceMappingURL=current-user.context.token-BnYpMzWI.js.map
