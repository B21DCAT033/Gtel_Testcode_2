import { UmbContextToken as e } from "@umbraco-cms/backoffice/context-api";
const r = new e("UmbCurrentUserStore");
export {
  r as U
};
//# sourceMappingURL=current-user.store.token-N-3TWEFa.js.map
