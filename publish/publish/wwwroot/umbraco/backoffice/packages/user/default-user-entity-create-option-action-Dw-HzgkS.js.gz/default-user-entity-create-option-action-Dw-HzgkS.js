import { U as r } from "./constants-vWMF1ODp.js";
import { U as s } from "./user-entity-create-option-action-base-bLbcG6GU.js";
class a extends s {
  constructor(t, e) {
    super(t, {
      ...e,
      kind: r.DEFAULT
    });
  }
}
export {
  a as UmbDefaultUserEntityCreateOptionAction,
  a as api
};
//# sourceMappingURL=default-user-entity-create-option-action-Dw-HzgkS.js.map
