import { UmbModalToken as e } from "@umbraco-cms/backoffice/modal";
const r = new e("Umb.Modal.CurrentUserExternalLogin", {
  modal: {
    type: "sidebar",
    size: "small"
  }
});
export {
  r as U
};
//# sourceMappingURL=external-login-modal.token-BIuwBNJv.js.map
