const e = Object.freeze({
  NAME: "Name",
  CREATE_DATE: "CreateDate",
  LAST_LOGIN_DATE: "LastLoginDate"
}), t = Object.freeze({
  ACTIVE: "Active",
  DISABLED: "Disabled",
  LOCKED_OUT: "LockedOut",
  INVITED: "Invited",
  INACTIVE: "Inactive"
});
export {
  e as U,
  t as a
};
//# sourceMappingURL=index-DtiCbM0v.js.map
