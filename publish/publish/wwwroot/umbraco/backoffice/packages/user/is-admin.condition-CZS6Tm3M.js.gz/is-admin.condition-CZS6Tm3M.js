import { i as o } from "./is-current-user-an-admin.function-BjNT31EQ.js";
import "./current-user.context.token-BnYpMzWI.js";
import "@umbraco-cms/backoffice/context-api";
import { UmbConditionBase as e } from "@umbraco-cms/backoffice/extension-registry";
class d extends e {
  constructor(r, t) {
    super(r, t), o(r).then((i) => this.permitted = i);
  }
}
export {
  d as UmbContentHasPropertiesWorkspaceCondition,
  d as api
};
//# sourceMappingURL=is-admin.condition-CZS6Tm3M.js.map
