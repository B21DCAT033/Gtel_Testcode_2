import { m as g } from "./manifests-DaLgmxce.js";
import "./constants-BCxOO27P.js";
import "@umbraco-cms/backoffice/external/backend-api";
import "@umbraco-cms/backoffice/id";
import "@umbraco-cms/backoffice/resources";
import "@umbraco-cms/backoffice/repository";
import "@umbraco-cms/backoffice/picker-input";
import "./input-entity-user-permission.element-CASDH22A.js";
import "./input-user-permission-verb.element-Cso_1zIo.js";
import "./constants-vWMF1ODp.js";
import "@umbraco-cms/backoffice/notification";
import "@umbraco-cms/backoffice/temporary-file";
import "@umbraco-cms/backoffice/localization-api";
import "@umbraco-cms/backoffice/external/rxjs";
export {
  g as manifests
};
//# sourceMappingURL=manifests.js.map
