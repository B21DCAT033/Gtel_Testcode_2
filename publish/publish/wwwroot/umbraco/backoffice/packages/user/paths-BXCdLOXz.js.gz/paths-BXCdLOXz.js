import { UMB_SECTION_PATH_PATTERN as e } from "@umbraco-cms/backoffice/section";
const t = "user-management";
e.generateAbsolute({
  sectionName: t
});
export {
  t as U
};
//# sourceMappingURL=paths-BXCdLOXz.js.map
