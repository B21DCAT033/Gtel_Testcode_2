import { UmbModalToken as e } from "@umbraco-cms/backoffice/modal";
const a = new e("Umb.Modal.User.Invite", {
  modal: {
    type: "dialog",
    size: "small"
  }
}), l = new e("Umb.Modal.User.Invite.Resend", {
  modal: {
    type: "dialog",
    size: "small"
  }
});
export {
  a as U,
  l as a
};
//# sourceMappingURL=resend-invite-to-user-modal.token-SCmTZoXA.js.map
