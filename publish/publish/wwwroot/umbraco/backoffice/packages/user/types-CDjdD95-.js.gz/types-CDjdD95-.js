import { UserStateModel as t } from "@umbraco-cms/backoffice/external/backend-api";
const o = t;
export {
  o as U
};
//# sourceMappingURL=types-CDjdD95-.js.map
