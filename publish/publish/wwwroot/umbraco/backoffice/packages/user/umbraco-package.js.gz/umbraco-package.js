const e = "Umbraco.Core.UserManagement", n = "0.0.1", a = [
  {
    name: "User Management Bundle",
    alias: "Umb.Bundle.UserManagement",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  a as extensions,
  e as name,
  n as version
};
//# sourceMappingURL=umbraco-package.js.map
