import { j as t } from "./constants-vWMF1ODp.js";
import { UmbStoreObjectBase as o } from "@umbraco-cms/backoffice/store";
class a extends o {
  constructor(r) {
    super(r, t.toString());
  }
}
export {
  a as UmbUserConfigStore,
  a as default
};
//# sourceMappingURL=user-config.store-BVn_p4Wq.js.map
