import { f as r } from "./constants-vWMF1ODp.js";
import { UmbDetailStoreBase as e } from "@umbraco-cms/backoffice/store";
class m extends e {
  /**
   * Creates an instance of UmbUserDetailStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbUserDetailStore
   */
  constructor(t) {
    super(t, r.toString());
  }
}
export {
  m as UmbUserDetailStore,
  m as default
};
//# sourceMappingURL=user-detail.store-DOudC3r_.js.map
