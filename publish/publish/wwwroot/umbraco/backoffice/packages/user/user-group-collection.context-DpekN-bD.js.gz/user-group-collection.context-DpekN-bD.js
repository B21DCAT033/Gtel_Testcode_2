import { i as t } from "./constants-BCxOO27P.js";
import { UmbDefaultCollectionContext as e } from "@umbraco-cms/backoffice/collection";
class l extends e {
  constructor(o) {
    super(o, t);
  }
}
export {
  l as UmbUserGroupCollectionContext,
  l as api
};
//# sourceMappingURL=user-group-collection.context-DpekN-bD.js.map
