import { t as r } from "./constants-BCxOO27P.js";
import { UmbDetailStoreBase as e } from "@umbraco-cms/backoffice/store";
class m extends e {
  /**
   * Creates an instance of UmbUserGroupDetailStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbUserGroupDetailStore
   */
  constructor(t) {
    super(t, r.toString());
  }
}
export {
  m as UmbUserGroupDetailStore,
  m as default
};
//# sourceMappingURL=user-group-detail.store-I3JOZ9Dc.js.map
