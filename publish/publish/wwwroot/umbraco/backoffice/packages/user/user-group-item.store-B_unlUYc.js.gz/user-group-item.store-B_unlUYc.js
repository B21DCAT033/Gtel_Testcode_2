import { p as t } from "./constants-BCxOO27P.js";
import { UmbItemStoreBase as e } from "@umbraco-cms/backoffice/store";
class p extends e {
  /**
   * Creates an instance of UmbUserGroupItemStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbUserGroupItemStore
   */
  constructor(r) {
    super(r, t.toString());
  }
}
export {
  p as UmbUserGroupItemStore,
  p as default
};
//# sourceMappingURL=user-group-item.store-B_unlUYc.js.map
