import { g as r } from "./constants-vWMF1ODp.js";
import { UmbItemStoreBase as e } from "@umbraco-cms/backoffice/store";
class a extends e {
  /**
   * Creates an instance of UmbUserItemStore.
   * @param {UmbControllerHost} host - The controller host for this controller to be appended to
   * @memberof UmbUserItemStore
   */
  constructor(t) {
    super(t, r.toString());
  }
}
export {
  a as UmbUserItemStore,
  a as default
};
//# sourceMappingURL=user-item.store-DpNQdNiC.js.map
