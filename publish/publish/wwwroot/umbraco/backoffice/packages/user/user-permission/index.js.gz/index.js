import { U as s } from "../input-entity-user-permission.element-CASDH22A.js";
import { U as i } from "../input-user-permission-verb.element-Cso_1zIo.js";
import { UmbModalToken as e } from "@umbraco-cms/backoffice/modal";
const r = new e("Umb.Modal.EntityUserPermissionSettings", {
  modal: {
    type: "sidebar"
  }
});
export {
  r as UMB_ENTITY_USER_PERMISSION_MODAL,
  s as UmbInputEntityUserPermissionElement,
  i as UmbUserPermissionVerbElement
};
//# sourceMappingURL=index.js.map
