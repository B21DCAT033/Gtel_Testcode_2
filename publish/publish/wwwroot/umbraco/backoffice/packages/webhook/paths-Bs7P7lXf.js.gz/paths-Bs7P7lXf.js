import { u as T } from "./paths-Cvoq37Uo.js";
import { UMB_SETTINGS_SECTION_PATHNAME as _ } from "@umbraco-cms/backoffice/settings";
import { UMB_WORKSPACE_PATH_PATTERN as O } from "@umbraco-cms/backoffice/workspace";
const e = O.generateAbsolute({
  sectionName: _,
  entityType: T
});
export {
  e as U
};
//# sourceMappingURL=paths-Bs7P7lXf.js.map
