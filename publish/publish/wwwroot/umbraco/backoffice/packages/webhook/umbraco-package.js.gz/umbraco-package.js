const e = "Umbraco.Core.Webhook", o = [
  {
    name: "Webhook Bundle",
    alias: "Umb.Bundle.Webhook",
    type: "bundle",
    js: () => import("./manifests.js")
  }
];
export {
  o as extensions,
  e as name
};
//# sourceMappingURL=umbraco-package.js.map
