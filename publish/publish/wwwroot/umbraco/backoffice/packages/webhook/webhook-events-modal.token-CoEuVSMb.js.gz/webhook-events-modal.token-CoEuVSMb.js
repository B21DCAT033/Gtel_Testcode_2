import { UmbModalToken as o } from "@umbraco-cms/backoffice/modal";
const m = new o(
  "Umb.Modal.Webhook.Events"
);
export {
  m as U
};
//# sourceMappingURL=webhook-events-modal.token-CoEuVSMb.js.map
